import preact from "@preact/preset-vite";
import { readFileSync } from "fs";
import { resolve } from "path";
import { defineConfig, lazyPlugins } from "vite-plus";
import macrosPlugin from "vite-plugin-babel-macros";
import { nodePolyfills } from "vite-plugin-node-polyfills";

const { version } = JSON.parse(readFileSync(new URL("./package.json", import.meta.url), "utf8"));

export default defineConfig({
  lint: {
    plugins: ["react", "unicorn", "typescript", "oxc"],
    env: {
      browser: true,
      node: true,
    },
    globals: {
      __MYST_EDITOR_VERSION__: "readonly",
    },
    rules: {
      "no-unused-vars": [
        "error",
        {
          argsIgnorePattern: "^_",
          varsIgnorePattern: "^_",
          caughtErrorsIgnorePattern: "^_",
        },
      ],
      "no-undef": "error",
      "prefer-template": "off",
      radix: "off",
      "react/rules-of-hooks": "warn",
      "react/immutability": "off",
      "react/exhaustive-deps": "off",
    },
    ignorePatterns: ["dist/**", "node_modules/**", ".github/**", "vite.config.js", "bin/**", "docs/**"],
  },
  test: {
    // Vitest v4 compatibility: preserve mock call history.
    // Remove after tests no longer rely on calls from setup or earlier tests.
    // https://viteplus.dev/guide/vitest-v5#remove-unneeded-compatibility-settings
    // https://vitest.dev/guide/migration/#clearmocks-is-enabled-by-default
    clearMocks: false,
    root: import.meta.dirname,
    environment: "happy-dom",
    // styled-components ships CommonJS that requires "react"; load its browser ESM build through Vite
    // instead, so preact/compat stands in for React as it does in the app. Without this the component
    // tests (GitPickerModal, MergeRequestModal, ...) fail to load.
    alias: { "styled-components": "styled-components/dist/styled-components.browser.esm.js" },
    server: { deps: { inline: ["styled-components"] } },
    include: ["tests/unit/**/*.{test.js,test.ts}"],
    globals: false,
  },
  fmt: {
    printWidth: 150,
    sortPackageJson: false,
    ignorePatterns: [
      "tests/fixtures/cheatsheet.md",
      "src/markdown/BENCHMARK.md",
      "tests/fixtures/parser-compare.md",
      "src/fixtures/jb2-showcase.md",
      "tests/fixtures/jb2-showcase.reference.html",
    ],
  },
  base: "",
  root: "src",
  plugins: lazyPlugins(() => [
    macrosPlugin(),
    preact(),
    nodePolyfills({
      include: ["path", "punycode"],
    }),
  ]),
  build: {
    minify: false,
    outDir: "../dist",
    emptyOutDir: true,
    sourcemap: false,
    lib: {
      entry: {
        options: resolve(import.meta.dirname, "src/index.html"),
        git: resolve(import.meta.dirname, "src/myst-git/git.html"),
      },
      formats: ["es"],
    },
    rollupOptions: {
      output: {
        minifyInternalExports: false,
        entryFileNames: "[name].js",
        chunkFileNames: "[name].js",
        assetFileNames: (assetInfo) => {
          if (assetInfo.name?.endsWith(".css")) {
            return "MystEditor.css";
          }
          return "assets/[name].[ext]";
        },
        manualChunks: (id) => {
          if (id.includes("yamlLSPWorker")) {
            return "yamlLSPWorker";
          }
          if (id.includes("index.html")) return "options";
          if (id.includes("git.html")) return "git";

          return "MystEditor";
        },
      },
    },
  },
  define: {
    "process.env": {},
    // Single source of truth for the version shown in the topbar and exported as `version`.
    __MYST_EDITOR_VERSION__: JSON.stringify(version),
  },
  resolve: {
    alias: [
      {
        find: "vscode-json-languageservice/lib/umd",
        replacement: "vscode-json-languageservice/lib/esm",
      },
    ],
  },
});
