# Working on myst-editor

The toolchain is [Vite+](https://viteplus.dev/guide/) (`vp`): Vite, Vitest, Oxlint and Oxfmt behind one CLI, configured in
`vite.config.js` (`lint`, `fmt` and `test` blocks next to the build settings). Packages are managed with **npm**, as CI
does (`npm ci`); there is no need for a global `vp`, the npm scripts call the local one.

Node: `^22.18.0 || ^24.11.0 || >=26.0.0` (what Vite+ supports).

## Commands

| Task                      | Command                                                                                     |
| ------------------------- | ------------------------------------------------------------------------------------------- |
| Install                   | `npm ci`                                                                                    |
| Demo / dev server         | `npm run dev` (plain editor), `npm run dev:git` (git editor)                                |
| Build                     | `npm run build` (writes `dist/`)                                                            |
| Format / check formatting | `npm run format` / `npm run check-format`                                                   |
| Lint                      | `npm run lint`                                                                              |
| Type check                | `npm run typecheck`                                                                         |
| Unit tests                | `npm run test:unit` (Vitest, `tests/unit/`)                                                 |
| End-to-end tests          | `npm run test` (Playwright; needs the preview and the collaboration server, see the README) |

Before pushing, run `check-format`, `lint`, `typecheck` and `test:unit`; CI runs all but the type check.

## Conventions

- Unit tests import from `vite-plus/test`, not `vitest`.
- Versions: Y for features, Z for fixes. `package.json` and `package-lock.json` must match, and every version needs a
  `## [x.y.z]` entry in `CHANGELOG.md`.
- The files in `fmt.ignorePatterns` (and `.prettierignore`) are MyST fixtures whose exact layout is what the parser is
  tested on; never reformat them.
