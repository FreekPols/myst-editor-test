# MyST Editor Fork

> **Fork Notice:** This project is a modified fork of the original [MyST Editor](https://github.com/antmicro/myst-editor) created by [Antmicro](https://antmicro.com).
>
> **Key changes in this fork include:**
>
> - Updated dependencies to ensure compatibility with the latest versions of libraries and frameworks.
> - Added a gitlab-ci configuration for releasing build files.

---

## Original Documentation: MyST Editor

Copyright (c) 2022-2025 [Antmicro](https://antmicro.com)

![MyST Editor logo](./assets/MyST-Editor--GH-readme.png)

This is a Markdown web editor that uses the [MyST Markdown](https://mystmd.org/) flavor, rendered with the [mystmd](https://mystmd.org/) toolchain — the same engine behind Jupyter Book v2.
It is implemented as a [Preact](https://preactjs.com/) component.
The intended way to use it is by embedding the editor in various websites/webapps.
It is written with collaborative editing in mind.

## User Manual

For an overview of the editor usage, see the [User Manual](https://antmicro.github.io/myst-editor/docs/).

## Demo

A demo of the editor is available [here](https://antmicro.github.io/myst-editor/).

## Main features

### Live preview and dual pane sync

Changes in the text editor are immediately reflected in the preview.
The editor also keeps track of where your cursor is and highlight and scroll the preview based on what you are editing.

![Live Preview Demo](./assets/dual-pane.gif)

### Inline Markdown rendering

You can toggle a mode where the Markdown will be rendered right in the editor.

![Inline Mode Demo](./assets/inline.gif)

### Collaborative editing

You can work on a document with multiple people at the same time.

![Collaboration Demo](./assets/collab.gif)

### Comments

The editor has a comments feature, allowing you to add text that will not appear in the preview.

![Comments Demo](./assets/comments.gif)

### Suggestions

You can suggest changes that others can accept or reject later.
Suggestions are based on the [CriticMarkup](https://fletcher.github.io/MultiMarkdown-6/syntax/critic.html) syntax.

Suggestions require `collaboration.enabled`. With collaboration off the toggle is hidden and
CriticMarkup stays literal text in both the editor and the preview, as Jupyter Book renders it - use
the Diff view to review your own changes instead.

![Suggestions Demo](./assets/suggestions.gif)

### Diff

You can use the diff view to see exactly what changes have been made to the document as compared to the original state.
There is also an option to discard all the changes.

![Diff Demo](./assets/diff.gif)

### Exporting the document

Using the buttons in the top-left, you can copy the rendered HTML or export the document to a PDF file.

![Copy Demo](./assets/copy.gif)

### User settings

Users can customize the editor with the settings dropdown.
In the example below, we can see settings that allow for scrolling past the last line of the editor and a Vim emulation mode.

![Settings Demo](./assets/settings.gif)

### Custom transforms

The editor allows you to extend the standard Markdown syntax with custom transforms.
You can specify regular expressions that turn some input to custom HTML output.
This is useful for implementing functionalities such as issue links, for example (as showcased in the demo):

```js
const transforms = [
  {
    target: /[0-9a-z\-]+\/[0-9a-z\-]+#\d{1,10}/g,
    transform: (match) => {
      const [repo, issueId] = match.split("#");
      return `<a href="https://github.com/${repo}/issues/${issueId}">${match}</a>`;
    },
  },
];
```

Then provide the transforms array as the `transforms` option for the editor.

For more examples, see the `exampleTransforms` object in [the demo HTML](src/index.html).

## Usage

### Building the component

```bash
npm i && npm run build
```

The toolchain is [Vite+](https://viteplus.dev/guide/), which needs Node `^22.18.0`, `^24.11.0` or `>=26.0.0`.
Formatting, linting and unit tests run with `npm run format` (or `check-format`), `npm run lint` and `npm run test:unit`;
their settings live in `vite.config.js`. The Prettier settings in `package.json` and `.prettierignore` produce the same
result, for editors that format on save with Prettier.

### Using as a library

You can embed this editor on another website.

After building, you should see a `dist` folder with `MystEditor.css` and `MystEditor.js` in it.
Put those files alongside your HTML.

Add a link to the CSS file into your HTML:

```html
<link rel="stylesheet" href="MystEditor.css" />
```

You need an HTML element that MyST Editor will attach to:

```html
<div id="myst"></div>
```

Add the following JavaScript as a module (of course add any options as needed):

```js
import MystEditor from "MystEditor.js";
MystEditor({/* options */}, document.getElementById("myst"));
```

And voilà!

### Developing / running the demo

There is a demo available for the editor with some example Markdown and templates, also useful for development of the component itself.

To run it locally, use:

```bash
npm run dev
```

Your terminal will display what URL to open to see the demo.
You can edit the source files in `src/` to modify the behavior of the component, with hot reload, thanks to Vite.

An analogous demo deployed with GH actions from latest main should be deployed at <https://antmicro.github.io/myst-editor/>

### Collaboration server

The example server is located in the `bin` directory. To run it use:

```bash
cd bin
npm i && npm run server
```

You can change the port it runs on by setting a `PORT` environment variable.

### Running tests

The Playwright test suite (including the `MystEditorGit` tests) runs against the **built and previewed** app, so it needs the app preview and the collaboration server running alongside the test runner. Use three terminals.

> [!IMPORTANT]
> Run the tests with a Node version Vite+ supports: `^22.18.0`, `^24.11.0` or `>=26.0.0`.

First-time setup (once):

```bash
npm i
npx playwright install
```

Terminal 1:

```bash
npm run build && npm run preview
```

Terminal 2:

```bash
cd bin
npm i
YPERSISTENCE=/tmp/myst-yjs-db PORT=4455 node server.js
```

Terminal 3 (with a supported Node, e.g. via `npx -y node@24`):

```bash
npx -y node@24 /usr/bin/npm run test
```

To run a single test (or a subset), pass a `-g` name filter through to Playwright:

```bash
npx -y node@24 node_modules/@playwright/test/cli.js test -c tests/playwright.config.js -g "Commits changes"
```

> [!NOTE]
> Without `YPERSISTENCE`, some git-wrapper tests may fail because change-status tracking is disabled on the server.

### Customizing the CSS

Note that MyST Editor uses the Shadow DOM to encapsulate the styles from the rest of the page.
In order to customize the look and feel, you can change the CSS variables
listed in [MystStyles.js](./src/styles/MystStyles.js) with the `additionalStyles` option
of the `MystEditor` function.
The editor exports an example `darkTheme` stylesheet.

### MystEditor options

Here are the options you can pass to the MystEditor function:

- `id` _(default: `crypto.randomUUID()`)_ - this changes where the global state of an editor is stored, it is used when accessing `window.myst_editor` and is part of the CodeMirror parent DOM id
- `name` _(default: "myst_editor_textarea")_ - this will change the name of the textarea element which contains your markdown. Useful if you want the editor to be part of an HTML `form`.
- `additionalStyles` _(`CSSStylesheet` | `CSSStylesheet[]`)_ - extra CSS stylesheets to customize the component
- `title` - the document title displayed in the topbar. You can include Markdown links in here.
- `mode` _(default: "Both", possibleValues: "Source" | "Preview" | "Both" | "Diff" | "Resolved" | "Outline" | "Inline")_ - changes what is visible when you open the editor. By default, you will see a split view with the text editor and preview.
- `initialText` _(default: "")_ - initial Markdown text
- `includeButtons` _(default: defaultButtons)_ - An array of button definitions. A button definition is an object which has an `action: () => void` and either `icon` or `text`. As an example, a button could be defined as `{ text: "Button title", action: () => alert('clicked!') }` Buttons for collaboration-only features (currently `suggest-mode`) are dropped when `collaboration.enabled` is false, even if listed here.
  The toolbar includes a `code-cell` button, which inserts a Jupyter Book `{code-cell}` directive. Its dialog asks what the cell is for rather than which tags it needs, and offers to add the page's `kernelspec` when it is missing — without one a markdown page's cells never run, and the build reports success with every figure blank. Pass an `includeButtons` list without `predefinedButtons.codeCell` to leave it out.
- `topbar` _(default: true)_ - whether to show the topbar
- `collaboration` - options related to live collaboration:
  - `enabled` _(default: false)_
  - `commentsEnabled` _(default: false)_ - enable basic comment functionality,
  - `resolvingCommentsEnabled` _(default: false)_ - enable resolving comments,
  - `wsUrl` _(example: ws://example:4444)_ - URL of the websocket server
  - `username`
  - `room` _(default: "0")_ - name of the room to join, users will see others in the same room
  - `color` _(default: "#ff0000")_ - color of the cursor seen by other users
  - `mode` _(default: "websocket")_ - determines how the document will be synced. You can set it to `"local"` for testing without a server (using BroadcastChannel API)
- `spellcheckOpts` - Configuration for the spellchecker. If the value is _null_ or _false_ then the spellchecker will be disabled.
  - `dict` _(default: "en_US")_ - Name of the desired dictionary. For an example, see `public/dictionaries/en_US`.
  - `dictionaryPath` _(default: "/dictionaries")_ - Path to a folder with dictionaries. For an example, see `public/dictionaries/`.
- `customRoles` - custom MyST roles. See the `exampleCustomRoles` object in [the demo HTML](./src/index.html) for examples.
- `transforms` - [custom transforms](#custom-transforms)
- `customDirectives` - custom MyST directives. See the `exampleCustomDirectives` object in [the demo HTML](./src/index.html) for examples.
- `getAvatar` _(default: (login) => `https://secure.gravatar.com/avatar/${login}?s=30&d=identicon`)_ - a function that returns the avatar for a given username
- `getUserUrl` _(default: (login) => `#`)_ - a function that returns the URL to the web page with the user's profile
  It is used when an avatar is clicked.
- `backslashLineBreak` _(default: true)_ - treat a trailing `\` as a line break even at the end of a paragraph/block, where CommonMark would render it literally. (Prior to v1.0.0 this option was documented but had no effect.)
- `hideUsernameDelay` _(default: 5000)_ - milliseconds of inactivity after which the username attached to a remote cursor will be hidden
- `showVersion` _(default: false)_ - show the editor's own version as a superscript beside the title. `mountGitEditor` turns this on for a real git backend, where knowing which build is deployed is worth the few pixels; the version is also exported as `version` if you would rather place it yourself.
- `serverName` _(default: "GitLab")_ - MystEditorGit only: what to call the git server when a fetch runs long enough that the editor names who is being waited on.
- `branding` _(default: COMBINE)_ - MystEditorGit and `mountGitEditor` only: the logos shown above the page index (`logo`), in the toolbar while the index is collapsed (`mark`), and small in the index's bottom-left corner (`secondary`); the loading screen shows `logo` and `secondary` too. Each logo is `{ light, dark, alt, href? }`, and the variant matching the theme is shown. Pass `false` for no branding, or an object of your own to replace it.
- `assets` _(default: null)_ - lets the figure dialog, and images pasted or dropped into the source, take an image file and hold it for upload. MystEditorGit supplies it when its backend can commit binary files; without it, figures take a URL only. See [Images](#images) below.
- `statusBar` _(default: true)_ - show a status bar along the bottom with the cursor position and the word count. MystEditorGit adds the branch, the commit (both open their pickers when clicked) and the number of pages with uncommitted changes, and then no longer repeats the branch and commit under the title.
- `syncScroll` _(default: true)_ - synchronize scrolling of the editor and preview in `Dual Pane` view mode, and jump the editor to the source of whatever is clicked in the preview.
  - > NOTE: This only works if you set a height limit on the editor parent element.
- `unfoldedHeadings` _(`number?`)_ - fold all but the given number of top level syntax nodes on startup.
  If the option is not set, nothing will be folded by default.
- `mapUrl` _(default: (tag, url) => url)_ - function used to map `href` and `src` attributes. Tag is the name of the HTML element and url is the source url you can transform.
- `yamlSchema` - must be an absoulte URL. If provided, a language server will launch in the background to provide tooltips, diagnostics and autocompletions based on the schema in YAML code blocks.
- `onPreviewClick` _(`(ev: MouseEvent) => boolean`)_ - callback for when the preview is clicked, if the builtin click actions should be skipped, it should return `true`
- `onDiscardChanges` _(`() => void`)_ - callback for when changes are discarded from the diff view mode
- `mermaidTheme` _(default: "neutral")_ - theme to use for Mermaid.js diagrams
- `cmDarkTheme` _(default: false)_ - whether to use a dark theme for CodeMirror
- `onExit` _(`() => void | false`)_ - If provided an exit button will be shown. The button will execute the provided hook.

### Accessibility

The editor chrome is checked against WCAG 2.2 AA with axe-core, in light and dark mode, as part of the end-to-end tests. Every toolbar control has a name, keyboard focus is shown with a ring, view modes and toggles expose their state (`aria-pressed`, `aria-expanded`), the "More" views and the settings open from the keyboard, the page index is a list of buttons with the open page marked as `aria-current`, and the layout has landmarks (`header`, `nav`, `main`, `footer`). Colours used for text meet 4.5:1, including the coloured admonition headers in the preview.

Also see [the demo HTML](./src/index.html) for an example on how you can set these options.
Using `window.myst_editor` or the return value of the `MystEditor` function, you can modify these options at runtime.

## Myst Editor for Git

There is an additonal wrapper around the base editor that is meant to be easy to integrate with Git version control.
The wrapper is provided as a component located in [src/myst-git/MystEditorGit.jsx](src/myst-git/MystEditorGit.jsx).
You can import it from a build of Myst Editor with the following syntax:

```js
import { MystEditorGit } from "MystEditor.js";
```

There is an example page that makes use of this wrapper in [src/myst-git/git.html](src/myst-git/git.html).
The example page can be accessed while the Editor is running in development mode via the following URL: `/myst-git/git.html`.

### Pages and chapters

With a YAML table of contents (`myst.yml`, a `toc.yml` it `extends`, or Jupyter Book v1's `_toc.yml`), the page index shows the book's chapters as folders that open and close; a chapter opens by itself while it holds the open page. The buttons above the index add pages and chapters, and entries can be rearranged.

- **Add page** asks for a name (which also becomes the page's first heading) and a chapter. The file goes in the chapter's folder: `Quick start` in a chapter whose pages live in `week1/` becomes `week1/quick-start.md`. A new chapter can be made from the same dialog.
- **Add chapter** creates a folder named after the title, with an `index.md` as the chapter's first page, and adds it to the end of the table of contents.
- **Moving** an entry is done by dragging it, or from the keyboard with Alt + ↑/↓ (past its neighbour), Alt + → (into the chapter above) and Alt + ← (out of its chapter). By default only the table of contents changes. When the files could follow, the dialog offers to move them too:
  - a page that lives outside the folder of the chapter it goes into (or, at the top level, outside the docs root) can move into that folder;
  - a chapter can take its whole folder, with everything in it (images, data, subfolders), into the folder of the chapter it goes into. This is only offered for a folder that is the chapter's own: if a page listed elsewhere in the table of contents lives in it, moving the folder would drag that page along, so it is not offered.

  When files move, every link and image that points at them is updated: in the moved pages, in the rest of the book's Markdown pages, and in the table of contents wherever a moved file is listed.

Each of these is a commit of its own, made straight away on top of the branch: the table of contents and the files change together. They need the latest commit of the branch (a table of contents from an older commit would undo later changes), and are not available while the commit dialog is open. Edits and comments that are not committed yet are carried over to the new commit: the open page's, and with a collaboration server every changed page's, whoever made them. Each changed page is locked while the commit is made, then its work is put into the same page of the new commit (at its new path if it moved, with its links updated like the committed text), and anyone editing it follows along. The table of contents is edited in place, so its comments, blank lines and other settings stay as they were; a chapter is written in the dialect of the file (`children` for mystmd, `sections` or a new part for Jupyter Book v1).

Moving a chapter's folder needs the backend's `listFiles(commit, dir)`, which lists every file under a folder; the bundled backends have it. A `move` document in `commitChanges` without `text` moves the file as it is, binary files included.

### Links between pages

In the git editor's preview, a link to another page of the book (`[next](chapter2/intro.md#setup)`) opens that page in the editor, at the heading when it has an anchor, instead of following the link to a page the hosting site does not have. Links are resolved as MyST resolves them: against the page they are in, `/…` against the project root, and with or without the page's extension. A link to a page that is not in the open version says so; links to other sites open as usual.

### Images

In the git editor, the figure dialog can take an image from the computer, and pasting or dropping an image into the source opens the same dialog with it. The image is saved under `images/` next to the page by default (the path is editable) and the figure refers to it relative to the page, as MyST does. Until the next commit the image is held in the open tab only, like unsaved text: the preview shows it straight away, the status bar counts it, and leaving the tab or switching branch warns first. The commit then adds it in the same commit as the page that shows it; the commit dialog lists each image and ticks the ones a changed page uses.

Photos wider than 2000 px, and JPEG or WebP files over 1 MB, are offered a smaller copy; the limit is 10 MB per image. A name that is already taken in the repository is refused with a free alternative suggested, so nothing is overwritten.

Image references in the preview are resolved against the page that uses them (and `/…` against the folder holding `myst.yml`), and images already in the repository are cached per commit rather than fetched on every re-render.

With a collaboration server, an image uploaded by one person is not visible to the others until it is committed.

Someone else may commit an image under the same name before you commit yours. When the commit dialog opens it checks every waiting image against the branch as it is now; one whose name has been taken in the meantime is listed unticked, with a warning, and ticking it replaces the other image. Nothing is replaced without that tick, on GitLab and GitHub alike (GitLab refuses to overwrite by itself; GitHub would overwrite silently, so its backend checks again just before committing).

A backend opts in by setting `supportsAssets: true`, accepting a third argument to `commitChanges(message, documents, assets)` (each asset is `{ path, type, base64, replace? }`, created as a new file unless `replace` is set), and providing `fileExists(commit, path)`. All bundled backends (GitLab, GitHub and the stub) do.

### Add-ons

`mountGitEditor` takes `plugins`: add-ons that change what the git editor offers without patching it. Deployment-specific
features, such as a course's rules about who works on which branch, belong in an add-on that the deployment ships next to
the editor and passes in its own configuration:

```js
import { mountGitEditor } from "./MystEditor.js";
import { branchAccess } from "./addons/branch-access.js";

mountGitEditor(document.getElementById("myst"), { backend: "gitlab" /* , ... */, plugins: [branchAccess({ file: "course-access.csv" })] });
```

A plugin is a plain object with a `name`, `apiVersion: 1` and either or both of two hooks:

- `wrapBackend(backend, ctx)` runs once after login, before the editor mounts. It returns the backend to use, usually the
  one it was given with some methods replaced. Every branch the editor lists, searches, opens or creates goes through
  `initialBranches`, `getBranches(page)`, `searchBranches(query)` and `createBranch(name, ref)`, plus the optional
  `canOpenBranch(name)` that the editor asks before any switch. `ctx` offers:
  - `backend`: `"gitlab"`, `"github"` or `"stub"`;
  - `projectId` and `defaultBranch`;
  - `user()`: the signed-in user, with `accessLevel`, their role in the project on GitLab's scale (30 Developer, 40 Maintainer, 50 Owner;
    GitHub's write, maintain and admin map to 30, 40 and 50);
  - `api(path, init)`: the editor's authorized fetch for the forge's API, so the add-on never holds the token (`null` for the stub);
  - `fail(message)`: stop, and show `message` instead of the editor.

  An error the add-on throws stops the editor the same way, naming the add-on.

- `setup({ state, git })` runs once the editor is up, with the same objects an `onReady` handler gets: for example
  `git.addStatusItem(item)` for the status bar (returns a remover), `git.notify(text)` for a toast,
  `git.openBranchPicker()` or `git.switchBranch(name)`. A failing `setup` is reported and skipped; the editor carries on.

Add-ons steer the editor; they are not a security boundary. Whatever one hides is still reachable through GitLab with
the same account. The demo page shows a small one: `/myst-git/git.html?only_branches=main,feature`. With the stub
backend, `stubUser: { username, accessLevel }` (or `?user=jdoe` on the demo page) sets who the demo user is, and
`?protected=main` marks branches as protected, as the branch picker shows them for GitLab.

### Running the stub git mode locally

The git demo runs against an in-memory stub git backend ([src/myst-git/stubGitBackend.js](src/myst-git/stubGitBackend.js)), so you can try the
branch/commit/file navigation and the commit flow without a real git server. The demo repository state (branches, commits and file
snapshots) comes from [src/myst-git/demo-data.js](src/myst-git/demo-data.js). Any commits you make are kept in `localStorage`, so clearing
site data resets the "repo".

Start the dev server and open the git demo:

```bash
npm run dev
# then open /myst-git/git.html on the URL Vite prints (typically http://localhost:5173)
```

By default collaboration runs in local mode, so no collaboration server is required. To test real-time collaboration against a local server:

```
/myst-git/git.html?collab_server=ws://localhost:4455&username=alice
```

### Running against a real GitLab (OAuth)

The git demo can also talk to a real GitLab instance ([src/myst-git/gitlabBackend.js](src/myst-git/gitlabBackend.js)) using an
in-browser OAuth 2.0 Authorization Code + PKCE flow ([src/myst-git/gitlabAuth.js](src/myst-git/gitlabAuth.js)) — no client secret,
no backend. Tokens are kept in memory only.

1. On the GitLab instance, register an OAuth application under **(User or Group) → Settings → Applications**: leave **Confidential
   unchecked** (public client), set the **Redirect URI** to your app URL (e.g. `http://localhost:5173/myst-git/git.html` for
   `npm run dev:git`), and grant the **`api`** scope (required for creating commits; use `read_api read_repository` for read-only).
2. Copy [.env.example](.env.example) to `.env` and fill in `VITE_GITLAB_URL`, `VITE_GITLAB_CLIENT_ID`, `VITE_GITLAB_REDIRECT_URI` and
   `VITE_GITLAB_PROJECT_ID`.
3. Run `npm run dev:git` and open `/myst-git/git.html?git_backend=gitlab`, then log in with GitLab.

> Note: because token exchange and API calls happen in the browser, the GitLab instance must allow CORS from your origin on
> `/oauth/token` and `/api/v4`. If it does not, a small backend proxy for the token exchange is required.

**Consuming as a library (runtime config):** when embedding the editor elsewhere via `mountGitEditor` (exported from `MystEditor.js`),
you can pass the OAuth config at runtime instead of baking `VITE_GITLAB_*` into the build — so one pre-built bundle works across
deployments:

```js
import { mountGitEditor } from "./MystEditor.js";
mountGitEditor(document.getElementById("myst"), {
  id: "editor",
  backend: "gitlab", // or rely on ?git_backend=gitlab
  gitlabUrl: "https://gitlab.tudelft.nl",
  clientId: "<oauth-application-id>",
  redirectUri: "https://your-app.example.com/editor/",
  gitlabProjectId: "group%2Fproject",
});
```

Each omitted value falls back to the corresponding `VITE_GITLAB_*` build env. Call `mountGitEditor` on every page load (including the
OAuth redirect-back load), since the auth state resets on the redirect.

**Signing in.** With no session yet, the editor sends the browser straight to GitLab: opening the editor is itself the request to use
it, so a "Log in with GitLab" button in between is one click that asks nothing the user has not already answered. The button is still
what appears if an automatic attempt comes back without a session, so a denied or broken login cannot become a redirect loop.

- `autoLogin` _(default: true)_ - set `false` to require the click instead.
- `onLoginRequired(login)` - replaces both: your own UI, called with a `login()` you invoke when ready.
- `onLoginError(err, login)` - replaces the built-in failure screen.

### Running against GitHub

The git editor also works on a GitHub repository ([src/myst-git/githubBackend.js](src/myst-git/githubBackend.js)), with `backend:
"github"` and `githubRepo: "owner/name"`. It does everything it does on GitLab; the wording follows GitHub ("pull request", "PR #12"),
and the merge request button opens GitHub's compare page.

There are two ways to sign in. GitHub's own OAuth cannot be completed by a page alone: its token endpoint wants the app's client secret
and sends no CORS headers (GitHub's support for browser-only sign-in is on its roadmap, currently paused).

- **A fine-grained personal access token** (the default when no relay is configured). The editor shows a sign-in form; the user makes a
  token on GitHub for this one repository with **Contents: Read and write** (and **Pull requests: Read-only**), pastes it, and the editor
  checks that it can write there before accepting it. The form is an ordinary login form - the repository as user name, the token as
  password - so password managers save it and fill it in next time. The token lasts until the expiry date chosen when making it.
- **A GitHub App and a token relay** (`clientId` and `tokenUrl` set). One-click sign-in like GitLab's. The relay is a few dozen lines that
  add the app's secret to the code exchange; see [tools/github-token-relay](tools/github-token-relay/README.md) for setting up the app and
  deploying it (a free Cloudflare Worker is enough). `auth: "token"` keeps the token form even when a relay is configured.

```js
mountGitEditor(document.getElementById("myst"), {
  id: "editor",
  backend: "github",
  githubRepo: "jdoe/thesis",
  // With a GitHub App and relay; leave both out to sign in with a token instead.
  clientId: "Iv23li...",
  tokenUrl: "https://myst-editor-github-relay.example.workers.dev",
  // GitHub Enterprise Server: its address; the API addresses follow from it (or set githubApiUrl).
  // githubUrl: "https://github.example.edu",
});
```

The demo page takes the same with URL parameters: `/myst-git/git.html?git_backend=github&github_repo=owner/name` (add
`&client_id=…&token_url=…` for the relay). `?flavor=github` shows the stub with GitHub's wording, without an account.

**What a sign-in can reach.** This differs between the forges, and matters most when the editor is hosted by someone you do not know:

| Sign-in                    | Reaches                                                                                                                                                                      |
| -------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| GitLab OAuth (`api` scope) | Everything the user can reach on that GitLab, as the user, while the token lives (about 2 hours, refreshed). GitLab has no narrower scope that still lets the editor commit. |
| GitHub App                 | Only the repositories the app is installed on, and only with the app's permissions (here: contents, pull requests, metadata).                                                |
| GitHub fine-grained token  | Only the repositories and permissions the user picked when making it; the host cannot widen it.                                                                              |

All three are kept in the tab's memory only, and a host can only use GitLab's or a GitHub App's sign-in through an application it
registered itself, whose name and permissions the consent screen shows.

## License

[Apache 2.0](./LICENSE)
