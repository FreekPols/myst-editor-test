import styled from "styled-components";
import { EditorView } from "codemirror";
import { useContext } from "preact/hooks";
import { MystState } from "../mystState";
import { useComputed, useSignal, useSignalEffect } from "@preact/signals";
import { pageTitle } from "./pageTitle.js";

const List = styled.div`
  width: 100%;

  ul {
    list-style: none;
    padding-left: 0;
    margin: 0;
    display: flex;
    flex-direction: column;
    gap: 2px;
  }

  .item-wrapper {
    position: relative;
    border-radius: 6px;
    width: 100%;

    &.drop-before {
      box-shadow: inset 0 2px 0 0 var(--accent-dark);
    }
    &.drop-after {
      box-shadow: inset 0 -2px 0 0 var(--accent-dark);
    }
    &.drop-inside {
      background-color: color-mix(in srgb, var(--accent-dark) 14%, transparent);
      outline: 2px dashed var(--accent-dark);
      outline-offset: -2px;
    }
  }

  .folder-header {
    display: flex;
    align-items: center;
    width: 100%;
    position: relative;
    border-radius: 6px;
    padding-right: 6px;

    &:hover {
      background-color: var(--button-bg-hover);

      .drag-handle {
        opacity: 0.5;
      }
    }
  }

  .toggle-button {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 22px;
    height: 22px;
    padding: 0;
    margin-left: 4px;
    border: 0;
    border-radius: 4px;
    background: transparent;
    cursor: pointer;
    flex: none;
    color: var(--gray-700);

    &:hover {
      background-color: color-mix(in srgb, var(--accent-dark) 15%, transparent);
      color: var(--accent-dark);
    }
  }

  .folder-icon {
    flex: none;
    margin-right: 6px;
    color: var(--gray-700);
    opacity: 0.8;
  }

  .drag-handle {
    opacity: 0;
    flex: none;
    cursor: grab;
    margin-left: auto;
    color: var(--gray-600);
    transition: opacity 120ms ease;
  }

  /* A page entry: its title, with the file name underneath for the author who thinks in files. */
  .file {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    width: 100%;
    min-width: 0;
    position: relative;
    padding: 6px 26px 6px 8px;
    border: 0;
    border-radius: 6px;
    background: transparent;
    font: inherit;
    text-align: left;
    cursor: pointer;
    box-sizing: border-box;

    &:hover {
      background-color: var(--button-bg-hover);

      .drag-handle {
        opacity: 0.5;
      }
    }

    .file-title {
      font-size: 15px;
      line-height: 1.3;
      overflow-wrap: anywhere;
    }

    .file-path {
      font-family: var(--font-mono);
      font-size: 11.5px;
      color: var(--gray-800);
      overflow-wrap: anywhere;
    }

    /* The current page is marked by a bar and a tint as well as by colour. */
    &[aria-current="page"] {
      background-color: color-mix(in srgb, var(--accent-dark) 11%, transparent);
      box-shadow: inset 3px 0 0 var(--accent-dark);

      .file-title {
        color: var(--accent-dark);
        font-weight: 600;
      }
    }

    .unsaved {
      position: absolute;
      right: 10px;
      top: 12px;
      width: 8px;
      height: 8px;
      border-radius: 50%;
      background-color: var(--unsaved);
    }
  }

  .folder-title-only {
    display: flex;
    align-items: center;
    flex: 1;
    min-width: 0;
    padding: 6px 8px;
    font: inherit;
    font-size: 14px;
    font-weight: 600;
    color: var(--gray-900);
    cursor: pointer;
    user-select: none;
    border: 0;
    background: transparent;
    text-align: left;

    .file-title {
      font-size: 15px;
      line-height: 1.3;
      overflow-wrap: anywhere;
    }
  }

  .folder-header .file {
    flex: 1;
    width: auto;
  }

  .entry {
    display: flex;
    align-items: center;
    width: 100%;
  }

  .entry-text {
    display: flex;
    flex-direction: column;
    min-width: 0;
    flex: 1;
  }

  .empty-folder-hint {
    font-size: 12px;
    color: var(--gray-600);
    padding: 4px 8px;
    font-style: italic;
  }

  /* Nesting from the table of contents, so a book's chapters and sections keep their shape. */
  .depth-1 {
    margin-left: 12px;
  }
  .depth-2 {
    margin-left: 24px;
  }
  .depth-3 {
    margin-left: 36px;
  }

  .children-list {
    list-style: none;
    padding-left: 8px;
    margin: 2px 0 4px 16px;
    border-left: 1px solid var(--border);
    display: flex;
    flex-direction: column;
    gap: 2px;
  }

  #headings {
    margin: 4px 0 10px 10px;
    padding-left: 12px;
    border-left: 1px solid var(--accent-dark);
    gap: 0;

    ul {
      margin: 0;
      padding-left: 12px;
      gap: 0;
    }

    .heading {
      display: block;
      width: 100%;
      padding: 3px 6px;
      border: 0;
      border-radius: 4px;
      background: transparent;
      font: inherit;
      font-size: 14px;
      text-align: left;
      cursor: pointer;
      overflow-wrap: anywhere;

      &:hover {
        text-decoration: underline;
      }
    }
  }

  .empty {
    font-size: 14px;
    color: var(--gray-800);
    margin: 4px 10px;
  }
`;

/** Titles read from other pages, per backend and commit. A file at a given commit never changes, so an
 * entry is good for as long as the editor is open; keyed by the backend so two editors never mix. */
const titleCache = new WeakMap();
/** Each title costs one request to the repository, so only a few go out at a time. */
const titleConcurrency = 3;

const ChevronIcon = ({ open }) => (
  <svg
    width="14"
    height="14"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    stroke-width="2"
    stroke-linecap="round"
    stroke-linejoin="round"
    style={{ transform: open ? "rotate(90deg)" : "none", transition: "transform 150ms ease" }}
    aria-hidden="true"
  >
    <polyline points="9 18 15 12 9 6" />
  </svg>
);

const FolderIcon = () => (
  <svg
    className="folder-icon"
    width="15"
    height="15"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    stroke-width="2"
    stroke-linecap="round"
    stroke-linejoin="round"
    aria-hidden="true"
  >
    <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" />
  </svg>
);

const DragHandleIcon = () => (
  <svg className="drag-handle" width="12" height="12" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
    <circle cx="9" cy="6" r="2" />
    <circle cx="15" cy="6" r="2" />
    <circle cx="9" cy="12" r="2" />
    <circle cx="15" cy="12" r="2" />
    <circle cx="9" cy="18" r="2" />
    <circle cx="15" cy="18" r="2" />
  </svg>
);

function Heading({ heading }) {
  return (
    <li>
      <button type="button" title="Go to heading" className="heading" data-heading-pos={heading.pos}>
        {heading.text}
      </button>
      {heading.children.length > 0 && (
        <ul>
          {heading.children.map((c) => (
            <Heading key={c.pos} heading={c} />
          ))}
        </ul>
      )}
    </li>
  );
}

/** Whether the entry at `inner` is the one at `outer` or sits somewhere under it. */
const isWithin = (outer, inner) => !!outer && !!inner && outer.length <= inner.length && outer.every((v, i) => inner[i] === v);

const MOVE_KEYS = "Alt+ArrowUp Alt+ArrowDown Alt+ArrowLeft Alt+ArrowRight";

export const TableOfContents = ({
  indexedFiles,
  markedFiles,
  currentFile,
  onFileClick,
  getText,
  branch,
  commit,
  query = "",
  // The table of contents as a tree (parseTocTree), when it is YAML; without one the list is flat.
  tree = null,
  // (source, target, "before" | "after" | "inside"): rearranges entries, by dragging or Alt + arrow keys.
  onMoveItem = null,
}) => {
  const { headings, editorView } = useContext(MystState);

  // Titles fetched from the repository for the pages that are not open. The open page's title comes
  // from its live headings instead, so renaming it shows up as it is typed.
  const fetchedTitles = useSignal({});
  useSignalEffect(() => {
    const entries = indexedFiles.value;
    const hash = commit.value?.hash;
    if (!hash || !getText) return;
    let cancelled = false;
    let perBackend = titleCache.get(getText);
    if (!perBackend) titleCache.set(getText, (perBackend = new Map()));

    const key = (f) => `${branch.peek()}/${hash}/${f.file}`;
    const known = () => Object.fromEntries(entries.filter((f) => perBackend.has(key(f))).map((f) => [f.file, perBackend.get(key(f))]));
    fetchedTitles.value = known();

    const queue = entries.filter((f) => !f.title && !perBackend.has(key(f)));
    const worker = async () => {
      while (queue.length && !cancelled) {
        const f = queue.shift();
        let title = null;
        try {
          title = pageTitle(await getText(branch.peek(), commit.peek(), f.file));
        } catch {
          /* the file name stands in */
        }
        perBackend.set(key(f), title);
        if (!cancelled) fetchedTitles.value = { ...fetchedTitles.peek(), [f.file]: title };
      }
    };
    for (let i = 0; i < titleConcurrency; i++) worker();
    return () => (cancelled = true);
  });

  // The open page's level-one heading is its entry's title, so its sections are lifted a level rather
  // than listed under a repeat of the title they sit beneath.
  const outline = useComputed(() => {
    const hs = headings.value;
    const h1s = hs.filter((h) => h.level === 1);
    if (h1s.length === 1 && hs[0] === h1s[0]) return { title: h1s[0].text, items: h1s[0].children };
    return { title: null, items: hs };
  });

  // Chapters opened or closed by hand. The others are open only while they hold the open page, so a
  // long book shows its outline rather than every page at once.
  const toggled = useSignal(new Map());
  // The entry being dragged, and where it would land: `{ id, position, node }`.
  const dragged = useSignal(null);
  const dropTarget = useSignal(null);

  function handleHeadingClick(ev) {
    const posAttr = ev.target?.closest?.("[data-heading-pos]")?.dataset?.headingPos;
    if (!posAttr) return;
    const pos = parseInt(posAttr, 10);
    editorView.value.dispatch({ selection: { anchor: pos, head: pos }, effects: EditorView.scrollIntoView(pos, { y: "start" }) });
  }

  const sections = (isCurrent) =>
    isCurrent &&
    outline.value.items.length > 0 && (
      <ul id="headings" aria-label="Sections" onClick={handleHeadingClick}>
        {outline.value.items.map((h) => (
          <Heading heading={h} key={h.pos} />
        ))}
      </ul>
    );

  const unsavedMark = (marked) =>
    marked && (
      <>
        <span className="unsaved" aria-hidden="true" title="Uncommitted changes" />
        <span className="visually-hidden">(uncommitted changes)</span>
      </>
    );

  const treeNodes = tree?.value ?? [];
  if (treeNodes.length > 0) {
    const existing = new Set(indexedFiles.value.map((f) => f.file));
    const nodes = [...treeNodes];
    // The page list puts README.md at the top when the table of contents leaves it out; so does the tree.
    const readme = indexedFiles.value.find((f) => f.fileName === "README.md");
    const listed = (ns) => ns.some((n) => n.file === readme?.file || listed(n.children));
    if (readme && !listed(nodes)) nodes.splice(1, 0, { ...readme, id: readme.file, path: null, isFolder: false, children: [], home: null });

    const ancestors = new Set();
    (function find(ns, trail) {
      for (const n of ns) {
        if (n.file && n.file === currentFile) trail.forEach((id) => ancestors.add(id));
        find(n.children, [...trail, n.id]);
      }
    })(nodes, []);
    const isOpen = (node) => !!query || (toggled.value.has(node.id) ? toggled.value.get(node.id) : ancestors.has(node.id));
    const toggle = (node) => (toggled.value = new Map(toggled.peek()).set(node.id, !isOpen(node)));

    /** The entry as shown: a page whose file is missing is left out, a chapter stays (as its title). */
    function prepare(node) {
      const file = node.file && existing.has(node.file) ? node.file : null;
      if (!file && !node.isFolder) return null;
      const isCurrent = !!file && file === currentFile;
      const title = node.title || (isCurrent && outline.value.title) || (file && fetchedTitles.value[file]) || null;
      const children = node.children.map(prepare).filter(Boolean);
      const matches = !query || [title, node.fileName, file].some((t) => t?.toLowerCase().includes(query));
      if (!matches && children.length === 0) return null;
      return { ...node, file, isCurrent, title, children };
    }
    const shown = nodes.map(prepare).filter(Boolean);

    const canMove = (node) => !!onMoveItem && !!node.path && !query;
    const move = (source, target, position) => target?.path && onMoveItem(source, target, position);

    /** Alt + arrow keys do what dragging does: up and down past a neighbour, right into the chapter
     * above, left out of the chapter the entry is in. */
    function handleKeyDown(ev, node, siblings, index, parent) {
      if (!ev.altKey || !canMove(node)) return;
      const before = siblings
        .slice(0, index)
        .reverse()
        .find((n) => n.path);
      const after = siblings.slice(index + 1).find((n) => n.path);
      if (ev.key === "ArrowUp" && before) move(node, before, "before");
      else if (ev.key === "ArrowDown" && after) move(node, after, "after");
      else if (ev.key === "ArrowRight" && before?.isFolder) move(node, before, "inside");
      else if (ev.key === "ArrowLeft" && parent?.path) move(node, parent, "after");
      else return;
      ev.preventDefault();
    }

    const dragProps = (node) => ({
      draggable: canMove(node),
      onDragStart: (ev) => {
        if (!canMove(node)) return;
        ev.stopPropagation();
        ev.dataTransfer.setData("text/plain", node.id);
        ev.dataTransfer.effectAllowed = "move";
        dragged.value = node;
      },
      onDragOver: (ev) => {
        const source = dragged.value;
        // Nowhere to land on itself, on its own children, or on an entry that cannot move.
        if (!source || !node.path || isWithin(source.path, node.path)) return;
        ev.preventDefault();
        ev.stopPropagation();
        const rect = ev.currentTarget.getBoundingClientRect();
        const y = (ev.clientY - rect.top) / rect.height;
        const position = node.isFolder ? (y < 0.25 ? "before" : y > 0.75 ? "after" : "inside") : y < 0.5 ? "before" : "after";
        if (dropTarget.peek()?.id !== node.id || dropTarget.peek()?.position !== position) dropTarget.value = { id: node.id, position, node };
      },
      onDragLeave: (ev) => {
        if (dropTarget.peek()?.id === node.id && !ev.currentTarget.contains(ev.relatedTarget)) dropTarget.value = null;
      },
      onDrop: (ev) => {
        ev.preventDefault();
        ev.stopPropagation();
        const source = dragged.value;
        const target = dropTarget.value;
        dragged.value = null;
        dropTarget.value = null;
        if (source && target) move(source, target.node, target.position);
      },
      onDragEnd: () => {
        dragged.value = null;
        dropTarget.value = null;
      },
    });

    function renderNode(node, siblings, index, parent) {
      const marked = node.file && markedFiles.value.includes(node.file);
      // Inside a chapter the folder is already shown by the chapter, so only the rest of the path is.
      const full = node.fileName || node.file || "";
      const name = parent?.home && node.file?.startsWith(`${parent.home}/`) ? node.file.slice(parent.home.length + 1) : full;
      const drop = dropTarget.value?.id === node.id ? `drop-${dropTarget.value.position}` : "";
      const keyDown = (ev) => handleKeyDown(ev, node, siblings, index, parent);
      const moveHint = canMove(node) ? ". Drag, or use Alt + arrow keys, to move it" : "";
      const pageButton = (icon) => (
        <button
          type="button"
          className={`file ${marked ? "marked" : ""}`}
          title={`Go to file ${node.file}${moveHint}`}
          aria-current={node.isCurrent ? "page" : undefined}
          aria-keyshortcuts={canMove(node) ? MOVE_KEYS : undefined}
          onClick={() => onFileClick(node)}
          onKeyDown={keyDown}
        >
          <span className="entry">
            {icon}
            <span className="entry-text">
              {node.title && <span className="file-title">{node.title}</span>}
              <span className={node.title ? "file-name file-path" : "file-name file-title"}>{name}</span>
            </span>
            {canMove(node) && <DragHandleIcon />}
          </span>
          {unsavedMark(marked)}
        </button>
      );

      if (!node.isFolder) {
        return (
          <li key={node.id}>
            <div className={`item-wrapper ${drop}`} {...dragProps(node)}>
              {pageButton(null)}
              {sections(node.isCurrent)}
            </div>
          </li>
        );
      }

      const open = isOpen(node);
      const label = node.title || name || "Chapter";
      return (
        <li key={node.id}>
          <div className={`item-wrapper ${drop}`} {...dragProps(node)}>
            <div className="folder-header">
              {node.file ? (
                pageButton(<FolderIcon />)
              ) : (
                <button
                  type="button"
                  className="folder-title-only"
                  aria-expanded={open}
                  title={moveHint ? `${label}${moveHint}` : undefined}
                  aria-keyshortcuts={canMove(node) ? MOVE_KEYS : undefined}
                  onClick={() => toggle(node)}
                  onKeyDown={keyDown}
                >
                  <FolderIcon />
                  <span className="file-title">{label}</span>
                  {canMove(node) && <DragHandleIcon />}
                </button>
              )}
              <button
                type="button"
                className="toggle-button"
                aria-label={open ? `Collapse ${label}` : `Expand ${label}`}
                aria-expanded={open}
                onClick={(ev) => {
                  ev.stopPropagation();
                  toggle(node);
                }}
              >
                <ChevronIcon open={open} />
              </button>
            </div>
            {sections(node.isCurrent)}
          </div>
          {open && (
            <ul className="children-list" role="group">
              {node.children.length > 0 ? (
                node.children.map((child, i) => renderNode(child, node.children, i, node))
              ) : (
                <li className="empty-folder-hint">No pages yet</li>
              )}
            </ul>
          )}
        </li>
      );
    }

    return (
      <List>
        {shown.length === 0 && <p className="empty">No pages match.</p>}
        <ul id="page-list">{shown.map((node, i) => renderNode(node, shown, i, null))}</ul>
      </List>
    );
  }

  const entries = indexedFiles.value.map((f) => {
    const isCurrent = currentFile.startsWith(f.file);
    const title = f.title || (isCurrent && outline.value.title) || fetchedTitles.value[f.file] || null;
    return { ...f, isCurrent, title };
  });
  const shown = query ? entries.filter((f) => [f.title, f.fileName, f.file].some((t) => t?.toLowerCase().includes(query))) : entries;

  return (
    <List>
      {shown.length === 0 && <p className="empty">No pages match.</p>}
      <ul id="page-list">
        {shown.map((f) => {
          const marked = markedFiles.value.includes(f.file);
          const name = f.fileName || f.file;

          return (
            <li key={f.file} className={f.depth ? `depth-${Math.min(f.depth, 3)}` : undefined}>
              <button
                type="button"
                className={`file ${marked ? "marked" : ""}`}
                title={`Go to file ${f.file}`}
                aria-current={f.isCurrent ? "page" : undefined}
                onClick={() => onFileClick(f)}
              >
                {f.title && <span className="file-title">{f.title}</span>}
                <span className={f.title ? "file-name file-path" : "file-name file-title"}>{name}</span>
                {unsavedMark(marked)}
              </button>
              {sections(f.isCurrent)}
            </li>
          );
        })}
      </ul>
    </List>
  );
};
