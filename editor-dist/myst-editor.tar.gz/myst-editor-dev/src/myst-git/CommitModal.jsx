import { useComputed, useSignal, useSignalEffect } from "@preact/signals";
import { EditorView } from "codemirror";
import { useContext, useEffect, useRef } from "preact/hooks";
import styled from "styled-components";
import { ExtensionBuilder } from "../extensions";
import { unifiedMergeView } from "@codemirror/merge";
import { CodeEditor } from "../components/CodeMirror";
import { MystState } from "../mystState";
import { Modal } from "../components/CommonUI";

const CommitForm = styled(Modal)`
  && {
    width: 800px;
  }

  form {
    margin-top: 20px;
  }

  label,
  input,
  textarea {
    display: block;
  }

  label {
    margin-bottom: 10px;
  }

  textarea,
  input {
    padding: 5px 10px;
    font-family: inherit;
    width: 100%;
    box-sizing: border-box;
    background-color: var(--button-bg);
    border: 1px solid var(--border);
    border-radius: var(--border-radius);
  }

  input {
    margin-bottom: 20px;
  }

  button {
    cursor: pointer;
    text-transform: uppercase;
    font-size: 12px;
    font-weight: bold;
    font-family: inherit;
    border: 1px solid var(--border);
    background-color: var(--button-bg);
    height: 40px;
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 0px 15px;
    transition: 0.4s ease;
    border-radius: var(--border-radius);

    &:hover {
      background-color: var(--button-bg-hover);
      border: 1px solid var(--button-bg-hover);
    }
  }

  #diffs {
    display: flex;
    flex-direction: column;
    gap: 16px;
  }

  .diff-parent {
    display: flex;
    flex-direction: column;
    gap: 10px;
  }

  .file-controls {
    display: flex;
    align-items: center;
    justify-content: space-between;
  }

  .file-name {
    display: flex;
    align-items: center;
    gap: 8px;

    input,
    label {
      display: inline;
      width: fit-content;
      margin: 0;
    }

    label.unstaged {
      text-decoration: line-through;
      color: var(--gray-700);
    }
  }

  .images {
    margin: 16px 0 0;
    padding: 0;
    border: 0;

    legend {
      font-weight: 700;
      margin-bottom: 8px;
    }

    ul {
      list-style: none;
      margin: 0;
      padding: 0;
      display: flex;
      flex-direction: column;
      gap: 8px;
    }

    li {
      display: flex;
      align-items: center;
      gap: 12px;
    }

    img {
      width: 64px;
      height: 48px;
      object-fit: contain;
      border: 1px solid var(--border);
      border-radius: var(--border-radius);
      background: var(--editor-bg);
      flex: none;
    }

    label {
      display: flex;
      align-items: center;
      gap: 8px;
      margin: 0;
      overflow-wrap: anywhere;
    }

    input {
      width: auto;
      margin: 0;
    }

    .note {
      display: block;
      font-size: 12px;
      color: var(--gray-700);
    }

    .warning {
      color: var(--error-fg);
    }
  }
`;

const formatSize = (bytes) => (bytes < 1024 * 1024 ? `${Math.max(1, Math.round(bytes / 1024))} KB` : `${(bytes / (1024 * 1024)).toFixed(1)} MB`);

const CommitModal = ({ initialSummary = "", onSubmit, onClose, onDiscardLocal, documents = [], assets = [], parent, latestCommit, statusSocket }) => {
  const summary = useSignal(initialSummary);
  const description = useSignal("");
  const message = useComputed(() => `${summary.value}\n\n${description.value}`);
  const changedDocs = useSignal(documents);
  const stagedDocs = useSignal(documents.map((d) => d.file));
  // Uploaded images go in when a changed page shows them; one no page uses is offered, unticked. So is
  // one whose name someone else has committed since: ticking it replaces theirs, so the author decides.
  const ticked = (list) => list.filter((a) => a.usedBy.length && !a.onBranch).map((a) => a.path);
  const stagedAssets = useSignal(ticked(assets));
  const modalRef = useRef();

  useEffect(() => {
    if (initialSummary) {
      summary.value = initialSummary;
      description.value = "";
      changedDocs.value = documents;
      stagedDocs.value = documents.map((d) => d.file);
      stagedAssets.value = ticked(assets);
      modalRef.current?.showModal?.();
      modalRef.current.onclose = onClose;
    } else {
      // The modal stays mounted between commits. Without this, the next opening would first render the
      // previous pages, and their diff views (keyed by file, built once) would keep that stale text.
      changedDocs.value = [];
    }
  }, [initialSummary]);

  function handleStage(staged, file) {
    if (staged) {
      stagedDocs.value = [...stagedDocs.peek(), file];
    } else {
      stagedDocs.value = stagedDocs.peek().filter((f) => f !== file);
    }
  }

  return (
    <CommitForm ref={modalRef}>
      <div id="diffs">
        {/* Only mount the diff editors while the modal is open, so they are destroyed on close. */}
        {initialSummary &&
          changedDocs.value.map((d) => (
            <Diff
              key={d.file}
              parent={parent}
              document={d}
              onStage={(staged) => handleStage(staged, d.file)}
              discardFile={() => {
                handleStage(false, d.file);
                if (d.client) {
                  d.client.ytext.delete(0, d.client.ytext.length);
                  d.client.ytext.insert(0, d.initialText);
                  statusSocket.current?.send?.(d.client.provider.roomname);
                } else if (onDiscardLocal) {
                  onDiscardLocal(d);
                }
                changedDocs.value = changedDocs.peek().filter((doc) => doc.file !== d.file);
                if (changedDocs.peek().length === 0) modalRef.current?.close?.();
              }}
            />
          ))}
      </div>
      {initialSummary && assets.length > 0 && (
        <fieldset className="images" id="commit-images">
          <legend>Images</legend>
          <ul>
            {assets.map((a) => {
              const staged = stagedAssets.value.includes(a.path);
              // Leaving out an image that a page being committed shows commits a broken figure.
              const brokenBy = staged || a.onBranch ? [] : a.usedBy.filter((f) => stagedDocs.value.includes(f));
              return (
                <li key={a.path}>
                  <img src={a.url} alt="" />
                  <label>
                    <input
                      type="checkbox"
                      name={a.path}
                      checked={staged}
                      onChange={(ev) =>
                        (stagedAssets.value = ev.currentTarget.checked
                          ? [...stagedAssets.peek(), a.path]
                          : stagedAssets.peek().filter((p) => p !== a.path))
                      }
                    />
                    <span>
                      {a.path} <span className="note">{formatSize(a.size)} · new file</span>
                      {a.usedBy.length === 0 && <span className="note">No longer used on any page</span>}
                      {a.onBranch && (
                        <span className="note warning" role="alert">
                          {staged
                            ? "Replaces the image with this name that is already on the branch"
                            : "An image with this name was committed since you uploaded this one. Tick to replace it."}
                        </span>
                      )}
                      {brokenBy.length > 0 && (
                        <span className="note warning" role="alert">
                          {brokenBy.join(", ")} will show a missing image
                        </span>
                      )}
                    </span>
                  </label>
                </li>
              );
            })}
          </ul>
        </fieldset>
      )}
      {latestCommit ? (
        <form
          onSubmit={(ev) => {
            ev.preventDefault();
            if (stagedDocs.value.length === 0) return;
            modalRef.current.onclose = () => {};
            modalRef.current.close();
            onSubmit({ summary: summary.value, message: message.value, stagedDocs: stagedDocs.value, stagedAssets: stagedAssets.value });
          }}
        >
          <label htmlFor="summary">Commit summary</label>
          <input id="summary" type="text" value={summary.value} onChange={(ev) => (summary.value = ev.target.value)} autoFocus />
          <label htmlFor="description">Commit description</label>
          <textarea
            name="description"
            id="description"
            value={description.value}
            onChange={(ev) => (description.value = ev.target.value)}
            cols={80}
            rows={5}
          />
          <div className="buttons">
            <button type="submit" disabled={stagedDocs.value.length === 0}>
              Commit
            </button>
            <button type="button" onClick={() => modalRef.current.close()}>
              Cancel
            </button>
          </div>
        </form>
      ) : (
        <>
          <p>You can only commit changes from the latest commit of a branch</p>
          <div className="buttons">
            <div />
            <button onClick={() => modalRef.current.close()}>Close</button>
          </div>
        </>
      )}
    </CommitForm>
  );
};

const MergeViewCodeEditor = styled(CodeEditor)``;

const Diff = ({ document, parent, onStage, discardFile }) => {
  const { options } = useContext(MystState);
  const diffRef = useRef();
  const staged = useSignal(true);

  useEffect(() => {
    if (!diffRef.current) return;
    const view = new EditorView({
      parent: diffRef.current,
      root: parent,
      doc: document.text,
      extensions: [
        ...ExtensionBuilder.basicSetup().useLanguage("markdown", options.transforms.value).useReadonly().create(),
        unifiedMergeView({
          original: document.initialText,
          mergeControls: false,
          collapseUnchanged: {
            margin: 3,
            minSize: 6,
          },
        }),
      ],
    });

    return () => {
      view.destroy();
    };
  }, []);

  useSignalEffect(() => onStage(staged.value));

  return (
    <div className="diff-parent">
      <div className="file-controls">
        <div className="file-name">
          <input
            type="checkbox"
            name={document.file}
            id={document.file}
            checked={staged.value}
            onChange={(ev) => (staged.value = ev.target.checked)}
          />
          <label
            for={document.file}
            className={staged.value ? "" : "unstaged"}
            title={staged.value ? "This file will be committed" : "This file will not be committed"}
          >
            {document.file}
          </label>
        </div>
        <button onClick={() => discardFile()}>Discard changes</button>
      </div>
      {staged.value && <MergeViewCodeEditor ref={diffRef} />}
    </div>
  );
};

export default CommitModal;
