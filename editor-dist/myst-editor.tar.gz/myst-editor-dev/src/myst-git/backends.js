// The git backends the editor can run on. Each is a module exporting a factory that returns the same
// callback contract (see stubGitBackend.js for the reference implementation), so the editor never
// knows which forge it is talking to. A new forge is a new module here, plus its sign-in in
// mountGitEditor.js.

import { createStubGitBackend } from "./stubGitBackend.js";
import { createGitLabBackend } from "./gitlabBackend.js";
import { createGitHubBackend } from "./githubBackend.js";

const factories = {
  stub: createStubGitBackend,
  gitlab: createGitLabBackend,
  github: createGitHubBackend,
};

/**
 * Create git API callbacks for MystEditorGit.
 *
 * @param {"stub"|"gitlab"|"github"} [kind] - Backend kind. `gitlab` and `github` talk to the real APIs.
 * @param {object} [options] - Passed to the chosen backend factory.
 * @returns {Promise<import("./stubGitBackend.js").GitBackendCallbacks & { initialBranches: string[] }>} - async so
 *   the real backends can prefetch.
 */
export async function createGitBackend(kind = "stub", options = {}) {
  const create = factories[kind];
  if (!create) throw new Error(`Unknown git backend: ${kind}`);
  return create(options);
}
