// GitLab REST API v4 implementation of the git-backend callback contract consumed by
// MystEditorGit (see stubGitBackend.js for the in-memory reference implementation).
//
// All network calls go through an injected `authorizedFetch` (from gitlabAuth.js), which adds the
// Bearer token and handles 401→refresh. Injecting it keeps this module pure and unit-testable.

import { authorizedFetch as defaultAuthorizedFetch } from "./gitlabAuth.js";
import { buildMergeRequestUrl, GITLAB_REVIEW } from "./mergeRequest.js";

const PAGE_SIZE = 20;
const DOC_EXTENSIONS = [".md", ".rst"];

/** Numeric project ids pass through; a namespace path ("group/project") must be URL-encoded. */
function encodeProjectId(projectId) {
  return /^\d+$/.test(String(projectId)) ? String(projectId) : encodeURIComponent(projectId);
}

/**
 * Create the GitLab-backed git API. Async because it prefetches the default branch and first page
 * of branches to populate `initialBranches` (page 1; the picker loads page 2+ on scroll).
 *
 * @param {{ projectId: string|number, getBranch?: () => string, authorizedFetch?: typeof defaultAuthorizedFetch, searchCommitPages?: number }} options
 * @returns {Promise<object>} the backend callbacks + `initialBranches`
 */
export async function createGitLabBackend(options = {}) {
  const { projectId, getBranch = () => "main", authorizedFetch = defaultAuthorizedFetch, searchCommitPages = 5 } = options;

  if (!projectId) throw new Error("createGitLabBackend: `projectId` is required.");
  const repoPath = `projects/${encodeProjectId(projectId)}/repository`;

  const apiJson = async (path, init) => (await authorizedFetch(path, init)).json();
  const apiText = async (path, init) => (await authorizedFetch(path, init)).text();

  // What GitLab said about each branch it listed: whether it is protected, and whether this user may
  // push to it. Kept from the listings the editor makes anyway, so the picker can mark them for free.
  const branchStatus = new Map();
  const branchNames = (branches) =>
    branches.map((b) => {
      branchStatus.set(b.name, { protected: !!b.protected, canPush: b.can_push !== false });
      return b.name;
    });

  const fetchBranchNames = async (page) => branchNames(await apiJson(`${repoPath}/branches?per_page=${PAGE_SIZE}&page=${page}`));

  const fetchCommits = async (branch, page) =>
    (await apiJson(`${repoPath}/commits?ref_name=${encodeURIComponent(branch)}&per_page=${PAGE_SIZE}&page=${page}`)).map((c) => ({
      hash: c.short_id,
      message: c.title,
    }));

  // Prefetch project metadata for the default branch, and page 1 of branches, so the editor opens
  // on a sensible branch with a populated picker.
  const project = await apiJson(`projects/${encodeProjectId(projectId)}`);
  const defaultBranch = project.default_branch || "main";
  const firstPage = await fetchBranchNames(1);
  const initialBranches = [defaultBranch, ...firstPage.filter((b) => b !== defaultBranch)];
  // The project answer above already carries the signed-in user's role in it, so only the user
  // themselves is left to ask for, and only when something (an add-on) wants to know.
  const permissions = project.permissions ?? {};
  const accessLevel = Math.max(permissions.project_access?.access_level ?? 0, permissions.group_access?.access_level ?? 0);
  let currentUser = null;

  return {
    initialBranches,
    projectId: project.id,
    projectWebUrl: project.web_url,
    defaultBranch,
    // Images uploaded in the editor go into the same commit as the pages that use them.
    supportsAssets: true,
    serverName: "GitLab",
    review: GITLAB_REVIEW,

    newMergeRequestUrl({ sourceBranch, targetBranch }) {
      return buildMergeRequestUrl({
        projectWebUrl: project.web_url,
        sourceProjectId: project.id,
        sourceBranch,
        targetProjectId: project.id,
        targetBranch,
      });
    },

    /** The signed-in user, with their role in this project (GitLab access level: 30 Developer,
     * 40 Maintainer, 50 Owner; 0 when they only see it as a public project). */
    async getCurrentUser() {
      currentUser ??= apiJson("user").then(
        (u) => ({ id: u.id, username: u.username, name: u.name, accessLevel }),
        (err) => {
          currentUser = null;
          throw err;
        },
      );
      return currentUser;
    },

    async getOpenMergeRequests(branch) {
      try {
        const query = branch ? `source_branch=${encodeURIComponent(branch)}&state=opened&per_page=20` : "state=opened&per_page=20";
        const mrs = await apiJson(`projects/${encodeProjectId(projectId)}/merge_requests?${query}`);
        return mrs.map((mr) => ({
          id: mr.id,
          iid: mr.iid,
          title: mr.title,
          webUrl: mr.web_url,
          sourceBranch: mr.source_branch,
          targetBranch: mr.target_branch,
          state: mr.state,
          author: mr.author?.name || mr.author?.username,
        }));
      } catch (err) {
        console.warn("Failed to fetch open merge requests:", err);
        return [];
      }
    },

    async getBranches(page) {
      return fetchBranchNames(page);
    },

    async searchBranches(input) {
      return branchNames(await apiJson(`${repoPath}/branches?per_page=${PAGE_SIZE}&search=${encodeURIComponent(input)}`));
    },

    /** `{ protected, canPush }` for a branch already listed or searched, else undefined. */
    getBranchStatus(name) {
      return branchStatus.get(name);
    },

    async getCommits(branch, page) {
      return fetchCommits(branch, page);
    },

    // GitLab's REST API has no commit-message search without Elasticsearch, so scan the first few
    // pages of the branch history and filter client-side. (See plan: server-side search is a follow-up.)
    async searchCommits(input, branch) {
      const q = input.toLowerCase();
      const matches = [];
      for (let page = 1; page <= searchCommitPages; page++) {
        const commits = await fetchCommits(branch, page);
        if (commits.length === 0) break;
        for (const c of commits) if (c.message.toLowerCase().includes(q)) matches.push(c);
        if (matches.length >= PAGE_SIZE) break;
      }
      return matches.slice(0, PAGE_SIZE);
    },

    async getFiles(_branch, commit) {
      if (!commit?.hash) return [];
      const files = [];
      // The tree endpoint paginates; walk pages until a short/empty page ends it.
      for (let page = 1; ; page++) {
        const tree = await apiJson(`${repoPath}/tree?ref=${encodeURIComponent(commit.hash)}&recursive=true&per_page=100&page=${page}`);
        for (const entry of tree) {
          if (entry.type === "blob" && DOC_EXTENSIONS.some((ext) => entry.path.endsWith(ext))) files.push(entry.path);
        }
        if (tree.length < 100) break;
      }
      return files;
    },

    /** Every file under a folder at this commit, pages, images and anything else, as repository paths. */
    async listFiles(commit, dir) {
      if (!commit?.hash || !dir) return [];
      const files = [];
      for (let page = 1; ; page++) {
        let tree;
        try {
          tree = await apiJson(
            `${repoPath}/tree?ref=${encodeURIComponent(commit.hash)}&path=${encodeURIComponent(dir)}&recursive=true&per_page=100&page=${page}`,
          );
        } catch (err) {
          if (err.status === 404) return files; // no such folder
          throw err;
        }
        for (const entry of tree) if (entry.type === "blob") files.push(entry.path);
        if (tree.length < 100) break;
      }
      return files;
    },

    async getText(_branch, commit, file) {
      if (!commit?.hash) return "";
      try {
        return await apiText(`${repoPath}/files/${encodeURIComponent(file)}/raw?ref=${encodeURIComponent(commit.hash)}`);
      } catch (err) {
        if (err.status === 404) return ""; // match the stub: a missing file reads as empty
        throw err;
      }
    },

    async getFileBlob(_branch, commit, file) {
      if (!commit?.hash) return null;
      try {
        const res = await authorizedFetch(`${repoPath}/files/${encodeURIComponent(file)}/raw?ref=${encodeURIComponent(commit.hash)}`);
        const blob = await res.blob();
        return URL.createObjectURL(blob);
      } catch (err) {
        if (err.status === 404) return null;
        throw err;
      }
    },

    /** Whether anything is at `path` at this commit - an image name must not land on an existing file. */
    async fileExists(commit, path) {
      if (!commit?.hash) return false;
      try {
        await authorizedFetch(`${repoPath}/files/${encodeURIComponent(path)}?ref=${encodeURIComponent(commit.hash)}`, { method: "HEAD" });
        return true;
      } catch (err) {
        if (err.status === 404) return false;
        throw err;
      }
    },

    /**
     * One commit for the edited pages and the images uploaded for them, so a page never lands without
     * the image it shows.
     *
     * @param {string} message
     * @param {{ file: string, text?: string, action?: string, previous_path?: string }[]} documents - edited pages; they exist, so `update` unless specified (e.g. `create`).
     *   A `move` without `text` keeps the file's content as it is, binary files included.
     * @param {{ path: string, base64: string, replace?: boolean }[]} [assets] - new binary files.
     *   `create` unless `replace`: GitLab refuses to create over an existing file, which is the answer we
     *   want - an image someone else committed at the same path must not be replaced without anyone saying
     *   so. The commit dialog asks, and passes `replace` when the author chose to.
     */
    async commitChanges(message, documents, assets = []) {
      const branch = getBranch();
      const actions = [
        ...documents.map((d) => {
          const act = { action: d.action || "update", file_path: d.file };
          if (d.text !== undefined) act.content = d.text;
          if (d.previous_path) act.previous_path = d.previous_path;
          return act;
        }),
        ...assets.map((a) => ({ action: a.replace ? "update" : "create", file_path: a.path, content: a.base64, encoding: "base64" })),
      ];
      const res = await apiJson(`${repoPath}/commits`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ branch, commit_message: message, actions }),
      });
      return { hash: res.short_id, webUrl: res.web_url };
    },

    async createBranch(branch, ref) {
      const res = await apiJson(`${repoPath}/branches`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ branch, ref }),
      });
      return {
        name: res.name,
        commit: {
          hash: res.commit?.short_id ?? res.commit?.id,
          message: res.commit?.title,
        },
      };
    },
  };
}
