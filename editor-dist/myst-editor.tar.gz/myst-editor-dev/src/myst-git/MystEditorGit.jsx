import { MystEditorPreact, CollaborationClient } from "../MystEditor";
import { render } from "preact";
import { EditorView } from "codemirror";
import { useContext, useEffect, useRef } from "preact/hooks";
import { batch, effect, useComputed, useSignal, useSignalEffect } from "@preact/signals";
import { createMystState, MystState } from "../mystState";
import styled, { StyleSheetManager } from "styled-components";
import CommitModal from "./CommitModal";
import MergeRequestModal from "./MergeRequestModal";
import FormDialog from "../components/FormDialog";
import { useWatchChanges } from "./useWatchChanges";
import { MystCSSVars } from "../styles/MystStyles";
import Sidebar from "./Sidebar";
import GitPickerModal from "./GitPickerModal";
import { createLogger, Logger } from "../logger";
import { parseTocYaml, parseToctree, tocExtends, TOC_CANDIDATES, isTocYaml, parseTocTree, addTocPage, addTocChapter, moveTocEntry } from "./toc.js";
import { resolveBranding } from "./branding.js";
import { createAssetStore, blobToBase64 } from "./assetStore.js";
import {
  dirname,
  imageReferences,
  isExternalUrl,
  relinkReferences,
  relativeTo,
  resolveAssetPath,
  sanitizeFileName,
  slugify,
  withUniqueSuffix,
} from "./assetPaths.js";
import { GITLAB_REVIEW } from "./mergeRequest.js";

/** GitHub's 40-character commit ids, cut to the 8 GitLab shows. Anything else (GitLab's own short ids,
 * the demo's "offline-3") is shown as it is. */
const sentenceCase = (text) => text.charAt(0).toUpperCase() + text.slice(1);
const shortHash = (hash) => (/^[0-9a-f]{40}$/i.test(hash ?? "") ? hash.slice(0, 8) : hash);

/** What an image shows until its real source is known. */
const TRANSPARENT_PIXEL = "data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==";

function escapeHtml(text) {
  return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
}

/** How long a git fetch may run before the editor says so. Long enough that an ordinary file switch
 * never flashes a popup, short enough that a stalled repository explains itself quickly. */
const SLOW_FETCH_MS = 400;
/** A fetch still running this long after the sequence started is no longer the editor being busy -
 * it is the server taking its time. Saying so is the whole point: a slow morning at GitLab otherwise
 * reads as a broken editor, and the person waiting has no way to tell the two apart. */
const BLAME_SERVER_MS = 3000;

/** How far to follow a chain of `extends:` before giving up. Configs delegate one or two levels deep
 * in practice; the cap is what stops a circular chain, together with the set of paths already read. */
const maxTocExtendsDepth = 3;

/** Remembering the page index's state is a convenience, never a correctness matter, so every access
 * tolerates storage being unavailable (private browsing, blocked site data) by falling back to open. */
const collapsedKey = (id) => `myst-editor:${id ?? "default"}:sidebar-collapsed`;

function readCollapsedPreference(id) {
  try {
    return localStorage.getItem(collapsedKey(id)) === "true";
  } catch {
    return false;
  }
}

function storeCollapsedPreference(id, collapsed) {
  try {
    localStorage.setItem(collapsedKey(id), String(collapsed));
  } catch {
    /* preference simply is not remembered */
  }
}

const MystContainer = styled(MystCSSVars)`
  display: grid;
  grid-template-columns: ${(props) => (props.$noSidebar ? "1fr" : "300px 1fr")};
  transition: grid-template-columns 150ms ease;

  @media (prefers-reduced-motion: reduce) {
    transition: none;
  }
  grid-template-rows: 100%;
  height: 100%;
  font-family: "Lato";
  position: relative;

  button,
  input,
  dialog,
  textarea {
    color: inherit;
  }
`;

const Toast = styled.div`
  background-color: var(--button-bg);
  position: absolute;
  top: 10px;
  left: 50%;
  z-index: 11;
  display: flex;
  align-items: center;
  height: 40px;
  padding: 0 15px;
  gap: 15px;
  border-radius: var(--border-radius);

  button {
    color: var(--border);
    background: transparent;
    border: none;
    cursor: pointer;
    font-family: inherit;
    font-size: inherit;
  }

  a {
    display: inline-block;
    color: var(--accent-dark);
  }
`;

/** Same shape and placement as <Toast>, but it stays until the work finishes and cannot be dismissed,
 * because dismissing it would not stop the fetch. Non-blocking on purpose: the previous document
 * stays readable while the next one loads. */
const LoadingStatus = styled(Toast)`
  cursor: default;

  /* Quieter than the label above it: an explanation, not a second thing to read every time. */
  .blame {
    display: block;
    font-size: 12px;
    opacity: 0.75;
  }
  /* Both are status popups in the same corner, so stack rather than overlap when a commit toast is
     still on screen. */
  top: ${(props) => (props.$stacked ? "60px" : "10px")};

  .spinner {
    width: 16px;
    height: 16px;
    border: 2px solid var(--border);
    border-top-color: var(--accent-dark);
    border-radius: 50%;
    animation: myst-git-spin 0.7s linear infinite;
  }

  @keyframes myst-git-spin {
    to {
      transform: rotate(360deg);
    }
  }

  @media (prefers-reduced-motion: reduce) {
    .spinner {
      animation-duration: 2.4s;
    }
  }
`;

/** Double chevrons, pointing the way the index is about to move: << closes it, >> brings it back.
 *
 * This was a panel glyph - a rectangle with one edge filled - which is what a sidebar toggle looks like
 * in an IDE, and it went unrecognised: on a bar that also carries the Dual Pane button, a second
 * rectangle-with-a-divider reads as another view mode rather than as a control for the index. */
const SidebarIcon = ({ collapsed }) => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    {/* Drawn pointing left and mirrored about the centre, so both directions are the same shape. */}
    <g
      transform={collapsed ? "translate(24 0) scale(-1 1)" : undefined}
      stroke="currentColor"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
    >
      <path d="M11.5 6.5L6 12L11.5 17.5" />
      <path d="M18 6.5L12.5 12L18 17.5" />
    </g>
  </svg>
);

const CommitIcon = () => (
  <svg width="24" height="26" viewBox="0 0 24 26" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path
      d="M17.5 24.2941V18.1277C17.4997 17.8572 17.446 17.5895 17.3421 17.3398C17.2383 17.0901 17.0862 16.8634 16.8946 16.6725C16.703 16.4817 16.4757 16.3304 16.2256 16.2275C15.9755 16.1246 15.7076 16.0719 15.4372 16.0726H8.56282C8.29239 16.0719 8.02448 16.1246 7.7744 16.2275C7.52433 16.3304 7.297 16.4817 7.10542 16.6725C6.91383 16.8634 6.76175 17.0901 6.65787 17.3398C6.55398 17.5895 6.50034 17.8572 6.5 18.1277V24.2941M17.5 1.36884V4.42554C17.4997 4.69597 17.446 4.96369 17.3421 5.21337C17.2383 5.46306 17.0862 5.68981 16.8946 5.88068C16.703 6.07154 16.4757 6.22277 16.2256 6.32571C15.9755 6.42865 15.7076 6.48128 15.4372 6.4806H8.56282C8.29239 6.48128 8.02448 6.42865 7.7744 6.32571C7.52433 6.22277 7.297 6.07154 7.10542 5.88068C6.91383 5.68981 6.76175 5.46306 6.65787 5.21337C6.55398 4.96369 6.50034 4.69597 6.5 4.42554V1.00001M17.5 1.36884C16.9633 1.12578 16.3809 1.00004 15.7918 1.00001H6.5M17.5 1.36884C17.9452 1.57072 18.3554 1.85284 18.7087 2.20354L21.7913 5.27707C22.1741 5.65796 22.4779 6.11066 22.6853 6.60922C22.8927 7.10778 22.9997 7.64238 23 8.18237V20.1814C22.9997 20.7224 22.8927 21.258 22.6851 21.7576C22.4776 22.2572 22.1736 22.7109 21.7905 23.0929C21.4075 23.4749 20.9529 23.7776 20.4527 23.9837C19.9525 24.1898 19.4166 24.2953 18.8756 24.2941H5.12565C4.58468 24.2955 4.04874 24.1902 3.54851 23.9842C3.04828 23.7783 2.59356 23.4757 2.21037 23.0938C1.82719 22.712 1.52305 22.2583 1.31536 21.7588C1.10767 21.2593 1.00051 20.7237 1 20.1827V5.11013C1.00068 4.56927 1.10797 4.03384 1.31573 3.53447C1.5235 3.0351 1.82766 2.58159 2.21083 2.19986C2.594 1.81813 3.04866 1.51568 3.54881 1.3098C4.04896 1.10392 4.58478 0.998652 5.12565 1.00001H6.5"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  </svg>
);

/** The branch glyph at status-bar size. */
const StatusBranchIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
    <line x1="6" y1="3" x2="6" y2="15" />
    <circle cx="18" cy="6" r="3" />
    <circle cx="6" cy="18" r="3" />
    <path d="M18 9a9 9 0 0 1-9 9" />
  </svg>
);

/** The merge request glyph at status-bar size. */
const StatusMergeRequestIcon = () => (
  <svg
    width="14"
    height="14"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    stroke-width="2"
    stroke-linecap="round"
    stroke-linejoin="round"
    aria-hidden="true"
  >
    <circle cx="18" cy="18" r="3" />
    <circle cx="6" cy="6" r="3" />
    <path d="M13 6h3a2 2 0 0 1 2 2v7" />
    <line x1="6" y1="9" x2="6" y2="21" />
  </svg>
);

/** The commit glyph at status-bar size. */
const StatusCommitIcon = () => (
  <svg
    width="14"
    height="14"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    stroke-width="2"
    stroke-linecap="round"
    stroke-linejoin="round"
    aria-hidden="true"
  >
    <circle cx="12" cy="12" r="4" />
    <line x1="1.05" y1="12" x2="8" y2="12" />
    <line x1="16" y1="12" x2="22.95" y2="12" />
  </svg>
);

const MystEditorGit = ({
  repo = "repo",
  initialBranches = ["main"],
  getBranches = async () => [],
  searchBranches = async () => [],
  getCommits = async () => [],
  searchCommits = async () => [],
  getFiles = async () => [],
  getText = async () => "",
  initialState = null,
  commitChanges = async () => {},
  createBranch = null,
  fileExists = null,
  // Every file under a folder, `(commit, dir) => paths`: what moves when a chapter's folder does.
  listFiles = null,
  // From an add-on (see plugins.js): whether this user may open a branch. Everything that switches
  // branch asks it first; without one, every branch is open.
  canOpenBranch = null,
  // `{ protected, canPush }` for a listed branch, so the picker can mark protected ones.
  getBranchStatus = null,
  getOpenMergeRequests = async () => [],
  // The GitLab project the book lives in. Without a web URL there is nowhere to open a merge request,
  // so the merge request controls are left out.
  projectId = null,
  projectWebUrl = null,
  defaultBranch = null,
  index = null,
  docsRoot = "",
  // Named so the wait can be attributed to something the reader recognises. Each backend says which it
  // is; GitLab when none does.
  serverName = "GitLab",
  // What the forge calls a merge request and how it numbers them (see mergeRequest.js), and the link
  // that starts one. From the backend.
  review = GITLAB_REVIEW,
  newMergeRequestUrl = null,
  // Default here so a consumer can omit it entirely: the three sites below read collaboration before
  // createMystState applies its defaults. Local-mode values mirror the git demo (git.html).
  collaboration = { enabled: false, mode: "local", wsUrl: "#" },
  // COMBINE's, unless replaced with another `{ logo, mark, secondary }` or turned off with `false`.
  branding: brandingOption,
  // Holds images uploaded in the editor until they are committed; created by the mount function.
  assetStore = null,
  ...props
}) => {
  const branding = resolveBranding(brandingOption);
  const branches = useSignal(initialBranches);
  const branch = useSignal(initialBranches[0]);
  const commits = useSignal([]);
  const commit = useSignal();
  const files = useSignal([]);
  const file = useSignal();
  const room = useComputed(() => (commit.value && file.value ? `${repo}/${branch.value}/${commit.value.hash}/${file.value}` : ""));
  const toast = useSignal({ content: null, timeout: null });
  const branchPickerOpen = useSignal(false);
  const commitPickerOpen = useSignal(false);
  const commitSummary = useSignal(null);
  const mergeRequestModalOpen = useSignal(false);
  const openMrForBranch = useSignal(null);
  // Bumped to look for an open merge request again: the author creates it in GitLab, in another tab.
  const mrCheck = useSignal(0);
  // Status bar items contributed from outside, e.g. by an add-on (git.addStatusItem). Kept apart
  // because the list below is rebuilt whenever the branch or commit changes.
  const extraStatusItems = useSignal([]);
  const commentStateToApply = useRef(null);
  const { docsWithChanges, statusSocket } = useWatchChanges({ ...props, collaboration }, repo);
  const indexFile = useSignal();

  useEffect(() => {
    let active = true;
    const curr = branch.value;
    void mrCheck.value;
    if (!curr || !projectWebUrl) {
      openMrForBranch.value = null;
      return;
    }
    (async () => {
      try {
        const mrs = await getOpenMergeRequests(curr);
        if (active) {
          openMrForBranch.value = Array.isArray(mrs) && mrs.length > 0 ? mrs[0] : null;
        }
      } catch {
        if (active) openMrForBranch.value = null;
      }
    })();
    return () => {
      active = false;
    };
  }, [branch.value, getOpenMergeRequests, mrCheck.value]);

  useEffect(() => {
    if (!projectWebUrl) return;
    const recheck = () => document.visibilityState === "visible" && mrCheck.value++;
    document.addEventListener("visibilitychange", recheck);
    return () => document.removeEventListener("visibilitychange", recheck);
  }, [projectWebUrl]);
  // Which table of contents we actually found, and what it listed. `index` names one explicitly;
  // otherwise resolveToc() probes the known filenames.
  const indexPath = useSignal(index ?? null);
  const tocEntries = useSignal([]);
  const tocCache = useRef(new Map());
  // A git fetch that outlasts SLOW_FETCH_MS puts a status popup on screen, so a slow repository does
  // not look like a frozen editor. Below the threshold nothing appears, so a fast switch stays quiet.
  const loading = useSignal(null);
  const loadDepth = useRef(0);
  // Set once a sequence passes BLAME_SERVER_MS, to say whose wait this is.
  const waitingOnServer = useSignal(false);
  const blameTimer = useRef(null);
  // Whether the page index is hidden, remembered per editor: someone who works with it closed should
  // not have to close it again on every load. A browser that refuses storage just starts open.
  const sidebarCollapsed = useSignal(readCollapsedPreference(props.id));
  // The toggle writes the preference itself rather than relying only on this effect: effects flush
  // after the render they belong to, so collapsing and immediately reloading could lose the write.
  // The effect stays for changes made through the exposed signal rather than the button.
  useSignalEffect(() => storeCollapsedPreference(props.id, sidebarCollapsed.value));
  const { collab, options, editorView, text: mystText } = useContext(MystState);
  const commitDocuments = useRef(null);
  const commitAssets = useRef([]);

  const docsPrefix = docsRoot === "" || docsRoot === "." || docsRoot === "./" ? "" : `${docsRoot}/`;

  // What `/`-prefixed image paths are relative to: the folder holding myst.yml, which is the project root
  // MyST itself uses; the docs root when the book has no myst.yml.
  const projectRoot = useComputed(() =>
    indexPath.value && /(^|\/)myst\.ya?ml$/.test(indexPath.value) ? dirname(indexPath.value) : docsPrefix.replace(/\/$/, ""),
  );
  // Images uploaded on this branch and not committed yet.
  const pendingImages = useComputed(() => {
    // Read only to subscribe: the store's own maps are not signals.
    void assetStore?.version.value;
    return assetStore ? assetStore.pendingFor(branch.value) : [];
  });

  /**
   * Find and read this commit's table of contents. A consumer that sets `index` gets exactly that
   * file; otherwise we probe the Jupyter Book filenames under the docs root, then the repository
   * root. A missing file reads as empty text in both backends, so the first non-empty answer wins
   * and a myst.yml repository costs a single request.
   *
   * Memoised per commit, because both the sidebar and the file-opening paths need it and they run
   * concurrently — the cache holds the in-flight promise, not just the result.
   */
  function resolveToc(forBranch, forCommit) {
    const key = `${forBranch}/${forCommit?.hash}`;
    const cached = tocCache.current.get(key);
    if (cached) return cached;

    // An explicit `index` is tried first but is no longer the only thing tried: a config can name a
    // file that turns out to hold no table of contents, and falling back beats showing no index.
    const probes = [...TOC_CANDIDATES.map((c) => docsPrefix + c), ...(docsPrefix ? TOC_CANDIDATES : [])];
    const candidates = index ? [index, ...probes] : probes;

    const pending = (async () => {
      const seen = new Set();

      /** Read one candidate, following `extends:` when the file itself carries no table of contents. */
      async function readFrom(path, depth) {
        if (!path || seen.has(path) || depth > maxTocExtendsDepth) return null;
        seen.add(path);
        const text = await getText(forBranch, forCommit, path);
        if (!text?.trim()) return null;

        const entries = isTocYaml(path) ? parseTocYaml(text, docsPrefix) : parseToctree(text, docsPrefix);
        if (entries.length) return { path, text, entries };

        // A myst.yml that keeps its toc in a separate file has no `project.toc` of its own, only
        // `extends: toc.yml`. Without following that, such a project reads as having no index at all.
        if (!isTocYaml(path)) return null;
        for (const next of tocExtends(text, path)) {
          const found = await readFrom(next, depth + 1);
          if (found) return found;
        }
        return null;
      }

      for (const path of candidates) {
        const found = await readFrom(path, 0);
        if (found) return found;
      }
      return { path: null, text: "", entries: [] };
    })();

    tocCache.current.set(key, pending);
    return pending;
  }

  /** Load the table of contents into the signals the sidebar renders from, and hand back its entries. */
  async function loadToc(forBranch, forCommit) {
    const toc = await resolveToc(forBranch, forCommit);
    batch(() => {
      indexPath.value = toc.path;
      indexFile.value = toc.text;
      tocEntries.value = toc.entries;
    });
    return toc.entries;
  }

  /**
   * Pick the document to open. The table of contents is authoritative when it has one, so a book
   * opens on its own landing page; README.md and index.md are the fallback for a repository that
   * has no table of contents at all.
   */
  function defaultFileFrom(tocFiles, resolvedFiles) {
    const firstIndexed = tocFiles.find((f) => resolvedFiles.includes(f));
    if (firstIndexed) return firstIndexed;
    for (const fallback of [docsPrefix + "README.md", "README.md", docsPrefix + "index.md", "index.md"]) {
      if (resolvedFiles.includes(fallback)) return fallback;
    }
    return resolvedFiles[0];
  }

  // The table of contents as a tree, for the sidebar to show chapters and rearrange entries. Only a YAML
  // table of contents has one; a `{toctree}` index stays a flat list.
  const tocTree = useComputed(() =>
    indexPath.value && isTocYaml(indexPath.value) && indexFile.value ? parseTocTree(indexFile.value, docsPrefix) : [],
  );

  // Lifted out of <Sidebar> so it can also be exposed to an external integration via externalSidebar.
  const indexedFiles = useComputed(() => {
    // A markdown index is itself a page worth listing; a YAML table of contents is not a document.
    const entries = indexPath.value && !isTocYaml(indexPath.value) ? [{ file: indexPath.value, fileName: indexPath.value }] : [];
    entries.push(...tocEntries.value);

    if (!entries.some((e) => e.file === docsPrefix + "README.md")) {
      // Add README.md right after the index file (index 1) so it appears at the top of the Page index
      entries.splice(1, 0, { file: docsPrefix + "README.md", fileName: "README.md" });
    }

    return entries.filter((f) => files.value.some((file) => file == f.file));
  });
  const unIndexedFiles = useComputed(() => files.value.filter((f) => !indexedFiles.value.some((iF) => iF.file === f)));
  const markedFiles = useComputed(() =>
    files.value.filter((f) =>
      docsWithChanges.value.some(
        ({ branch: branchName, commitHash, file: changedFile }) =>
          branchName == branch.value && commit.value?.hash === commitHash && f == changedFile,
      ),
    ),
  );

  // Pages on this branch and commit whose changes have not been committed yet, edited here or by anyone else.
  const uncommittedCount = useComputed(
    () => new Set(docsWithChanges.value.filter((d) => d.branch === branch.value && d.commitHash === commit.value?.hash).map((d) => d.file)).size,
  );

  useSignalEffect(() => {
    const commitHash = commit.value?.hash;
    if (!branch.value || !commitHash) {
      options.statusItems.value = [];
      return;
    }
    const n = uncommittedCount.value;
    const openMr = openMrForBranch.value;
    options.statusItems.value = [
      {
        id: "commit",
        icon: StatusCommitIcon,
        label: shortHash(commitHash),
        mono: true,
        title: `Switch commit (now: ${commit.value.message ?? commitHash})`,
        onClick: () => (commitPickerOpen.value = true),
        attrs: { "data-git-commit": "", "aria-label": `Commit ${shortHash(commitHash)}. Switch commit` },
      },
      {
        id: "branch",
        icon: StatusBranchIcon,
        label: branch.value,
        title: "Switch or create branch",
        onClick: () => (branchPickerOpen.value = true),
        attrs: { "data-git-branch": "", "aria-label": `Branch ${branch.value}. Switch or create branch` },
      },
      projectWebUrl && {
        id: "merge-request",
        icon: StatusMergeRequestIcon,
        label: openMr ? `${review.short} ${review.prefix}${openMr.iid}` : review.short,
        title: openMr
          ? `Branch '${branch.value}' has an open ${review.name} (${review.prefix}${openMr.iid}): ${openMr.title}. Click to view or create one.`
          : `Create ${serverName} ${review.name}`,
        onClick: () => (mergeRequestModalOpen.value = true),
        attrs: {
          "data-git-mr": "",
          ...(openMr ? { "data-git-open-mr": "" } : {}),
          "aria-label": openMr ? `${review.title} ${review.prefix}${openMr.iid}` : `Create ${review.name}`,
        },
      },
      ...(n > 0 ? [{ id: "uncommitted", dot: true, label: `${n} ${n === 1 ? "page" : "pages"} with uncommitted changes` }] : []),
      ...(pendingImages.value.length > 0
        ? [
            {
              id: "pending-images",
              dot: true,
              label: `${pendingImages.value.length} ${pendingImages.value.length === 1 ? "image" : "images"} waiting to be committed`,
            },
          ]
        : []),
      ...extraStatusItems.value,
    ].filter(Boolean);
  });

  // The brand's mark stands in beside the title while the page index - and the logo on it - is closed.
  useSignalEffect(() => {
    options.titleMark.value = branding?.mark && sidebarCollapsed.value && !options.externalSidebar.value ? branding.mark : null;
  });

  // Resolved titles for external integrations only; the built-in <TableOfContents> resolves its own.
  const pageIndex = useSignal([]);
  useSignalEffect(() => {
    if (!options.externalSidebar.value) return;
    const entries = indexedFiles.value;
    (async () => {
      const resolved = entries.map((f) => ({ ...f, title: f.fileName || f.file }));
      pageIndex.value = resolved;
    })();
  });

  const dialogRequest = useSignal(null);
  const ask = (spec) => new Promise((resolve) => (dialogRequest.value = { ...spec, resolve }));

  function hasUnsavedText() {
    if (!file.peek()) return false;
    const currentText = collab.peek()?.ytext?.toString() ?? editorView.peek()?.state?.doc?.toString() ?? options.initialText.peek();
    return currentText !== options.initialText.peek();
  }

  /** Text not saved, or (with `images`) uploads not committed. Uploads belong to the branch, not the page,
   * so moving to another page on the same branch keeps them; leaving the branch or the tab does not. */
  function hasUnsavedChanges({ images = true } = {}) {
    return hasUnsavedText() || (images && pendingImages.peek().length > 0);
  }

  function revertText(original = options.initialText.peek()) {
    const view = editorView.peek();
    view?.dispatch({ changes: { from: 0, to: view.state.doc.length, insert: original } });
  }

  async function confirmDiscardChanges({ images = false } = {}) {
    const text = hasUnsavedText();
    const uploads = images ? pendingImages.peek().length : 0;
    if (!text && !uploads) return true;
    const lost = [
      text && "unsaved changes in this file",
      uploads && `${uploads} uploaded ${uploads === 1 ? "image" : "images"} not committed yet`,
    ].filter(Boolean);
    const discard = await ask({
      title: "Discard unsaved changes?",
      message: `You have ${lost.join(" and ")}. Switching away will discard ${lost.length > 1 ? "them" : "it"}.`,
      fields: [],
      submitLabel: "Discard changes",
      cancelLabel: "Keep editing",
    });
    if (discard && uploads) assetStore.discard(branch.peek());
    // Put the loaded text back now. Loading the next page only replaces the editor's text when it differs
    // from the last loaded text, so the same page on another branch (or the same branch) would keep the
    // discarded edits. With collaboration the edits live in the room, which the switch leaves.
    if (discard && text && !collab.peek()) revertText();
    return discard;
  }

  async function switchFile(newFile) {
    if (!(await confirmDiscardChanges({ images: false }))) return;
    const text = await withLoadingStatus(`Loading ${newFile}`, () => getText(branch.peek(), commit.peek(), newFile));
    batch(() => {
      file.value = newFile;
      options.initialText.value = text;
    });
  }

  /**
   * Where a link in the preview goes in this version of the book: the page it opens, if any, and the
   * heading. MyST resolves a link against the page it is in (`/…` against the project root), and a page
   * can be named without its extension. Null for a link that leaves the book (another site, an email).
   */
  function previewLinkTarget(href) {
    if (!href || isExternalUrl(href)) return null;
    const cut = href.indexOf("#");
    let anchor = cut < 0 ? "" : href.slice(cut + 1);
    try {
      anchor = decodeURIComponent(anchor);
    } catch {}
    const pathPart = (cut < 0 ? href : href.slice(0, cut)).split("?")[0];
    if (!pathPart) return { path: null, file: null, anchor };
    const path = resolveAssetPath(file.peek(), pathPart, projectRoot.peek());
    if (!path) return null;
    const pages = files.peek();
    return { path, file: [path, `${path}.md`, `${path}.rst`, `${path}/index.md`].find((p) => pages.includes(p)) ?? null, anchor };
  }

  /** Scroll the preview to the heading (or other element) with this id, if it has one. */
  function scrollPreviewTo(anchor) {
    const preview = mystText.preview.peek();
    if (!anchor || !preview) return false;
    const el = preview.querySelector(`#${CSS.escape(anchor)}`);
    el?.scrollIntoView({ block: "start" });
    return !!el;
  }

  /** Open a page from a link, then go to its heading once the preview shows the page. */
  async function openLinkedPage(target, anchor) {
    if (target === file.peek()) return scrollPreviewTo(anchor);
    const preview = mystText.preview.peek();
    // Watched from before the switch, so the new page's first render is not missed.
    const rendered = preview
      ? new Promise((resolve) => {
          const observer = new MutationObserver(() => {
            observer.disconnect();
            clearTimeout(timer);
            requestAnimationFrame(resolve);
          });
          const timer = setTimeout(() => {
            observer.disconnect();
            resolve();
          }, 3000);
          observer.observe(preview, { childList: true, subtree: true, characterData: true });
        })
      : Promise.resolve();
    await switchFile(target);
    // Kept on the page when the author chose to keep editing it.
    if (file.peek() !== target || !anchor) return;
    await rendered;
    scrollPreviewTo(anchor);
  }

  // A link between pages points at a file in the repository, which the site hosting the editor does not
  // serve: following it would leave the editor for a page that is not there. Open it in the editor
  // instead. Links to other sites are left alone.
  useSignalEffect(() => {
    const preview = mystText.preview.value;
    if (!preview) return;
    const onClick = (ev) => {
      if (ev.defaultPrevented || ev.button !== 0) return;
      const link = ev.target instanceof Element ? ev.target.closest("a[href]") : null;
      if (!link || !preview.contains(link)) return;
      const target = previewLinkTarget(link.getAttribute("href"));
      if (!target) return;
      ev.preventDefault();
      if (!target.path) scrollPreviewTo(target.anchor);
      else if (target.file) openLinkedPage(target.file, target.anchor);
      else toastNotify({ text: `${target.path} is not a page in this version of the book.` });
    };
    preview.addEventListener("click", onClick);
    return () => preview.removeEventListener("click", onClick);
  });

  function scrollToHeading(pos) {
    const view = editorView.peek();
    if (!view) return;
    view.dispatch({ selection: { anchor: pos, head: pos }, effects: EditorView.scrollIntoView(pos, { y: "start" }) });
  }

  useEffect(() => {
    window.myst_editor[props.id].git = {
      branch,
      branches,
      commits,
      commit,
      files,
      file,
      room,
      statusSocket,
      indexFile,
      indexedFiles,
      unIndexedFiles,
      markedFiles,
      pageIndex,
      loading,
      waitingOnServer,
      sidebarCollapsed,
      projectRoot,
      pendingImages,
      switchFile,
      switchBranch,
      createBranch: (name, source) => (createBranch ? createBranch(name, source) : null),
      scrollToHeading,
      openMergeRequest: openMrForBranch,
      openMergeRequestModal: () => (mergeRequestModalOpen.value = true),
      /** Show a short message in the editor's toast, e.g. from an add-on. */
      notify: (text) => toastNotify({ text }),
      /** Add an item to the status bar (same shape as `statusItems`); returns a function removing it. */
      addStatusItem: (item) => {
        extraStatusItems.value = [...extraStatusItems.peek(), item];
        return () => (extraStatusItems.value = extraStatusItems.peek().filter((i) => i !== item));
      },
      /** Open the branch picker. */
      openBranchPicker: () => (branchPickerOpen.value = true),
    };
    options.onReady.value?.({ state: window.myst_editor[props.id].state, git: window.myst_editor[props.id].git });
  }, [props.id]);

  useEffect(() => {
    const handleBeforeUnload = (e) => {
      if (hasUnsavedChanges()) {
        e.preventDefault();
        e.returnValue = "";
      }
    };
    window.addEventListener("beforeunload", handleBeforeUnload);
    return () => window.removeEventListener("beforeunload", handleBeforeUnload);
  }, []);

  useSignalEffect(() => {
    if (!room.value) return;
    const current = options.collaboration.peek();
    options.collaboration.value = { ...current, room: room.value, mode: collaboration.mode };
  });

  useEffect(() => {
    options.onSubtitleClick.value = (ev) => {
      if (props.onSubtitleClick?.(ev)) return true;
      if (ev.target.closest?.("[data-git-branch]")) {
        ev.preventDefault();
        branchPickerOpen.value = true;
        return true;
      }
      if (ev.target.closest?.("[data-git-commit]")) {
        ev.preventDefault();
        commitPickerOpen.value = true;
        return true;
      }
      if (ev.target.closest?.("[data-git-mr]")) {
        ev.preventDefault();
        mergeRequestModalOpen.value = true;
        return true;
      }
      return false;
    };
    options.onRefresh.value = refreshGitView;
  }, []);

  useSignalEffect(() => {
    const commitHash = commit.value?.hash;
    if (!branch.value || !commitHash || options.statusBar.value) {
      options.subtitle.value = "";
      return;
    }
    const openMr = openMrForBranch.value;
    // Without the status bar this is the only way to the merge request dialog.
    const mrLink = projectWebUrl
      ? ` · <span class="git-branch-link" data-git-mr title="Create ${escapeHtml(`${serverName} ${review.name}`)}">${openMr ? `${review.short} ${review.prefix}${escapeHtml(String(openMr.iid))}` : escapeHtml(sentenceCase(review.name))}</span>`
      : "";
    options.subtitle.value = `<span class="git-branch-link" data-git-branch>${escapeHtml(branch.value)}</span> @ <span class="git-commit-link" data-git-commit title="${escapeHtml(commit.value.message)}">${escapeHtml(shortHash(commitHash))}</span>${mrLink}`;
  });

  async function loadBranches(page) {
    const moreBranches = await getBranches(page);
    if (moreBranches.length == 0) throw "Empty branches";
    branches.value = [...new Set([...branches.value, ...moreBranches])];
  }

  async function loadCommits(page) {
    let moreCommits = await getCommits(branch.value, page);
    if (moreCommits.length == 0) throw "Empty commits";
    moreCommits = moreCommits.filter((newC) => !commits.value.some((oldC) => newC.hash == oldC.hash));
    commits.value = [...commits.value, ...moreCommits];
  }

  // Re-fetch the first page of branches and of the current branch's commits, so the pickers show newly
  // pushed refs. Deliberately does not touch `branch`/`commit` or the editor document — the user stays
  // on the same branch/commit with unsaved work intact.
  async function refreshGitView() {
    const currBranch = branch.peek();
    try {
      const [freshBranches, freshCommits] = await Promise.all([getBranches(1), getCommits(currBranch, 1)]);
      batch(() => {
        branches.value = [...new Set([currBranch, ...freshBranches])];
        commits.value = freshCommits;
      });
    } catch {
      // Leave the current lists in place if the refresh fails.
    }
  }

  const branchRow = (b) => {
    const status = getBranchStatus?.(b);
    return {
      label: b,
      value: b,
      marked: docsWithChanges.value.some((d) => d.branch === b),
      tag: status?.protected ? "protected" : null,
      tagTitle: status?.canPush === false ? "Protected branch: you cannot commit to it" : "Protected branch",
    };
  };
  const commitRow = (c) => ({
    label: `[${shortHash(c.hash)}] ${c.message}`,
    value: c.hash,
    message: c.message,
    marked: docsWithChanges.value.some((d) => d.branch === branch.peek() && d.commitHash === c.hash),
  });
  const branchOptions = useComputed(() => branches.value.map(branchRow));
  const commitOptions = useComputed(() => commits.value.map(commitRow));

  /**
   * Run a git fetch, and if it is still going after SLOW_FETCH_MS put a status popup on screen until
   * it finishes. The delay is the whole point: opening a file is usually instant, and a spinner that
   * flashes on every click is worse than none. Nested calls are counted, so a branch switch (commits,
   * then files, then text) shows one popup for the whole sequence rather than three in a row.
   */
  async function withLoadingStatus(label, work) {
    // Timed from the start of the whole sequence rather than per call: a branch switch is three
    // fetches back to back, and the person waiting is waiting for all of them.
    if (loadDepth.current === 0) blameTimer.current = setTimeout(() => (waitingOnServer.value = true), BLAME_SERVER_MS);
    loadDepth.current += 1;
    const timer = setTimeout(() => (loading.value = label), SLOW_FETCH_MS);
    try {
      return await work();
    } finally {
      clearTimeout(timer);
      loadDepth.current -= 1;
      if (loadDepth.current === 0) {
        clearTimeout(blameTimer.current);
        loading.value = null;
        waitingOnServer.value = false;
      }
    }
  }

  function toastNotify(content) {
    if (toast.value.timeout) {
      clearTimeout(toast.value.timeout);
    }
    toast.value = { content, timeout: setTimeout(() => (toast.value = { content: null }), 5000) };
  }

  function toggleSidebar() {
    const collapsed = !sidebarCollapsed.peek();
    storeCollapsedPreference(props.id, collapsed);
    sidebarCollapsed.value = collapsed;
    // The control that was pressed is gone with the panel (or was not there before it), so keep the
    // keyboard where it was: on the toggle, now in its other home.
    requestAnimationFrame(() => props.parent?.querySelector?.('[name="toggle-sidebar"]')?.focus());
  }

  // In the toolbar only while the index is closed; while it is open the control sits on the panel it
  // collapses (see collapseButton below), which is where people look for it.
  const sidebarButton = {
    id: "toggle-sidebar",
    tooltip: "Show the page index",
    icon: () => <SidebarIcon collapsed={sidebarCollapsed.value} />,
    hidden: () => !sidebarCollapsed.value && !options.externalSidebar.value,
    expanded: () => false,
    action: toggleSidebar,
  };

  const collapseButton = (
    <button
      type="button"
      name="toggle-sidebar"
      title="Hide the page index"
      aria-label="Hide the page index"
      aria-expanded="true"
      aria-controls="page-index-panel"
      onClick={toggleSidebar}
    >
      <SidebarIcon collapsed={false} />
    </button>
  );

  async function handleCreateBranch(initialName = "") {
    if (!(await confirmDiscardChanges())) return;
    const defaultName = typeof initialName === "string" ? initialName.trim() : "";
    const answers = await ask({
      title: "Create new branch",
      fields: [
        {
          name: "branchName",
          label: "New branch name",
          value: defaultName,
          placeholder: "e.g. feature-branch",
          required: true,
          autoFocus: !defaultName,
        },
        {
          name: "source",
          label: "Source (branch or commit)",
          type: "autocomplete",
          value: branch.peek(),
          placeholder: "Select branch or search commits...",
          hint: "Branch name or commit SHA to branch from",
          required: true,
          branches: branches.value,
          commits: commits.value,
          currentBranch: branch.peek(),
          searchCommits: (q) => searchCommits(q, branch.peek()),
          searchBranches: (q) => searchBranches(q),
        },
      ],
      submitLabel: "Create branch",
      cancelLabel: "Cancel",
    });
    if (!answers) return;

    const newBranch = (answers.branchName || "").trim();
    let sourceRef = (answers.source || "").trim();
    if (!newBranch || !sourceRef) return;

    if (sourceRef.includes("@")) {
      sourceRef = sourceRef.split("@")[1].trim() || sourceRef.split("@")[0].trim();
    }

    if (!branches.peek().includes(sourceRef)) {
      const hashMatch = sourceRef.match(/\b([a-f0-9]{7,40})\b/i);
      if (hashMatch) {
        sourceRef = hashMatch[1];
      } else {
        const matchedCommit = commits.peek().find((c) => c.message?.toLowerCase() === sourceRef.toLowerCase());
        if (matchedCommit) {
          sourceRef = matchedCommit.hash;
        }
      }
    }

    if (branches.peek().includes(newBranch)) {
      toastNotify({ text: `Branch '${newBranch}' already exists.` });
      return;
    }

    try {
      await withLoadingStatus(`Creating branch ${newBranch}`, async () => {
        if (createBranch) {
          await createBranch(newBranch, sourceRef);
        }
        await switchBranch(newBranch, true, true);
      });
      toastNotify({ text: `Branch '${newBranch}' created.` });
    } catch (error) {
      console.error("Failed to create branch:", error);
      toastNotify({ text: `Error creating branch: ${error.message || error}` });
    }
  }

  /* Adding and moving pages. Each is committed straight away, on top of the branch, and the editor then
   * opens that commit: the table of contents and the files have to change together, and a half-done
   * change to either would leave the book broken in between. Edits and comments not committed yet are
   * carried over to the new commit (see commitRestructure), so nobody has to commit first. */

  const docsDir = docsPrefix.replace(/\/$/, "");
  const inDocs = (name) => (docsDir ? `${docsDir}/${name}` : name);
  const tocLabel = (node) => node.title || node.fileName || node.file?.split("/").pop() || "Untitled";
  // Whether each page has a room on the collaboration server, where uncommitted work of everyone lives.
  const roomsOnServer = () => !!options.collaboration.peek()?.enabled && collaboration.mode === "websocket";

  /** Whether the table of contents can be changed from here, explaining why not when it cannot. */
  async function readyToRestructure(action) {
    if (!indexPath.peek() || !isTocYaml(indexPath.peek())) {
      toastNotify({ text: `To ${action}, the book needs a YAML table of contents (myst.yml or _toc.yml).` });
      return false;
    }
    // The commit dialog holds the changed pages, locked, for a commit onto this version.
    if (commitDocuments.current) {
      toastNotify({ text: `Finish or cancel the commit first, then ${action}.` });
      return false;
    }
    // A table of contents from an older commit, committed on top of the branch, would undo later changes.
    const tip = await withLoadingStatus("Checking for newer commits", () => getCommits(branch.peek(), 1))
      .then((list) => list?.[0])
      .catch(() => null);
    if (tip && tip.hash !== commit.peek()?.hash) {
      toastNotify({ text: `This is not the latest commit of ${branch.peek()}. Open the latest one to ${action}.` });
      return false;
    }
    return true;
  }

  /** Whether a file is already in the repository at this commit, pages and other files alike. */
  async function pathTaken(path) {
    if (files.peek().includes(path)) return true;
    return fileExists ? !!(await fileExists(commit.peek(), path).catch(() => false)) : false;
  }

  /** The pages of this version that may hold work not committed yet, by anyone: the open one, through the
   * editor's own connection, and with a collaboration server every page it marks as changed, each with a
   * connection of its own to its room. */
  async function gatherUncommitted() {
    const current = file.peek();
    const hash = commit.peek().hash;
    const others = roomsOnServer()
      ? [
          ...new Set(
            docsWithChanges
              .peek()
              .filter((d) => d.branch === branch.peek() && d.commitHash === hash)
              .map((d) => d.file),
          ),
        ].filter((f) => f !== current)
      : [];
    const docs = others.length ? await setupFileConnections(repo, { ...props, collaboration }, branch.peek(), hash, others, getText) : [];
    if (current) docs.unshift({ client: collab.peek(), file: current, initialText: options.initialText.peek(), current: true });
    return docs;
  }

  /** A page's text and comments as they are now. */
  function snapshot(d) {
    const text = d.client ? d.client.ytext.toString() : (editorView.peek()?.state?.doc?.toString() ?? d.initialText);
    const comments = d.client?.ycomments?.comments?.peek()?.length ? d.client.ycomments.encodeState() : null;
    return { ...d, text, comments };
  }

  /** Wait until `test` holds, reading signals, for up to `ms`; resolves with whether it did. */
  function waitFor(test, ms = 5000) {
    return new Promise((resolve) => {
      let done = false;
      let stop = null;
      const finish = (ok) => {
        if (done) return;
        done = true;
        clearTimeout(timer);
        queueMicrotask(() => stop?.());
        resolve(ok);
      };
      const timer = setTimeout(() => finish(false), ms);
      stop = effect(() => {
        if (test()) finish(true);
      });
      if (done) stop();
    });
  }

  /** Put carried work into a page's room on the new version. An empty room first gets the committed
   * text, marked as its starting point the way the editor marks it (see CodeMirror.jsx); the edits then
   * go on top, so the server counts them as uncommitted changes. */
  function fillRoom(client, committed, edited, comments) {
    if (client.ytext.length === 0) {
      client.ydoc.transact(() => {
        if (committed) client.ytext.insert(0, committed);
        client.metaMap.set("initial", !!committed);
      });
    }
    replaceText(client.ytext, edited);
    if (comments) client.ycomments?.applyState(comments);
  }

  /** The open page's carried work, when it has no room on a server to be put in beforehand: once the
   * editor shows the new version, its text is replaced with the edited one. */
  async function carryIntoEditor({ text, comments }) {
    if (options.collaboration.peek()?.enabled) {
      const ready = await waitFor(() => collab.value?.provider?.roomname === room.peek() && collab.value.ready.value && !collab.value.lockMsg.value);
      if (!ready) return false;
      replaceText(collab.peek().ytext, text);
      if (comments) collab.peek().ycomments?.applyState(comments);
      return true;
    }
    // Without collaboration the editor puts the loaded text back when it takes the new room. Both happen
    // in signal effects that run on the next animation frame, one after the other; the edits go in after.
    if (!(await waitFor(() => options.collaboration.value.room === room.value))) return false;
    await nextFrame();
    const view = editorView.peek();
    if (!view) return false;
    if (view.state.doc.toString() !== text) view.dispatch({ changes: { from: 0, to: view.state.doc.length, insert: text } });
    return true;
  }

  /**
   * Commit a change to the book's structure and open the new version.
   *
   * Edits and comments on this version that are not committed yet, anyone's, go with it: each changed
   * page is locked while the commit is made, then its work is put into the same page of the new version
   * (at its new path if it moved, with its links updated like the committed text) and whoever is on it
   * follows, as they do after a commit. The work also stays on the old version, unmarked.
   *
   * @param {string} message
   * @param {object[]} documents what the commit changes (see commitChanges)
   * @param {{ openPath?: string|null, retarget?: (path: string) => string|null }} [opts] the page to open
   *   afterwards, and the new path of each file that moves
   */
  async function commitRestructure(message, documents, { openPath = null, retarget = () => null } = {}) {
    const fromHash = commit.peek().hash;
    const docs = await withLoadingStatus("Collecting uncommitted changes", gatherUncommitted);
    let released = false;
    const release = () => {
      if (released) return;
      released = true;
      cleanupConnections(docs, collab);
    };
    let newConnections = [];
    try {
      docs.forEach((d) => d.client?.lock?.("The book is being rearranged. This page reopens on the new version, edits included."));
      // Read once locked, so nothing typed in the meantime is left behind.
      const carried = docs.map(snapshot).filter((d) => d.text !== d.initialText || d.comments);
      const { hash, webUrl } = await withLoadingStatus("Committing", () => commitChanges(message, documents));

      const root = projectRoot.peek();
      const moved = Object.fromEntries(carried.map((d) => [d.file, retarget(d.file) || d.file]));
      const work = carried.map((d) => ({
        ...d,
        to: moved[d.file],
        text: relinkReferences(d.text, { from: d.file, to: moved[d.file], retarget, projectRoot: root }),
      }));
      let carryError = null;
      if (roomsOnServer() && work.length) {
        try {
          newConnections = await withLoadingStatus("Carrying uncommitted changes over", () =>
            setupFileConnections(
              repo,
              { ...props, collaboration },
              branch.peek(),
              hash,
              work.map((w) => w.to),
              getText,
            ),
          );
          newConnections.forEach((conn, i) => fillRoom(conn.client, conn.initialText ?? "", work[i].text, work[i].comments));
        } catch (error) {
          carryError = error;
        }
      }
      if (!carryError) {
        for (const w of work) {
          w.client?.provider?.awareness?.setLocalStateField("newCommit", { hash, message, moved });
          // The work is on the new version now.
          if (roomsOnServer() && w.client?.provider?.roomname && statusSocket.current?.readyState === 1)
            statusSocket.current.send(w.client.provider.roomname);
        }
      }
      release();

      const current = file.peek();
      await switchCommit({ hash, message }, true, true, openPath ?? moved[current] ?? retarget(current) ?? null);
      const open = work.find((w) => w.current);
      if (!carryError && open && !roomsOnServer() && !(await carryIntoEditor(open))) carryError = new Error("the editor did not reopen in time");
      // A room with nobody in it may be dropped by a server that keeps nothing: hold on until the editor is in.
      if (newConnections.length) await waitFor(() => collab.value?.provider?.roomname === room.peek() && collab.value.ready.value);
      await refreshGitView();
      if (carryError) {
        console.error("Could not carry uncommitted changes over:", carryError);
        toastNotify({
          text: `Changes have been commited, but uncommitted edits could not be carried over (${carryError.message || carryError}); they are still on ${shortHash(fromHash)}. `,
          link: { text: `See in ${serverName}`, href: webUrl },
        });
      } else {
        toastNotify({ text: "Changes have been commited. ", link: { text: `See in ${serverName}`, href: webUrl } });
      }
    } finally {
      release();
      cleanupConnections(newConnections, collab);
    }
  }

  /** A page file name from what was typed: "Quick start" becomes quick-start.md. */
  function pageFileName(typed) {
    const name = typed.trim().split("/").pop() ?? "";
    const ext = /\.(md|rst|ipynb)$/i.exec(name)?.[0].toLowerCase() ?? "";
    const stem = slugify(ext ? name.slice(0, -ext.length) : name);
    return stem ? `${stem}${ext || ".md"}` : "";
  }

  async function handleAddFile() {
    if (!(await readyToRestructure("add a page"))) return;
    const tree = tocTree.peek();
    const chapters = [{ label: "(Top level)", value: "" }];
    (function collect(nodes, trail) {
      for (const n of nodes) {
        if (!n.isFolder || !n.path) continue;
        const label = trail ? `${trail} › ${tocLabel(n)}` : tocLabel(n);
        chapters.push({ label, value: n.id });
        collect(n.children, label);
      }
    })(tree, "");

    const answers = await ask({
      title: "Add a page",
      fields: [
        { name: "fileName", label: "Page name", placeholder: "e.g. Quick start", required: true, autoFocus: true, hint: "Also its first heading." },
        { name: "parent", label: "Chapter", type: "folder-select", options: chapters, value: "", allowCreate: true },
        { name: "commitMessage", label: "Commit message", value: "MyST: add a page", required: true },
      ],
      submitLabel: "Add and commit",
      cancelLabel: "Cancel",
    });
    if (!answers) return;

    const typed = (answers.fileName || "").trim();
    const name = pageFileName(typed);
    if (!name) {
      toastNotify({ text: "Give the page a name with at least one letter or digit." });
      return;
    }
    const choice = answers.parent || "";
    const newChapter = choice.startsWith("new:") ? choice.slice(4).trim() : null;
    const findNode = (nodes) => {
      for (const n of nodes) {
        if (n.id === choice) return n;
        const found = findNode(n.children);
        if (found) return found;
      }
      return null;
    };
    const chapter = newChapter || !choice ? null : findNode(tree);
    let dir = docsDir;
    if (newChapter) {
      if (!slugify(newChapter)) {
        toastNotify({ text: "Give the chapter a name with at least one letter or digit." });
        return;
      }
      dir = inDocs(slugify(newChapter));
    } else if (chapter) {
      // A chapter's own folder; a new empty one gets a folder named after it.
      dir = chapter.home ?? (chapter.children.length === 0 && slugify(chapter.title ?? "") ? inDocs(slugify(chapter.title)) : docsDir);
    }
    const path = dir ? `${dir}/${name}` : name;
    if (await pathTaken(path)) {
      toastNotify({ text: `There is already a file at ${path}.` });
      return;
    }

    try {
      const toc = newChapter
        ? addTocChapter(indexFile.peek(), { title: newChapter, file: path, prefix: docsPrefix })
        : addTocPage(indexFile.peek(), { file: path, parentPath: chapter?.path ?? null, prefix: docsPrefix });
      await commitRestructure(
        answers.commitMessage,
        [
          { file: path, text: `# ${typed.replace(/\.(md|rst|ipynb)$/i, "")}\n`, action: "create" },
          { file: indexPath.peek(), text: toc },
        ],
        { openPath: path },
      );
    } catch (error) {
      console.error("Failed to add a page:", error);
      toastNotify({ text: `Could not add the page: ${error.message || error}` });
    }
  }

  async function handleAddFolder() {
    if (!(await readyToRestructure("add a chapter"))) return;
    const answers = await ask({
      title: "Add a chapter",
      message: "A chapter is a folder with a first page, index.md, that more pages can go under.",
      fields: [
        { name: "title", label: "Chapter title", placeholder: "e.g. Week 1", required: true, autoFocus: true },
        { name: "commitMessage", label: "Commit message", value: "MyST: add a chapter", required: true },
      ],
      submitLabel: "Add and commit",
      cancelLabel: "Cancel",
    });
    if (!answers) return;

    const title = (answers.title || "").trim();
    const folder = slugify(title);
    if (!folder) {
      toastNotify({ text: "Give the chapter a title with at least one letter or digit." });
      return;
    }
    const dir = inDocs(folder);
    if (files.peek().some((f) => f.startsWith(`${dir}/`)) || (await pathTaken(`${dir}/index.md`))) {
      toastNotify({ text: `There is already a folder ${dir}. Choose another title.` });
      return;
    }

    try {
      const path = `${dir}/index.md`;
      const toc = addTocChapter(indexFile.peek(), { title, file: path, prefix: docsPrefix });
      await commitRestructure(
        answers.commitMessage,
        [
          { file: path, text: `# ${title}\n`, action: "create" },
          { file: indexPath.peek(), text: toc },
        ],
        { openPath: path },
      );
    } catch (error) {
      console.error("Failed to add a chapter:", error);
      toastNotify({ text: `Could not add the chapter: ${error.message || error}` });
    }
  }

  /** Every file the table of contents lists under these entries. */
  const tocFilesOf = (nodes) => nodes.flatMap((n) => [...(n.file ? [n.file] : []), ...tocFilesOf(n.children)]);

  /**
   * The files that can move along with an entry going into `destDir` (the folder of the chapter it goes
   * into, or the docs root at the top level), or null when there are none to offer:
   * - a page moves to `destDir` if it lives elsewhere;
   * - a chapter takes its whole folder, with everything in it (images, data, subfolders), into
   *   `destDir`, but only a folder that is the chapter's own: if a page listed elsewhere in the table of
   *   contents lives in it, moving the folder would drag that page along, so nothing is offered.
   */
  function fileMoveFor(source, destDir, tree) {
    if (destDir == null) return null;
    const join = (dir, name) => (dir ? `${dir}/${name}` : name);
    if (!source.isFolder) {
      if (!source.file || dirname(source.file) === destDir) return null;
      return { kind: "page", from: source.file, to: join(destDir, source.file.split("/").pop()) };
    }
    const home = source.home;
    if (!home || home === docsDir || !listFiles) return null;
    const to = join(destDir, home.split("/").pop());
    if (to === home || destDir === home || destDir.startsWith(`${home}/`) || indexPath.peek()?.startsWith(`${home}/`)) return null;
    const own = new Set(tocFilesOf([source]));
    if (tocFilesOf(tree).some((f) => !own.has(f) && f.startsWith(`${home}/`))) return null;
    return { kind: "folder", from: home, to };
  }

  /** The Markdown pages of this commit that refer to a moved file, with those references updated. */
  async function relinkOtherPages(retarget, skip) {
    const pages = files.peek().filter((f) => /\.md$/i.test(f) && !skip(f));
    const root = projectRoot.peek();
    const updated = await mapLimit(pages, 6, async (page) => {
      const text = await getText(branch.peek(), commit.peek(), page);
      const next = relinkReferences(text, { from: page, retarget, projectRoot: root });
      return next === text ? null : { file: page, text: next };
    });
    return updated.filter(Boolean);
  }

  /**
   * Move an entry of the table of contents before, after or into another. Only the table of contents
   * changes, unless the author also asks to move the files (see fileMoveFor). Then every link to a moved
   * file is updated, in the moved pages and in the rest of the book.
   */
  async function handleMoveItem(source, target, position) {
    if (!source?.path || !target?.path) return;
    if (!(await readyToRestructure("move pages"))) return;

    const findByPath = (nodes, path) => {
      for (const n of nodes) {
        if (n.path && n.path.length === path.length && n.path.every((v, i) => v === path[i])) return n;
        const found = findByPath(n.children, path);
        if (found) return found;
      }
      return null;
    };
    const tree = tocTree.peek();
    const chapter = position === "inside" ? target : target.path.length > 1 ? findByPath(tree, target.path.slice(0, -1)) : null;
    let offer = fileMoveFor(source, chapter ? chapter.home : docsDir, tree);
    let folderFiles = [];
    if (offer?.kind === "folder") {
      folderFiles = await withLoadingStatus(`Listing ${offer.from}`, () => listFiles(commit.peek(), offer.from)).catch((error) => {
        console.error(`Could not list ${offer.from}:`, error);
        return [];
      });
      if (!folderFiles.length) offer = null;
    }

    const where = position === "inside" ? `into "${tocLabel(target)}"` : `${position} "${tocLabel(target)}"`;
    const count = folderFiles.length;
    const answers = await ask({
      title: "Move in the table of contents",
      message: `Move "${tocLabel(source)}" ${where}?`,
      fields: [
        ...(offer
          ? [
              {
                name: "moveFile",
                type: "checkbox",
                label:
                  offer.kind === "page"
                    ? `Also move the file to ${offer.to}`
                    : `Also move the folder ${offer.from} to ${offer.to} (${count} ${count === 1 ? "file" : "files"})`,
                hint: "Links and images that point at the moved files are updated, in the moved pages and in the rest of the book.",
              },
            ]
          : []),
        { name: "commitMessage", label: "Commit message", value: `MyST: move ${tocLabel(source)} ${where}`, required: true },
      ],
      submitLabel: "Move and commit",
      cancelLabel: "Cancel",
    });
    if (!answers) return;

    const move = offer && answers.moveFile ? offer : null;
    const retarget = !move
      ? () => null
      : move.kind === "page"
        ? (p) => (p === move.from ? move.to : null)
        : (p) => (p === move.from || p.startsWith(`${move.from}/`) ? move.to + p.slice(move.from.length) : null);
    try {
      if (move?.kind === "page" && (await pathTaken(move.to))) {
        toastNotify({ text: `There is already a file at ${move.to}.` });
        return;
      }
      if (move?.kind === "folder" && ((await pathTaken(move.to)) || (await listFiles(commit.peek(), move.to)).length)) {
        toastNotify({ text: `There is already a folder ${move.to}.` });
        return;
      }
      const toc = moveTocEntry(indexFile.peek(), {
        from: source.path,
        to: target.path,
        position,
        renames: move ? retarget : null,
        prefix: docsPrefix,
      });
      const documents = [{ file: indexPath.peek(), text: toc }];
      if (move) {
        const moving = move.kind === "page" ? [move.from] : folderFiles;
        const root = projectRoot.peek();
        await withLoadingStatus("Updating links", async () => {
          // Pages are rewritten for their new place; anything else moves as it is.
          const movedFiles = await mapLimit(moving, 6, async (from) => {
            const to = retarget(from);
            if (!/\.md$/i.test(from)) return { file: to, previous_path: from, action: "move" };
            const text = await getText(branch.peek(), commit.peek(), from);
            return { file: to, previous_path: from, action: "move", text: relinkReferences(text, { from, to, retarget, projectRoot: root }) };
          });
          const set = new Set(moving);
          documents.push(...movedFiles, ...(await relinkOtherPages(retarget, (f) => set.has(f))));
        });
      }
      await commitRestructure(answers.commitMessage, documents, { retarget });
    } catch (error) {
      console.error("Failed to move:", error);
      toastNotify({ text: `Could not move it: ${error.message || error}` });
    }
  }

  const commitButton = {
    id: "commit",
    tooltip: "Compare changes and commit",
    // Saving work back to the repository is the one action every session ends with, so it is named and
    // coloured rather than being one more grey square.
    label: "Commit",
    primary: true,
    icon: CommitIcon,
    action: async () => {
      options.includeButtons.value = options.includeButtons.peek().filter((b) => b.id != "commit");
      const changedFiles = docsWithChanges
        .peek()
        .filter((d) => d.branch === branch.peek() && d.commitHash === commit.peek().hash)
        .map(({ file }) => file);
      const otherFiles = changedFiles.filter((f) => f !== file.peek());
      let documents;
      try {
        documents = await setupFileConnections(repo, { ...props, collaboration }, branch.peek(), commit.peek().hash, otherFiles, getText);
      } catch (error) {
        console.error(error);
        toastNotify({ text: `Could not load the changed pages to commit: ${error.message || error}` });
        options.includeButtons.value = [...options.includeButtons.peek(), commitButton];
        return;
      }
      const currentText = collab.peek()?.ytext?.toString() ?? editorView.peek()?.state?.doc?.toString() ?? options.initialText.peek();
      const currentInitialText = options.initialText.peek();
      if (otherFiles.length < changedFiles.length || currentText !== currentInitialText) {
        documents.unshift({
          client: collab.peek(),
          file: file.peek(),
          initialText: currentInitialText,
          text: currentText,
        });
      }
      documents = documents.map((d) => ({
        ...d,
        textChanged: d.text != d.initialText,
        commentCount: d.client?.ycomments?.comments?.peek()?.length ?? 0,
      }));

      // Filter out documents without any changes and remove the change mark from the UI for them all
      const unchangedDocs = documents.filter((d) => !d.textChanged && d.commentCount == 0);
      cleanupConnections(unchangedDocs, collab);
      unchangedDocs.forEach((d) => {
        if (d.client?.provider?.roomname) statusSocket.current.send(d.client.provider.roomname);
      });
      documents = documents.filter((d) => d.textChanged || d.commentCount > 0);

      if (!documents.some((d) => d.textChanged)) {
        toastNotify({ text: "No changes to commit" });
        options.includeButtons.value = [...options.includeButtons.peek(), commitButton];
        return;
      }
      documents.forEach(({ client }) => client?.lock?.("A commit is being prepared for this document"));
      commitDocuments.current = documents;

      // The uploads waiting on this branch, and which of the changed pages show each one. An upload no
      // page uses any more (its figure was deleted) is offered unticked rather than committed blind.
      const root = projectRoot.peek();
      const usedBy = (path) =>
        documents
          .filter((d) => d.textChanged && imageReferences(d.text).some((ref) => resolveAssetPath(d.file, ref, root) === path))
          .map((d) => d.file);
      // Someone may have committed an image at the same path since this one was uploaded. Checked against
      // the branch as it is now, not the commit being edited, so the dialog can ask before replacing it.
      const tip = pendingImages.peek().length && fileExists ? (await getCommits(branch.peek(), 1).catch(() => []))[0] : null;
      commitAssets.current = await Promise.all(
        pendingImages.peek().map(async (image) => ({
          ...image,
          usedBy: usedBy(image.path),
          onBranch: !!tip && (await fileExists(tip, image.path).catch(() => false)),
        })),
      );
      const usedImages = commitAssets.current.filter((a) => a.usedBy.length);

      commitSummary.value =
        `MyST: update docs ${documents.map(({ file }) => file).join(", ")}` +
        (usedImages.length ? `; add ${usedImages.map((a) => a.path).join(", ")}` : "");
    },
  };
  async function onCommit({ summary, message, stagedDocs, stagedAssets = [] }) {
    let newConnections = [];
    try {
      commitSummary.value = null;
      const images = commitAssets.current.filter((a) => stagedAssets.includes(a.path));
      const { hash, webUrl } = await withLoadingStatus(images.length ? "Uploading and committing" : "Committing", async () =>
        commitChanges(
          message,
          commitDocuments.current.filter((d) => d.textChanged && stagedDocs.includes(d.file)),
          await Promise.all(images.map(async (a) => ({ path: a.path, type: a.type, base64: await blobToBase64(a.blob), replace: !!a.onBranch }))),
        ),
      );
      // They are in the repository now: keep showing them from memory instead of fetching them back.
      assetStore?.promote(
        branch.peek(),
        hash,
        images.map((a) => a.path),
      );
      // Let the server know the changes have been commited
      if (!statusSocket.current || statusSocket.current.readyState !== 1) {
        console.warn("Document statuses not available");
      } else {
        // Let the server know the changes have been commited (also includes comments)
        commitDocuments.current
          .filter((d) => (d.textChanged && stagedDocs.includes(d.file)) || (!d.textChanged && d.commentCount > 0))
          .forEach(({ client }) => {
            if (client?.provider?.roomname) statusSocket.current.send(client.provider.roomname);
          });
      }
      // Store comment information for the other files, do not include comments from files where text changed but were not committed
      const commentStates = commitDocuments.current
        .filter((d) => d.client && d.client != collab.peek() && d.commentCount > 0 && (!d.textChanged || stagedDocs.includes(d.file)))
        .reduce((states, { client, file }) => ({ ...states, [file]: client.ycomments.encodeState() }), {});
      // Store comments for this file
      if (collab.value?.ycomments) {
        commentStateToApply.current = collab.value.ycomments.encodeState();
      }
      toastNotify({ text: "Changes have been commited. ", link: { text: `See in ${serverName}`, href: webUrl } });
      commitDocuments.current.forEach(({ client }) => client?.provider?.awareness?.setLocalStateField("newCommit", { hash, message: summary }));
      cleanupConnections(commitDocuments.current, collab);
      commitDocuments.current = null;

      switchCommit({ hash, message: summary }, true, true);

      // Move comments over in other files
      newConnections = await setupFileConnections(repo, { ...props, collaboration }, branch.peek(), hash, Object.keys(commentStates));
      newConnections.forEach(({ client, file }) => client?.ycomments?.applyState(commentStates[file]));
    } catch (error) {
      console.error(error);
      toastNotify({ text: `Error occured while commiting: ${error}` });
      // Null once the commit itself went through and only moving the comments across failed.
      cleanupConnections(commitDocuments.current ?? [], collab);
      commitDocuments.current = null;
    } finally {
      cleanupConnections(newConnections, collab);
      options.includeButtons.value = [...options.includeButtons.peek(), commitButton];
    }
  }
  function onCommitCancel() {
    commitSummary.value = null;
    commitAssets.current = [];
    options.includeButtons.value = [...options.includeButtons.peek(), commitButton];
    cleanupConnections(commitDocuments.current, collab);
    commitDocuments.current = null;
  }

  const branchAllowed = (name) => !canOpenBranch || canOpenBranch(name) !== false;

  async function switchBranch(newBranch, isNew = false, force = false) {
    if (!branchAllowed(newBranch)) {
      toastNotify({ text: `Branch '${newBranch}' is not available to you.` });
      return;
    }
    if (branch.peek() && !force && !(await confirmDiscardChanges({ images: true }))) return;
    if (isNew && !branches.value.includes(newBranch)) {
      branches.value = [newBranch, ...branches.value];
    }
    const { resolvedCommits, resolvedFiles, resolvedFile, text } = await withLoadingStatus(`Loading branch ${newBranch}`, async () => {
      const resolvedCommits = await getCommits(newBranch, 1);
      const resolvedFiles = await getFiles(newBranch, resolvedCommits[0]);
      const tocFiles = (await loadToc(newBranch, resolvedCommits[0])).map((e) => e.file);
      const currentFile = file.peek();

      const resolvedFile = resolvedFiles.includes(currentFile) ? currentFile : defaultFileFrom(tocFiles, resolvedFiles);
      return { resolvedCommits, resolvedFiles, resolvedFile, text: await getText(newBranch, resolvedCommits[0], resolvedFile) };
    });
    batch(() => {
      branch.value = newBranch;
      commits.value = resolvedCommits;
      commit.value = resolvedCommits[0];
      files.value = resolvedFiles;
      file.value = resolvedFile;
      options.initialText.value = text;
    });
  }

  const gotoInitialRoom = async () => {
    // A saved or linked position on a branch this user may not open falls back to where they would
    // have started anyway, instead of opening it.
    if (initialState.branch && !branchAllowed(initialState.branch)) {
      toastNotify({ text: `Branch '${initialState.branch}' is not available to you.` });
      return switchBranch(branches.peek()[0], false, true);
    }
    const currBranch = initialState.branch ?? branches.peek()[0];
    if (!branches.value.includes(currBranch)) {
      branches.value = [currBranch, ...branches.value];
    }

    const resolvedCommits = await getCommits(currBranch, 1);
    const currCommit = initialState.commit ?? resolvedCommits[0];
    if (!resolvedCommits.some((c) => c.hash == currCommit.hash)) {
      resolvedCommits.push(currCommit);
    }

    const { resolvedFiles, currFile, text } = await withLoadingStatus("Loading documents", async () => {
      const resolvedFiles = await getFiles(currBranch, currCommit);
      const tocFiles = (await loadToc(currBranch, currCommit)).map((e) => e.file);

      const currFile = initialState.file && resolvedFiles.includes(initialState.file) ? initialState.file : defaultFileFrom(tocFiles, resolvedFiles);
      return { resolvedFiles, currFile, text: await getText(currBranch, currCommit, currFile) };
    });

    batch(() => {
      branch.value = currBranch;
      commits.value = resolvedCommits;
      commit.value = currCommit;
      files.value = resolvedFiles;
      file.value = currFile;
      options.initialText.value = text;
    });
  };

  // Since we need to make some async calls, we cannot just pass initial values to signals
  useEffect(() => {
    if (initialState) {
      gotoInitialRoom(initialState);
    } else {
      switchBranch(initialBranches[0]);
    }
    // Filtered first so a re-run cannot stack duplicates of the same control.
    const others = options.includeButtons.peek().filter((b) => b.id !== "toggle-sidebar" && b.id !== "commit");
    options.includeButtons.value = [...others, sidebarButton, commitButton];
  }, [initialBranches, initialState]);

  /** Open another commit of this branch, staying on the same page if it is there, or on `openFile`. */
  async function switchCommit(newCommit, isNew = false, force = false, openFile = null) {
    if (commit.peek() && !force && !(await confirmDiscardChanges({ images: true }))) return;
    if (isNew) {
      commits.value = [newCommit, ...commits.value];
    }
    const newCommitFromList = commits.peek().find((c) => c.hash == newCommit.hash) || newCommit;
    const { resolvedFiles, resolvedFile, text } = await withLoadingStatus(`Loading commit ${newCommitFromList?.hash ?? ""}`.trim(), async () => {
      const resolvedFiles = await getFiles(branch.peek(), newCommitFromList);
      const tocFiles = (await loadToc(branch.peek(), newCommitFromList)).map((e) => e.file);
      const currentFile = openFile && resolvedFiles.includes(openFile) ? openFile : file.peek();

      const resolvedFile = resolvedFiles.includes(currentFile) ? currentFile : defaultFileFrom(tocFiles, resolvedFiles);
      return { resolvedFiles, resolvedFile, text: await getText(branch.peek(), newCommitFromList, resolvedFile) };
    });
    batch(() => {
      commit.value = newCommitFromList;
      files.value = resolvedFiles;
      file.value = resolvedFile;
      options.initialText.value = text;
    });
  }

  useSignalEffect(() => {
    const doc = collab.value?.ydoc;
    const awareness = collab.value?.provider?.awareness;
    if (!doc || !awareness) return;

    const changeHandler = ({ added, updated }) => {
      const ids = [...added, ...updated];
      const states = awareness.getStates();
      for (const id of ids) {
        if (id === awareness.clientID) continue;
        const state = states.get(id);
        if (state.newCommit) {
          // After pages moved, `moved` says where the open one went.
          const { moved, ...newCommit } = state.newCommit;
          switchCommit(newCommit, true, true, moved?.[file.peek()] ?? null);
          return;
        }
      }
    };

    awareness.on("change", changeHandler);

    // This is done to keep this signal effect from running in a cycle when some singals are updated in applyState.
    queueMicrotask(() => {
      if (commentStateToApply.current != null) {
        collab.value?.ycomments?.applyState(commentStateToApply.current);
        commentStateToApply.current = null;
      }
    });

    return () => {
      awareness.off("change", changeHandler);
    };
  });

  // Safety net: the three paths that change branch/commit load the toc themselves, but an external
  // integration can move those signals directly. resolveToc() is memoised, so this costs nothing when
  // the toc for this commit has already been read.
  useSignalEffect(() => {
    if (!branch.value || !commit.value?.hash) return;
    loadToc(branch.value, commit.value);
  });

  return (
    <div style="all: initial;">
      <StyleSheetManager target={props.parent}>
        <MystContainer id="myst-css-namespace" $noSidebar={options.externalSidebar.value || sidebarCollapsed.value}>
          {!options.externalSidebar.value && !sidebarCollapsed.value && (
            <Sidebar
              {...{ file, branch, commit, getText, indexFile, indexedFiles, unIndexedFiles, markedFiles, switchFile, branding, collapseButton }}
              onAddFile={handleAddFile}
              onAddFolder={handleAddFolder}
              onMoveItem={handleMoveItem}
              tocTree={tocTree}
            />
          )}
          <GitPickerModal
            id="git-branch-picker"
            title="Switch or create branch"
            open={branchPickerOpen}
            options={branchOptions}
            selectedValue={branch.value}
            searchPlaceholder="Search or create branch..."
            searchOptions={(q) => searchBranches(q).then((bs) => bs.map(branchRow))}
            loadMore={loadBranches}
            onSelect={(o, isNew) => switchBranch(o.value, isNew)}
            onCreate={handleCreateBranch}
            currentBranch={branch.value}
          />
          <GitPickerModal
            id="git-commit-picker"
            title="Switch commit"
            open={commitPickerOpen}
            options={commitOptions}
            selectedValue={commit.value?.hash}
            searchPlaceholder="Search commits"
            searchOptions={(q) => searchCommits(q, branch.value).then((cs) => cs.map(commitRow))}
            loadMore={loadCommits}
            onSelect={(o, isNew) => switchCommit({ hash: o.value, message: o.message }, isNew)}
          />
          {loading.value && (
            <LoadingStatus id="loading-status" role="status" aria-live="polite" $stacked={!!toast.value.content}>
              <div class="spinner" />
              <span>
                {loading.value}…{waitingOnServer.value && <span class="blame">Waiting for {serverName}</span>}
              </span>
            </LoadingStatus>
          )}
          {toast.value.content && (
            <Toast id="toast">
              <span>
                {toast.value.content.text}
                {toast.value.content.link && (
                  <a href={toast.value.content.link.href} target="_blank" rel="noreferrer">
                    {toast.value.content.link.text}
                  </a>
                )}
              </span>
              <button
                type="button"
                title="Dismiss"
                aria-label="Dismiss"
                onClick={() => {
                  clearTimeout(toast.value.timeout);
                  toast.value = { content: null };
                }}
              >
                x
              </button>
            </Toast>
          )}
          <FormDialog request={dialogRequest} />
          <CommitModal
            initialSummary={commitSummary.value}
            onSubmit={onCommit}
            onClose={onCommitCancel}
            onDiscardLocal={(d) => revertText(d.initialText)}
            documents={commitDocuments.current?.filter?.((d) => d.textChanged) ?? []}
            assets={commitAssets.current}
            parent={props.parent}
            latestCommit={commits.value?.[0]?.hash == commit.value?.hash}
            statusSocket={statusSocket}
          />
          {projectWebUrl && (
            <MergeRequestModal
              open={mergeRequestModalOpen}
              onClose={() => {
                mergeRequestModalOpen.value = false;
                mrCheck.value++;
              }}
              currentBranch={branch.value}
              branches={branches.value}
              searchBranches={(q) => searchBranches(q)}
              projectId={projectId}
              projectWebUrl={projectWebUrl}
              serverName={serverName}
              review={review}
              newMergeRequestUrl={newMergeRequestUrl}
              defaultBranch={defaultBranch || initialBranches[0] || "main"}
              getOpenMergeRequests={getOpenMergeRequests}
            />
          )}
          {room.value && <MystEditorPreact />}
        </MystContainer>
      </StyleSheetManager>
    </div>
  );
};

export default ({ additionalStyles, id, ...params }, /** @type {HTMLElement} */ target) => {
  if (!target.shadowRoot) {
    target.attachShadow({
      mode: "open",
    });
  }
  if (additionalStyles) {
    target.shadowRoot.adoptedStyleSheets = target.shadowRoot.adoptedStyleSheets.filter((s) => !additionalStyles.includes(s));
    target.shadowRoot.adoptedStyleSheets.push(...(Array.isArray(additionalStyles) ? additionalStyles : [additionalStyles]));
  }
  params.parent = target.shadowRoot;

  const editorId = id ?? crypto.randomUUID();
  if (!window.myst_editor) window.myst_editor = {};
  window.myst_editor[editorId] = {};

  const form = target.closest("form");
  if (form) {
    form.addEventListener("formdata", (e) => e.formData.append(params.name, window.myst_editor[id].text));
  }

  // runs Preact cleanup logic when target is removed
  const observer = new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      if (Array.prototype.findIndex.call(mutation.removedNodes, (n) => n == target) != -1) {
        delete window.myst_editor[editorId];
        render(null, target.shadowRoot);
        observer.disconnect();
      }
    }
  });
  observer.observe(target.parentElement, { childList: true });

  const fileLinkTransform = {
    target: /\[\[(.+)\]\]/g,
    transform: async (input, file) => {
      const fileFull = file + ".md";
      const files = window.myst_editor[editorId].git.files.peek();
      if (!files.includes(fileFull)) return `<span title="Invalid file path">${input}</span>`;
      const text = await params.getText(window.myst_editor[editorId].git.branch.peek(), window.myst_editor[editorId].git.commit.peek(), fileFull);
      const heading = text.match(/^# .+$/gm);
      const fileName = heading ? heading[0].slice(2) : file;

      return `<span class="file-link" title="Switch to file" data-file-link="${fileFull}">${fileName}</span>`;
    },
  };

  // Images shown in the preview: uploads waiting for a commit, and a per-commit cache of the rest.
  const assetStore = createAssetStore({ getFileBlob: params.getFileBlob });
  const git = () => window.myst_editor[editorId]?.git;
  const pagePath = () => git()?.file?.peek() ?? "";
  const repoRoot = () => git()?.projectRoot?.peek() ?? "";
  const existsAnywhere = async (repoPath) =>
    assetStore.isPending(git()?.branch?.peek(), repoPath) || !!(await params.fileExists?.(git()?.commit?.peek(), repoPath));
  // Only a backend that can commit binary files gets an upload option; one whose commitChanges takes
  // just the pages would otherwise drop the images without a word.
  const assets = params.supportsAssets
    ? {
        defaultPath: (fileName) => `images/${sanitizeFileName(fileName)}`,
        resolve: (pathFromPage) => resolveAssetPath(pagePath(), pathFromPage, repoRoot()),
        relative: (repoPath) => relativeTo(pagePath(), repoPath),
        exists: existsAnywhere,
        suggestFreePath: (repoPath) => withUniqueSuffix(repoPath, existsAnywhere),
        stage: (repoPath, blob) => assetStore.stage(git()?.branch?.peek(), repoPath, blob),
      }
    : null;

  const state = createMystState({
    id: editorId,
    ...params,
    assets,
    mapUrl: (tag, url) => {
      if (tag === "img" && !url.startsWith("http") && !url.startsWith("data:")) {
        // We embed the path in the hash of a transparent data URI.
        // This prevents DOMPurify from stripping it, and prevents the browser from throwing a 404.
        return `${TRANSPARENT_PIXEL}#git-img-${url}`;
      }
      return params.mapUrl ? params.mapUrl(tag, url) : url;
    },
    collaboration: { ...params.collaboration, mode: "manual" },
    transforms: [...(params.transforms ?? []), fileLinkTransform],
    onPreviewClick: (ev) => {
      if (params.onPreviewClick?.(ev)) return true;
      const file = ev.target.dataset?.fileLink;
      if (!file) return false;

      ev.preventDefault();
      ev.stopPropagation();
      (async () => {
        const editorState = window.myst_editor[editorId];
        if (editorState.git && editorState.git.switchFile) {
          await editorState.git.switchFile(file);
        } else {
          const text = await params.getText(editorState.git.branch.peek(), editorState.git.commit.peek(), file);
          batch(() => {
            editorState.git.file.value = file;
            editorState.state.options.initialText.value = text;
          });
        }
      })();
      return true;
    },
    onDiscardChanges: () => {
      // Unmark file in the sidebar
      window.myst_editor[editorId].git.statusSocket.current.send(window.myst_editor[editorId].git.room.peek());
      params.onDiscardChanges?.();
    },
  });
  window.myst_editor[editorId].state = state;
  const logger = createLogger(state);
  window.myst_editor[editorId].logger = logger;

  effect(() => {
    if (!state.text.preview.value) return;

    // Images are swapped in on the rendered DOM, after the sanitizer has run, so nothing here widens
    // what the sanitizer lets through: the page only ever carries the placeholder URL.
    const fetchImages = () => {
      const g = git();
      const branch = g?.branch?.peek() || "main";
      const commit = g?.commit?.peek();
      for (const img of state.text.preview.value.querySelectorAll('img[src*="#git-img-"]')) {
        const src = img.getAttribute("src");
        // Relative to the page that shows it - which is how MyST resolves it when the book is built.
        const path = resolveAssetPath(pagePath(), src.slice(src.indexOf("#git-img-") + 9), repoRoot());
        img.dataset.gitPath = path ?? "";
        const known = path && assetStore.peek(branch, commit?.hash, path);
        img.setAttribute("src", known || TRANSPARENT_PIXEL);
        if (known || !path) continue;

        assetStore.lookup(branch, commit, path).then(
          (url) => {
            // The preview may have moved on to another page or commit while this was in flight.
            if (img.dataset.gitPath !== path) return;
            img.classList.toggle("git-img-missing", !url);
            if (url) img.setAttribute("src", url);
            else img.title = `Not in the repository yet: ${path}`;
          },
          (e) => console.warn("Failed to load image from git:", path, e),
        );
      }
    };

    const observer = new MutationObserver(fetchImages);
    observer.observe(state.text.preview.value, { childList: true, subtree: true });

    // Initial check
    fetchImages();
  });

  render(
    <MystState.Provider value={state}>
      <Logger.Provider value={logger}>
        <MystEditorGit id={editorId} {...params} assetStore={assetStore} />
      </Logger.Provider>
    </MystState.Provider>,
    target.shadowRoot,
  );
};

/** Resolve after the next animation frame, as component signal effects run then (or after 35 ms where
 * frames are paused, as in a background tab). */
const nextFrame = () =>
  new Promise((resolve) => {
    let done = false;
    const go = () => {
      if (done) return;
      done = true;
      setTimeout(resolve, 0);
    };
    requestAnimationFrame(go);
    setTimeout(go, 50);
  });

/** `fn` over every item, at most `limit` at a time, with the results in order. */
async function mapLimit(items, limit, fn) {
  const results = Array.from({ length: items.length });
  let next = 0;
  await Promise.all(
    Array.from({ length: Math.min(limit, items.length) }, async () => {
      while (next < items.length) {
        const i = next++;
        results[i] = await fn(items[i], i);
      }
    }),
  );
  return results;
}

/** Change a shared text into `next`, touching only the part that differs, so that others' cursors and
 * comments elsewhere in it stay where they are. */
function replaceText(ytext, next) {
  const prev = ytext.toString();
  if (prev === next) return;
  let start = 0;
  while (start < prev.length && start < next.length && prev[start] === next[start]) start++;
  let end = 0;
  while (end < prev.length - start && end < next.length - start && prev[prev.length - 1 - end] === next[next.length - 1 - end]) end++;
  ytext.doc.transact(() => {
    if (prev.length - start - end > 0) ytext.delete(start, prev.length - start - end);
    if (next.length - start - end > 0) ytext.insert(start, next.slice(start, next.length - end));
  });
}

/** Open a connection to each file's room and wait until it has synced. If any file fails (its text could
 * not be fetched), the connections already opened for the others are closed before the error is passed on. */
async function setupFileConnections(repo, props, branch, commitHash, files, getText) {
  const results = await Promise.allSettled(
    files.map(async (file) => {
      const initialText = getText ? await getText(branch, { hash: commitHash }, file) : null;
      const client = new CollaborationClient(
        {
          wsUrl: props.collaboration.wsUrl,
          room: `${repo}/${branch}/${commitHash}/${file}`,
          mode: "websocket",
          commentsEnabled: true,
        },
        { id: props.id },
      );
      let stopWatching;
      await new Promise((res) => {
        stopWatching = effect(() => {
          if (client.ready.value) res();
        });
      });
      stopWatching();
      return { client, file, text: client.ytext.toString(), initialText };
    }),
  );
  const failure = results.find((r) => r.status === "rejected");
  if (failure) {
    results.forEach((r) => r.status === "fulfilled" && r.value.client.destroy());
    throw failure.reason;
  }
  return results.map((r) => r.value);
}

function cleanupConnections(documents, currClient) {
  documents.forEach(({ client }) => {
    client?.unlock?.();
    if (client != currClient.peek()) client?.destroy?.();
  });
}
