// GitHub REST + GraphQL implementation of the git-backend callback contract consumed by MystEditorGit
// (see stubGitBackend.js for the in-memory reference, gitlabBackend.js for its GitLab sibling).
//
// All network calls go through an injected `authorizedFetch` (from githubAuth.js), which adds the token.
// REST covers almost everything; GraphQL is used where REST has no equivalent: searching branches by
// name, and committing several files (pages and images) as one commit.

import { GITHUB_REVIEW } from "./mergeRequest.js";

const PAGE_SIZE = 20;
const DOC_EXTENSIONS = [".md", ".rst"];
const RAW = { Accept: "application/vnd.github.raw" };

/** GitHub's repository roles on GitLab's access-level scale, which add-ons (e.g. branch access) compare against. */
const ROLE_LEVELS = [
  ["admin", 50],
  ["maintain", 40],
  ["push", 30],
  ["triage", 20],
  ["pull", 10],
];
export const accessLevelFor = (permissions = {}) => ROLE_LEVELS.find(([role]) => permissions[role])?.[1] ?? 0;

/** A path with its slashes kept, every segment escaped. */
const encodePath = (p) => p.split("/").map(encodeURIComponent).join("/");

/** Base64 of a string's UTF-8 bytes, which is what GitHub expects for file contents. In chunks:
 * spreading a whole page into String.fromCharCode overflows the call stack on long pages. */
export function utf8ToBase64(text) {
  return bytesToBase64(new TextEncoder().encode(text));
}

/** Base64 of raw bytes, for files moved as they are (images, notebooks, data). */
export function bytesToBase64(bytes) {
  let binary = "";
  for (let i = 0; i < bytes.length; i += 0x8000) binary += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return btoa(binary);
}

/** A commit message's first line, as GitHub splits it into headline and body. */
const headline = (message) => String(message ?? "").split("\n")[0];

const SEARCH_BRANCHES = `query($owner: String!, $name: String!, $query: String!, $first: Int!) {
  repository(owner: $owner, name: $name) {
    refs(refPrefix: "refs/heads/", query: $query, first: $first, orderBy: { field: ALPHABETICAL, direction: ASC }) { nodes { name } }
  }
}`;

const CREATE_COMMIT = `mutation($input: CreateCommitOnBranchInput!) {
  createCommitOnBranch(input: $input) { commit { oid url } }
}`;

/**
 * Create the GitHub-backed git API. Async because it prefetches the repository and the first page of
 * branches to populate `initialBranches`.
 *
 * @param {{ repo: string, getBranch?: () => string, authorizedFetch: (path: string, init?: RequestInit) => Promise<Response>,
 *   graphqlUrl?: string, githubUrl?: string, searchCommitPages?: number }} options
 *   `repo` is "owner/name"; `graphqlUrl` defaults to github.com's.
 */
export async function createGitHubBackend(options = {}) {
  const { repo, getBranch = () => "main", authorizedFetch, graphqlUrl = "https://api.github.com/graphql", searchCommitPages = 5 } = options;
  if (!/^[^/\s]+\/[^/\s]+$/.test(repo ?? "")) throw new Error('createGitHubBackend: `repo` must be "owner/name".');
  if (!authorizedFetch) throw new Error("createGitHubBackend: `authorizedFetch` is required.");
  const [owner, name] = repo.split("/");
  const repoPath = `repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}`;

  const apiJson = async (path, init) => (await authorizedFetch(path, init)).json();
  async function graphql(query, variables) {
    const res = await apiJson(graphqlUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query, variables }),
    });
    if (res.errors?.length) {
      const err = new Error(`GitHub: ${res.errors.map((e) => e.message).join("; ")}`);
      err.graphqlErrors = res.errors;
      throw err;
    }
    return res.data;
  }
  /** Read a file at a commit, or null when there is nothing at that path. */
  async function raw(commit, path, init) {
    try {
      return await authorizedFetch(`${repoPath}/contents/${encodePath(path)}?ref=${encodeURIComponent(commit.hash)}`, { ...init, headers: RAW });
    } catch (err) {
      if (err.status === 404) return null;
      throw err;
    }
  }
  const tipOf = async (branch) => (await apiJson(`${repoPath}/git/ref/heads/${encodePath(branch)}`)).object.sha;

  // Prefetch the repository, which also says what the signed-in user may do here.
  const project = await apiJson(repoPath);
  const defaultBranch = project.default_branch || "main";
  const permissions = project.permissions ?? {};
  const accessLevel = accessLevelFor(permissions);
  const webUrl = project.html_url;

  // Protection comes with every branch listing. Whether this user may push to a protected branch
  // depends on its rules, which only admins can read, so that stays unknown unless they cannot push at all.
  const branchStatus = new Map();
  const branchNames = (branches) =>
    branches.map((b) => {
      branchStatus.set(b.name, { protected: !!b.protected, canPush: !permissions.push ? false : b.protected ? undefined : true });
      return b.name;
    });
  const fetchBranchNames = async (page) => branchNames(await apiJson(`${repoPath}/branches?per_page=${PAGE_SIZE}&page=${page}`));

  const fetchCommits = async (branch, page) =>
    (await apiJson(`${repoPath}/commits?sha=${encodeURIComponent(branch)}&per_page=${PAGE_SIZE}&page=${page}`)).map((c) => ({
      hash: c.sha,
      message: headline(c.commit?.message),
    }));

  const firstPage = await fetchBranchNames(1);
  const initialBranches = [defaultBranch, ...firstPage.filter((b) => b !== defaultBranch)];
  let currentUser = null;

  return {
    initialBranches,
    projectId: project.id ?? null,
    projectWebUrl: webUrl,
    defaultBranch,
    supportsAssets: true,
    serverName: "GitHub",
    review: GITHUB_REVIEW,

    /** GitHub's "compare" page, which offers to open the pull request. */
    newMergeRequestUrl({ sourceBranch, targetBranch }) {
      return `${webUrl}/compare/${encodePath(targetBranch)}...${encodePath(sourceBranch)}?expand=1`;
    },

    /** The signed-in user, with their role here on GitLab's scale (30 write, 40 maintain, 50 admin). */
    async getCurrentUser() {
      currentUser ??= apiJson("user").then(
        (u) => ({ id: u.id, username: u.login, name: u.name || u.login, accessLevel }),
        (err) => {
          currentUser = null;
          throw err;
        },
      );
      return currentUser;
    },

    async getOpenMergeRequests(branch) {
      try {
        const query = branch
          ? `state=open&per_page=${PAGE_SIZE}&head=${encodeURIComponent(`${owner}:${branch}`)}`
          : `state=open&per_page=${PAGE_SIZE}`;
        const pulls = await apiJson(`${repoPath}/pulls?${query}`);
        return pulls.map((pr) => ({
          id: pr.id,
          iid: pr.number,
          title: pr.title,
          webUrl: pr.html_url,
          sourceBranch: pr.head?.ref,
          targetBranch: pr.base?.ref,
          state: "opened",
          author: pr.user?.login,
        }));
      } catch (err) {
        console.warn("Could not load pull requests:", err);
        return [];
      }
    },

    async getBranches(page) {
      return fetchBranchNames(page);
    },

    // The REST branch list cannot filter by name; GraphQL's refs can.
    async searchBranches(input) {
      const data = await graphql(SEARCH_BRANCHES, { owner, name, query: input, first: PAGE_SIZE });
      return (data.repository?.refs?.nodes ?? []).map((r) => r.name);
    },

    /** `{ protected, canPush }` for a branch already listed, else undefined. */
    getBranchStatus(branchName) {
      return branchStatus.get(branchName);
    },

    async getCommits(branch, page) {
      return fetchCommits(branch, page);
    },

    // GitHub's commit search only covers the default branch, so scan the branch's recent history,
    // as the GitLab backend does.
    async searchCommits(input, branch) {
      const q = input.toLowerCase();
      const matches = [];
      for (let page = 1; page <= searchCommitPages; page++) {
        const commits = await fetchCommits(branch, page);
        if (commits.length === 0) break;
        for (const c of commits) if (c.message.toLowerCase().includes(q)) matches.push(c);
        if (matches.length >= PAGE_SIZE) break;
      }
      return matches.slice(0, PAGE_SIZE);
    },

    async getFiles(_branch, commit) {
      if (!commit?.hash) return [];
      const tree = await apiJson(`${repoPath}/git/trees/${encodeURIComponent(commit.hash)}?recursive=1`);
      if (tree.truncated) console.warn("GitHub returned a truncated file list: this repository is very large.");
      return tree.tree.filter((e) => e.type === "blob" && DOC_EXTENSIONS.some((ext) => e.path.endsWith(ext))).map((e) => e.path);
    },

    /** Every file under a folder at this commit, pages, images and anything else, as repository paths. */
    async listFiles(commit, dir) {
      if (!commit?.hash || !dir) return [];
      const tree = await apiJson(`${repoPath}/git/trees/${encodeURIComponent(commit.hash)}?recursive=1`);
      // A partial list would leave files behind in a folder being moved.
      if (tree.truncated) throw new Error("This repository is too large to list a folder's files from GitHub.");
      return tree.tree.filter((e) => e.type === "blob" && e.path.startsWith(`${dir}/`)).map((e) => e.path);
    },

    async getText(_branch, commit, file) {
      if (!commit?.hash) return "";
      const res = await raw(commit, file);
      return res ? res.text() : ""; // match the stub: a missing file reads as empty
    },

    async getFileBlob(_branch, commit, file) {
      if (!commit?.hash) return null;
      const res = await raw(commit, file);
      return res ? URL.createObjectURL(await res.blob()) : null;
    },

    /** Whether anything is at `path` at this commit - an image name must not land on an existing file. */
    async fileExists(commit, path) {
      if (!commit?.hash) return false;
      return !!(await raw(commit, path, { method: "HEAD" }));
    },

    /**
     * One commit for the edited pages and the images uploaded for them, on top of the branch's tip.
     *
     * GitHub would replace an existing file without a word, where GitLab refuses. So an image is
     * checked against the tip first, and only replaces what is there when the author said so
     * (`replace`, ticked in the commit dialog).
     *
     * @param {string} message
     * @param {{ file: string, text?: string, action?: string, previous_path?: string }[]} documents - a
     *   `move` without `text` copies the file as it is, binary files included.
     * @param {{ path: string, base64: string, replace?: boolean }[]} [assets]
     */
    async commitChanges(message, documents, assets = []) {
      const branch = getBranch();
      const tip = await tipOf(branch);
      for (const a of assets) {
        if (!a.replace && (await raw({ hash: tip }, a.path, { method: "HEAD" }))) {
          throw new Error(`${a.path} already exists on ${branch}. Commit again to choose whether to replace it.`);
        }
      }
      const additions = [];
      const deletions = [];

      for (const d of documents) {
        if (d.action === "delete") {
          deletions.push({ path: d.file });
        } else if (d.action === "move") {
          if (d.previous_path) deletions.push({ path: d.previous_path });
          if (d.text === undefined && d.previous_path) {
            // Moved as it is: copied byte for byte, so an image or notebook survives the move.
            const rawRes = await raw({ hash: tip }, d.previous_path);
            if (!rawRes) throw new Error(`${d.previous_path} is no longer on ${branch}.`);
            additions.push({ path: d.file, contents: bytesToBase64(new Uint8Array(await rawRes.arrayBuffer())) });
          } else {
            additions.push({ path: d.file, contents: utf8ToBase64(d.text ?? "") });
          }
        } else {
          additions.push({ path: d.file, contents: utf8ToBase64(d.text ?? "") });
        }
      }

      for (const a of assets) {
        additions.push({ path: a.path, contents: a.base64 });
      }

      const fileChanges = {};
      if (additions.length) fileChanges.additions = additions;
      if (deletions.length) fileChanges.deletions = deletions;

      const [first, ...rest] = String(message ?? "").split("\n");
      const data = await graphql(CREATE_COMMIT, {
        input: {
          branch: { repositoryNameWithOwner: repo, branchName: branch },
          message: { headline: first.trim() || "MyST: update docs", body: rest.join("\n").trim() || undefined },
          expectedHeadOid: tip,
          fileChanges,
        },
      });
      const commit = data.createCommitOnBranch.commit;
      return { hash: commit.oid, webUrl: commit.url };
    },

    /** `ref` is a branch name or a commit hash, as the branch picker passes either. */
    async createBranch(branch, ref) {
      let sha;
      try {
        sha = await tipOf(ref);
      } catch (err) {
        if (err.status !== 404) throw err;
        sha = (await apiJson(`${repoPath}/commits/${encodeURIComponent(ref)}`)).sha;
      }
      try {
        await apiJson(`${repoPath}/git/refs`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ ref: `refs/heads/${branch}`, sha }),
        });
      } catch (err) {
        if (err.status === 422) throw new Error(`Branch '${branch}' already exists`);
        throw err;
      }
      const commit = await apiJson(`${repoPath}/commits/${sha}`);
      return { name: branch, commit: { hash: sha, message: headline(commit.commit?.message) } };
    },
  };
}
