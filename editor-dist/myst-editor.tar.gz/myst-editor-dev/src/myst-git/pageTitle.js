/** A page's own title: the frontmatter `title:`, else its first level-one heading. */
export function pageTitle(text) {
  if (!text) return null;
  let body = text;
  const fm = text.match(/^---\r?\n([\s\S]*?)\r?\n---\r?\n?/);
  if (fm) {
    const title = fm[1].match(/^title:\s*["']?(.+?)["']?\s*$/m);
    if (title) return title[1];
    body = text.slice(fm[0].length);
  }
  // Skipping fenced blocks, so a "# comment" in a code cell is not mistaken for the page title.
  let fence = null;
  for (const line of body.split("\n")) {
    const opening = line.match(/^\s*(`{3,}|~{3,})/);
    if (fence) {
      if (opening && opening[1][0] === fence[0] && opening[1].length >= fence.length) fence = null;
      continue;
    }
    if (opening) {
      fence = opening[1];
      continue;
    }
    const heading = line.match(/^#\s+(.+?)\s*#*\s*$/);
    if (heading) return heading[1];
  }
  return null;
}
