import { createInitialRepoState, demoBranches } from "./demo-data.js";
import { buildMergeRequestUrl, GITLAB_REVIEW, GITHUB_REVIEW } from "./mergeRequest.js";

// The factory used to live here; kept importable from its old place.
export { createGitBackend } from "./backends.js";

const PAGE_SIZE = 20;
const DEMO_PROJECT_WEB_URL = "https://gitlab.example.org/demo/book";
const DEMO_GITHUB_WEB_URL = "https://github.example.org/demo/book";

function cloneRepoState(state) {
  return structuredClone(state);
}

/**
 * In-memory git API for demos and tests. Models branches, commits, and file snapshots
 * the same way a real git backend would expose them via callbacks.
 *
 * `latency` delays every read by that many milliseconds. The in-memory stub answers instantly, which
 * makes the slow-fetch indicator impossible to see or test; a real repository over a slow link is the
 * case it exists for.
 *
 * `flavor: "github"` words and links things as GitHub does (pull requests, compare pages), so the UI's
 * GitHub wording can be seen and tested without a GitHub account.
 *
 * @param {{ repoKey?: string, initialState?: ReturnType<typeof createInitialRepoState>, getBranch?: () => string, latency?: number, flavor?: "gitlab"|"github" }} [options]
 */
export function createStubGitBackend(options = {}) {
  const storageKey = `myst-stub-repo:${options.repoKey ?? "default"}`;
  const latency = Number(options.latency) || 0;
  const delay = () => (latency > 0 ? new Promise((r) => setTimeout(r, latency)) : null);
  let state = cloneRepoState(options.initialState ?? createInitialRepoState());
  let commitCounter = 0;
  let customBranches = [];
  // Committed images, as data URLs per commit. Kept in memory only: localStorage is far too small for
  // images, so the demo forgets them on reload while remembering the commits that added them.
  const binaries = new Map();
  const reload = () => {
    try {
      const saved = localStorage.getItem(storageKey);
      if (saved) ({ state, commitCounter, customBranches = [] } = JSON.parse(saved));
    } catch {}
  };
  reload();

  const allBranches = () => [...customBranches, ...demoBranches.filter((b) => !customBranches.includes(b))];
  const getBranch = () => options.getBranch?.() ?? "main";

  function commitEntry(hash) {
    const entry = state.commits[hash];
    if (!entry) throw new Error(`Unknown commit: ${hash}`);
    return entry;
  }

  /** Whether a commit or one of its ancestors added an image at `path`. The paths are saved with the
   * commits (unlike the images themselves), so another tab on the same demo repository sees them. */
  function imageAt(hash, path) {
    for (let h = hash; h; h = state.commits[h]?.parent) {
      if (state.commits[h]?.images?.includes(path)) return true;
      if (state.commits[h]?.removed?.includes(path)) return false;
    }
    return false;
  }

  /** A binary file as of a commit: added there, or inherited from the nearest ancestor that added it. */
  function binaryAt(hash, path) {
    for (let h = hash; h; h = state.commits[h]?.parent) {
      const found = binaries.get(h)?.[path];
      if (found) return found;
      if (state.commits[h]?.removed?.includes(path)) return null;
    }
    return null;
  }

  function listFilesAtCommit(hash) {
    return Object.keys(commitEntry(hash).files).filter((f) => f.endsWith(".md") || f.endsWith(".rst"));
  }

  // A made-up project, so the demo can show the merge request controls without sending anyone to a
  // real repository. Pass `projectWebUrl: null` to leave them out.
  const github = options.flavor === "github";
  const projectWebUrl = options.projectWebUrl === undefined ? (github ? DEMO_GITHUB_WEB_URL : DEMO_PROJECT_WEB_URL) : options.projectWebUrl;

  return {
    initialBranches: allBranches().slice(0, PAGE_SIZE),
    projectId: options.projectId ?? null,
    projectWebUrl,
    defaultBranch: "main",
    supportsAssets: true,
    serverName: github ? "GitHub" : "GitLab",
    review: github ? GITHUB_REVIEW : GITLAB_REVIEW,

    newMergeRequestUrl({ sourceBranch, targetBranch }) {
      return github
        ? `${projectWebUrl}/compare/${targetBranch}...${sourceBranch}?expand=1`
        : buildMergeRequestUrl({ projectWebUrl, sourceProjectId: options.projectId, sourceBranch, targetProjectId: options.projectId, targetBranch });
    },

    /** The demo has no accounts: a Maintainer called "demo", unless `options.user` says otherwise. */
    async getCurrentUser() {
      return { id: 1, username: "demo", name: "Demo Author", accessLevel: 40, ...options.user };
    },

    async getOpenMergeRequests(branch) {
      await delay();
      const defaultStubMergeRequests = [
        {
          id: 1001,
          iid: 1,
          title: "Draft: Updates from development",
          webUrl: `${projectWebUrl}/-/merge_requests/1`,
          sourceBranch: "development",
          targetBranch: "main",
          state: "opened",
          author: "Demo Author",
        },
      ];
      const mrs = options.mergeRequests ?? defaultStubMergeRequests;
      if (!branch) return mrs.filter((m) => m.state === "opened");
      return mrs.filter((m) => m.sourceBranch === branch && m.state === "opened");
    },

    async getBranches(page) {
      await delay();
      reload();
      const start = (Math.max(1, page) - 1) * PAGE_SIZE;
      return allBranches().slice(start, start + PAGE_SIZE);
    },

    /** The demo protects only what `options.protectedBranches` names; nobody can push to those. */
    getBranchStatus(name) {
      const isProtected = (options.protectedBranches ?? []).includes(name);
      return { protected: isProtected, canPush: !isProtected };
    },

    async searchBranches(input) {
      await delay();
      reload();
      const q = input.toLowerCase();
      return allBranches()
        .filter((b) => b.toLowerCase().includes(q))
        .slice(0, PAGE_SIZE);
    },

    async getCommits(branch, page) {
      await delay();
      // Another tab on the same demo repository may have committed since.
      reload();
      const hashes = state.history[branch] ?? [];
      const start = (Math.max(1, page) - 1) * PAGE_SIZE;
      return hashes.slice(start, start + PAGE_SIZE).map((hash) => ({
        hash,
        message: commitEntry(hash).message,
      }));
    },

    async searchCommits(input, branch) {
      const q = input.toLowerCase();
      const hashes = branch ? (state.history[branch] ?? []) : [...new Set(Object.values(state.history).flat())];
      return hashes
        .filter((hash) => hash.toLowerCase().includes(q) || commitEntry(hash).message.toLowerCase().includes(q))
        .slice(0, PAGE_SIZE)
        .map((hash) => ({ hash, message: commitEntry(hash).message }));
    },

    async getFiles(_branch, commit) {
      if (!commit?.hash) return [];
      await delay();
      reload();
      return listFilesAtCommit(commit.hash);
    },

    /** Every file under a folder at this commit: pages, and the images committed in this demo. */
    async listFiles(commit, dir) {
      if (!commit?.hash || !dir) return [];
      await delay();
      reload();
      const under = (p) => p.startsWith(`${dir}/`);
      const images = new Set();
      for (let h = commit.hash; h; h = state.commits[h]?.parent) for (const p of state.commits[h]?.images ?? []) if (under(p)) images.add(p);
      return [...Object.keys(commitEntry(commit.hash).files).filter(under), ...[...images].filter((p) => imageAt(commit.hash, p))];
    },

    async getText(_branch, commit, file) {
      if (!commit?.hash) return "";
      await delay();
      reload();
      return commitEntry(commit.hash).files[file] ?? "";
    },

    async getFileBlob(_branch, commit, file) {
      if (!commit?.hash) return null;
      reload();
      // Only images committed in this session exist; like GitLab, anything else is not found.
      return binaryAt(commit.hash, file);
    },

    async fileExists(commit, path) {
      if (!commit?.hash) return false;
      reload();
      return path in commitEntry(commit.hash).files || imageAt(commit.hash, path) || !!binaryAt(commit.hash, path);
    },

    async commitChanges(message, documents, assets = []) {
      reload();
      const branch = getBranch();
      const parent = state.branches[branch];
      if (!parent) throw new Error(`Unknown branch: ${branch}`);

      // Like GitLab: an image never silently replaces one already on the branch, unless asked to.
      const taken = assets.find((a) => !a.replace && imageAt(parent, a.path));
      if (taken) throw new Error(`A file with this name already exists: ${taken.path}`);

      commitCounter++;
      const hash = `offline-${commitCounter}`;
      const files = { ...commitEntry(parent).files };
      // Images moved along with a folder: added at the new path, and gone from the old one.
      const movedImages = {};
      const removed = [];
      for (const d of documents) {
        if (d.action === "move" && d.text === undefined && !(d.previous_path in files) && imageAt(parent, d.previous_path)) {
          movedImages[d.file] = binaryAt(parent, d.previous_path);
          removed.push(d.previous_path);
        } else if (d.action === "move") {
          const content = d.text !== undefined ? d.text : files[d.previous_path];
          delete files[d.previous_path];
          files[d.file] = content;
        } else if (d.action === "delete") {
          delete files[d.file];
        } else {
          files[d.file] = d.text;
        }
      }

      const images = [...assets.map((a) => a.path), ...Object.keys(movedImages)];
      state.commits[hash] = { message, parent, files, ...(images.length ? { images } : {}), ...(removed.length ? { removed } : {}) };
      const blobs = {
        ...Object.fromEntries(Object.entries(movedImages).filter(([, url]) => url)),
        ...Object.fromEntries(assets.map((a) => [a.path, `data:${a.type || "application/octet-stream"};base64,${a.base64}`])),
      };
      if (Object.keys(blobs).length) binaries.set(hash, blobs);
      state.branches[branch] = hash;
      state.history[branch] = [hash, ...(state.history[branch] ?? []).filter((h) => h !== hash)];

      try {
        localStorage.setItem(storageKey, JSON.stringify({ state, commitCounter, customBranches }));
      } catch {}
      return { hash, webUrl: "#" };
    },

    async createBranch(name, ref) {
      await delay();
      reload();
      if (!name) throw new Error("Branch name is required");
      if (state.branches[name]) throw new Error(`Branch '${name}' already exists`);

      let targetCommit = ref;
      let history = [];
      if (state.branches[ref]) {
        targetCommit = state.branches[ref];
        history = [...(state.history[ref] ?? [targetCommit])];
      } else if (state.commits[ref]) {
        targetCommit = ref;
        for (const b in state.history) {
          const idx = state.history[b]?.indexOf(ref);
          if (idx !== undefined && idx !== -1) {
            history = state.history[b].slice(idx);
            break;
          }
        }
        if (history.length === 0) history = [targetCommit];
      } else if (Object.keys(state.commits).some((h) => h.toLowerCase().startsWith(ref.toLowerCase()))) {
        targetCommit = Object.keys(state.commits).find((h) => h.toLowerCase().startsWith(ref.toLowerCase()));
        for (const b in state.history) {
          const idx = state.history[b]?.indexOf(targetCommit);
          if (idx !== undefined && idx !== -1) {
            history = state.history[b].slice(idx);
            break;
          }
        }
        if (history.length === 0) history = [targetCommit];
      } else {
        throw new Error(`Unknown ref: ${ref}`);
      }

      state.branches[name] = targetCommit;
      state.history[name] = history;
      if (!customBranches.includes(name)) {
        customBranches = [name, ...customBranches];
      }

      try {
        localStorage.setItem(storageKey, JSON.stringify({ state, commitCounter, customBranches }));
      } catch {}

      return {
        name,
        commit: {
          hash: targetCommit,
          message: state.commits[targetCommit]?.message,
        },
      };
    },
  };
}

/** @typedef {ReturnType<typeof createStubGitBackend>} GitBackendCallbacks */
