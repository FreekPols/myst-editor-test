import { useEffect, useRef, useState } from "preact/hooks";
import styled from "styled-components";
import { Modal, DefaultButton } from "../components/CommonUI";
import { buildMergeRequestUrl, GITLAB_REVIEW } from "./mergeRequest";
import SearchableBranchSelect from "./SearchableBranchSelect";

const MergeRequestDialog = styled(Modal)`
  && {
    width: 580px;
    max-width: calc(100vw - 32px);
    padding: 24px;
    box-sizing: border-box;
    overflow: visible;
  }

  .mr-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 16px;

    h2 {
      margin: 0;
      font-size: 18px;
      font-weight: 700;
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .close-btn {
      background: transparent;
      border: none;
      font-size: 20px;
      line-height: 1;
      cursor: pointer;
      color: var(--gray-700);
      padding: 4px 8px;
      border-radius: var(--border-radius);

      &:hover {
        background-color: var(--button-bg-hover);
        color: inherit;
      }
    }
  }

  .mr-description {
    font-size: 13px;
    color: var(--gray-700);
    margin: 0 0 16px 0;
    line-height: 1.4;
  }

  .alert-box {
    display: flex;
    gap: 12px;
    padding: 12px 14px;
    border-radius: var(--border-radius);
    margin-bottom: 18px;
    font-size: 13px;
    line-height: 1.4;
    border: 1px solid var(--border);

    &.warning {
      background-color: color-mix(in srgb, var(--unsaved, #e6aa3a) 12%, transparent);
      border-color: color-mix(in srgb, var(--unsaved, #e6aa3a) 40%, transparent);

      .alert-icon {
        color: var(--unsaved, #d97706);
        flex-shrink: 0;
        margin-top: 1px;
      }
    }

    &.error {
      background-color: color-mix(in srgb, var(--error-fg, #ef4444) 10%, transparent);
      border-color: color-mix(in srgb, var(--error-fg, #ef4444) 35%, transparent);

      .alert-icon {
        color: var(--error-fg, #ef4444);
        flex-shrink: 0;
        margin-top: 1px;
      }
    }

    .alert-content {
      flex: 1;
      min-width: 0;

      strong {
        display: block;
        margin-bottom: 4px;
      }

      p {
        margin: 0 0 6px 0;
      }

      .mr-details {
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        gap: 6px;
        margin-bottom: 8px;

        .mr-link {
          font-weight: 600;
          color: var(--accent-dark);
          text-decoration: underline;
        }

        .mr-target {
          color: var(--gray-700);
          font-size: 12px;
        }
      }

      .alert-actions {
        display: flex;
        gap: 8px;

        button.view-mr-btn {
          font-size: 12px;
          font-weight: 600;
          padding: 4px 10px;
          height: auto;
          background-color: var(--button-bg);
          border: 1px solid var(--border);
          border-radius: var(--border-radius);
          cursor: pointer;
          color: inherit;

          &:hover {
            background-color: var(--button-bg-hover);
          }
        }
      }
    }
  }

  .form-group {
    display: flex;
    flex-direction: column;
    gap: 4px;
    margin-bottom: 16px;

    .field-label-row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
      margin-bottom: 2px;

      label {
        font-size: 13px;
        font-weight: 600;
      }

      .quick-actions {
        display: flex;
        gap: 4px;
      }

      .chip-btn {
        background: transparent;
        border: 1px solid var(--border);
        border-radius: 12px;
        font-size: 11px;
        padding: 2px 8px;
        cursor: pointer;
        color: var(--gray-700);
        white-space: nowrap;

        &:hover {
          background-color: var(--button-bg-hover);
          color: inherit;
        }

        &.active {
          border-color: var(--accent);
          color: var(--accent-dark);
          font-weight: 600;
        }
      }
    }

    .field-hint {
      font-size: 11px;
      color: var(--gray-700);
    }

    .commit-input {
      width: 100%;
      padding: 8px 12px;
      font-size: 13px;
      font-family: var(--font-mono, monospace);
      border: 1px solid var(--border);
      border-radius: var(--border-radius);
      background-color: var(--editor-bg);
      color: inherit;
      box-sizing: border-box;

      &:focus {
        outline: none;
        border-color: var(--accent);
      }
    }
  }

  .url-preview-card {
    background-color: var(--editor-bg);
    border: 1px solid var(--border);
    border-radius: var(--border-radius);
    padding: 10px 12px;
    margin-bottom: 20px;

    label {
      display: block;
      font-size: 11px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      color: var(--gray-700);
      margin-bottom: 6px;
    }

    .url-input-wrap {
      display: flex;
      gap: 8px;
      align-items: flex-start;

      input {
        flex: 1;
        font-family: var(--font-mono, monospace);
        font-size: 11px;
        padding: 6px 8px;
        background-color: var(--modal-bg);
        border: 1px solid var(--border);
        border-radius: var(--border-radius);
        color: var(--gray-800);
        cursor: pointer;

        &:hover {
          border-color: var(--gray-400, #9ca3af);
        }
      }

      textarea {
        flex: 1;
        font-family: var(--font-mono, monospace);
        font-size: 11px;
        line-height: 1.45;
        padding: 6px 8px;
        background-color: var(--modal-bg);
        border: 1px solid var(--border);
        border-radius: var(--border-radius);
        color: var(--gray-800);
        resize: vertical;
        min-height: 72px;
        word-break: break-all;
        white-space: pre-wrap;
      }

      .preview-actions {
        display: flex;
        flex-direction: column;
        gap: 6px;
        flex-shrink: 0;
      }

      button.copy-btn,
      button.collapse-btn {
        flex-shrink: 0;
        padding: 6px 12px;
        font-size: 12px;
        font-weight: 600;
        background-color: var(--button-bg);
        border: 1px solid var(--border);
        border-radius: var(--border-radius);
        cursor: pointer;
        color: inherit;
        min-width: 65px;
        text-align: center;

        &:hover {
          background-color: var(--button-bg-hover);
        }

        &.copied {
          color: var(--accent-dark, #2563eb);
          border-color: var(--accent, #3b82f6);
        }
      }
    }
  }

  .modal-actions {
    display: flex;
    align-items: center;
    justify-content: flex-end;
    gap: 8px;

    button.primary {
      background-color: var(--primary-bg);
      color: var(--primary-fg);
      border-color: transparent;

      &:hover:not(:disabled) {
        background-color: var(--primary-bg-hover);
      }
    }
  }
`;

const WarningIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" />
    <line x1="12" y1="9" x2="12" y2="13" />
    <line x1="12" y1="17" x2="12.01" y2="17" />
  </svg>
);

const MergeRequestIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="18" cy="18" r="3" />
    <circle cx="6" cy="6" r="3" />
    <path d="M13 6h3a2 2 0 0 1 2 2v7" />
    <line x1="6" y1="9" x2="6" y2="21" />
  </svg>
);

/**
 * Prepare a merge request (GitHub: pull request) and open the forge's page for starting it.
 *
 * The source is always a branch: neither forge opens one from a commit. To propose a single commit,
 * create a branch from it first (the branch picker can). The wording and the link come from the backend
 * (`serverName`, `review`, `newMergeRequestUrl`); without them it is GitLab's.
 */
export const MergeRequestModal = ({
  open,
  onClose,
  currentBranch = "",
  branches = [],
  searchBranches,
  projectId,
  projectWebUrl,
  defaultBranch = "main",
  getOpenMergeRequests = async () => [],
  serverName = "GitLab",
  review = GITLAB_REVIEW,
  newMergeRequestUrl = null,
}) => {
  const dialogRef = useRef(null);
  const isOpen = typeof open === "object" && open !== null && "value" in open ? open.value : !!open;

  const [sourceBranch, setSourceBranch] = useState(currentBranch || defaultBranch || "main");
  const [targetBranch, setTargetBranch] = useState(defaultBranch || "main");
  const [openMr, setOpenMr] = useState(null);
  /** "idle", "copied", or "failed" when the browser would not let us write to the clipboard. */
  const [copyState, setCopyState] = useState("idle");
  const [isExpandedPreview, setIsExpandedPreview] = useState(false);
  const previewRef = useRef(null);

  // Synchronize initial state when modal opens
  useEffect(() => {
    if (isOpen) {
      setSourceBranch(currentBranch || defaultBranch || "main");
      setTargetBranch(defaultBranch || "main");
      setCopyState("idle");
      dialogRef.current?.showModal();
    } else {
      setIsExpandedPreview(false);
      dialogRef.current?.close();
    }
  }, [isOpen, currentBranch, defaultBranch]);

  // After a failed copy the link is shown in full; focusing it selects it, ready for Ctrl+C.
  useEffect(() => {
    if (copyState === "failed") previewRef.current?.focus();
  }, [copyState, isExpandedPreview]);

  const effectiveSource = sourceBranch.trim();

  // Query for open merge requests from the selected source branch
  useEffect(() => {
    if (!isOpen) return;
    let active = true;

    if (!effectiveSource) {
      setOpenMr(null);
      return;
    }

    (async () => {
      try {
        const mrs = await getOpenMergeRequests(effectiveSource);
        if (active) {
          setOpenMr(Array.isArray(mrs) && mrs.length > 0 ? mrs[0] : null);
        }
      } catch {
        if (active) setOpenMr(null);
      }
    })();

    return () => {
      active = false;
    };
  }, [isOpen, effectiveSource, getOpenMergeRequests]);

  const isSameBranch = Boolean(effectiveSource && targetBranch.trim() && effectiveSource === targetBranch.trim());

  const generatedUrl = newMergeRequestUrl
    ? newMergeRequestUrl({ sourceBranch: effectiveSource, targetBranch })
    : buildMergeRequestUrl({
        projectWebUrl,
        sourceProjectId: projectId,
        sourceBranch: effectiveSource,
        targetProjectId: projectId,
        targetBranch,
      });

  const handleCopy = async () => {
    try {
      // Throws when there is no clipboard (a plain-http page) as well as when permission is refused.
      await navigator.clipboard.writeText(generatedUrl);
      setCopyState("copied");
    } catch {
      // Show the whole link instead, selected, so it can be copied by hand.
      setIsExpandedPreview(true);
      setCopyState("failed");
    }
    setTimeout(() => setCopyState("idle"), 2000);
  };

  const handleSubmit = (ev) => {
    ev?.preventDefault();
    if (!effectiveSource || !targetBranch.trim() || isSameBranch) return;

    if (typeof window !== "undefined") {
      window.open(generatedUrl, "_blank", "noopener,noreferrer");
    }
    onClose?.();
  };

  if (!isOpen) return null;

  return (
    <MergeRequestDialog
      ref={dialogRef}
      id="merge-request-modal"
      onCancel={(ev) => {
        ev.preventDefault();
        onClose?.();
      }}
    >
      <div className="mr-header">
        <h2>
          <MergeRequestIcon />
          <span>New {review.title}</span>
        </h2>
        <button type="button" className="close-btn" aria-label="Close" onClick={onClose}>
          ×
        </button>
      </div>

      <p className="mr-description">
        Fill in the source and target branches to initiate a new {review.name} in {serverName}.
      </p>

      {isSameBranch && (
        <div className="alert-box error" role="alert" data-testid="mr-same-branch-error">
          <div className="alert-icon">
            <WarningIcon />
          </div>
          <div className="alert-content">
            <strong>Source and target branch cannot be the same</strong>
            <p>You cannot merge &apos;{effectiveSource}&apos; into itself. Please select a different target branch to merge into.</p>
          </div>
        </div>
      )}

      {openMr && (
        <div className="alert-box warning" role="alert" data-testid="mr-warning-box">
          <div className="alert-icon">
            <WarningIcon />
          </div>
          <div className="alert-content">
            <strong>
              Open {review.name} exists for &apos;{effectiveSource}&apos;
            </strong>
            <p>An open {review.name} already includes changes from this ref:</p>
            <div className="mr-details">
              <a href={openMr.webUrl} target="_blank" rel="noopener noreferrer" className="mr-link">
                {review.prefix}
                {openMr.iid} {openMr.title}
              </a>
              <span className="mr-target">
                (target: <code>{openMr.targetBranch}</code>
                {openMr.author ? ` by ${openMr.author}` : ""})
              </span>
            </div>
            <div className="alert-actions">
              <button
                type="button"
                className="view-mr-btn"
                onClick={() => {
                  if (typeof window !== "undefined") window.open(openMr.webUrl, "_blank", "noopener,noreferrer");
                }}
              >
                View {review.title} {review.prefix}
                {openMr.iid} ↗
              </button>
            </div>
          </div>
        </div>
      )}

      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <div className="field-label-row">
            <label htmlFor="mr-field-source">Source branch</label>
            {currentBranch && (
              <div className="quick-actions">
                <button
                  type="button"
                  className={`chip-btn ${sourceBranch === currentBranch ? "active" : ""}`}
                  aria-pressed={sourceBranch === currentBranch}
                  onClick={() => setSourceBranch(currentBranch)}
                  title={`Use the branch you are on: ${currentBranch}`}
                >
                  Current: {currentBranch}
                </button>
              </div>
            )}
          </div>

          <SearchableBranchSelect
            id="mr-field-source"
            value={sourceBranch}
            onChange={(b) => setSourceBranch(b)}
            branches={branches}
            searchBranches={searchBranches}
            defaultBranch={defaultBranch}
            currentBranch={currentBranch}
            placeholder="Search source branch..."
          />

          <span className="field-hint">The branch with the changes to propose. To propose a single commit, create a branch from it first.</span>
        </div>

        <div className="form-group">
          <div className="field-label-row">
            <label htmlFor="mr-field-target">Target branch (merge into)</label>
            {defaultBranch && (
              <div className="quick-actions">
                <button
                  type="button"
                  className={`chip-btn ${targetBranch === defaultBranch ? "active" : ""}`}
                  aria-pressed={targetBranch === defaultBranch}
                  onClick={() => setTargetBranch(defaultBranch)}
                  title={`Autofill to default target branch: ${defaultBranch}`}
                >
                  Default: {defaultBranch}
                </button>
              </div>
            )}
          </div>
          <SearchableBranchSelect
            id="mr-field-target"
            value={targetBranch}
            onChange={(b) => setTargetBranch(b)}
            // The default branch is where merge requests usually go, so it stays on offer even when an
            // add-on has narrowed the branch list to the author's own.
            branches={defaultBranch && !branches.includes(defaultBranch) ? [defaultBranch, ...branches] : branches}
            searchBranches={searchBranches}
            defaultBranch={defaultBranch}
            currentBranch={currentBranch}
            placeholder="Search and select existing target branch..."
          />
          <span className="field-hint">
            The branch to merge into. Shows only existing branches (autofilled to <code>{defaultBranch || "main"}</code> as safe default).
          </span>
        </div>

        <div className="url-preview-card">
          <label>Generated {serverName} Link Preview</label>
          <div className="url-input-wrap">
            {isExpandedPreview ? (
              <textarea
                readOnly
                className="expanded-url"
                value={generatedUrl}
                aria-label={`Generated ${serverName} Link`}
                rows={3}
                data-testid="mr-preview-expanded"
                ref={previewRef}
                onFocus={(e) => e.currentTarget.select()}
              />
            ) : (
              <input
                type="text"
                readOnly
                value={generatedUrl}
                aria-label={`Generated ${serverName} Link`}
                onClick={() => setIsExpandedPreview(true)}
                title="Click to show the whole link"
              />
            )}
            <div className="preview-actions">
              <button type="button" className={`copy-btn ${copyState === "copied" ? "copied" : ""}`} onClick={handleCopy}>
                {copyState === "copied" ? "Copied!" : copyState === "failed" ? "Copy by hand" : "Copy"}
              </button>
              {isExpandedPreview && (
                <button type="button" className="collapse-btn" onClick={() => setIsExpandedPreview(false)} title="Collapse link preview">
                  Collapse
                </button>
              )}
            </div>
          </div>
        </div>

        <div className="modal-actions">
          {openMr && (
            <DefaultButton
              type="button"
              onClick={() => {
                if (typeof window !== "undefined") window.open(openMr.webUrl, "_blank", "noopener,noreferrer");
              }}
            >
              View Existing MR
            </DefaultButton>
          )}
          <DefaultButton type="button" onClick={onClose}>
            Cancel
          </DefaultButton>
          <DefaultButton
            type="submit"
            className="primary"
            disabled={!effectiveSource || !targetBranch.trim() || isSameBranch}
            title={isSameBranch ? "Source and target branch cannot be the same" : undefined}
          >
            Open in {serverName} ↗
          </DefaultButton>
        </div>
      </form>
    </MergeRequestDialog>
  );
};

export default MergeRequestModal;
