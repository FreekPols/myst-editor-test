// GitLab sign-in: the shared OAuth + PKCE client (oauth.js) pointed at a GitLab instance. GitLab's
// token endpoint accepts public clients and answers CORS, so the browser does the whole exchange.
//
// The functions below keep the names this module has always exported, so existing consumers and
// tests are unaffected by the move to a shared client.

import { createOAuthClient } from "./oauth.js";

export { base64url, randomString, sha256Challenge, clearOAuthCallbackParams } from "./oauth.js";

const client = createOAuthClient({
  name: "GitLab",
  keyPrefix: "myst-gl",
  /** Resolve config: runtime overrides → VITE_GITLAB_* build env → defaults. Read lazily per call. */
  getConfig(overrides) {
    const env = (typeof import.meta !== "undefined" && import.meta.env) || {};
    const fallbackRedirect = typeof window !== "undefined" ? `${window.location.origin}${window.location.pathname}` : "";
    return {
      gitlabUrl: (overrides.gitlabUrl || env.VITE_GITLAB_URL || "https://gitlab.tudelft.nl").replace(/\/+$/, ""),
      clientId: overrides.clientId || env.VITE_GITLAB_CLIENT_ID || "",
      redirectUri: overrides.redirectUri || env.VITE_GITLAB_REDIRECT_URI || fallbackRedirect,
      // `api` is required to create commits via the REST API. Narrow to `read_api read_repository`
      // for a read-only deployment.
      scope: overrides.scope || env.VITE_GITLAB_SCOPE || "api",
    };
  },
  authorizeUrl: (config) => `${config.gitlabUrl}/oauth/authorize`,
  authorizeParams: (config) => ({ scope: config.scope }),
  tokenUrl: (config) => `${config.gitlabUrl}/oauth/token`,
  apiUrl: (config, path) => `${config.gitlabUrl}/api/v4/${path}`,
});

/**
 * Set OAuth config at runtime so a single pre-built bundle can be configured per deployment
 * (rather than baking `VITE_GITLAB_*` at build time). Only defined values override; call with no
 * argument to clear.
 *
 * @param {{ gitlabUrl?: string, clientId?: string, redirectUri?: string, scope?: string }} [options]
 */
export const configure = client.configure;
export const isAuthenticated = client.isAuthenticated;
export const logout = client.logout;
export const login = client.login;
export const handleRedirect = client.handleRedirect;
/** Authenticated call to the GitLab REST API; `path` is absolute or relative to `/api/v4`. */
export const authorizedFetch = client.authorizedFetch;
