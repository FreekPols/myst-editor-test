import combineLight from "../assets/brand/combine-light.webp";
import combineDark from "../assets/brand/combine-dark.webp";
import combineMark from "../assets/brand/combine-mark.webp";
import tudelftBlack from "../assets/brand/tudelft-black.svg";
import tudelftWhite from "../assets/brand/tudelft-white.svg";

/**
 * Whose editor this is: shown above the page index, where a Jupyter Book shows the book's own logo,
 * with the institution behind it in the panel's bottom corner and on the loading screen.
 *
 * Every image comes in a light and a dark variant and both are rendered; the theme picks one through
 * --logo-light-display / --logo-dark-display, so a consumer's dark stylesheet needs no knowledge of it.
 * The COMBINE images are raster at four times their displayed size and TU Delft's are vector, so both
 * stay sharp on high-density screens and when zoomed.
 *
 * @typedef {{ light: string, dark: string, alt: string, href?: string }} BrandImage
 * @typedef {{ logo: BrandImage, mark?: string, secondary?: BrandImage }} Branding
 */

/** @type {Branding} */
export const combineBranding = {
  logo: { light: combineLight, dark: combineDark, alt: "COMBINE", href: "https://combine.tudelft.nl" },
  // Stands in for the logo in the toolbar while the page index, and with it the logo, is collapsed.
  mark: combineMark,
  // TU Delft's own exports, clear-space margin included: the margin is part of how their logo is to be
  // shown, so it is sized as a whole rather than cropped to the artwork.
  secondary: { light: tudelftBlack, dark: tudelftWhite, alt: "TU Delft", href: "https://www.tudelft.nl" },
};

/** `branding` as given to the editor: omitted means COMBINE, `false` means none, an object replaces it. */
export const resolveBranding = (branding) => (branding === false || branding === null ? null : (branding ?? combineBranding));
