import { useState, useRef, useEffect } from "preact/hooks";
import styled from "styled-components";

const SmallBranchIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <line x1="6" y1="3" x2="6" y2="15" />
    <circle cx="18" cy="6" r="3" />
    <circle cx="6" cy="18" r="3" />
    <path d="M18 9a9 9 0 0 1-9 9" />
  </svg>
);

const ChevronDown = () => (
  <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
    <path d="M4.293 5.293a1 1 0 0 1 1.414 0L8 7.586l2.293-2.293a1 1 0 1 1 1.414 1.414l-3 3a1 1 0 0 1-1.414 0l-3-3a1 1 0 0 1 0-1.414z" />
  </svg>
);

const CheckIcon = () => (
  <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="3 8 7 12 13 4" />
  </svg>
);

const SmallCommitIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="4" />
    <line x1="1.05" y1="12" x2="8" y2="12" />
    <line x1="16" y1="12" x2="22.95" y2="12" />
  </svg>
);

const Container = styled.div`
  position: relative;
  width: 100%;

  .input-wrapper {
    position: relative;
    display: flex;
    align-items: center;
    width: 100%;
  }

  .branch-left-icon {
    position: absolute;
    left: 10px;
    display: flex;
    align-items: center;
    color: var(--gray-700);
    pointer-events: none;
    z-index: 1;
  }

  input.search-input {
    width: 100%;
    padding: 8px 34px 8px 30px;
    font-size: 13px;
    font-family: inherit;
    border: 1px solid var(--border);
    border-radius: var(--border-radius);
    background-color: var(--editor-bg);
    color: inherit;
    box-sizing: border-box;
    transition: border-color 0.15s ease;

    &:focus {
      outline: none;
      border-color: var(--accent);
    }
  }

  .toggle-btn {
    position: absolute;
    right: 4px;
    top: 50%;
    transform: translateY(-50%);
    background: transparent;
    border: none;
    cursor: pointer;
    padding: 6px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--gray-700);
    border-radius: var(--border-radius);

    &:hover {
      background-color: var(--button-bg-hover);
      color: inherit;
    }
  }

  .dropdown-menu {
    position: absolute;
    top: calc(100% + 4px);
    left: 0;
    right: 0;
    z-index: 1000;
    max-height: 220px;
    overflow-y: auto;
    scrollbar-width: thin;
    background-color: var(--modal-bg, white);
    border: 1px solid var(--border);
    border-radius: var(--border-radius);
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.2);
    margin: 0;
    padding: 4px 0;
    list-style: none;
    box-sizing: border-box;
  }

  .dropdown-item {
    padding: 7px 12px;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 13px;
    color: inherit;
    transition: background-color 0.1s ease;

    &:hover,
    &.highlighted {
      background-color: var(--button-bg-hover, var(--gray-300));
    }

    &.selected {
      color: var(--accent-dark);
      font-weight: 600;
    }

    .branch-item-icon {
      display: flex;
      align-items: center;
      color: var(--gray-700);
      flex-shrink: 0;
    }

    .branch-name {
      flex: 1;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .badge {
      font-size: 10px;
      padding: 1px 6px;
      border-radius: 10px;
      text-transform: uppercase;
      font-weight: bold;
      flex-shrink: 0;

      &.badge-default {
        background-color: var(--gray-300);
        color: var(--gray-800);
      }

      &.badge-current {
        background-color: var(--accent-light);
        color: var(--accent-dark);
      }
    }

    .check-icon {
      color: var(--accent-dark);
      flex-shrink: 0;
    }
  }

  .dropdown-section-header {
    padding: 6px 12px 2px 12px;
    font-size: 10px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    color: var(--gray-600, #6b7280);
    user-select: none;
    pointer-events: none;
  }

  .commit-item {
    .commit-item-icon {
      display: flex;
      align-items: center;
      color: var(--gray-700);
      flex-shrink: 0;
    }

    .commit-hash {
      font-family: var(--font-mono, monospace);
      font-size: 11px;
      padding: 1px 5px;
      border-radius: 3px;
      background-color: var(--gray-300, #e2e8f0);
      color: var(--gray-800, #1e293b);
      font-weight: 600;
      flex-shrink: 0;
    }

    .commit-message {
      flex: 1;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      font-size: 12px;
      color: var(--gray-700);
    }
  }

  .dropdown-status {
    padding: 10px 12px;
    text-align: center;
    font-size: 12px;
    color: var(--gray-700);
    user-select: none;
  }
`;

export const SearchableBranchSelect = ({
  id,
  value,
  onChange,
  onModeChange,
  branches = [],
  searchBranches,
  commits = [],
  searchCommits,
  placeholder,
  defaultBranch = "",
  currentBranch = "",
  mode,
}) => {
  const effectiveMode = mode || (commits?.length > 0 ? "both" : "branch");
  const [isOpen, setIsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [highlightedIndex, setHighlightedIndex] = useState(-1);
  const [asyncBranches, setAsyncBranches] = useState([]);
  const [asyncCommits, setAsyncCommits] = useState([]);
  const [isSearching, setIsSearching] = useState(false);

  const containerRef = useRef(null);
  const inputRef = useRef(null);
  const menuRef = useRef(null);

  // Close when clicking outside
  useEffect(() => {
    if (!isOpen) return;
    const onMouseDown = (ev) => {
      if (containerRef.current && !containerRef.current.contains(ev.target)) {
        setIsOpen(false);
        setSearchQuery("");
      }
    };
    document.addEventListener("mousedown", onMouseDown);
    return () => document.removeEventListener("mousedown", onMouseDown);
  }, [isOpen]);

  // Async branch and commit search debounce
  useEffect(() => {
    const q = searchQuery.trim();
    if (!q || !isOpen) {
      setAsyncBranches([]);
      setAsyncCommits([]);
      setIsSearching(false);
      return;
    }

    const shouldSearchBranches = Boolean(searchBranches);
    const shouldSearchCommits = Boolean(searchCommits);

    if (!shouldSearchBranches && !shouldSearchCommits) {
      setAsyncBranches([]);
      setAsyncCommits([]);
      setIsSearching(false);
      return;
    }

    let active = true;
    const timer = setTimeout(async () => {
      setIsSearching(true);
      try {
        const promises = [];
        if (shouldSearchBranches) promises.push(searchBranches(q));
        else promises.push(Promise.resolve([]));

        if (shouldSearchCommits) promises.push(searchCommits(q));
        else promises.push(Promise.resolve([]));

        const [branchesRes, commitsRes] = await Promise.all(promises);
        if (active) {
          setAsyncBranches(Array.isArray(branchesRes) ? branchesRes : []);
          setAsyncCommits(Array.isArray(commitsRes) ? commitsRes : []);
          setIsSearching(false);
        }
      } catch {
        if (active) setIsSearching(false);
      }
    }, 200);

    return () => {
      active = false;
      clearTimeout(timer);
    };
  }, [searchQuery, isOpen, searchBranches, searchCommits, effectiveMode]);

  // Scroll highlighted item into view
  useEffect(() => {
    if (highlightedIndex >= 0 && menuRef.current) {
      const items = menuRef.current.querySelectorAll(".dropdown-item");
      if (items[highlightedIndex]) {
        items[highlightedIndex].scrollIntoView({ block: "nearest" });
      }
    }
  }, [highlightedIndex]);

  const query = searchQuery.trim().toLowerCase();
  const allBranches = Array.from(new Set([...(branches || []), ...asyncBranches]));
  const filteredBranches = query ? allBranches.filter((b) => typeof b === "string" && b.toLowerCase().includes(query)) : allBranches;

  const supportsCommits = Boolean((commits && commits.length > 0) || searchCommits);
  const commitMap = new Map();
  for (const c of [...(commits || []), ...asyncCommits]) {
    if (c?.hash && !commitMap.has(c.hash)) {
      commitMap.set(c.hash, c);
    }
  }
  const allCommits = Array.from(commitMap.values());
  const filteredCommits = query
    ? allCommits.filter((c) => c?.hash?.toLowerCase().includes(query) || c?.message?.toLowerCase().includes(query))
    : allCommits;

  let matchingBranches = [];
  let matchingCommits = [];

  if (!query) {
    if (effectiveMode === "commit") {
      matchingBranches = [];
      matchingCommits = allCommits;
    } else {
      matchingBranches = allBranches;
      matchingCommits = [];
    }
  } else {
    matchingBranches = filteredBranches;
    matchingCommits = supportsCommits ? filteredCommits : [];
  }

  const branchItems = matchingBranches.map((b) => ({ type: "branch", value: b, label: b }));
  const commitItems = matchingCommits.map((c) => ({ type: "commit", value: c.hash, hash: c.hash, message: c.message }));

  const allItems = effectiveMode === "commit" ? [...commitItems, ...branchItems] : [...branchItems, ...commitItems];

  const selectItem = (item) => {
    onChange?.(item.value, item.type);
    if (onModeChange && item.type) {
      onModeChange(item.type);
    }
    setSearchQuery("");
    setIsOpen(false);
    setHighlightedIndex(-1);
  };

  const openDropdown = () => {
    setIsOpen(true);
    setSearchQuery("");
    const selectedIdx = allItems.findIndex((item) => item.value === value);
    setHighlightedIndex(selectedIdx >= 0 ? selectedIdx : 0);
  };

  const handleKeyDown = (ev) => {
    if (ev.key === "ArrowDown") {
      ev.preventDefault();
      if (!isOpen) {
        openDropdown();
      } else if (allItems.length > 0) {
        setHighlightedIndex((prev) => (prev + 1 < allItems.length ? prev + 1 : 0));
      }
    } else if (ev.key === "ArrowUp") {
      ev.preventDefault();
      if (!isOpen) {
        openDropdown();
      } else if (allItems.length > 0) {
        setHighlightedIndex((prev) => (prev - 1 >= 0 ? prev - 1 : allItems.length - 1));
      }
    } else if (ev.key === "Enter") {
      if (isOpen && allItems.length > 0) {
        ev.preventDefault();
        const target = highlightedIndex >= 0 && highlightedIndex < allItems.length ? allItems[highlightedIndex] : allItems[0];
        selectItem(target);
      } else if (isOpen && searchQuery.trim()) {
        ev.preventDefault();
        onChange?.(searchQuery.trim());
        setSearchQuery("");
        setIsOpen(false);
      }
    } else if (ev.key === "Escape") {
      if (isOpen) {
        ev.preventDefault();
        ev.stopPropagation();
        setIsOpen(false);
        setSearchQuery("");
      }
    } else if (ev.key === "Tab") {
      setIsOpen(false);
      setSearchQuery("");
    }
  };

  const isCommitValue =
    effectiveMode === "commit" || Boolean(value && (commits?.some((c) => c.hash === value) || (value.length >= 7 && /^[0-9a-f]+$/i.test(value))));
  const renderBranchList = () => (
    <>
      {matchingCommits.length > 0 && (
        <li className="dropdown-section-header" role="presentation">
          Branches
        </li>
      )}
      {matchingBranches.map((b) => {
        const overallIndex = allItems.findIndex((i) => i.type === "branch" && i.value === b);
        const isSelected = b === value;
        const isHighlighted = overallIndex === highlightedIndex;
        return (
          <li
            key={`branch-${b}`}
            role="option"
            aria-selected={isSelected}
            className={`dropdown-item branch-item ${isSelected ? "selected" : ""} ${isHighlighted ? "highlighted" : ""}`}
            onMouseDown={(ev) => {
              ev.preventDefault();
              selectItem({ type: "branch", value: b });
            }}
            onMouseEnter={() => setHighlightedIndex(overallIndex)}
          >
            <span className="branch-item-icon">
              <SmallBranchIcon />
            </span>
            <span className="branch-name" title={b}>
              {b}
            </span>
            {b === defaultBranch && <span className="badge badge-default">default</span>}
            {b === currentBranch && <span className="badge badge-current">current</span>}
            {isSelected && (
              <span className="check-icon">
                <CheckIcon />
              </span>
            )}
          </li>
        );
      })}
    </>
  );

  const renderCommitList = () => (
    <>
      {matchingBranches.length > 0 && (
        <li className="dropdown-section-header" role="presentation">
          Commits
        </li>
      )}
      {matchingCommits.map((c) => {
        const overallIndex = allItems.findIndex((i) => i.type === "commit" && i.value === c.hash);
        const isSelected = c.hash === value;
        const isHighlighted = overallIndex === highlightedIndex;
        return (
          <li
            key={`commit-${c.hash}`}
            role="option"
            aria-selected={isSelected}
            className={`dropdown-item commit-item ${isSelected ? "selected" : ""} ${isHighlighted ? "highlighted" : ""}`}
            onMouseDown={(ev) => {
              ev.preventDefault();
              selectItem({ type: "commit", value: c.hash });
            }}
            onMouseEnter={() => setHighlightedIndex(overallIndex)}
          >
            <span className="commit-item-icon">
              <SmallCommitIcon />
            </span>
            <span className="commit-message" title={c.message}>
              {c.message}
            </span>
            <span className="commit-hash">{c.hash.slice(0, 7)}</span>
            {isSelected && (
              <span className="check-icon">
                <CheckIcon />
              </span>
            )}
          </li>
        );
      })}
    </>
  );

  const effectivePlaceholder = placeholder || (effectiveMode === "commit" ? "Search commit messages..." : "Search existing branches...");

  return (
    <Container ref={containerRef} className="searchable-branch-select">
      <div className="input-wrapper">
        <span className="branch-left-icon">{isCommitValue ? <SmallCommitIcon /> : <SmallBranchIcon />}</span>
        <input
          id={id}
          ref={inputRef}
          type="text"
          className="search-input"
          value={isOpen ? searchQuery : value || ""}
          placeholder={isOpen ? (value ? `Current: ${value}` : effectivePlaceholder) : effectivePlaceholder}
          autoComplete="off"
          spellCheck={false}
          onFocus={() => {
            if (!isOpen) openDropdown();
          }}
          onClick={() => {
            if (!isOpen) openDropdown();
          }}
          onInput={(ev) => {
            setSearchQuery(ev.currentTarget.value);
            if (!isOpen) setIsOpen(true);
            setHighlightedIndex(0);
          }}
          onKeyDown={handleKeyDown}
        />
        <button
          type="button"
          className="toggle-btn"
          title="Toggle branch dropdown"
          tabIndex={-1}
          onClick={(ev) => {
            ev.preventDefault();
            if (isOpen) {
              setIsOpen(false);
              setSearchQuery("");
            } else {
              openDropdown();
              inputRef.current?.focus();
            }
          }}
        >
          <ChevronDown />
        </button>
      </div>

      {isOpen && (
        <ul className="dropdown-menu" ref={menuRef} role="listbox">
          {allItems.length > 0 ? (
            effectiveMode === "commit" ? (
              <>
                {matchingCommits.length > 0 && renderCommitList()}
                {matchingBranches.length > 0 && renderBranchList()}
              </>
            ) : (
              <>
                {matchingBranches.length > 0 && renderBranchList()}
                {matchingCommits.length > 0 && renderCommitList()}
              </>
            )
          ) : isSearching ? (
            <li className="dropdown-status">Searching…</li>
          ) : effectiveMode === "commit" ? (
            <li className="dropdown-status no-branches">{searchQuery ? `No commits match "${searchQuery}"` : "No commits found"}</li>
          ) : supportsCommits && effectiveMode === "both" ? (
            <li className="dropdown-status no-branches">No matching branches or commits for &quot;{searchQuery}&quot;</li>
          ) : (
            <li className="dropdown-status no-branches">No existing branches match &quot;{searchQuery}&quot;</li>
          )}
        </ul>
      )}
    </Container>
  );
};

export default SearchableBranchSelect;
