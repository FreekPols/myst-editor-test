// Browser-side OAuth 2.0 using the Authorization Code + PKCE flow (RFC 7636), shared by the GitLab and
// GitHub sign-ins. Each provider (gitlabAuth.js, githubAuth.js) creates one client with
// `createOAuthClient`, describing where it authorizes, where the code is exchanged and how its API is
// called; everything else - PKCE, the CSRF state, token storage, refresh on 401 - lives here.
//
// This is a "public client": there is no client secret in the browser. PKCE proves that the party
// redeeming the authorization code is the same one that started the flow, using a one-time
// `code_verifier`/`code_challenge` pair. (GitHub still wants a secret for the exchange, so its
// `tokenUrl` is a small relay that adds it; see tools/github-token-relay.)
//
// Security choices:
//  - Tokens are held only in memory, never localStorage - an editor that renders user content is
//    exposed to XSS, and localStorage would hand such an attacker the token.
//  - Only the short-lived PKCE `verifier` and CSRF `state` touch sessionStorage, because they must
//    survive the full-page redirect to the provider and back. They are cleared the moment they are used.
//  - The returned `?code`/`state` are stripped from the address bar after exchange.

// --- PKCE helpers (exported for unit testing against the RFC 7636 vectors) ---

/** URL-safe base64 without padding, per PKCE. Accepts an ArrayBuffer or typed array. */
export function base64url(bytes) {
  const arr = new Uint8Array(bytes);
  let str = "";
  for (let i = 0; i < arr.length; i++) str += String.fromCharCode(arr[i]);
  return btoa(str).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

/** Cryptographically random URL-safe string (default 32 bytes of entropy). */
export function randomString(byteLength = 32) {
  return base64url(crypto.getRandomValues(new Uint8Array(byteLength)));
}

/** S256 code challenge: base64url(SHA-256(verifier)). */
export async function sha256Challenge(verifier) {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(verifier));
  return base64url(digest);
}

/**
 * Strip the spent OAuth callback params from the address bar so a plain reload doesn't re-attempt an
 * already-failed exchange (the code/state are single-use). Used by the login-error recovery path.
 */
export function clearOAuthCallbackParams() {
  if (typeof window === "undefined") return;
  const url = new URL(window.location.href);
  for (const p of ["code", "state", "session_state", "error", "error_description"]) url.searchParams.delete(p);
  const clean = url.pathname + (url.searchParams.toString() ? `?${url.searchParams}` : "") + url.hash;
  window.history.replaceState({}, document.title, clean);
}

/**
 * @typedef {object} OAuthProvider
 * @property {string} name - shown in errors ("GitLab", "GitHub")
 * @property {string} keyPrefix - prefix for the sessionStorage keys, so two providers never mix
 * @property {(overrides: object) => object} getConfig - resolve the runtime config (runtime overrides
 *   first); must return at least `clientId` and `redirectUri`
 * @property {(config: object) => string} authorizeUrl - the provider's authorize endpoint
 * @property {(config: object) => string} tokenUrl - where codes and refresh tokens are exchanged
 * @property {(config: object, path: string) => string} apiUrl - absolute URL for an API path
 * @property {(config: object) => Record<string, string>} [apiHeaders] - extra headers on API calls
 * @property {(config: object) => Record<string, string>} [authorizeParams] - extra authorize params
 */

/**
 * One provider's sign-in: its config, its in-memory session, and an authorized fetch for its API.
 *
 * @param {OAuthProvider} provider
 */
export function createOAuthClient(provider) {
  const PKCE_VERIFIER_KEY = `${provider.keyPrefix}-pkce-verifier`;
  const OAUTH_STATE_KEY = `${provider.keyPrefix}-oauth-state`;
  // The exact redirect_uri sent to the authorize endpoint. Stashed so the token exchange reuses the
  // same byte-for-byte value instead of re-deriving it from window.location, which a web server is free
  // to rewrite between the two legs (trailing slash, canonical host) - the provider then rejects it.
  const REDIRECT_URI_KEY = `${provider.keyPrefix}-redirect-uri`;

  /** In-memory token store. Lost on reload by design (re-login is cheap while the provider session is live). */
  let session = { accessToken: null, refreshToken: null, expiresAt: null };
  /** Runtime config overrides, set via configure(). */
  let overrides = {};

  const getConfig = () => provider.getConfig(overrides);

  function clearPkce() {
    sessionStorage.removeItem(PKCE_VERIFIER_KEY);
    sessionStorage.removeItem(OAUTH_STATE_KEY);
    sessionStorage.removeItem(REDIRECT_URI_KEY);
  }

  function storeTokens(tok) {
    session = {
      accessToken: tok.access_token ?? null,
      // Providers rotate refresh tokens; keep the newest, fall back to the previous one.
      refreshToken: tok.refresh_token ?? session.refreshToken,
      expiresAt: tok.expires_in ? Date.now() + tok.expires_in * 1000 : null,
    };
  }

  /** POST a form to the token endpoint and read the JSON answer. GitHub answers 200 with an `error` field. */
  async function tokenRequest(fields) {
    const res = await fetch(provider.tokenUrl(getConfig()), {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded", Accept: "application/json" },
      body: new URLSearchParams(fields),
    });
    const body = res.ok ? await res.json() : null;
    if (!res.ok || !body?.access_token) {
      const detail = body ? body.error_description || body.error : await res.text().catch(() => "");
      const err = new Error(`Token exchange failed (${res.status}): ${detail ?? ""}`);
      err.status = res.status;
      throw err;
    }
    return body;
  }

  /** Exchange the refresh token for a fresh access token. */
  async function refresh() {
    if (!session.refreshToken) throw new Error("No refresh token available; please log in again.");
    const { clientId } = getConfig();
    try {
      storeTokens(await tokenRequest({ grant_type: "refresh_token", refresh_token: session.refreshToken, client_id: clientId }));
    } catch {
      logout();
      throw new Error("Session expired — please log in again.");
    }
  }

  /**
   * Authenticated call to the provider's REST API. `path` is either an absolute URL or a path
   * relative to the API root. Adds the Bearer header and, on a single 401, refreshes the token and
   * retries once. Returns the raw `Response` so callers can pick `.json()`/`.text()`/`.headers`.
   *
   * @param {string} path
   * @param {RequestInit} [init]
   * @returns {Promise<Response>}
   */
  async function authorizedFetch(path, init = {}, _retried = false) {
    const config = getConfig();
    const url = /^https?:/.test(path) ? path : provider.apiUrl(config, path.replace(/^\/+/, ""));

    const res = await fetch(url, {
      ...init,
      headers: { ...provider.apiHeaders?.(config), ...init.headers, Authorization: `Bearer ${session.accessToken}` },
    });

    if (res.status === 401 && !_retried && session.refreshToken) {
      await refresh();
      return authorizedFetch(path, init, true);
    }
    if (!res.ok) {
      const body = await res.text().catch(() => "");
      const err = new Error(`${provider.name} API ${res.status}: ${body || res.statusText}`);
      err.status = res.status;
      err.headers = res.headers;
      throw err;
    }
    return res;
  }

  function logout() {
    session = { accessToken: null, refreshToken: null, expiresAt: null };
  }

  return {
    /**
     * Set config at runtime so a single pre-built bundle can be configured per deployment. Only
     * defined values override; call with no argument to clear. Consumers must apply this on every page
     * load, including the redirect-back load (module state does not survive the full-page redirect).
     */
    configure(options) {
      if (!options) {
        overrides = {};
        return;
      }
      for (const [k, v] of Object.entries(options)) if (v !== undefined) overrides[k] = v;
    },

    getConfig,

    isAuthenticated() {
      return !!session.accessToken;
    },

    /** Drop all tokens (e.g. on logout or an unrecoverable 401). */
    logout,

    /** Use a token the user supplied (a GitHub fine-grained token). Kept in memory like any other. */
    useToken(token) {
      session = { accessToken: token || null, refreshToken: null, expiresAt: null };
    },

    /**
     * Step 1: start the login. Generates PKCE material, persists it across the redirect, and sends the
     * browser to the provider's authorize endpoint. Never returns (the page navigates away).
     */
    async login() {
      const config = getConfig();
      const verifier = randomString(48);
      const state = randomString(24);
      sessionStorage.setItem(PKCE_VERIFIER_KEY, verifier);
      sessionStorage.setItem(OAUTH_STATE_KEY, state);
      // Persist the exact redirect_uri we send now, so handleRedirect() can reuse it verbatim.
      sessionStorage.setItem(REDIRECT_URI_KEY, config.redirectUri);

      const params = new URLSearchParams({
        client_id: config.clientId,
        redirect_uri: config.redirectUri,
        response_type: "code",
        state,
        code_challenge: await sha256Challenge(verifier),
        code_challenge_method: "S256",
        ...provider.authorizeParams?.(config),
      });
      window.location.assign(`${provider.authorizeUrl(config)}?${params}`);
    },

    /**
     * Step 2: complete the login if we've been redirected back with `?code`. Verifies the CSRF
     * `state`, exchanges the code for tokens, cleans the URL, and returns the access token.
     * Returns `null` when there is no code (i.e. a normal page load, not a callback).
     */
    async handleRedirect() {
      if (typeof window === "undefined") return null;
      const url = new URL(window.location.href);
      const params = url.searchParams;

      if (params.get("error")) {
        clearPkce();
        throw new Error(`${provider.name} OAuth error: ${params.get("error_description") || params.get("error")}`);
      }

      const code = params.get("code");
      if (!code) return null;

      const expectedState = sessionStorage.getItem(OAUTH_STATE_KEY);
      const verifier = sessionStorage.getItem(PKCE_VERIFIER_KEY);
      if (!expectedState || params.get("state") !== expectedState) {
        clearPkce();
        throw new Error("OAuth state mismatch — aborting login (possible CSRF).");
      }
      if (!verifier) {
        clearPkce();
        throw new Error("Missing PKCE verifier — please restart the login flow.");
      }

      const { clientId, redirectUri: configuredRedirect } = getConfig();
      // Reuse the redirect_uri login() actually sent; only fall back to re-deriving it if it's missing
      // (e.g. login started in another tab). OAuth requires this to match the authorize leg byte-for-byte.
      const redirectUri = sessionStorage.getItem(REDIRECT_URI_KEY) || configuredRedirect;
      try {
        storeTokens(
          await tokenRequest({ client_id: clientId, redirect_uri: redirectUri, grant_type: "authorization_code", code, code_verifier: verifier }),
        );
      } finally {
        clearPkce();
      }

      // Remove the sensitive params from the address bar / history.
      params.delete("code");
      params.delete("state");
      params.delete("session_state");
      const clean = url.pathname + (params.toString() ? `?${params}` : "") + url.hash;
      window.history.replaceState({}, document.title, clean);

      return session.accessToken;
    },

    authorizedFetch,
  };
}
