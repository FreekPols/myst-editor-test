/**
 * Utilities for GitLab Merge Request URL generation and integration.
 */

/**
 * What each forge calls a request to merge a branch, and how it numbers them ("MR !12", "PR #12"). The
 * editor's wording comes from the backend's `review`; GitLab's is the default.
 */
export const GITLAB_REVIEW = { title: "Merge Request", name: "merge request", short: "MR", prefix: "!" };
export const GITHUB_REVIEW = { title: "Pull Request", name: "pull request", short: "PR", prefix: "#" };

/**
 * Builds the GitLab URL to initiate a new merge request with pre-filled query parameters.
 *
 * Example target:
 * https://gitlab.tudelft.nl/combine/myst-editor/-/merge_requests/new?merge_request%5Bsource_project_id%5D=28652&merge_request%5Bsource_branch%5D=development&merge_request%5Btarget_project_id%5D=28652&merge_request%5Btarget_branch%5D=main
 *
 * There are deliberately no defaults for the project: a wrong one sends the author to open a merge
 * request in somebody else's repository. GitLab only accepts a branch as the source, never a commit.
 *
 * @param {object} options
 * @param {string} options.projectWebUrl - Web URL of the GitLab project the book lives in
 * @param {string|number} [options.sourceProjectId] - Source project ID
 * @param {string} options.sourceBranch - Source branch name
 * @param {string|number} [options.targetProjectId] - Target project ID
 * @param {string} options.targetBranch - Target branch name (e.g. 'main')
 * @returns {string} Fully formatted URL with encoded query parameters
 */
export function buildMergeRequestUrl({ projectWebUrl, sourceProjectId, sourceBranch, targetProjectId, targetBranch } = {}) {
  if (!projectWebUrl) throw new Error("buildMergeRequestUrl: `projectWebUrl` is required.");
  const base = `${projectWebUrl.replace(/\/+$/, "")}/-/merge_requests/new`;
  const params = new URLSearchParams();
  const set = (key, value) => {
    if (value !== undefined && value !== null && String(value).trim() !== "") params.set(`merge_request[${key}]`, String(value).trim());
  };
  set("source_project_id", sourceProjectId);
  set("source_branch", sourceBranch);
  set("target_project_id", targetProjectId);
  set("target_branch", targetBranch);

  const queryString = params.toString();
  return queryString ? `${base}?${queryString}` : base;
}
