// GitHub sign-in, two ways:
//
//  - OAuth through a GitHub App: the shared OAuth + PKCE client (oauth.js). GitHub's token endpoint
//    still demands the app's client secret and answers no CORS, so the code is exchanged through a
//    small relay (`tokenUrl`, see tools/github-token-relay) that adds the secret. The token can only
//    reach repositories the app is installed on, with the app's permissions.
//  - A fine-grained personal access token the user pastes (`useToken`). No relay needed, and the
//    token reaches only the repositories and permissions the user picked when making it.
//
// Either way the token lives in memory only, like the GitLab one.

import { createOAuthClient } from "./oauth.js";

/** GitHub's REST API version this editor is written against. */
const API_VERSION = "2022-11-28";

const client = createOAuthClient({
  name: "GitHub",
  keyPrefix: "myst-gh",
  getConfig(overrides) {
    const fallbackRedirect = typeof window !== "undefined" ? `${window.location.origin}${window.location.pathname}` : "";
    const githubUrl = (overrides.githubUrl || "https://github.com").replace(/\/+$/, "");
    // github.com serves its API from api.github.com; GitHub Enterprise Server from <host>/api/v3.
    const apiUrl = (overrides.githubApiUrl || (githubUrl === "https://github.com" ? "https://api.github.com" : `${githubUrl}/api/v3`)).replace(
      /\/+$/,
      "",
    );
    return {
      githubUrl,
      apiUrl,
      graphqlUrl: graphqlUrlFor(apiUrl),
      clientId: overrides.clientId || "",
      redirectUri: overrides.redirectUri || fallbackRedirect,
      tokenUrl: overrides.tokenUrl || "",
    };
  },
  authorizeUrl: (config) => `${config.githubUrl}/login/oauth/authorize`,
  tokenUrl: (config) => {
    if (!config.tokenUrl) throw new Error("GitHub sign-in needs `tokenUrl`, the address of the token relay.");
    return config.tokenUrl;
  },
  apiUrl: (config, path) => `${config.apiUrl}/${path}`,
  apiHeaders: () => ({ Accept: "application/vnd.github+json", "X-GitHub-Api-Version": API_VERSION }),
});

/** GraphQL lives next to REST: api.github.com/graphql, or <host>/api/graphql on Enterprise Server. */
export function graphqlUrlFor(apiUrl) {
  return apiUrl.endsWith("/api/v3") ? `${apiUrl.slice(0, -"/v3".length)}/graphql` : `${apiUrl}/graphql`;
}

/** @param {{ githubUrl?: string, githubApiUrl?: string, clientId?: string, redirectUri?: string, tokenUrl?: string }} [options] */
export const configure = client.configure;
export const getConfig = client.getConfig;
export const isAuthenticated = client.isAuthenticated;
export const logout = client.logout;
export const login = client.login;
export const handleRedirect = client.handleRedirect;
export const useToken = client.useToken;
/** Authenticated call to the GitHub REST API; `path` is absolute or relative to the API root. */
export const authorizedFetch = client.authorizedFetch;
export { clearOAuthCallbackParams } from "./oauth.js";
