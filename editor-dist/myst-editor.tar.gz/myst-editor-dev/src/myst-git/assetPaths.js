/** Where an image referenced from a page lives in the repository, and the reverse.
 *
 * MyST resolves a relative image path against the page that uses it, and an absolute one (`/x.png`)
 * against the project root - the folder holding myst.yml. The preview has to do the same, or every
 * image on a page in a chapter folder is looked for at the top of the repository and comes up empty. */

/** Normalise a slash-separated path: collapse `.` and `..` and repeated slashes. A `..` that would climb
 * above the repository root is dropped rather than kept, since there is nothing above it to point at. */
export function normalizePath(path) {
  const out = [];
  for (const part of path.split("/")) {
    if (!part || part === ".") continue;
    if (part === "..") out.pop();
    else out.push(part);
  }
  return out.join("/");
}

/** The folder a repository path sits in, without a trailing slash; "" at the root. */
export const dirname = (path) => (path.includes("/") ? path.slice(0, path.lastIndexOf("/")) : "");

/** Whether a reference points outside the repository, and so is the browser's to fetch, not ours. */
export const isExternalUrl = (url) => /^([a-z][a-z0-9+.-]*:|\/\/)/i.test(url);

/**
 * The repository path a page's image reference points at.
 *
 * @param {string} pagePath - the page, as a repository path (e.g. "chapter1/page.md")
 * @param {string} url - the reference as written in the page (e.g. "images/fig.png" or "/fig.png")
 * @param {string} [projectRoot] - the folder `/`-prefixed references are relative to ("" for the repo root)
 * @returns {string|null} null for a URL that is not a repository path at all
 */
export function resolveAssetPath(pagePath, url, projectRoot = "") {
  if (!url || isExternalUrl(url)) return null;
  // A query or fragment is not part of the file name.
  const clean = decodeURIComponentSafe(url.split(/[?#]/)[0]);
  if (!clean) return null;
  const base = clean.startsWith("/") ? projectRoot : dirname(pagePath ?? "");
  return normalizePath(`${base}/${clean}`);
}

/** The reference to write into a page so that it resolves to `repoPath`: relative to the page's folder. */
export function relativeTo(pagePath, repoPath) {
  const from = normalizePath(dirname(pagePath ?? ""))
    .split("/")
    .filter(Boolean);
  const to = normalizePath(repoPath).split("/").filter(Boolean);
  let common = 0;
  while (common < from.length && common < to.length - 1 && from[common] === to[common]) common++;
  return [...from.slice(common).map(() => ".."), ...to.slice(common)].join("/");
}

/** A file name that is safe in a repository path and in a Markdown directive line: lowercase, no spaces,
 * nothing a shell or a URL would trip on. The extension is kept (lowercased) so the type stays obvious. */
export function sanitizeFileName(name) {
  const base = String(name ?? "")
    .split(/[\\/]/)
    .pop();
  const dot = base.lastIndexOf(".");
  const stem = dot > 0 ? base.slice(0, dot) : base;
  const ext =
    dot > 0
      ? base
          .slice(dot + 1)
          .toLowerCase()
          .replace(/[^a-z0-9]/g, "")
      : "";
  const cleanStem =
    stem
      .normalize("NFKD")
      .replace(/[̀-ͯ]/g, "")
      .toLowerCase()
      .replace(/[^a-z0-9._-]+/g, "-")
      .replace(/-{2,}/g, "-")
      .replace(/^[-.]+|[-.]+$/g, "") || "image";
  return ext ? `${cleanStem}.${ext}` : cleanStem;
}

/** `path` itself if nothing is there yet, otherwise the first of `name-2.ext`, `name-3.ext`, … that is free. */
export async function withUniqueSuffix(path, exists) {
  if (!(await exists(path))) return path;
  const dot = path.lastIndexOf(".");
  const slash = path.lastIndexOf("/");
  const hasExt = dot > slash + 1;
  const stem = hasExt ? path.slice(0, dot) : path;
  const ext = hasExt ? path.slice(dot) : "";
  for (let n = 2; n < 1000; n++) {
    const candidate = `${stem}-${n}${ext}`;
    if (!(await exists(candidate))) return candidate;
  }
  throw new Error(`No free name for ${path}`);
}

function decodeURIComponentSafe(s) {
  try {
    return decodeURIComponent(s);
  } catch {
    return s;
  }
}

/** Every image a page refers to, as written: `{figure}`/`{image}` directives, Markdown images and HTML
 * `<img>`. Used to tell which uploads a commit's pages actually need. */
export function imageReferences(text) {
  const refs = [];
  for (const m of String(text ?? "").matchAll(/^[ \t]*(?:`{3,}|~{3,}|:{3,})\{(?:figure|image)\}[ \t]+(\S[^\n]*?)[ \t]*$/gm)) refs.push(m[1]);
  // `![alt](<path with spaces.png>)` is how CommonMark writes a destination that has spaces in it.
  for (const m of String(text ?? "").matchAll(/!\[[^\]]*\]\(\s*(?:<([^>\n]+)>|([^)\s]+))(?:\s+["'][^)]*["'])?\s*\)/g)) refs.push(m[1] ?? m[2]);
  for (const m of String(text ?? "").matchAll(/<img\b[^>]*?\bsrc\s*=\s*["']([^"']+)["']/gi)) refs.push(m[1]);
  return refs;
}

/** A folder or file stem made from what an author typed: "Week 1: Forces" becomes "week-1-forces". */
export function slugify(name) {
  return String(name ?? "")
    .normalize("NFKD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9_-]+/g, "-")
    .replace(/-{2,}/g, "-")
    .replace(/^-+|-+$/g, "");
}

/**
 * Rewrite a page's references to files in the repository, for files that move: the page itself (from
 * `from` to `to`), and any file it points at (`retarget`). Each reference keeps pointing at the same
 * file. Covers Markdown links, images and link definitions, the `{figure}`, `{image}`, `{include}` and
 * `{literalinclude}` directives, and HTML `<img>`. References to other sites and to anchors on the page
 * are left alone; a reference that needs no change keeps the exact form it was written in.
 *
 * @param {string} text the page
 * @param {{ from: string, to?: string, retarget?: (path: string) => string|null|undefined, projectRoot?: string }} move
 *   `from` and `to` are the page's repository paths before and after (the same when only other files
 *   move); `retarget` gives a file's new path, or nothing when it stays; `projectRoot` is what `/…`
 *   references are relative to.
 */
export function relinkReferences(text, { from, to = from, retarget = () => null, projectRoot = "" }) {
  const root = normalizePath(projectRoot);
  const relink = (url) => {
    if (!url || isExternalUrl(url) || url.startsWith("#")) return url;
    const cut = url.search(/[?#]/);
    const path = cut < 0 ? url : url.slice(0, cut);
    const rest = cut < 0 ? "" : url.slice(cut);
    if (!path) return url;
    if (path.startsWith("/")) {
      // Relative to the project root, so it only changes when the file it points at moves.
      const moved = retarget(normalizePath(`${root}/${path}`));
      if (!moved) return url;
      if (root && moved !== root && !moved.startsWith(`${root}/`)) return relativeTo(to, moved) + rest;
      return `/${root ? moved.slice(root.length + 1) : moved}${rest}`;
    }
    const target = normalizePath(`${dirname(from)}/${path}`);
    const moved = retarget(target);
    if (!moved && dirname(from) === dirname(to)) return url;
    return relativeTo(to, moved || target) + rest;
  };
  return String(text ?? "")
    .replace(
      /^([ \t]*(?:`{3,}|~{3,}|:{3,})\{(?:figure|image|include|literalinclude)\}[ \t]+)(\S[^\n]*?)([ \t]*)$/gm,
      (_, lead, url, tail) => lead + relink(url) + tail,
    )
    .replace(/(\]\(\s*)(?:<([^>\n]+)>|([^)\s]+))/g, (_, lead, angled, plain) =>
      angled != null ? `${lead}<${relink(angled)}>` : lead + relink(plain),
    )
    .replace(/^( {0,3}\[[^\]\n]+\]:[ \t]*)(?:<([^>\n]+)>|(\S+))/gm, (_, lead, angled, plain) =>
      angled != null ? `${lead}<${relink(angled)}>` : lead + relink(plain),
    )
    .replace(/(<img\b[^>]*?\bsrc\s*=\s*["'])([^"']+)/gi, (_, lead, url) => lead + relink(url));
}

/** Rewrite a page's relative references for the page moving from `fromPage` to `toPage` alone (see
 * relinkReferences). */
export function rebaseReferences(text, fromPage, toPage) {
  if (dirname(fromPage) === dirname(toPage)) return text;
  return relinkReferences(text, { from: fromPage, to: toPage });
}
