import styled from "styled-components";
import { useSignal, useSignalEffect } from "@preact/signals";
import { useRef } from "preact/hooks";
import { Modal } from "../components/CommonUI";

const PickerForm = styled(Modal)`
  && {
    width: 400px;
  }
  &::backdrop {
    pointer-events: none;
  }
  h2 {
    margin: 0 0 12px;
    font-size: 14px;
    font-weight: 600;
  }
  input {
    width: 100%;
    height: 40px;
    padding: 0 15px;
    box-sizing: border-box;
    background-color: var(--button-bg);
    border: 1px solid var(--border);
    border-radius: var(--border-radius);
    font-family: Lato, sans-serif;
  }
  ul {
    list-style: none;
    padding: 0;
    margin: 12px 0 0;
    max-height: 320px;
    overflow-y: auto;
    scrollbar-width: thin;
  }
  li {
    cursor: pointer;
    border-radius: var(--border-radius);
    min-height: 40px;
    padding: 8px 5px;
    display: flex;
    align-items: center;
    font-size: 12px;
    font-family: Lato, sans-serif;
    &:hover {
      background-color: var(--button-bg-hover);
    }
    &.active {
      color: var(--accent-dark);
      font-weight: bold;
    }
  }
  .tag {
    margin-left: auto;
    padding: 1px 6px;
    border: 1px solid var(--border);
    border-radius: var(--border-radius);
    color: var(--gray-700);
    font-size: 11px;
    font-weight: normal;
  }
  .marked::after {
    content: "";
    display: inline-block;
    margin-left: 8px;
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background-color: currentColor;
  }

  .create-branch-item {
    cursor: pointer;
    border-radius: var(--border-radius);
    min-height: 38px;
    padding: 8px 12px;
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 12px;
    font-family: Lato, sans-serif;
    background-color: var(--code-bg, rgba(0, 0, 0, 0.04));
    border: 1px dashed var(--accent, #3b82f6);
    color: var(--accent-dark, #2563eb);
    margin: 10px 0 4px;
    width: 100%;
    box-sizing: border-box;
    text-align: left;

    &:hover {
      background-color: var(--button-bg-hover);
      border-style: solid;
    }

    .create-icon {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 18px;
      height: 18px;
      border-radius: 50%;
      background-color: var(--accent-light, #dbeafe);
      color: var(--accent-dark, #2563eb);
      font-weight: bold;
      font-size: 14px;
      flex-shrink: 0;
    }

    .from-hint {
      color: var(--gray-600, #64748b);
      font-size: 11px;
      margin-left: 4px;
    }
  }
`;

const GitPickerModal = ({
  id,
  title,
  open,
  options,
  selectedValue,
  onSelect,
  searchPlaceholder,
  searchOptions,
  loadMore,
  onCreate,
  currentBranch,
}) => {
  const modalRef = useRef();
  const search = useSignal("");
  const shown = useSignal(options.value);
  // The query `shown` holds results for; differs from `search` while a search is still debouncing.
  const shownFor = useRef("");
  // Page 1 is the initial list; paginate from 2.
  const page = useRef(2);
  const loading = useRef(false);

  useSignalEffect(() => {
    const dialog = modalRef.current;
    if (!open.value) {
      dialog?.close?.();
      // Cleared on the way out rather than on opening, so the next opening starts empty without racing
      // whatever is typed straight away.
      search.value = "";
      return;
    }
    page.current = 2;
    dialog.onclose = () => (open.value = false);
    dialog.showModal?.();
    const dismiss = (ev) => dialog.open && !ev.composedPath().includes(dialog) && dialog.close();
    document.addEventListener("mousedown", dismiss);
    return () => document.removeEventListener("mousedown", dismiss);
  });

  // A signal effect, so it also re-runs when `options` grows: that is how a page loaded by scrolling to
  // the bottom of the list shows up.
  useSignalEffect(() => {
    if (!open.value) return;
    const query = search.value.trim();
    if (query == "") {
      shownFor.current = "";
      shown.value = options.value;
      return;
    }
    const timer = setTimeout(
      () =>
        searchOptions(query).then((opts) => {
          shownFor.current = query;
          shown.value = opts;
        }),
      300,
    );
    return () => clearTimeout(timer);
  });

  const choose = (o) => {
    onSelect(o, !options.peek().some((x) => x.value == o.value));
    open.value = false;
  };
  const create = (name) => {
    onCreate(name);
    open.value = false;
  };

  /** Enter picks the exact match, else the first match; it only offers to create a branch when nothing
   * matches, so a half-typed name opens that branch rather than a dialog to create it. */
  async function onEnter() {
    const query = search.peek().trim();
    if (!query) return shown.peek().length > 0 && choose(shown.peek()[0]);
    const q = query.toLowerCase();
    const exact = (list) => list.find((o) => o.value.toLowerCase() === q);
    // Until the search answers, `shown` is the unfiltered list, so filter it here.
    const matching = (list) => list.filter((o) => o.value.toLowerCase().includes(q) || String(o.label).toLowerCase().includes(q));
    let local = shownFor.current === query ? shown.peek() : matching(shown.peek());
    if (local.length === 0 && shownFor.current !== query) {
      // Nothing loaded matches yet; ask the backend before deciding the name is free.
      local = await searchOptions(query);
      if (search.peek().trim() !== query) return;
    }
    const pick = exact(local) ?? exact(options.peek()) ?? local[0];
    if (pick) choose(pick);
    else if (onCreate) create(query);
  }

  function loadNextPage() {
    if (loading.current) return;
    loading.current = true;
    loadMore?.(page.current)
      ?.then?.(() => {
        page.current++;
        setTimeout(() => (loading.current = false), 500);
      })
      // Keep `loading` set on failure (e.g. no more pages) to stop retrying.
      ?.catch?.((err) => console.warn("Error while loading more options: ", err));
  }

  const query = search.value.trim();

  return (
    <PickerForm ref={modalRef} id={id}>
      <h2>{title}</h2>
      <input
        type="text"
        placeholder={searchPlaceholder}
        value={search.value}
        onInput={(ev) => (search.value = ev.target.value)}
        onKeyDown={(ev) => {
          if (ev.key !== "Enter") return;
          ev.preventDefault();
          onEnter();
        }}
      />
      {onCreate && (
        <button type="button" className="create-branch-item" data-create-branch="" onClick={() => create(query)}>
          <span className="create-icon">+</span>
          <span>
            {query ? (
              <>
                Create branch <strong>{query}</strong>
                {currentBranch && <span className="from-hint">from {currentBranch}</span>}
              </>
            ) : (
              <>
                Create new branch...
                {currentBranch && <span className="from-hint">from {currentBranch}</span>}
              </>
            )}
          </span>
        </button>
      )}
      <ul
        id={`${id}-list`}
        onScroll={(ev) => {
          const list = ev.currentTarget;
          const atBottom = Math.abs(list.scrollTop + list.clientHeight - list.scrollHeight) < 5;
          if (atBottom && !search.value.trim()) loadNextPage();
        }}
      >
        {shown.value.map((o) => (
          <li key={o.value} onClick={() => choose(o)} className={o.value == selectedValue ? "active" : ""}>
            <span className={o.marked ? "marked" : ""}>{o.label}</span>
            {o.tag && (
              <span className="tag" title={o.tagTitle}>
                {o.tag}
              </span>
            )}
          </li>
        ))}
      </ul>
    </PickerForm>
  );
};

export default GitPickerModal;
