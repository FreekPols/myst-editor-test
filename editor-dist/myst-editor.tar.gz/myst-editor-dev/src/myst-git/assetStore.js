import { signal } from "@preact/signals";

/**
 * The images the preview shows, held in this tab.
 *
 * Two kinds, looked up in this order:
 * - pending: uploaded in the editor and not committed yet, per branch. They exist nowhere else, so they
 *   live exactly as long as the tab - the same lifetime as unsaved text - and go out with the next commit.
 * - committed: images already in the repository, cached per commit. A file at a given commit never
 *   changes, so an entry stays good; without this every re-render of a paragraph with an image in it
 *   asked GitLab for the image again.
 *
 * Preview URLs are object URLs, so every one handed out is revoked when its entry goes.
 */
export function createAssetStore({ getFileBlob, maxCached = 100 } = {}) {
  /** @type {Map<string, Map<string, { path: string, blob: Blob, url: string, size: number, type: string }>>} */
  const pending = new Map();
  /** @type {Map<string, { promise: Promise<string|null>, url?: string|null }>} oldest first */
  const committed = new Map();
  /** Bumped on every change to the pending uploads, for anything that displays or counts them. */
  const version = signal(0);

  const revoke = (url) => {
    if (url?.startsWith("blob:")) URL.revokeObjectURL(url);
  };
  const key = (commitHash, path) => `${commitHash}:${path}`;
  const forBranch = (branch) => {
    if (!pending.has(branch)) pending.set(branch, new Map());
    return pending.get(branch);
  };
  const remember = (k, entry) => {
    committed.delete(k);
    committed.set(k, entry);
    while (committed.size > maxCached) {
      const [oldest, { url }] = committed.entries().next().value;
      committed.delete(oldest);
      revoke(url);
    }
  };

  return {
    version,

    /** Hold an uploaded image until it is committed. Replaces (and releases) one staged at the same path. */
    stage(branch, path, blob) {
      const entries = forBranch(branch);
      revoke(entries.get(path)?.url);
      entries.set(path, { path, blob, url: URL.createObjectURL(blob), size: blob.size, type: blob.type });
      version.value++;
    },

    unstage(branch, path) {
      const entries = pending.get(branch);
      if (!entries?.has(path)) return;
      revoke(entries.get(path).url);
      entries.delete(path);
      version.value++;
    },

    /** Every image waiting to be committed on a branch. */
    pendingFor(branch) {
      return [...(pending.get(branch)?.values() ?? [])];
    },

    isPending(branch, path) {
      return !!pending.get(branch)?.has(path);
    },

    /** A URL to show right away, if one is already known - so a re-render does not flash a blank image. */
    peek(branch, commitHash, path) {
      return pending.get(branch)?.get(path)?.url ?? committed.get(key(commitHash, path))?.url;
    },

    /** A URL for the image, or null if it is neither pending nor in the repository at this commit. */
    lookup(branch, commit, path) {
      const local = pending.get(branch)?.get(path);
      if (local) return Promise.resolve(local.url);
      const k = key(commit?.hash, path);
      const cached = committed.get(k);
      if (cached) {
        remember(k, cached);
        return cached.promise;
      }
      const entry = {};
      entry.promise = Promise.resolve(getFileBlob ? getFileBlob(branch, commit, path) : null).then(
        (url) => (entry.url = url ?? null),
        (err) => {
          // A failure is not cached: the next render asks again, which is what a transient error wants.
          committed.delete(k);
          throw err;
        },
      );
      remember(k, entry);
      return entry.promise;
    },

    /** After a commit: the uploads it carried are in the repository now, at `commitHash`. Their URLs are
     * moved across rather than revoked, so the preview keeps showing them without fetching them back. */
    promote(branch, commitHash, paths) {
      const entries = pending.get(branch);
      if (!entries) return;
      for (const path of paths) {
        const entry = entries.get(path);
        if (!entry) continue;
        entries.delete(path);
        remember(key(commitHash, path), { promise: Promise.resolve(entry.url), url: entry.url });
      }
      version.value++;
    },

    /** Drop the uploads waiting on a branch, e.g. when the author discards their changes. */
    discard(branch) {
      for (const { url } of pending.get(branch)?.values() ?? []) revoke(url);
      pending.delete(branch);
      version.value++;
    },
  };
}

/** A Blob as base64, for GitLab's commit API. */
export function blobToBase64(blob) {
  return new Promise((ok, fail) => {
    const reader = new FileReader();
    reader.onload = () => ok(String(reader.result).slice(String(reader.result).indexOf(",") + 1));
    reader.onerror = () => fail(reader.error);
    reader.readAsDataURL(blob);
  });
}
