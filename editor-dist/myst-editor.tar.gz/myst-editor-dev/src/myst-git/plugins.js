/**
 * Add-ons for the git editor.
 *
 * A plugin is a plain object passed in `mountGitEditor(target, { plugins: [...] })`:
 *
 *   {
 *     name: "branch-access",
 *     apiVersion: 1,
 *     // Optional. Runs once after login, before the editor mounts. Returns the backend to use, usually
 *     // the one it was given with some methods replaced. May be async.
 *     wrapBackend(backend, ctx) { return { ...backend, getBranches, canOpenBranch } },
 *     // Optional. Runs once the editor is up, with the same { state, git } an `onReady` handler gets.
 *     setup(editor) {},
 *   }
 *
 * The seams are deliberately few. Every branch the editor lists, searches, opens or creates goes
 * through the backend object (getBranches, searchBranches, initialBranches, createBranch) or through
 * the optional `canOpenBranch(name)`, which the editor asks before switching. So a plugin can change
 * what is on offer without reaching into the UI, and the UI can change without breaking plugins.
 *
 * A plugin steers the editor; it is not a security boundary. Anything it hides is still reachable
 * through the forge itself with the same account.
 */

export const PLUGIN_API_VERSION = 1;

/** Thrown by `ctx.fail`: the plugin has decided the editor must not open, and says why. */
export class PluginStop extends Error {
  constructor(message, plugin) {
    super(message);
    this.name = "PluginStop";
    this.plugin = plugin;
  }
}

/**
 * Let each plugin wrap the backend in turn.
 *
 * @param {object[]} plugins
 * @param {object} backend - what createGitBackend returned
 * @param {{ kind: string, api?: (path: string, init?: RequestInit) => Promise<Response> }} env
 * @returns {Promise<object>} the backend after every plugin has had its turn
 * @throws {PluginStop} when a plugin calls `ctx.fail`, or wraps any other error a plugin throws
 */
export async function applyPluginBackends(plugins, backend, { kind, api = null } = {}) {
  let userPromise = null;
  let current = backend;
  for (const plugin of plugins) {
    checkVersion(plugin);
    if (typeof plugin.wrapBackend !== "function") continue;
    const ctx = {
      backend: kind,
      projectId: current.projectId ?? null,
      defaultBranch: current.defaultBranch ?? current.initialBranches?.[0] ?? "main",
      // Shared across plugins: one request however many ask.
      user: () => (userPromise ??= Promise.resolve(current.getCurrentUser ? current.getCurrentUser() : null)),
      // The editor's own authorized fetch for the forge's API (GitLab or GitHub), so a plugin can make
      // API calls without ever holding the token. Null for the stub.
      api,
      fail: (message) => {
        throw new PluginStop(message, plugin.name);
      },
    };
    try {
      const next = await plugin.wrapBackend(current, ctx);
      if (next && typeof next === "object") current = next;
    } catch (err) {
      if (err instanceof PluginStop) throw err;
      // A plugin that breaks would otherwise leave the boot half done. Stopping with its name keeps
      // the failure attributable; a plugin that is meant to be optional should catch its own errors.
      throw new PluginStop(`The "${plugin.name ?? "unnamed"}" add-on could not start: ${err?.message ?? err}`, plugin.name);
    }
  }
  return current;
}

/**
 * Run each plugin's `setup` once the editor is ready. A failing setup is reported and skipped: by now
 * the editor works, and one add-on's bug should not take it away.
 *
 * @param {object[]} plugins
 * @param {{ state: object, git: object }} editor
 * @param {(text: string) => void} [notify]
 */
export function runPluginSetups(plugins, editor, notify = () => {}) {
  for (const plugin of plugins) {
    if (typeof plugin.setup !== "function") continue;
    try {
      const result = plugin.setup(editor);
      // An async setup reports the same way when it rejects.
      result?.catch?.((err) => reportSetupFailure(plugin, err, notify));
    } catch (err) {
      reportSetupFailure(plugin, err, notify);
    }
  }
}

function reportSetupFailure(plugin, err, notify) {
  console.error(`Add-on "${plugin.name ?? "unnamed"}" failed to set up:`, err);
  notify(`The "${plugin.name ?? "unnamed"}" add-on failed to start; the editor works without it.`);
}

function checkVersion(plugin) {
  if (plugin.apiVersion !== undefined && plugin.apiVersion !== PLUGIN_API_VERSION) {
    console.warn(`Add-on "${plugin.name ?? "unnamed"}" targets plugin API ${plugin.apiVersion}; this editor provides ${PLUGIN_API_VERSION}.`);
  }
}
