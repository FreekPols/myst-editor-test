import MystEditorGit from "./MystEditorGit.jsx";
import { createGitBackend } from "./backends.js";
import * as gitlabAuth from "./gitlabAuth.js";
import * as githubAuth from "./githubAuth.js";
import { clearOAuthCallbackParams } from "./oauth.js";
import { resolveBranding } from "./branding.js";
import { applyPluginBackends, runPluginSetups, PluginStop } from "./plugins.js";

/** The forges the editor signs in to, and what to call each on screen. */
const FORGES = {
  gitlab: { auth: gitlabAuth, name: "GitLab" },
  github: { auth: githubAuth, name: "GitHub" },
};

function defaultLoginPrompt(target, login, message, serverName = "GitLab") {
  target.innerHTML =
    '<div style="display:flex;height:100%;flex-direction:column;gap:14px;align-items:center;justify-content:center;font-family:Lato,sans-serif;text-align:center;padding:20px;">' +
    (message ? `<p style="margin:0;">${escapeHtml(message)}</p>` : "") +
    `<button id="myst-gl-login" style="padding:12px 22px;font-size:16px;cursor:pointer;border-radius:6px;">Log in with ${escapeHtml(serverName)}</button>` +
    "</div>";
  target.querySelector("#myst-gl-login").addEventListener("click", () => login());
}

/** How long the boot wait has to run before it is worth naming who is being waited on. Longer than
 * the in-editor threshold: a cold load legitimately spends a couple of seconds here. */
const BLAME_SERVER_MS = 4000;

/**
 * A full-page spinner with a caption.
 *
 * Rendered into the target's light DOM, which is why it needs no stylesheet and disappears on its
 * own: the editor attaches a shadow root when it mounts, and light-DOM children of a shadow host
 * stop being rendered. The animation is SMIL rather than CSS keyframes so that nothing has to be
 * injected into the host page's styles; reduced motion is honoured by simply not animating.
 *
 * With branding, the wordmark sits above the spinner and the secondary logo at the foot of the page -
 * the one screen with nothing else competing for attention. Both are outside the live region, so a
 * screen reader announces the wait and not the logos. The light variants are used: this screen sits
 * on the host page, which the editor's dark theme does not reach.
 */
function loadingScreen(target, caption, slowNote, branding = null) {
  const still = typeof matchMedia === "function" && matchMedia("(prefers-reduced-motion: reduce)").matches;
  target.innerHTML =
    '<div style="position:relative;display:flex;height:100%;min-height:320px;flex-direction:column;gap:40px;align-items:center;justify-content:center;font-family:Lato,sans-serif;box-sizing:border-box;padding:24px 16px 96px;">' +
    (branding?.logo
      ? `<img id="myst-loading-logo" src="${escapeAttr(branding.logo.light)}" alt="${escapeAttr(branding.logo.alt)}" style="height:58px;width:auto;max-width:80%;object-fit:contain;">`
      : "") +
    '<div role="status" aria-live="polite" style="display:flex;flex-direction:column;gap:18px;align-items:center;">' +
    '<svg width="64" height="64" viewBox="0 0 50 50" aria-hidden="true">' +
    '<circle cx="25" cy="25" r="20" fill="none" stroke="currentColor" stroke-width="5" opacity="0.15"/>' +
    '<path d="M25 5 a20 20 0 0 1 20 20" fill="none" stroke="currentColor" stroke-width="5" stroke-linecap="round">' +
    (still ? "" : '<animateTransform attributeName="transform" type="rotate" from="0 25 25" to="360 25 25" dur="0.9s" repeatCount="indefinite"/>') +
    "</path></svg>" +
    `<p style="margin:0;">${escapeHtml(caption)}</p>` +
    (slowNote
      ? `<p id="myst-slow-note" hidden style="margin:0;max-width:36ch;text-align:center;opacity:0.7;font-size:14px;line-height:1.5;">${escapeHtml(slowNote)}</p>`
      : "") +
    "</div>" +
    (branding?.secondary
      ? `<img id="myst-loading-secondary" src="${escapeAttr(branding.secondary.light)}" alt="${escapeAttr(branding.secondary.alt)}" style="position:absolute;bottom:24px;left:50%;transform:translateX(-50%);height:56px;width:auto;">`
      : "") +
    "</div>";

  if (!slowNote) return;
  // Held back rather than shown up front: on a normal load the editor is up long before this, and a
  // note about the server being slow would then be the first thing it ever said.
  const note = target.querySelector("#myst-slow-note");
  setTimeout(() => {
    // Gone means the editor has taken over, or another screen replaced this one.
    if (note?.isConnected) note.hidden = false;
  }, BLAME_SERVER_MS);
}

/** Shown for the moment between deciding to log in and the browser leaving for the forge. Usually
 * invisible; it matters when the network is slow enough that the blank page would look broken. */
function redirectingNotice(target, branding, serverName = "GitLab") {
  loadingScreen(target, `Redirecting to ${serverName} to sign in…`, null, branding);
}

/** Marks that we sent the browser to GitLab without the user asking. Read back on the next load: if
 * we are still unauthenticated moments later, the round trip failed to produce a session and going
 * again would loop forever, so we fall back to the button. sessionStorage (not local) so it dies with
 * the tab, and a timestamp rather than a flag so a later, legitimate auto-login is not blocked. */
const AUTO_LOGIN_AT_KEY = "myst-gl-auto-login-at";
/** A completed round trip takes seconds of human time at minimum. Anything faster came straight back. */
const AUTO_LOGIN_RETRY_WINDOW_MS = 20_000;

function autoLoginJustFailed() {
  try {
    const at = Number(sessionStorage.getItem(AUTO_LOGIN_AT_KEY));
    return Number.isFinite(at) && at > 0 && Date.now() - at < AUTO_LOGIN_RETRY_WINDOW_MS;
  } catch {
    // Storage can be unavailable (private mode, blocked cookies). Without the guard we cannot detect
    // a loop, so treat it as "just failed" and show the button rather than risk one.
    return true;
  }
}

function markAutoLogin() {
  try {
    sessionStorage.setItem(AUTO_LOGIN_AT_KEY, String(Date.now()));
  } catch {
    /* see autoLoginJustFailed */
  }
}

function clearAutoLoginMark() {
  try {
    sessionStorage.removeItem(AUTO_LOGIN_AT_KEY);
  } catch {
    /* nothing to clear if storage is unavailable */
  }
}

const escapeHtml = (s) => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
/** For a value inside a double-quoted attribute, where a branding URL or alt text supplied by a consumer lands. */
const escapeAttr = (s) => escapeHtml(s).replace(/"/g, "&quot;");

/**
 * Render an OAuth failure on-screen (rather than rejecting into a blank page) with a working restart.
 * The spent `?code`/`state` are cleared from the URL first, so a manual reload lands on a clean login
 * instead of re-running the same doomed exchange.
 */
function defaultAuthErrorPrompt(target, err, login) {
  clearOAuthCallbackParams();
  target.innerHTML =
    '<div style="display:flex;height:100%;flex-direction:column;gap:14px;align-items:center;justify-content:center;font-family:Lato,sans-serif;text-align:center;padding:20px;">' +
    "<p style=\"margin:0;\">Login failed: <code style='color:#b00;'>" +
    escapeHtml(err?.message ?? err) +
    "</code></p>" +
    '<button id="myst-gl-login" style="padding:12px 22px;font-size:16px;cursor:pointer;border-radius:6px;">Restart login</button>' +
    "</div>";
  target.querySelector("#myst-gl-login").addEventListener("click", () => login());
}

/**
 * An add-on decided the editor must not open for this user (e.g. they are not on a course's access
 * list). Its message is the whole point of the screen, so it takes the spinner's place. "Try again"
 * reloads, for once whatever the message asked for (a teacher adding them, say) has happened.
 */
function pluginStopScreen(target, message, branding) {
  target.innerHTML =
    '<div style="position:relative;display:flex;height:100%;min-height:320px;flex-direction:column;gap:32px;align-items:center;justify-content:center;font-family:Lato,sans-serif;box-sizing:border-box;padding:24px 16px 96px;text-align:center;">' +
    (branding?.logo
      ? `<img src="${escapeAttr(branding.logo.light)}" alt="${escapeAttr(branding.logo.alt)}" style="height:58px;width:auto;max-width:80%;object-fit:contain;">`
      : "") +
    `<div role="alert" id="myst-plugin-stop" style="max-width:52ch;line-height:1.5;"><p style="margin:0;">${escapeHtml(message)}</p></div>` +
    `<p style="margin:0;"><a id="myst-plugin-retry" href="${escapeAttr(window.location.pathname)}">Try again</a></p>` +
    "</div>";
}

/**
 * Why a GitHub token cannot be used for this repository, in words the person who made it can act on;
 * null when it can. Asks GitHub for the repository with the token, which also says what it may do there.
 */
async function checkGitHubToken(repo, authorizedFetch) {
  try {
    const res = await authorizedFetch(`repos/${repo}`);
    const { permissions = {} } = await res.json();
    if (!permissions.push) return `This token can read ${repo} but not change it. Give it the permission "Contents: Read and write".`;
    return null;
  } catch (err) {
    if (err.status === 401) return "GitHub did not accept this token. It may have been mistyped, have expired or have been revoked.";
    if (err.status === 404 || err.status === 403)
      return `This token cannot reach ${repo}. When making it, choose this repository under "Repository access".`;
    return `GitHub could not be reached to check the token (${err.message}).`;
  }
}

/**
 * Sign in to GitHub with a fine-grained personal access token. Resolves once a token that can write to
 * the repository is in use; the page stays on this screen until then.
 *
 * The form is an ordinary login form - the repository as the user name, the token as the password - so
 * a password manager offers to save it and fills it in next time. Where the browser has the Credential
 * Management API (Chromium), a saved token is also picked up without a click. The editor itself keeps
 * the token in memory only, like any other.
 */
async function tokenSignIn(target, { repo, githubUrl, branding }) {
  const auth = githubAuth;
  const credentials = typeof navigator !== "undefined" ? navigator.credentials : null;
  const saved = await credentials?.get?.({ password: true, mediation: "silent" }).catch(() => null);
  if (saved?.id === repo && saved.password) {
    auth.useToken(saved.password);
    if (!(await checkGitHubToken(repo, auth.authorizedFetch))) return;
    auth.logout();
  }

  const newTokenUrl = `${githubUrl}/settings/personal-access-tokens/new`;
  target.innerHTML =
    '<div style="position:relative;display:flex;min-height:100%;flex-direction:column;gap:28px;align-items:center;justify-content:center;font-family:Lato,sans-serif;box-sizing:border-box;padding:24px 16px 96px;">' +
    (branding?.logo
      ? `<img src="${escapeAttr(branding.logo.light)}" alt="${escapeAttr(branding.logo.alt)}" style="height:58px;width:auto;max-width:80%;object-fit:contain;">`
      : "") +
    '<form id="myst-gh-token-form" method="post" action="#" style="display:flex;flex-direction:column;gap:12px;width:100%;max-width:44ch;line-height:1.5;">' +
    '<h2 style="margin:0;font-size:20px;">Sign in to GitHub with a token</h2>' +
    '<label for="myst-gh-repo" style="font-weight:bold;">Repository</label>' +
    `<input id="myst-gh-repo" name="username" autocomplete="username" value="${escapeAttr(repo)}" readonly style="padding:8px;font:inherit;">` +
    '<label for="myst-gh-token" style="font-weight:bold;">Fine-grained personal access token</label>' +
    '<input id="myst-gh-token" name="password" type="password" autocomplete="current-password" required spellcheck="false" style="padding:8px;font:inherit;">' +
    '<p id="myst-gh-token-error" role="alert" style="margin:0;color:#b00;"></p>' +
    '<button type="submit" style="padding:10px 18px;font-size:16px;cursor:pointer;border-radius:6px;">Sign in</button>' +
    '<details style="font-size:14px;"><summary style="cursor:pointer;">How do I make a token?</summary><ol style="padding-left:20px;">' +
    `<li>Open <a href="${escapeAttr(newTokenUrl)}" target="_blank" rel="noopener">GitHub's new token page</a>.</li>` +
    `<li>Under <b>Repository access</b>, choose <b>Only select repositories</b> and pick <b>${escapeHtml(repo)}</b>.</li>` +
    "<li>Under <b>Permissions</b>, set <b>Contents</b> to <b>Read and write</b> and <b>Pull requests</b> to <b>Read-only</b>.</li>" +
    "<li>Generate it, paste it here, and let your browser save it: it lasts until the expiry date you chose.</li>" +
    '</ol><p style="margin:0;">The token can reach only that repository. The editor keeps it in this tab\'s memory and sends it nowhere but GitHub.</p></details>' +
    "</form></div>";

  const form = target.querySelector("#myst-gh-token-form");
  const input = target.querySelector("#myst-gh-token");
  const error = target.querySelector("#myst-gh-token-error");
  await new Promise((resolve) => {
    form.addEventListener("submit", async (ev) => {
      ev.preventDefault();
      const token = input.value.trim();
      error.textContent = "";
      form.querySelector("button").disabled = true;
      auth.useToken(token);
      const problem = await checkGitHubToken(repo, auth.authorizedFetch);
      form.querySelector("button").disabled = false;
      if (problem) {
        auth.logout();
        error.textContent = problem;
        input.focus();
        return;
      }
      // Offer to save it where the browser lets a page ask; elsewhere the form itself prompts the
      // password manager once it disappears.
      if (typeof window.PasswordCredential === "function") {
        await credentials?.store?.(new window.PasswordCredential({ id: repo, password: token, name: `GitHub token for ${repo}` })).catch(() => {});
      }
      resolve();
    });
  });
}

/**
 * Boot a git-backed MyST editor, choosing the backend from `config.backend` or the `?git_backend=`
 * URL param (default "stub"). For the "gitlab" backend it runs the OAuth (PKCE) gate first: with no
 * session yet it sends the browser to GitLab (see `autoLogin`) and returns early.
 *
 * Every key other than the bootstrap-specific ones below is forwarded to MystEditorGit.
 *
 * The gitlab OAuth config (gitlabUrl/clientId/redirectUri/scope) can be passed here at runtime so a
 * single pre-built bundle works across deployments; each omitted value falls back to VITE_GITLAB_*.
 *
 * @param {HTMLElement} target - element to mount into
 * @param {object} [config]
 * @param {"stub"|"gitlab"} [config.backend] - overrides the `?git_backend=` URL param
 * @param {number} [config.latency] - stub backend only: delay every read by this many ms (also `?latency=`)
 * @param {object} [config.stubUser] - stub backend only: who the demo user is ({ username, name, accessLevel })
 * @param {string} [config.repo] - repo key (stub) / fallback project (gitlab)
 * @param {string} [config.gitlabProjectId] - GitLab numeric id or URL-encoded namespace path
 * @param {string} [config.gitlabUrl] - GitLab base URL (OAuth runtime override)
 * @param {string} [config.clientId] - OAuth application id (OAuth runtime override)
 * @param {string} [config.redirectUri] - OAuth redirect URI (OAuth runtime override)
 * @param {string} [config.scope] - OAuth scope (OAuth runtime override)
 * @param {() => string} [config.getBranch] - current-branch getter (defaults to the editor's git state)
 * @param {boolean} [config.autoLogin=true] - go straight to GitLab when there is no session, instead of
 *   showing a "Log in with GitLab" button first. Set false to require the click. Ignored when
 *   `onLoginRequired` is given, since that handler decides what happens.
 * @param {(login: () => void) => void} [config.onLoginRequired] - custom login UI; replaces auto-login
 *   and the default "Log in with GitLab" button
 * @param {(err: Error, login: () => void) => void} [config.onLoginError] - custom OAuth-error UI; defaults to an on-screen message + "Restart login"
 * @param {object[]} [config.plugins] - add-ons; see plugins.js for the contract
 * @returns {Promise<void>}
 */
export async function mountGitEditor(target, config = {}) {
  const params = new URLSearchParams(window.location.search);
  const kind = config.backend ?? params.get("git_backend") ?? "stub";
  const {
    backend: _backend,
    gitlabProjectId,
    gitlabUrl,
    clientId,
    redirectUri,
    scope,
    githubRepo: _githubRepo,
    githubUrl,
    githubApiUrl,
    tokenUrl,
    auth: authMode,
    flavor: _flavor,
    onLoginRequired,
    onLoginError,
    autoLogin,
    latency: _latency,
    stubUser,
    plugins = [],
    ...editorOptions
  } = config;
  const getBranch = config.getBranch ?? (() => window.myst_editor?.[editorOptions.id]?.git?.branch?.value ?? "main");
  const branding = resolveBranding(config.branding);

  let backendOptions;
  const forge = FORGES[kind];
  if (forge) {
    const { auth, name: serverName } = forge;
    // Apply runtime sign-in config (for GitLab each omitted value falls back to the VITE_GITLAB_* build
    // env). Re-applied every load, including the redirect-back load, since module state resets on redirect.
    if (kind === "gitlab") auth.configure({ gitlabUrl, clientId, redirectUri, scope });
    else auth.configure({ githubUrl, githubApiUrl, clientId, redirectUri, tokenUrl });
    // A GitHub book without a token relay signs in with a token the user pastes; see tokenSignIn.
    const tokenMode = kind === "github" && (authMode ?? (tokenUrl ? "oauth" : "token")) === "token";
    const githubRepo = config.githubRepo ?? config.repo;
    if (kind === "github" && !/^[^/\s]+\/[^/\s]+$/.test(githubRepo ?? "")) {
      throw new Error('mountGitEditor: the github backend needs `githubRepo: "owner/name"`.');
    }
    const login = () => auth.login();
    // Everything from here to the editor mounting is network: the token exchange on the way back from
    // the forge, then the backend's prefetch of project metadata and branches. That is seconds of blank
    // page on a cold load, and a blank page after an OAuth round trip reads as a failed login.
    const showLoading = () =>
      loadingScreen(
        target,
        "Loading the editor…",
        `${serverName} is taking a while to answer. The editor is waiting on it, not stuck - this should clear on its own.`,
        branding,
      );
    if (tokenMode) {
      if (!auth.isAuthenticated()) await tokenSignIn(target, { repo: githubRepo, githubUrl: auth.getConfig().githubUrl, branding });
      showLoading();
    } else {
      showLoading();
      try {
        await auth.handleRedirect();
      } catch (err) {
        // Any OAuth failure (state mismatch, invalid_grant, network) would otherwise reject out of this
        // async function and leave a blank page. Render it instead so the user can restart the login.
        (onLoginError ?? ((e, l) => defaultAuthErrorPrompt(target, e, l)))(err, login);
        return;
      }
      if (!auth.isAuthenticated()) {
        if (onLoginRequired) {
          // An explicit handler owns the whole decision, auto-login included.
          onLoginRequired(login);
          return;
        }
        // Opening the editor is itself the request to use it - the user has already clicked something
        // to get here - so send them straight to the forge rather than asking them to click again. The
        // button remains the fallback: for a consumer that opts out, and for the case where an
        // automatic attempt has just come back without a session (see autoLoginJustFailed).
        if (autoLogin === false) {
          defaultLoginPrompt(target, login, undefined, serverName);
          return;
        }
        if (autoLoginJustFailed()) {
          defaultLoginPrompt(target, login, `Signing in with ${serverName} did not complete.`, serverName);
          return;
        }
        markAutoLogin();
        redirectingNotice(target, branding, serverName);
        try {
          await login();
        } catch (err) {
          // login() builds the authorize URL (PKCE, config); if that throws the browser never leaves,
          // and without this the user is left looking at "Redirecting…" forever.
          clearAutoLoginMark();
          (onLoginError ?? ((e, l) => defaultAuthErrorPrompt(target, e, l)))(err, login);
        }
        return;
      }
      // A session exists, so any earlier automatic attempt evidently worked; let the next one run free.
      clearAutoLoginMark();
    }
    backendOptions =
      kind === "gitlab"
        ? { projectId: gitlabProjectId ?? config.repo, getBranch, authorizedFetch: auth.authorizedFetch }
        : { repo: githubRepo, getBranch, authorizedFetch: auth.authorizedFetch, graphqlUrl: auth.getConfig().graphqlUrl };
  } else {
    // ?latency=1500 makes the stub answer slowly, so the slow-fetch indicator can be seen and tested;
    // ?protected=main marks branches as protected, as GitLab would; ?flavor=github words things as GitHub does.
    backendOptions = {
      repoKey: config.repo ?? "repos/myst",
      getBranch,
      latency: config.latency ?? params.get("latency"),
      user: stubUser,
      protectedBranches: params.get("protected")?.split(",").filter(Boolean),
      flavor: config.flavor ?? params.get("flavor") ?? undefined,
    };
  }

  // Which build is deployed matters once a real repository is behind the editor: a bug report from a
  // book author is otherwise impossible to place. The stub is a demo, whose pages say it themselves.
  if (kind !== "stub" && editorOptions.showVersion === undefined) editorOptions.showVersion = true;

  let backend = await createGitBackend(kind, backendOptions);
  if (plugins.length > 0) {
    try {
      backend = await applyPluginBackends(plugins, backend, { kind, api: forge ? forge.auth.authorizedFetch : null });
    } catch (err) {
      if (!(err instanceof PluginStop)) throw err;
      pluginStopScreen(target, err.message, branding);
      return;
    }
    const consumerOnReady = editorOptions.onReady;
    editorOptions.onReady = (editor) => {
      consumerOnReady?.(editor);
      runPluginSetups(plugins, editor, (text) => editor.git?.notify?.(text));
    };
  }
  const { initialBranches, ...gitCallbacks } = backend;
  // The editor's shadow root hides anything left in the light DOM, but dropping the loading screen
  // explicitly keeps the host element honest for consumer CSS and leaves nothing to retain.
  target.innerHTML = "";
  MystEditorGit({ ...editorOptions, initialBranches, ...gitCallbacks }, target);
}
