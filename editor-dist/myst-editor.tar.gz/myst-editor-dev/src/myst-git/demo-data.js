export const docsRoot = "docs";
/** The demo repository is laid out the way a real COMBINE book is: myst.yml holds the project
 * metadata and delegates the table of contents to toc.yml with `extends:`, alongside a shared
 * template served over https. The editor discovers all of this on its own; `indexPath` is exported
 * only for a consumer that wants to name the config explicitly. */
export const indexPath = "docs/myst.yml";
const tocPath = "docs/toc.yml";

/** Enough items to paginate past PAGE_SIZE (20) in stubGitBackend. */
export const DEMO_BRANCH_COUNT = 45;
export const DEMO_FEATURE_COMMIT_COUNT = 45;

/** 7-char hex hashes (git-style abbreviations). */
export const DEMO_INITIAL_COMMIT = "4a3f2b1";
export const DEMO_FEATURE_TIP = "e7c91d0";

function demoMiddleCommitHash(seq) {
  return ((seq * 2654435761) >>> 0).toString(16).padStart(7, "0").slice(-7);
}

// Deliberately carries no `project.toc` of its own: the toc is a separate file, reached through
// `extends`. A remote template sits in the same list and must be ignored rather than fetched.
const mystYml = `version: 1
project:
  title: Demo Documentation
extends:
  - toc.yml
  - https://gitlab.example/api/v4/projects/1/packages/generic/template/template-v0.0.4/template.yml
site:
  template: book-theme
`;

const mainToc = `version: 1
project:
  toc:
    - file: index.md
    - file: file1.md
    - file: file2.md
`;

const featureToc = mainToc.replace("    - file: file2.md\n", "    - file: file2.md\n    - file: feature.md\n");

const indexPage = `# Demo Documentation

Welcome to the MyST editor git demo. Edit files, then use the Commit button to save.
`;

const file1 = `# Document 1

## Introduction

This is the first document in the demo repository.

## Content

Edit this text and commit the changes to see git history.
`;

const file2 = `# Document 2

## Overview

This is the second document in the demo repository.

## Details

Edit this text and commit the changes to see git history.
`;

const feature = `# Feature Document

This file was added on the feature branch.
`;

/** Initial commit on main — three files, index without feature. */
const initialCommitFiles = {
  [indexPath]: mystYml,
  [tocPath]: mainToc,
  "docs/index.md": indexPage,
  "docs/file1.md": file1,
  "docs/file2.md": file2,
};

/** Feature branch tip — adds feature.md and lists it in the table of contents. */
const featureCommitFiles = {
  ...initialCommitFiles,
  [tocPath]: featureToc,
  "docs/feature.md": feature,
};

export const demoBranches = [
  "feature",
  "main",
  ...Array.from({ length: DEMO_BRANCH_COUNT - 2 }, (_, i) => `branch-${String(i + 3).padStart(3, "0")}`),
];

function buildFeatureHistory() {
  const commits = {
    [DEMO_INITIAL_COMMIT]: { message: "Initial commit", files: { ...initialCommitFiles } },
  };

  let parent = DEMO_INITIAL_COMMIT;
  const middleHashes = [];
  for (let i = 1; i < DEMO_FEATURE_COMMIT_COUNT - 1; i++) {
    const hash = demoMiddleCommitHash(i);
    commits[hash] = {
      message: `Update docs (${i})`,
      parent,
      files: { ...initialCommitFiles },
    };
    middleHashes.push(hash);
    parent = hash;
  }

  commits[DEMO_FEATURE_TIP] = { message: "Add feature document", parent, files: { ...featureCommitFiles } };

  return {
    commits,
    history: [DEMO_FEATURE_TIP, ...middleHashes.reverse(), DEMO_INITIAL_COMMIT],
  };
}

/**
 * In-memory repo state matching the demo layout used by a future real git backend.
 * @returns {{ branches: Record<string, string>, commits: Record<string, { message: string, parent?: string, files: Record<string, string> }>, history: Record<string, string[]> }}
 */
export function createInitialRepoState() {
  const { commits, history: featureHistory } = buildFeatureHistory();
  const extraBranches = demoBranches.filter((b) => b !== "main" && b !== "feature");

  return {
    branches: {
      main: DEMO_INITIAL_COMMIT,
      feature: DEMO_FEATURE_TIP,
      ...Object.fromEntries(extraBranches.map((b) => [b, DEMO_INITIAL_COMMIT])),
    },
    commits,
    history: {
      main: [DEMO_INITIAL_COMMIT],
      feature: featureHistory,
      ...Object.fromEntries(extraBranches.map((b) => [b, [DEMO_INITIAL_COMMIT]])),
    },
  };
}
