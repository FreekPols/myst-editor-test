import styled from "styled-components";
import { useSignal } from "@preact/signals";
import { TableOfContents } from "./TableOfContents";

const GitSidebar = styled.aside`
  display: flex;
  flex-direction: column;
  padding: 0 25px;
  overflow-y: auto;
  overflow-x: hidden;
  padding-bottom: 20px;
  overscroll-behavior: contain;
  background-color: var(--navbar-bg);
  border-right: 1px solid var(--sidebar-border);
  box-sizing: border-box;
`;

/** Both variants are in the page; the theme's variables decide which one shows. */
const ThemedImage = ({ image, className }) => (
  <>
    <img className={`${className} logo-light`} src={image.light} alt={image.alt} />
    <img className={`${className} logo-dark`} src={image.dark} alt={image.alt} />
  </>
);

const BrandLink = styled.a`
  display: block;
  line-height: 0;

  .logo-light {
    display: var(--logo-light-display);
  }
  .logo-dark {
    display: var(--logo-dark-display);
  }
`;

const Masthead = styled(BrandLink)`
  align-self: stretch;
  padding: 24px 0 20px;
  border-bottom: 1px solid var(--sidebar-border);

  img {
    height: 40px;
    width: auto;
    max-width: 100%;
    object-fit: contain;
    object-position: left center;
  }
`;

/** The institution, small and alone in the panel's bottom-left corner. margin-top: auto keeps it at the
 * foot of a short index and lets it follow a long one, so it never sits between the author and a page. */
const SecondaryLogo = styled(BrandLink)`
  margin-top: auto;
  align-self: flex-start;
  padding-top: 18px;

  img {
    /* The file carries TU Delft's clear space, so roughly half of this height is the logo itself. */
    height: 42px;
    width: auto;
  }
`;

const PagesHead = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin: 20px 0 10px;

  h2 {
    margin: 0;
    font-size: 12px;
    font-weight: 700;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    color: var(--gray-800);
  }

  .actions {
    display: flex;
    align-items: center;
    gap: 4px;
  }

  button {
    display: grid;
    place-items: center;
    width: 28px;
    height: 28px;
    padding: 0;
    border: 0;
    border-radius: var(--border-radius);
    background: transparent;
    cursor: pointer;

    &:hover {
      background-color: var(--button-bg-hover);
    }

    svg {
      width: 16px;
      height: 16px;
    }
  }
`;

const NewFileIcon = () => (
  <svg
    width="16"
    height="16"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    stroke-width="2"
    stroke-linecap="round"
    stroke-linejoin="round"
    aria-hidden="true"
  >
    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
    <polyline points="14 2 14 8 20 8" />
    <line x1="12" y1="18" x2="12" y2="12" />
    <line x1="9" y1="15" x2="15" y2="15" />
  </svg>
);

const NewFolderIcon = () => (
  <svg
    width="16"
    height="16"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    stroke-width="2"
    stroke-linecap="round"
    stroke-linejoin="round"
    aria-hidden="true"
  >
    <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" />
    <line x1="12" y1="11" x2="12" y2="17" />
    <line x1="9" y1="14" x2="15" y2="14" />
  </svg>
);

const Filter = styled.label`
  display: flex;
  align-items: center;
  gap: 8px;
  margin: 0 0 14px;
  padding: 6px 10px;
  border: 1px solid var(--border);
  border-radius: 6px;
  background-color: var(--button-bg);

  &:focus-within {
    outline: 2px solid var(--focus-ring);
    outline-offset: 2px;
  }

  svg {
    flex: none;
    opacity: 0.65;
  }

  input {
    width: 100%;
    border: 0;
    outline: 0;
    background: transparent;
    font: inherit;
    font-size: 14px;
  }
`;

const UnindexedFiles = styled.details`
  width: 100%;
  margin-top: 16px;

  summary {
    margin-bottom: 12px;
    font-weight: 600;
    font-size: 14px;
    user-select: none;
    cursor: pointer;
  }

  ul {
    list-style: none;
    padding-left: 12px;
    margin: 0;
    display: flex;
    flex-direction: column;
    gap: 2px;
  }

  button {
    border: 0;
    background: transparent;
    font: inherit;
    font-size: 14px;
    text-align: left;
    padding: 3px 6px;
    border-radius: 4px;
    cursor: pointer;
    overflow-wrap: anywhere;

    &:hover {
      text-decoration: underline;
    }

    &[aria-current="page"] {
      color: var(--accent-dark);
      font-weight: 600;
    }
  }

  .marked::after {
    content: "";
    display: inline-block;
    margin-left: 8px;
    width: 8px;
    height: 8px;
    border-radius: 100%;
    background-color: var(--unsaved);
  }
`;

const SearchIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
    <circle cx="11" cy="11" r="7" />
    <path d="M20 20l-4-4" />
  </svg>
);

// Page-index data and `switchFile` are computed in MystEditorGit and passed in so an external integration can reuse them.
const Sidebar = ({
  file,
  branch,
  commit,
  getText,
  indexFile,
  indexedFiles,
  unIndexedFiles,
  markedFiles,
  switchFile,
  branding,
  collapseButton,
  onAddFile,
  onAddFolder,
  onMoveItem,
  tocTree = null,
}) => {
  const filter = useSignal("");
  const query = filter.value.trim().toLowerCase();
  const visibleUnindexed = unIndexedFiles.value.filter((f) => !query || f.toLowerCase().includes(query));

  return (
    <GitSidebar id="page-index-panel" aria-label="Book">
      {branding?.logo && (
        <Masthead href={branding.logo.href} target="_blank" rel="noreferrer" id="brand-logo">
          <ThemedImage image={branding.logo} />
        </Masthead>
      )}

      <nav aria-labelledby="pages-heading">
        <PagesHead>
          <h2 id="pages-heading">Pages</h2>
          <div className="actions">
            {onAddFile && (
              <button type="button" title="Add page" aria-label="Add page" onClick={onAddFile}>
                <NewFileIcon />
              </button>
            )}
            {onAddFolder && (
              <button type="button" title="Add chapter" aria-label="Add chapter" onClick={onAddFolder}>
                <NewFolderIcon />
              </button>
            )}
            {collapseButton}
          </div>
        </PagesHead>
        <Filter>
          <SearchIcon />
          <input
            type="search"
            placeholder="Filter pages"
            aria-label="Filter pages"
            value={filter.value}
            onInput={(ev) => (filter.value = ev.currentTarget.value)}
          />
        </Filter>

        {indexFile.value && file.value && (
          <TableOfContents
            indexedFiles={indexedFiles}
            markedFiles={markedFiles}
            currentFile={file.value}
            onFileClick={(f) => switchFile(f.file)}
            getText={getText}
            branch={branch}
            commit={commit}
            query={query}
            tree={tocTree}
            onMoveItem={onMoveItem}
          />
        )}
        {visibleUnindexed.length > 0 && (
          <UnindexedFiles open={!!query || undefined}>
            <summary>Unindexed files</summary>
            <ul id="unindexed-files-list">
              {visibleUnindexed.map((f) => (
                <li key={f}>
                  <button
                    type="button"
                    title={`Go to file ${f}`}
                    onClick={() => switchFile(f)}
                    aria-current={file.value == f ? "page" : undefined}
                    className={markedFiles.value.includes(f) ? "marked" : undefined}
                  >
                    {f}
                    {markedFiles.value.includes(f) && <span className="visually-hidden"> (uncommitted changes)</span>}
                  </button>
                </li>
              ))}
            </ul>
          </UnindexedFiles>
        )}
      </nav>

      {branding?.secondary && (
        <SecondaryLogo href={branding.secondary.href} target="_blank" rel="noreferrer" id="brand-secondary">
          <ThemedImage image={branding.secondary} />
        </SecondaryLogo>
      )}
    </GitSidebar>
  );
};

export default Sidebar;
