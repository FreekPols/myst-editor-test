import yaml from "js-yaml";
import { isAlias, isMap, isScalar, isSeq, parseDocument } from "yaml";

/** Table-of-contents files we look for, in priority order, when the consumer does not name one.
 * `myst.yml` is Jupyter Book v2 / mystmd; `_toc.yml` is Jupyter Book v1; `toc.yml` is neither, but
 * is a common hand-rolled name and costs one extra lookup to support. */
export const TOC_CANDIDATES = ["myst.yml", "_toc.yml", "toc.yml"];

export const isTocYaml = (path) => !!path && (path.endsWith(".yml") || path.endsWith(".yaml"));

/** Anything with a scheme is somewhere else entirely: a shared template served over https, not a file
 * in the repository. Those carry styling and plugins, never a table of contents. */
const REMOTE = /^[a-z][a-z0-9+.-]*:\/\//i;

/** Resolve "a/b/../c.yml" style paths, since `extends` entries are relative to the file naming them. */
function normalizePath(path) {
  const out = [];
  for (const segment of path.split("/")) {
    if (segment === "" || segment === ".") continue;
    else if (segment === "..") out.pop();
    else out.push(segment);
  }
  return out.join("/");
}

/**
 * The local files a config delegates to with mystmd's `extends:`.
 *
 * A project whose table of contents lives in its own file says so this way - `myst.yml` holds the
 * project metadata and carries `extends: toc.yml` - so a config with no `project.toc` of its own is
 * not necessarily a project without a table of contents.
 *
 * @param {string} text raw YAML
 * @param {string} fromPath repository path of the file that contains this config, so relative
 *   entries resolve against its directory
 * @returns {string[]} repository paths, remote entries dropped
 */
export function tocExtends(text, fromPath = "") {
  let doc;
  try {
    doc = yaml.load(text);
  } catch {
    return [];
  }
  const declared = doc?.extends;
  const list = typeof declared === "string" ? [declared] : Array.isArray(declared) ? declared : [];
  const dir = fromPath.includes("/") ? fromPath.slice(0, fromPath.lastIndexOf("/") + 1) : "";
  return list
    .filter((entry) => typeof entry === "string" && entry.trim() && !REMOTE.test(entry.trim()))
    .map((entry) => normalizePath(dir + entry.trim()));
}

/** TOC entries name documents, not files: `file: intro` means intro.md. A name that already carries
 * an extension is left alone, so `file: intro.ipynb` survives. */
export function withExtension(name) {
  const last = name.split("/").pop() ?? "";
  return last.includes(".") ? name : `${name}.md`;
}

/** Both TOC dialects nest, under different keys: mystmd uses `children`, Jupyter Book v1 uses
 * `parts`, `chapters` and `sections`. Depth is kept so the sidebar can indent. */
const CHILD_KEYS = ["children", "parts", "chapters", "sections"];

function walk(nodes, depth, out) {
  if (!Array.isArray(nodes)) return;
  for (const node of nodes) {
    if (typeof node === "string") {
      out.push({ name: node, title: null, depth });
      continue;
    }
    if (!node || typeof node !== "object") continue;
    // `url:` entries point outside the repo, so there is no file to open; their children still count.
    if (typeof node.file === "string") out.push({ name: node.file, title: node.title ?? null, depth });
    for (const key of CHILD_KEYS) {
      if (node[key]) walk(node[key], depth + (node.file ? 1 : 0), out);
    }
  }
}

/** Pull the entry list out of whichever dialect this document is written in. */
function tocNodes(doc) {
  if (Array.isArray(doc)) return doc; // a bare list, e.g. a hand-written toc.yml
  if (!doc || typeof doc !== "object") return [];
  // mystmd: the toc lives under `project`, but tolerate it at the top level too.
  if (Array.isArray(doc.project?.toc)) return doc.project.toc;
  if (Array.isArray(doc.toc)) return doc.toc;
  // Jupyter Book v1: `root` is the landing page, then parts/chapters.
  const jb1 = [];
  if (typeof doc.root === "string") jb1.push({ file: doc.root });
  for (const key of CHILD_KEYS) if (doc[key]) jb1.push({ [key]: doc[key] });
  return jb1;
}

/** Jupyter Book v1 keeps its landing page in `root` and its entries under one of these. */
const JB1_KEYS = ["parts", "chapters", "sections"];

const childKeyOf = (entry) => CHILD_KEYS.find((k) => Array.isArray(entry?.[k])) ?? null;

/** Where the entries are, in plain parsed YAML, and which dialect they are written in. */
function tocLayout(doc) {
  if (Array.isArray(doc)) return { format: "myst", list: doc, root: null };
  if (!doc || typeof doc !== "object") return null;
  if (Array.isArray(doc.project?.toc)) return { format: "myst", list: doc.project.toc, root: null };
  if (Array.isArray(doc.toc)) return { format: "myst", list: doc.toc, root: null };
  const key = JB1_KEYS.find((k) => Array.isArray(doc[k]));
  if (!key && typeof doc.root !== "string") return null;
  return { format: "jb1", list: key ? doc[key] : [], root: typeof doc.root === "string" ? doc.root : null };
}

/** The folder a repository path sits in, without a trailing slash; "" at the root. */
const dirOf = (path) => (path.includes("/") ? path.slice(0, path.lastIndexOf("/")) : "");

function buildTree(list, parentPath, depth, prefix, seen) {
  const out = [];
  list.forEach((raw, i) => {
    const entry = typeof raw === "string" ? { file: raw } : raw && typeof raw === "object" ? raw : null;
    if (!entry) return;
    const path = [...parentPath, i];
    const fileName = typeof entry.file === "string" ? entry.file.trim() : null;
    const file = fileName ? prefix + withExtension(fileName) : null;
    const key = childKeyOf(entry);
    const children = key ? buildTree(entry[key], path, depth + 1, prefix, seen) : [];
    // A `url:` entry with nothing under it has no page to show.
    if (!file && !key) return;
    const title = entry.title ?? entry.caption ?? null;
    // The folder a chapter's pages live in: its landing page's, or the one folder all its pages share.
    // A chapter whose pages are scattered has none, and then nothing is offered to move into it.
    let home = null;
    if (key) {
      const dirs = new Set(children.filter((c) => c.file && !c.isFolder).map((c) => dirOf(c.file)));
      home = file ? dirOf(file) : dirs.size === 1 ? [...dirs][0] : null;
    }
    // Pages are known by their file, which a table of contents lists once. A chapter has no file of
    // its own to go by, so its title and first page stand in; two that still collide are numbered.
    const firstFile = file ?? children.find((c) => c.file)?.file ?? "";
    let id = file ?? `chapter:${title ?? ""}:${firstFile}`;
    for (let n = 2; seen.has(id); n++) id = `${file ?? `chapter:${title ?? ""}:${firstFile}`}#${n}`;
    seen.add(id);
    out.push({ id, path, file, fileName, title, isFolder: !!key, children, depth, home });
  });
  return out;
}

/**
 * The table of contents as a tree, for the sidebar to show and rearrange.
 *
 * Every entry carries `path`, its position in the YAML (indexes down through the nested lists), which is
 * what the editing functions below take: unlike a title or a file name it names exactly one entry. The
 * Jupyter Book v1 `root` page is listed first with `path: null`, since it cannot be moved.
 *
 * @param {string} text raw YAML
 * @param {string} prefix docs root, already ending in "/" (or "")
 * @returns {TocNode[]}
 *
 * @typedef {{ id: string, path: number[]|null, file: string|null, fileName: string|null, title: string|null,
 *   isFolder: boolean, children: TocNode[], depth: number, home: string|null }} TocNode
 */
export function parseTocTree(text, prefix = "") {
  let doc;
  try {
    doc = yaml.load(text);
  } catch {
    return [];
  }
  const layout = tocLayout(doc);
  if (!layout) return [];
  const seen = new Set();
  const tree = buildTree(layout.list, [], 0, prefix, seen);
  if (layout.root) {
    const file = prefix + withExtension(layout.root.trim());
    seen.add(file);
    tree.unshift({ id: file, path: null, file, fileName: layout.root.trim(), title: null, isFolder: false, children: [], depth: 0, home: null });
  }
  return tree;
}

/* Editing works on the YAML document itself rather than on parsed data, so that comments, blank lines
 * and the order of keys survive: a myst.yml carries the whole project's settings, not just the toc. */

/** Open a table of contents for editing: the document, the list of entries and its dialect. */
function openToc(text) {
  const doc = parseDocument(text);
  if (doc.errors.length) throw new Error(`The table of contents is not valid YAML: ${doc.errors[0].message}`);
  const c = doc.contents;
  if (isSeq(c)) return { doc, seq: c, format: "myst", rootKey: null };
  if (isMap(c)) {
    const project = c.get("project");
    if (isMap(project) && isSeq(project.get("toc"))) return { doc, seq: project.get("toc"), format: "myst", rootKey: null };
    if (isSeq(c.get("toc"))) return { doc, seq: c.get("toc"), format: "myst", rootKey: null };
    const rootKey = JB1_KEYS.find((k) => isSeq(c.get(k)));
    if (rootKey) return { doc, seq: c.get(rootKey), format: "jb1", rootKey };
  }
  throw new Error("No table of contents found to change.");
}

const childSeqOf = (node) => {
  if (!isMap(node)) return null;
  const key = CHILD_KEYS.find((k) => isSeq(node.get(k)));
  return key ? node.get(key) : null;
};

/** The entry at `path`, with the list holding it. */
function locate(seq, path) {
  if (!Array.isArray(path) || path.length === 0) return null;
  let parent = seq;
  let node = null;
  for (let d = 0; d < path.length; d++) {
    if (d > 0) parent = childSeqOf(node);
    node = parent?.items[path[d]];
    if (!node) return null;
    if (isAlias(node)) throw new Error("This table of contents reuses entries with YAML anchors; change it by hand.");
  }
  return { parent, node };
}

/** A Jupyter Book v1 part: a caption over chapters, with no page of its own. */
const isPart = (node) => isMap(node) && node.has("caption") && !node.has("file");

/** The list an entry's children go in, made if it has none yet. Each dialect has its own key: mystmd
 * nests `children`; Jupyter Book v1 puts `chapters` in a part and `sections` in a chapter. A bare
 * string entry is turned into `file:` form first, since only a mapping can hold children. */
function childrenOf(doc, found, format) {
  let node = found.node;
  if (isScalar(node)) {
    const map = doc.createNode({ file: node.value });
    found.parent.items[found.parent.items.indexOf(node)] = map;
    node = map;
  }
  const existing = childSeqOf(node);
  if (existing) return existing;
  const key = format === "myst" ? "children" : isPart(node) ? "chapters" : "sections";
  const seq = doc.createNode([]);
  node.set(key, seq);
  return seq;
}

function append(seq, node) {
  // `children: []` is written inline; once it holds entries it reads better as a block list.
  seq.flow = false;
  seq.items.push(node);
}

/** How the file is written in the table of contents: relative to the docs root, and in Jupyter Book v1
 * without `.md`, as that format's own files are written. */
function entryName(file, prefix, format) {
  const name = prefix && file.startsWith(prefix) ? file.slice(prefix.length) : file;
  return format === "jb1" ? name.replace(/\.md$/, "") : name;
}

/** The same layout as the file had: two or four spaces, lists indented under their key or not. */
function render(doc, original) {
  const keyIndent = /^( +)[^\s#-][^\n]*:/m.exec(original);
  const seqUnder = /^( *)[^\s#-][^\n:]*:[ \t]*(?:#[^\n]*)?\n(?:[ \t]*(?:#[^\n]*)?\n)*( *)- /m.exec(original);
  return doc.toString({
    indent: keyIndent ? keyIndent[1].length : 2,
    indentSeq: seqUnder ? seqUnder[2].length > seqUnder[1].length : true,
    lineWidth: 0,
    flowCollectionPadding: false,
  });
}

/**
 * Add a page to the table of contents.
 *
 * @param {string} text raw YAML
 * @param {{ file: string, parentPath?: number[]|null, prefix?: string }} options - `file` is the
 *   repository path; `parentPath` the chapter to add it to (see parseTocTree), or none for the top level.
 * @returns {string} the updated YAML
 */
export function addTocPage(text, { file, parentPath = null, prefix = "" }) {
  const { doc, seq, format, rootKey } = openToc(text);
  const entry = doc.createNode({ file: entryName(file, prefix, format) });
  let target = seq;
  if (parentPath) {
    const found = locate(seq, parentPath);
    if (!found) throw new Error("That chapter is no longer in the table of contents.");
    target = childrenOf(doc, found, format);
  } else if (rootKey === "parts") {
    // Jupyter Book v1 allows only parts at the top of a book with parts: the page joins the last one.
    const last = seq.items.length - 1;
    if (last < 0) throw new Error("This book has no part to add the page to.");
    target = childrenOf(doc, { parent: seq, node: seq.items[last] }, format);
  }
  append(target, entry);
  return render(doc, text);
}

/**
 * Add a chapter at the end of the table of contents, with `file` as its landing page.
 *
 * In mystmd that is the page with an empty `children` list. Jupyter Book v1 has no chapter without a
 * page either: it gets a chapter with empty `sections`, or, in a book made of parts, a new part.
 *
 * @param {string} text raw YAML
 * @param {{ title: string, file: string, prefix?: string }} options
 * @returns {string} the updated YAML
 */
export function addTocChapter(text, { title, file, prefix = "" }) {
  const { doc, seq, format, rootKey } = openToc(text);
  const name = entryName(file, prefix, format);
  const entry =
    format === "myst"
      ? { file: name, children: [] }
      : rootKey === "parts"
        ? { caption: title, chapters: [{ file: name }] }
        : { file: name, sections: [] };
  append(seq, doc.createNode(entry));
  return render(doc, text);
}

/**
 * Move an entry, with everything under it, before, after or into another.
 *
 * @param {string} text raw YAML
 * @param {{ from: number[], to: number[], position: "before"|"after"|"inside",
 *   renames?: ((path: string) => string|null|undefined)|null, prefix?: string }} move - `from` and `to`
 *   are entry paths (see parseTocTree). `renames` gives a file's new repository path when files move
 *   too (a page, or a chapter's whole folder); every entry for a moved file is updated, wherever it is.
 * @returns {string} the updated YAML
 */
export function moveTocEntry(text, { from, to, position, renames = null, prefix = "" }) {
  const { doc, seq, format, rootKey } = openToc(text);
  if (!from?.length || !to?.length) throw new Error("This entry cannot be moved.");
  if (from.length <= to.length && from.every((v, i) => to[i] === v)) throw new Error("A chapter cannot be moved into itself.");
  const source = locate(seq, from);
  const target = locate(seq, to);
  if (!source || !target) throw new Error("The table of contents has changed; reload the page and try again.");
  if (rootKey === "parts") {
    const toTop = position !== "inside" && to.length === 1;
    if (isPart(source.node) && !toTop) throw new Error("A part can only sit at the top level.");
    if (!isPart(source.node) && toTop) throw new Error("In this book, pages go inside a part.");
  }

  source.parent.items.splice(source.parent.items.indexOf(source.node), 1);
  const moved = source.node;
  if (position === "inside") {
    append(childrenOf(doc, target, format), moved);
  } else {
    const at = target.parent.items.indexOf(target.node);
    target.parent.items.splice(position === "before" ? at : at + 1, 0, moved);
  }
  if (renames) renameFiles(doc, seq, renames, prefix, format);
  return render(doc, text);
}

/** Point every entry whose file moved at its new path, in the style it was written in: `file: intro`
 * stays without its extension. */
function renameFiles(doc, seq, renames, prefix, format) {
  const rename = (scalar) => {
    if (!isScalar(scalar) || typeof scalar.value !== "string") return;
    const old = scalar.value.trim();
    const next = renames(prefix + withExtension(old));
    if (!next) return;
    const name = entryName(next, prefix, format);
    scalar.value = /\.[^/]*$/.test(old.split("/").pop() ?? "") ? name : name.replace(/\.md$/, "");
  };
  const walkSeq = (list) => {
    for (const item of list?.items ?? []) {
      if (isScalar(item)) rename(item);
      if (!isMap(item)) continue;
      rename(item.get("file", true));
      for (const key of CHILD_KEYS) if (isSeq(item.get(key))) walkSeq(item.get(key));
    }
  };
  walkSeq(seq);
  // Jupyter Book v1's landing page sits outside the list.
  if (format === "jb1" && isMap(doc.contents)) rename(doc.contents.get("root", true));
}

/**
 * Flatten a Jupyter Book (v1 or v2) table of contents into the ordered entries the sidebar renders.
 *
 * @param {string} text raw YAML
 * @param {string} prefix docs root, already ending in "/" (or "")
 * @returns {{ file: string, fileName: string, title: string|null, depth: number }[]} empty if the
 *   document is unparseable or holds no toc, so a malformed file degrades to "no index" rather than
 *   taking the sidebar down with it.
 */
export function parseTocYaml(text, prefix = "") {
  let doc;
  try {
    doc = yaml.load(text);
  } catch {
    return [];
  }
  const out = [];
  walk(tocNodes(doc), 0, out);
  return out.map(({ name, title, depth }) => {
    const file = prefix + withExtension(name.trim());
    return { file, fileName: name.trim(), title, depth };
  });
}

/**
 * Parse the Sphinx-style `{toctree}` block out of a markdown index page — the layout the editor
 * supported before Jupyter Book's YAML tables of contents, kept so existing repositories still work.
 *
 * @param {string} text the index document
 * @param {string} prefix docs root, already ending in "/" (or "")
 * @returns {{ file: string, fileName: string, title: string|null, depth: number }[]}
 */
export function parseToctree(text, prefix = "") {
  const start = "```{toctree}";
  if (!text?.includes(start)) return [];
  let body = text.slice(text.indexOf(start) + start.length);
  if (!body.includes("```")) return [];
  body = body.slice(0, body.indexOf("```"));
  return body
    .split("\n")
    .map((l) => l.trim())
    .filter((l) => l && !l.startsWith(":")) // `:maxdepth: 2` and friends are options, not documents
    .map((name) => ({ file: prefix + withExtension(name), fileName: name, title: null, depth: 0 }));
}
