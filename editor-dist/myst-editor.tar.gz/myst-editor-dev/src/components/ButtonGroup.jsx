import { useEffect } from "preact/hooks";
import styled from "styled-components";
import { DefaultButton } from "./CommonUI";
import { useComputed, useSignal } from "@preact/signals";

const GroupContainer = styled.div`
  display: flex;

  & > button:first-child {
    border-left: 1px solid var(--border) !important;
    border-radius: var(--border-radius) 0 0 var(--border-radius);
  }

  .btn-wrap {
    position: relative;
  }

  .btn-dropdown {
    right: 0;
  }

  .dropdown-btns {
    display: flex;
    flex-direction: column;
    gap: 8px;
  }
`;

const RadioButton = styled(DefaultButton)`
  background-color: ${(props) => (props.active ? "var(--selected-bg)" : "var(--button-bg)")};
  min-width: 40px;
  padding: 0 12px;
  gap: 7px;
  border: 1px solid var(--border);
  border-left: none;
  border-radius: 0;
  text-transform: none;
  font-size: 13.5px;
  font-weight: 500;

  svg {
    height: 18px;
    width: auto;
    flex: none;
  }

  /* Selected is shown by weight and an underline as well as the fill, so it does not rest on telling
     two blues apart. */
  &[aria-pressed="true"] {
    font-weight: 700;
    box-shadow: inset 0 -3px 0 var(--accent-dark);
  }

  &:hover:not(&:disabled) {
    background-color: var(--accent-light);
  }

  &:hover ~ .btn-dropdown {
    display: block;
  }

  &.more {
    border-radius: 0 var(--border-radius) var(--border-radius) 0;
  }
`;

const DropdownButton = styled(DefaultButton)`
  gap: 8px;
  width: 100%;
  padding: 0 16px;
  justify-content: start;
  white-space: nowrap;
  background-color: ${(props) => (props.active ? "var(--selected-bg) !important" : "var(--button-bg)")};
`;

const MoreIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="currentColor" aria-hidden="true">
    <path d="M240-400q-33 0-56.5-23.5T160-480q0-33 23.5-56.5T240-560q33 0 56.5 23.5T320-480q0 33-23.5 56.5T240-400Zm240 0q-33 0-56.5-23.5T400-480q0-33 23.5-56.5T480-560q33 0 56.5 23.5T560-480q0 33-23.5 56.5T480-400Zm240 0q-33 0-56.5-23.5T640-480q0-33 23.5-56.5T720-560q33 0 56.5 23.5T800-480q0 33-23.5 56.5T720-400Z" />
  </svg>
);

const ButtonGroup = ({ buttons, clickedId, mainButtonsNum = buttons.value.length, label = "View" }) => {
  useEffect(() => {
    buttons.value[clickedId].action();
  }, []);

  const mainButtons = useComputed(() => buttons.value.slice(0, mainButtonsNum));
  const dropdownButtons = useComputed(() => buttons.value.slice(mainButtonsNum));
  // Open from a click or a key press as well as on hover, so the extra views are reachable without a mouse.
  const moreOpen = useSignal(false);

  return (
    <GroupContainer role="group" aria-label={label}>
      {mainButtons.value.map((button, i) => (
        <RadioButton
          className="icon radio-icon"
          type="button"
          disabled={button.disabled}
          key={button.id}
          name={button.id}
          onClick={() => button.action()}
          onMouseOver={() => button.hover?.()}
          title={button.tooltip}
          aria-pressed={String(i === clickedId)}
          active={i === clickedId}
        >
          {typeof button.icon == "function" ? <button.icon /> : <img src={button.icon} alt="" />}
          <span className="collapsible-label">{button.label ?? button.tooltip}</span>
        </RadioButton>
      ))}
      {dropdownButtons.value.length > 0 && (
        <div
          className="btn-wrap"
          onFocusOut={(ev) => {
            if (!ev.currentTarget.contains(ev.relatedTarget)) moreOpen.value = false;
          }}
          onKeyDown={(ev) => {
            if (ev.key !== "Escape" || !moreOpen.value) return;
            moreOpen.value = false;
            ev.currentTarget.querySelector(".more")?.focus();
          }}
        >
          <RadioButton
            type="button"
            className="icon radio-icon more"
            active={clickedId >= mainButtonsNum}
            title="More views"
            aria-expanded={String(moreOpen.value)}
            aria-controls="more-views"
            onClick={() => (moreOpen.value = !moreOpen.value)}
          >
            <MoreIcon />
            <span className="collapsible-label">More</span>
          </RadioButton>
          <div id="more-views" className={moreOpen.value ? "btn-dropdown open" : "btn-dropdown"}>
            <div className="dropdown-content">
              <div className="dropdown-btns">
                {dropdownButtons.value.map((button, i) => (
                  <DropdownButton
                    type="button"
                    disabled={button.disabled}
                    key={button.id}
                    name={button.id}
                    onClick={() => {
                      moreOpen.value = false;
                      button.action();
                    }}
                    onMouseOver={() => button.hover?.()}
                    onFocus={() => button.hover?.()}
                    title={button.tooltip}
                    aria-pressed={String(i + mainButtonsNum === clickedId)}
                    active={i + mainButtonsNum === clickedId}
                  >
                    {typeof button.icon == "function" ? <button.icon /> : <img src={button.icon} alt="" />}
                    <span>{button.text}</span>
                  </DropdownButton>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </GroupContainer>
  );
};

export default ButtonGroup;
