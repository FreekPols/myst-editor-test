/** Checking, measuring and shrinking an image the author picked, before it is held for a commit.
 *
 * Everything committed stays in the repository's history for good, so a 6 MB phone photo shown at
 * half a page width is worth offering to shrink. Vector and animated images are never resized. */

export const ACCEPTED_IMAGE_TYPES = ["image/png", "image/jpeg", "image/gif", "image/svg+xml", "image/webp"];
/** Hard limit per image, after shrinking. */
export const MAX_IMAGE_BYTES = 10 * 1024 * 1024;
/** Above this, a JPEG or WebP is offered a re-encode even when it is already narrow enough. */
export const SHRINK_ABOVE_BYTES = 1024 * 1024;
/** Wider than a book page can use at any zoom a reader is likely to pick. */
export const SHRINK_TO_WIDTH = 2000;

const RESIZABLE = ["image/png", "image/jpeg", "image/webp"];
const EXTENSION_TYPES = { png: "image/png", jpg: "image/jpeg", jpeg: "image/jpeg", gif: "image/gif", svg: "image/svg+xml", webp: "image/webp" };

/** The image's type, falling back to its extension: some systems hand over files with no type at all. */
export function imageType(file) {
  if (file?.type) return file.type;
  const ext = String(file?.name ?? "")
    .split(".")
    .pop()
    .toLowerCase();
  return EXTENSION_TYPES[ext] ?? "";
}

export const isAcceptedImage = (file) => ACCEPTED_IMAGE_TYPES.includes(imageType(file));

export function formatBytes(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

/** Pixel size, as the browser will draw it (photos' EXIF rotation applied). */
export async function imageDimensions(file) {
  if (imageType(file) !== "image/svg+xml" && typeof createImageBitmap === "function") {
    const bitmap = await createImageBitmap(file, { imageOrientation: "from-image" });
    const size = { width: bitmap.width, height: bitmap.height };
    bitmap.close?.();
    return size;
  }
  // SVG has no bitmap; let an <img> work out its intrinsic size.
  const url = URL.createObjectURL(file);
  try {
    const img = new Image();
    await new Promise((ok, fail) => {
      img.onload = ok;
      img.onerror = () => fail(new Error("This file could not be read as an image."));
      img.src = url;
    });
    return { width: img.naturalWidth, height: img.naturalHeight };
  } finally {
    URL.revokeObjectURL(url);
  }
}

/** Whether shrinking could help: a resizable raster that is wider than a page needs, or a large photo. */
export function canShrink(file, { width }) {
  const type = imageType(file);
  if (!RESIZABLE.includes(type)) return false;
  return width > SHRINK_TO_WIDTH || (file.size > SHRINK_ABOVE_BYTES && type !== "image/png");
}

/** A smaller copy: at most SHRINK_TO_WIDTH wide, same format, photos at 0.85 quality. Returns null when
 * the copy would not actually be smaller, so the offer is only made when it means something. */
export async function shrinkImage(file, maxWidth = SHRINK_TO_WIDTH) {
  const type = imageType(file);
  const bitmap = await createImageBitmap(file, { imageOrientation: "from-image" });
  const scale = Math.min(1, maxWidth / bitmap.width);
  const canvas = document.createElement("canvas");
  canvas.width = Math.round(bitmap.width * scale);
  canvas.height = Math.round(bitmap.height * scale);
  canvas.getContext("2d").drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  bitmap.close?.();
  const blob = await new Promise((ok) => canvas.toBlob(ok, type, type === "image/png" ? undefined : 0.85));
  return blob && blob.size < file.size ? blob : null;
}
