import { useEffect, useRef, useState } from "preact/hooks";
import {
  ACCEPTED_IMAGE_TYPES,
  MAX_IMAGE_BYTES,
  SHRINK_TO_WIDTH,
  canShrink,
  formatBytes,
  imageDimensions,
  isAcceptedImage,
  shrinkImage,
} from "./imageFile";

/** What an image field holds. `url` is used when no file was picked; otherwise the file is uploaded with
 * the next commit and `savePath` (relative to the page) is where it goes and what the page refers to. */
export const emptyImageValue = () => ({ url: "", file: null, savePath: "", shrink: true, shrunk: null, info: null, error: null, busy: false });

/** The blob that will actually be committed. */
export const imageToUpload = (value) => (value.shrink && value.shrunk ? value.shrunk : value.file);

/**
 * Pick an image from the computer (uploaded with the next commit), or give a URL / repository path.
 *
 * `field.assets` is the editor's asset helper: it supplies the default save path and resolves a path
 * against the page, so the author sees where in the repository the image will land.
 */
export const ImageField = ({ field, value, onChange, hint }) => {
  const v = value ?? emptyImageValue();
  const input = useRef(null);
  const [preview, setPreview] = useState(null);
  // The latest value, for the async reading below: the author may type while an image is being read.
  const latest = useRef(v);
  latest.current = v;
  const update = (patch) => onChange({ ...latest.current, ...patch });

  async function read(file) {
    if (!isAcceptedImage(file)) {
      update({
        file,
        info: null,
        shrunk: null,
        busy: false,
        error: `Only ${ACCEPTED_IMAGE_TYPES.map((t) => t.split("/")[1].replace("+xml", "")).join(", ")} images can be uploaded.`,
      });
      return;
    }
    update({ file, busy: true, error: null, shrunk: null, savePath: latest.current.savePath || field.assets.defaultPath(file.name) });
    try {
      const info = await imageDimensions(file);
      const shrunk = canShrink(file, info) ? await shrinkImage(file) : null;
      const size = latest.current.shrink && shrunk ? shrunk.size : file.size;
      update({
        info,
        shrunk,
        busy: false,
        error: size > MAX_IMAGE_BYTES ? `This image is ${formatBytes(size)}; the limit is ${formatBytes(MAX_IMAGE_BYTES)}.` : null,
      });
    } catch (err) {
      update({ busy: false, error: err?.message || "This file could not be read as an image." });
    }
  }

  // A file handed over by paste or drop arrives as the field's starting value, still unread.
  useEffect(() => {
    if (v.file && !v.info && !v.busy && !v.error) read(v.file);
  }, [v.file]);

  useEffect(() => {
    if (!v.file) return setPreview(null);
    const url = URL.createObjectURL(v.file);
    setPreview(url);
    return () => URL.revokeObjectURL(url);
  }, [v.file]);

  const finalSize = v.file ? imageToUpload(v).size : 0;
  const repoPath = v.file && v.savePath ? field.assets.resolve(v.savePath) : null;

  return (
    <fieldset className="image-field">
      <legend>{field.label}</legend>
      <input
        ref={input}
        type="file"
        className="visually-hidden"
        accept={ACCEPTED_IMAGE_TYPES.join(",")}
        aria-label="Upload an image from this computer"
        tabIndex={-1}
        onChange={(ev) => {
          const file = ev.currentTarget.files?.[0];
          ev.currentTarget.value = "";
          if (file) read(file);
        }}
      />

      {!v.file ? (
        <div className="image-source">
          <button type="button" className="upload" autoFocus={field.autoFocus} onClick={() => input.current?.click()}>
            Upload from computer…
          </button>
          <span className="or">or</span>
          <input
            type="text"
            aria-label="Image URL or repository path"
            placeholder={field.placeholder ?? "images/figure.png or https://…"}
            value={v.url}
            onInput={(ev) => update({ url: ev.currentTarget.value })}
          />
        </div>
      ) : (
        <>
          <div className="image-chosen">
            {preview && <img src={preview} alt="" />}
            <div className="image-meta">
              <span className="image-name">{v.file.name}</span>
              <span className="hint">
                {v.busy ? "Reading…" : [formatBytes(finalSize), v.info && `${v.info.width} × ${v.info.height} px`].filter(Boolean).join(" · ")}
              </span>
              <button type="button" className="link" onClick={() => onChange(emptyImageValue())}>
                Choose another image
              </button>
            </div>
          </div>

          {v.shrunk && (
            <label className="checkbox">
              <input type="checkbox" checked={v.shrink} onChange={(ev) => update({ shrink: ev.currentTarget.checked })} />
              <span>
                Shrink to at most {SHRINK_TO_WIDTH} px wide ({formatBytes(v.file.size)} → {formatBytes(v.shrunk.size)})
                <br />
                <span className="hint">Everything committed stays in the repository's history, so smaller is kinder.</span>
              </span>
            </label>
          )}

          <label>
            Save as
            <input type="text" value={v.savePath} onInput={(ev) => update({ savePath: ev.currentTarget.value })} />
            <span className="hint">
              {repoPath ? `Saved in the repository at ${repoPath} with your next commit.` : "A path relative to this page, e.g. images/figure.png."}
            </span>
          </label>
        </>
      )}

      {v.error && (
        <p className="field-error" role="alert">
          {v.error}
        </p>
      )}
      {hint}
    </fieldset>
  );
};
