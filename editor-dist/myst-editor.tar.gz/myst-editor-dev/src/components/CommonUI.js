import styled from "styled-components";

export const DefaultButton = styled.button`
  cursor: pointer;
  text-transform: uppercase;
  font-size: 12px;
  font-weight: bold;
  font-family: inherit;
  border: 1px solid var(--border);
  background-color: var(--button-bg);
  height: 40px;
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 0;
  transition: 0.4s ease;
  border-radius: var(--border-radius);

  /* A ring for the keyboard only: a mouse click already shows where it landed, but someone tabbing
     through the toolbar has nothing else to tell them which control is current. */
  &:focus {
    outline: 0;
  }

  &:focus-visible {
    outline: 2px solid var(--focus-ring);
    outline-offset: 2px;
  }

  &:disabled {
    cursor: default;
  }

  &:not(:has(svg)) {
    padding: 0px 15px;
  }
`;

export const Modal = styled.dialog`
  width: 450px;
  max-width: 100vw;
  padding: 20px;
  background-color: var(--modal-bg);
  border: 1px solid var(--border);
  border-radius: var(--border-radius);
  /* Centred on the viewport. A <dialog> opened with showModal() is centred by the UA, but zeroing the
   * margin (needed so the width is honoured) opts out of that, so position it explicitly. */
  margin: 0;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  max-height: calc(100vh - 80px);
  overflow-y: auto;
  scrollbar-width: thin;
  overscroll-behavior: contain;

  &::backdrop {
    background-color: rgba(0, 0, 0, 0.35);
  }

  .buttons {
    display: flex;
    align-items: center;
    justify-content: flex-end;
    gap: 10px;
    margin-top: 20px;
  }
`;
