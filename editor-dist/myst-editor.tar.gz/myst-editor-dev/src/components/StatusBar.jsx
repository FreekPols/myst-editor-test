import { useContext } from "preact/hooks";
import styled from "styled-components";
import { MystState } from "../mystState";

const Bar = styled.footer`
  display: flex;
  align-items: center;
  gap: 2px;
  flex: none;
  min-height: 30px;
  padding: 0 12px;
  box-sizing: border-box;
  font-size: 12.5px;
  background-color: var(--statusbar-bg);
  border-top: 1px solid var(--statusbar-border);
  color: var(--statusbar-fg);
  overflow: hidden;
  white-space: nowrap;

  .grow {
    flex: 1;
  }

  .item {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 3px 8px;
    border: 0;
    border-radius: 4px;
    background: transparent;
    color: inherit;
    font: inherit;
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  button.item {
    cursor: pointer;

    &:hover {
      background-color: color-mix(in srgb, currentColor 12%, transparent);
    }
  }

  .mono {
    font-family: var(--font-mono);
  }

  .dot {
    width: 7px;
    height: 7px;
    border-radius: 50%;
    flex: none;
    background-color: var(--unsaved);
  }

  @media print {
    & {
      display: none;
    }
  }
`;

/** One item: a button when it does something, plain text otherwise. `attrs` passes through, which is how
 * an integration keeps a stable hook (`data-git-branch`) for its own code and tests. */
const Item = ({ item }) => {
  const content = (
    <>
      {item.icon && <item.icon />}
      {item.dot && <span className="dot" aria-hidden="true" />}
      {item.label}
    </>
  );
  const className = item.mono ? "item mono" : "item";
  return item.onClick ? (
    <button type="button" className={className} title={item.title} onClick={item.onClick} {...item.attrs}>
      {content}
    </button>
  ) : (
    <span className={className} title={item.title} {...item.attrs}>
      {content}
    </span>
  );
};

/** Where you are in the repository, whether your work is safe, and where you are in the file - the
 * things a writer glances at without wanting to go looking for them. */
export const StatusBar = () => {
  const { options, status } = useContext(MystState);
  const { line, col, words } = status.value;
  const items = options.statusItems.value ?? [];

  return (
    <Bar id="status-bar" aria-label="Document status">
      {items.map((item) => (
        <Item key={item.id} item={item} />
      ))}
      <span className="grow" />
      <span className="item" id="status-position">
        Ln {line}, Col {col}
      </span>
      <span className="item" id="status-words">
        {words.toLocaleString("en-GB")} {words === 1 ? "word" : "words"}
      </span>
      <span className="item">{options.language.value === "markdown" ? "MyST" : options.language.value}</span>
    </Bar>
  );
};
