import { useRef, useState, useEffect } from "preact/hooks";
import { useSignal, useSignalEffect } from "@preact/signals";
import styled from "styled-components";
import { DefaultButton, Modal } from "./CommonUI";
import { ImageField, emptyImageValue } from "./ImageField";

const Form = styled(Modal)`
  && {
    margin: auto;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    height: fit-content;
    transform: none;
    overflow: visible;
  }

  h1 {
    font-size: 20px;
    margin: 0 0 16px 0;
  }

  label {
    display: flex;
    flex-direction: column;
    gap: 4px;
    margin-bottom: 12px;
    font-size: 13px;
    font-weight: bold;
  }

  .form-field-group {
    display: flex;
    flex-direction: column;
    gap: 4px;
    margin-bottom: 12px;
  }

  .form-field-group > label {
    margin-bottom: 0;
    font-size: 13px;
    font-weight: bold;
  }

  input,
  textarea,
  select {
    font-family: inherit;
    font-size: 14px;
    font-weight: normal;
    padding: 8px;
    border: 1px solid var(--border);
    border-radius: var(--border-radius);
    background-color: var(--editor-bg);
    color: inherit;
    box-sizing: border-box;
    width: 100%;
  }

  textarea {
    min-height: 90px;
    resize: vertical;
  }

  .hint {
    font-weight: normal;
    font-size: 12px;
    color: var(--gray-700);
  }

  /* A checkbox reads as "box, then what it does", so it is the one field that runs along the line
     rather than stacking its control under a label. */
  label.checkbox {
    flex-direction: row;
    align-items: flex-start;
    gap: 8px;
    font-weight: normal;
  }

  label.checkbox input {
    width: auto;
    margin: 2px 0 0 0;
    padding: 0;
    flex: none;
  }

  fieldset {
    border: none;
    margin: 0 0 12px 0;
    padding: 0;
    display: flex;
    flex-direction: column;
    gap: 4px;
  }

  legend {
    padding: 0;
    font-size: 13px;
    font-weight: bold;
  }

  fieldset label.checkbox {
    margin-bottom: 0;
  }

  .image-field {
    gap: 8px;
  }

  .image-source {
    display: flex;
    align-items: center;
    gap: 8px;

    input {
      flex: 1;
    }
  }

  .image-source .or {
    font-size: 13px;
    color: var(--gray-700);
  }

  button.upload,
  button.link {
    font: inherit;
    font-size: 14px;
    cursor: pointer;
    color: inherit;
  }

  button.upload {
    flex: none;
    padding: 8px 12px;
    border: 1px solid var(--border);
    border-radius: var(--border-radius);
    background-color: var(--button-bg);
  }

  button.link {
    align-self: flex-start;
    padding: 0;
    border: 0;
    background: none;
    color: var(--accent-dark);
    text-decoration: underline;
  }

  .image-chosen {
    display: flex;
    gap: 12px;
    align-items: center;

    img {
      width: 96px;
      height: 72px;
      object-fit: contain;
      border: 1px solid var(--border);
      border-radius: var(--border-radius);
      background: var(--editor-bg);
    }
  }

  .image-meta {
    display: flex;
    flex-direction: column;
    gap: 2px;
    min-width: 0;
  }

  .image-name {
    font-size: 14px;
    overflow-wrap: anywhere;
  }

  .field-error {
    margin: 0;
    font-size: 13px;
    color: var(--error-fg);
  }

  .dialog-message {
    margin: 0 0 12px;
  }
`;

export const SmallBranchIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <line x1="6" y1="3" x2="6" y2="15" />
    <circle cx="18" cy="6" r="3" />
    <circle cx="6" cy="18" r="3" />
    <path d="M18 9a9 9 0 0 1-9 9" />
  </svg>
);

const ChevronDown = () => (
  <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
    <path d="M4.293 5.293a1 1 0 0 1 1.414 0L8 7.586l2.293-2.293a1 1 0 1 1 1.414 1.414l-3 3a1 1 0 0 1-1.414 0l-3-3a1 1 0 0 1 0-1.414z" />
  </svg>
);

export const CheckIcon = () => (
  <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="3 8 7 12 13 4" />
  </svg>
);

export const FolderIcon = () => (
  <svg
    width="15"
    height="15"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    aria-hidden="true"
  >
    <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" />
  </svg>
);

const DropdownContainer = styled.div`
  position: relative;
  width: 100%;

  .input-wrapper {
    position: relative;
    display: flex;
    align-items: center;
    width: 100%;
  }

  .input-wrapper input {
    padding-right: 32px;
  }

  .dropdown-toggle-btn {
    position: absolute;
    right: 4px;
    top: 50%;
    transform: translateY(-50%);
    background: transparent;
    border: none;
    cursor: pointer;
    padding: 6px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--gray-700);
    border-radius: var(--border-radius);
    transition:
      background-color 0.15s ease,
      color 0.15s ease;

    &:hover {
      background-color: var(--button-bg-hover, var(--gray-300));
      color: var(--gray-900);
    }
  }

  .dropdown-menu {
    position: absolute;
    top: calc(100% + 4px);
    left: 0;
    width: 100%;
    z-index: 10000;
    overflow-y: auto;
    scrollbar-width: thin;
    background-color: var(--modal-bg, white);
    border: 1px solid var(--border);
    border-radius: var(--border-radius);
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.2);
    margin: 0;
    padding: 0;
    list-style: none;
    box-sizing: border-box;
    max-height: 240px;
  }

  .dropdown-section-header {
    padding: 6px 10px 4px;
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    color: var(--gray-700);
    background-color: var(--gray-200);
    border-top: 1px solid var(--border);
    border-bottom: 1px solid var(--gray-300);
    user-select: none;
    position: sticky;
    top: 0;
    z-index: 1;

    &:first-child {
      border-top: none;
    }
  }

  .dropdown-item {
    padding: 7px 10px;
    cursor: pointer;
    display: flex;
    align-items: center;
    font-size: 13px;
    font-weight: normal;
    color: inherit;
    gap: 8px;
    transition: background-color 0.1s ease;

    &:hover,
    &.highlighted {
      background-color: var(--button-bg-hover, var(--gray-400));
    }

    &.selected {
      color: var(--accent-dark);
      font-weight: 600;
    }
  }

  .branch-item {
    .branch-icon {
      display: flex;
      align-items: center;
      flex-shrink: 0;
      opacity: 0.7;
    }
    .branch-name {
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      flex: 1;
    }
    .current-badge {
      font-size: 10px;
      padding: 1px 6px;
      border-radius: 10px;
      background-color: var(--accent-light);
      color: var(--accent-dark);
      font-weight: bold;
      text-transform: uppercase;
      flex-shrink: 0;
    }
  }

  .commit-item {
    align-items: baseline;

    .commit-hash {
      font-family: var(--font-mono, monospace);
      font-size: 11px;
      font-weight: 600;
      color: var(--accent-dark);
      background-color: var(--gray-300);
      padding: 1px 5px;
      border-radius: 3px;
      flex-shrink: 0;
    }

    .commit-message {
      font-size: 12px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      flex: 1;
      color: var(--gray-800);
    }
  }

  .dropdown-empty,
  .dropdown-status {
    padding: 12px 10px;
    font-size: 12px;
    color: var(--gray-700);
    text-align: center;
    font-weight: normal;
  }

  .folder-left-icon {
    position: absolute;
    left: 10px;
    display: flex;
    align-items: center;
    color: var(--gray-700);
    pointer-events: none;
    z-index: 1;
  }

  .dropdown-create-row {
    padding: 8px 10px;
    display: flex;
    gap: 6px;
    align-items: center;

    input {
      flex: 1;
      height: 32px;
      font-size: 13px;
      padding: 4px 8px;
    }

    button.create-submit-btn {
      flex: none;
      padding: 6px 12px;
      font-size: 12px;
      font-weight: 600;
      background-color: var(--button-bg);
      border: 1px solid var(--border);
      border-radius: var(--border-radius);
      cursor: pointer;
      color: inherit;

      &:hover {
        background-color: var(--button-bg-hover);
      }
    }
  }
`;

export const AutocompleteField = ({ id, field, value, onChange }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [filterQuery, setFilterQuery] = useState("");
  const [highlightedIndex, setHighlightedIndex] = useState(-1);
  const [asyncCommits, setAsyncCommits] = useState([]);
  const [asyncBranches, setAsyncBranches] = useState([]);
  const [isSearching, setIsSearching] = useState(false);
  const [coords, setCoords] = useState({ top: 0, left: 0, minWidth: 320, maxHeight: 280 });

  const containerRef = useRef(null);
  const inputRef = useRef(null);
  const menuRef = useRef(null);

  const updateCoords = () => {
    if (!inputRef.current) return;
    const rect = inputRef.current.getBoundingClientRect();
    const viewportWidth = typeof window !== "undefined" ? window.innerWidth : 1024;
    const viewportHeight = typeof window !== "undefined" ? window.innerHeight : 768;

    const minW = Math.max(rect.width || 0, 320);
    const idealWidth = Math.max(minW, 520);
    let left = rect.left || 0;
    if (left + idealWidth > viewportWidth - 16) {
      left = Math.max(16, viewportWidth - idealWidth - 16);
    }

    const spaceBelow = rect.bottom ? viewportHeight - rect.bottom - 16 : 300;
    const spaceAbove = rect.top ? rect.top - 16 : 300;
    let top = rect.bottom ? rect.bottom + 4 : (rect.top || 0) + 40;
    let maxHeight = 280;

    if (spaceBelow < 180 && spaceAbove > spaceBelow) {
      maxHeight = Math.min(280, Math.max(120, spaceAbove - 8));
      top = rect.top - maxHeight - 4;
    } else {
      maxHeight = Math.min(280, Math.max(120, spaceBelow));
    }

    setCoords({
      top,
      left,
      minWidth: minW,
      maxHeight,
    });
  };

  const openDropdown = () => {
    updateCoords();
    setIsOpen(true);
    setFilterQuery("");
  };

  useEffect(() => {
    if (!isOpen) return;
    updateCoords();

    const handleUpdate = () => updateCoords();
    window.addEventListener("resize", handleUpdate, { passive: true });
    window.addEventListener("scroll", handleUpdate, { passive: true, capture: true });

    return () => {
      window.removeEventListener("resize", handleUpdate);
      window.removeEventListener("scroll", handleUpdate, { capture: true });
    };
  }, [isOpen]);

  useEffect(() => {
    if (!isOpen) return;
    const onMouseDown = (ev) => {
      const path = ev.composedPath ? ev.composedPath() : [];
      if (containerRef.current && !path.includes(containerRef.current) && menuRef.current && !path.includes(menuRef.current)) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", onMouseDown);
    return () => document.removeEventListener("mousedown", onMouseDown);
  }, [isOpen]);

  useEffect(() => {
    const q = filterQuery.trim();
    if (!q || !isOpen) {
      setAsyncCommits([]);
      setAsyncBranches([]);
      setIsSearching(false);
      return;
    }

    let active = true;
    const timer = setTimeout(async () => {
      setIsSearching(true);
      try {
        const promises = [];
        if (field.searchCommits) promises.push(field.searchCommits(q));
        else promises.push(Promise.resolve([]));

        if (field.searchBranches) promises.push(field.searchBranches(q));
        else promises.push(Promise.resolve([]));

        const [commitsRes, branchesRes] = await Promise.all(promises);
        if (active) {
          setAsyncCommits(Array.isArray(commitsRes) ? commitsRes : []);
          setAsyncBranches(Array.isArray(branchesRes) ? branchesRes : []);
          setIsSearching(false);
        }
      } catch {
        if (active) setIsSearching(false);
      }
    }, 200);

    return () => {
      active = false;
      clearTimeout(timer);
    };
  }, [filterQuery, isOpen, field.searchCommits, field.searchBranches]);

  const query = filterQuery.trim().toLowerCase();
  const allBranches = field.branches || [];
  const matchingBranches = query ? [...new Set([...allBranches.filter((b) => b.toLowerCase().includes(query)), ...asyncBranches])] : allBranches;

  const allCommits = field.commits || [];
  let matchingCommits = [];
  if (query) {
    const localFiltered = allCommits.filter((c) => c.hash?.toLowerCase().includes(query) || c.message?.toLowerCase().includes(query));
    const commitMap = new Map();
    for (const c of [...localFiltered, ...asyncCommits]) {
      if (c?.hash && !commitMap.has(c.hash)) {
        commitMap.set(c.hash, c);
      }
    }
    matchingCommits = Array.from(commitMap.values());
  } else {
    matchingCommits = allCommits.slice(0, 10);
  }

  const genericOptions = field.options
    ? (query
        ? field.options.filter((o) => optionLabel(o).toLowerCase().includes(query) || optionValue(o).toLowerCase().includes(query))
        : field.options
      ).map((o) => ({ type: "option", value: optionValue(o), label: optionLabel(o) }))
    : [];

  const allItems =
    genericOptions.length > 0
      ? genericOptions
      : [
          ...matchingBranches.map((b) => ({ type: "branch", value: b, label: b })),
          ...matchingCommits.map((c) => ({ type: "commit", value: c.hash, hash: c.hash, message: c.message })),
        ];

  useEffect(() => {
    if (highlightedIndex >= 0 && menuRef.current) {
      const items = menuRef.current.querySelectorAll(".dropdown-item");
      if (items[highlightedIndex]) {
        items[highlightedIndex].scrollIntoView({ block: "nearest" });
      }
    }
  }, [highlightedIndex]);

  const selectItem = (item) => {
    onChange(item.value);
    setFilterQuery("");
    setIsOpen(false);
    setHighlightedIndex(-1);
  };

  const handleKeyDown = (ev) => {
    if (ev.key === "ArrowDown") {
      ev.preventDefault();
      if (!isOpen) {
        setIsOpen(true);
        setHighlightedIndex(0);
      } else if (allItems.length > 0) {
        setHighlightedIndex((prev) => (prev + 1 < allItems.length ? prev + 1 : 0));
      }
    } else if (ev.key === "ArrowUp") {
      ev.preventDefault();
      if (!isOpen) {
        setIsOpen(true);
        setHighlightedIndex(allItems.length - 1);
      } else if (allItems.length > 0) {
        setHighlightedIndex((prev) => (prev - 1 >= 0 ? prev - 1 : allItems.length - 1));
      }
    } else if (ev.key === "Enter") {
      if (isOpen && highlightedIndex >= 0 && highlightedIndex < allItems.length) {
        ev.preventDefault();
        selectItem(allItems[highlightedIndex]);
      }
    } else if (ev.key === "Escape") {
      if (isOpen) {
        ev.preventDefault();
        ev.stopPropagation();
        setIsOpen(false);
      }
    } else if (ev.key === "Tab") {
      setIsOpen(false);
    }
  };

  const getItemIndex = (type, val) => allItems.findIndex((i) => i.type === type && (type === "branch" ? i.value === val : i.hash === val));

  return (
    <DropdownContainer ref={containerRef}>
      <div className="input-wrapper">
        <input
          id={id}
          ref={inputRef}
          type="text"
          autoFocus={field.autoFocus}
          placeholder={field.placeholder}
          value={value}
          onFocus={() => {
            openDropdown();
          }}
          onClick={() => {
            if (!isOpen) {
              openDropdown();
            }
          }}
          onInput={(ev) => {
            const val = ev.currentTarget.value;
            onChange(val);
            setFilterQuery(val);
            updateCoords();
            setIsOpen(true);
            setHighlightedIndex(0);
          }}
          onKeyDown={handleKeyDown}
          autoComplete="off"
          spellCheck={false}
        />
        <button
          type="button"
          className="dropdown-toggle-btn"
          title="Toggle source options"
          tabIndex={-1}
          onClick={(ev) => {
            ev.preventDefault();
            if (!isOpen) {
              openDropdown();
              inputRef.current?.focus();
            } else {
              setIsOpen(false);
            }
          }}
        >
          <ChevronDown />
        </button>
      </div>

      {isOpen && (
        <ul
          className="dropdown-menu"
          ref={menuRef}
          role="listbox"
          style={{
            position: "fixed",
            top: `${coords.top}px`,
            left: `${coords.left}px`,
            minWidth: `${coords.minWidth}px`,
            width: "max-content",
            maxWidth: "min(600px, calc(100vw - 32px))",
            maxHeight: `${coords.maxHeight}px`,
          }}
        >
          {genericOptions.length > 0 ? (
            genericOptions.map((opt, idx) => (
              <li
                key={opt.value}
                role="option"
                aria-selected={opt.value === value}
                className={`dropdown-item ${opt.value === value ? "selected" : ""} ${highlightedIndex === idx ? "highlighted" : ""}`}
                onMouseDown={(e) => {
                  e.preventDefault();
                  selectItem(opt);
                }}
                onMouseEnter={() => setHighlightedIndex(idx)}
              >
                <span>{opt.label}</span>
              </li>
            ))
          ) : (
            <>
              {matchingBranches.length > 0 && (
                <>
                  <li className="dropdown-section-header" role="presentation">
                    Branches
                  </li>
                  {matchingBranches.map((b) => {
                    const idx = getItemIndex("branch", b);
                    return (
                      <li
                        key={`branch-${b}`}
                        role="option"
                        aria-selected={b === value}
                        className={`dropdown-item branch-item ${b === value ? "selected" : ""} ${highlightedIndex === idx ? "highlighted" : ""}`}
                        onMouseDown={(e) => {
                          e.preventDefault();
                          selectItem({ type: "branch", value: b });
                        }}
                        onMouseEnter={() => setHighlightedIndex(idx)}
                      >
                        <span className="branch-icon">
                          <SmallBranchIcon />
                        </span>
                        <span className="branch-name">{b}</span>
                        {b === field.currentBranch && <span className="current-badge">current</span>}
                      </li>
                    );
                  })}
                </>
              )}

              {matchingCommits.length > 0 && (
                <>
                  <li className="dropdown-section-header" role="presentation">
                    Commits
                  </li>
                  {matchingCommits.map((c) => {
                    const idx = getItemIndex("commit", c.hash);
                    return (
                      <li
                        key={`commit-${c.hash}`}
                        role="option"
                        aria-selected={c.hash === value}
                        className={`dropdown-item commit-item ${c.hash === value ? "selected" : ""} ${highlightedIndex === idx ? "highlighted" : ""}`}
                        onMouseDown={(e) => {
                          e.preventDefault();
                          selectItem({ type: "commit", value: c.hash });
                        }}
                        onMouseEnter={() => setHighlightedIndex(idx)}
                      >
                        <span className="commit-hash">{c.hash}</span>
                        <span className="commit-message" title={c.message}>
                          {c.message}
                        </span>
                      </li>
                    );
                  })}
                </>
              )}

              {isSearching && <li className="dropdown-status">Searching commits…</li>}

              {!isSearching && matchingBranches.length === 0 && matchingCommits.length === 0 && (
                <li className="dropdown-empty">No matching branches or commits</li>
              )}
            </>
          )}
        </ul>
      )}
    </DropdownContainer>
  );
};

export const FolderSelectField = ({ id, field, value, onChange }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [options, setOptions] = useState(field.options || []);
  const [isCreating, setIsCreating] = useState(false);
  const [newFolderName, setNewFolderName] = useState("");

  const containerRef = useRef(null);
  const inputRef = useRef(null);
  const menuRef = useRef(null);
  const createInputRef = useRef(null);

  useEffect(() => {
    const newOptions = (field.options || []).slice();
    setOptions((prev) => {
      const created = prev.filter((o) => typeof o === "object" && o.isNew);
      for (const c of created) {
        if (!newOptions.some((o) => optionValue(o) === optionValue(c))) {
          newOptions.push(c);
        }
      }
      return newOptions;
    });
  }, [field.options]);

  const toggleDropdown = () => {
    setIsOpen((prev) => !prev);
    setIsCreating(false);
  };

  // The list is usable from the keyboard too: arrows open it and walk the options, Enter or Space picks
  // one, Escape closes it and returns to the field.
  const [focusOnOpen, setFocusOnOpen] = useState(false);
  const menuItems = () => Array.from(menuRef.current?.querySelectorAll("[data-option]") ?? []);
  useEffect(() => {
    if (!isOpen || !focusOnOpen) return;
    setFocusOnOpen(false);
    const items = menuItems();
    (items.find((el) => el.getAttribute("aria-selected") === "true") ?? items[0])?.focus();
  }, [isOpen, focusOnOpen]);

  const onFieldKeyDown = (ev) => {
    if (["ArrowDown", "ArrowUp", "Enter", " "].includes(ev.key)) {
      ev.preventDefault();
      setIsOpen(true);
      setFocusOnOpen(true);
    } else if (ev.key === "Escape" && isOpen) {
      ev.preventDefault();
      ev.stopPropagation();
      setIsOpen(false);
    }
  };

  const onMenuKeyDown = (ev) => {
    if (ev.target.closest?.(".dropdown-create-row")) return;
    const items = menuItems();
    const at = items.indexOf(document.activeElement ?? ev.target);
    if (ev.key === "ArrowDown" || ev.key === "ArrowUp") {
      ev.preventDefault();
      const next = ev.key === "ArrowDown" ? Math.min(items.length - 1, at + 1) : Math.max(0, at - 1);
      items[next]?.focus();
    } else if (ev.key === "Enter" || ev.key === " ") {
      ev.preventDefault();
      ev.target.click?.();
    } else if (ev.key === "Escape") {
      ev.preventDefault();
      ev.stopPropagation();
      setIsOpen(false);
      inputRef.current?.focus();
    } else if (ev.key === "Tab") {
      setIsOpen(false);
    }
  };

  useEffect(() => {
    if (!isOpen) return;

    const onMouseDown = (ev) => {
      const path = ev.composedPath ? ev.composedPath() : [];
      if (containerRef.current && !path.includes(containerRef.current) && menuRef.current && !path.includes(menuRef.current)) {
        setIsOpen(false);
        setIsCreating(false);
      }
    };
    document.addEventListener("mousedown", onMouseDown);

    return () => {
      document.removeEventListener("mousedown", onMouseDown);
    };
  }, [isOpen]);

  useEffect(() => {
    if (isCreating) {
      createInputRef.current?.focus();
    }
  }, [isCreating]);

  const handleCreate = () => {
    const trimmed = newFolderName.trim();
    if (!trimmed) return;
    const val = `new:${trimmed}`;
    const newOpt = { label: trimmed, value: val, isNew: true };
    setOptions((prev) => [...prev, newOpt]);
    onChange(val);
    setNewFolderName("");
    setIsCreating(false);
    setIsOpen(false);
    inputRef.current?.focus();
  };

  const getDisplayLabel = () => {
    if (typeof value === "string" && value.startsWith("new:")) {
      return `${value.slice(4)} (new chapter)`;
    }
    const found = options.find((o) => optionValue(o) === value);
    if (found) return optionLabel(found);
    if (!value) return "(Top level)";
    return value;
  };

  return (
    <DropdownContainer ref={containerRef} className="folder-select-container">
      <div className="input-wrapper">
        <span className="folder-left-icon">
          <FolderIcon />
        </span>
        <input
          id={id}
          ref={inputRef}
          type="text"
          readOnly
          role="combobox"
          aria-haspopup="listbox"
          aria-expanded={isOpen}
          aria-controls={`${id}-options`}
          value={getDisplayLabel()}
          onClick={toggleDropdown}
          onKeyDown={onFieldKeyDown}
          style={{ paddingLeft: "34px", paddingRight: "32px", cursor: "pointer", userSelect: "none" }}
        />
        <button
          type="button"
          className="dropdown-toggle-btn"
          title="Toggle folder selection"
          tabIndex={-1}
          onClick={(ev) => {
            ev.preventDefault();
            toggleDropdown();
          }}
        >
          <ChevronDown />
        </button>
      </div>
      {isOpen && (
        <ul
          className="dropdown-menu"
          id={`${id}-options`}
          ref={menuRef}
          role="listbox"
          onMouseDown={(e) => e.stopPropagation()}
          onKeyDown={onMenuKeyDown}
        >
          {options.map((opt) => {
            const optVal = optionValue(opt);
            const isSelected = optVal === value;
            return (
              <li
                key={optVal}
                role="option"
                aria-selected={isSelected}
                tabIndex={-1}
                data-option
                className={`dropdown-item ${isSelected ? "selected" : ""}`}
                onClick={() => {
                  onChange(optVal);
                  setIsOpen(false);
                  inputRef.current?.focus();
                }}
              >
                <FolderIcon />
                <span style={{ flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                  {optionLabel(opt)}
                  {opt.isNew ? " (new)" : ""}
                </span>
                {isSelected && <CheckIcon />}
              </li>
            );
          })}
          {field.allowCreate && (
            <>
              <li className="dropdown-section-header" role="presentation">
                New chapter
              </li>
              {isCreating ? (
                <li className="dropdown-create-row" onMouseDown={(e) => e.stopPropagation()}>
                  <input
                    ref={createInputRef}
                    type="text"
                    placeholder="New chapter title..."
                    aria-label="New chapter title"
                    value={newFolderName}
                    onInput={(e) => setNewFolderName(e.currentTarget.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        e.preventDefault();
                        handleCreate();
                      } else if (e.key === "Escape") {
                        e.preventDefault();
                        setIsCreating(false);
                      }
                    }}
                  />
                  <button type="button" onClick={handleCreate} className="create-submit-btn">
                    Add
                  </button>
                </li>
              ) : (
                <li
                  className="dropdown-item create-folder-btn"
                  role="option"
                  aria-selected={false}
                  tabIndex={-1}
                  data-option
                  onClick={() => {
                    setIsCreating(true);
                    setNewFolderName("");
                  }}
                  style={{ color: "var(--accent-dark)", fontWeight: 600 }}
                >
                  <span style={{ fontSize: "16px", lineHeight: "1" }}>+</span>
                  <span>New chapter…</span>
                </li>
              )}
            </>
          )}
        </ul>
      )}
    </DropdownContainer>
  );
};

/** Option lists take plain strings, or `{ value, label }` when what the author should read is not what
 * the document should contain - a tag called `remove-stderr` is "Hide warnings", to anyone who has not
 * memorised the tag table. */
const optionValue = (option) => (typeof option === "string" ? option : option.value);
const optionLabel = (option) => (typeof option === "string" ? option : (option.label ?? option.value));

/** Each field type carries its own empty value, and its own idea of what "the user left this blank"
 * means - `required` on a checkbox means it has to be ticked, on a multiselect that something is. */
const emptyValue = (field) =>
  field.type === "checkbox" ? false : field.type === "multiselect" ? [] : field.type === "image" ? emptyImageValue() : "";
const isBlank = (field, value) =>
  field.type === "checkbox"
    ? !value
    : field.type === "multiselect"
      ? !value?.length
      : field.type === "image"
        ? !value?.file && !String(value?.url ?? "").trim()
        : !String(value ?? "").trim();
/** A field whose value cannot be submitted yet, whether or not it is required: an image still being read,
 * or one that is too large. */
const isInvalid = (field, value) => field.type === "image" && !!value && (value.busy || !!value.error) && !isBlank(field, value);

const Field = ({ field, value, onChange }) => {
  const hint = field.hint && <span className="hint">{field.hint}</span>;

  if (typeof field.render === "function") {
    return field.render({ field, value, onChange, hint });
  }

  // A group of checkboxes is a fieldset, not a label: a <label> may only name one control, so wrapping
  // several in one leaves a screen reader announcing the group's name for each box in it.
  if (field.type === "multiselect") {
    const selected = value ?? [];
    return (
      <fieldset>
        <legend>{field.label}</legend>
        {field.options.map((option) => {
          const optValue = optionValue(option);
          return (
            <label className="checkbox" key={optValue}>
              <input
                type="checkbox"
                checked={selected.includes(optValue)}
                // Rebuilt from the option order rather than by appending, so the emitted list reads in
                // the order it is shown regardless of which box was ticked first.
                onChange={() =>
                  onChange(field.options.map(optionValue).filter((v) => (v === optValue ? !selected.includes(v) : selected.includes(v))))
                }
              />
              <span>{optionLabel(option)}</span>
            </label>
          );
        })}
        {hint}
      </fieldset>
    );
  }

  if (field.type === "image") {
    return <ImageField field={field} value={value} onChange={onChange} hint={hint} />;
  }

  if (field.type === "checkbox") {
    return (
      <label className="checkbox">
        <input type="checkbox" autoFocus={field.autoFocus} checked={!!value} onChange={(ev) => onChange(ev.currentTarget.checked)} />
        <span>
          {field.label}
          {hint && <br />}
          {hint}
        </span>
      </label>
    );
  }

  if (field.type === "folder-select") {
    return (
      <div className="form-field-group">
        <label htmlFor={`field-${field.name}`}>{field.label}</label>
        <FolderSelectField id={`field-${field.name}`} field={field} value={value} onChange={onChange} />
        {hint}
      </div>
    );
  }

  if (field.type === "autocomplete" || field.type === "combobox") {
    return (
      <div className="form-field-group">
        <label htmlFor={`field-${field.name}`}>{field.label}</label>
        <AutocompleteField id={`field-${field.name}`} field={field} value={value} onChange={onChange} />
        {hint}
      </div>
    );
  }

  return (
    <label>
      {field.label}
      {field.type === "textarea" ? (
        <textarea autoFocus={field.autoFocus} placeholder={field.placeholder} value={value} onInput={(ev) => onChange(ev.currentTarget.value)} />
      ) : field.type === "select" ? (
        <select autoFocus={field.autoFocus} value={value} onChange={(ev) => onChange(ev.currentTarget.value)}>
          {field.options.map((option) => (
            <option key={optionValue(option)} value={optionValue(option)}>
              {optionLabel(option)}
            </option>
          ))}
        </select>
      ) : (
        <input
          type="text"
          autoFocus={field.autoFocus}
          placeholder={field.placeholder}
          value={value}
          onInput={(ev) => onChange(ev.currentTarget.value)}
        />
      )}
      {hint}
    </label>
  );
};

/** A single in-theme replacement for the chains of window.prompt() the toolbar buttons used to show.
 *
 * Driven by a signal rather than props: `request.value` is set to a spec plus the `resolve` of a promise
 * the caller is awaiting, so a button action reads as `const values = await ask({...})`. Submitting
 * resolves with a `{ [field.name]: value }` object - a string, or a boolean for `checkbox` and an array
 * of values for `multiselect`; cancelling or pressing Escape resolves with null, which every caller
 * treats as "abort". */
const FormDialog = ({ request }) => {
  const dialogRef = useRef(null);
  const values = useSignal({});

  useSignalEffect(() => {
    const req = request.value;
    if (!req) return;
    values.value = Object.fromEntries(req.fields.map((f) => [f.name, f.value ?? emptyValue(f)]));
    dialogRef.current?.showModal?.();
  });

  const finish = (result) => {
    const req = request.peek();
    dialogRef.current?.close?.();
    request.value = null;
    req?.resolve(result);
  };

  const req = request.value;
  if (!req) return null;

  const missingRequired = req.fields.some((f) => (f.required && isBlank(f, values.value[f.name])) || isInvalid(f, values.value[f.name]));

  return (
    <Form
      id="form-dialog"
      ref={dialogRef}
      // Escape closes a <dialog> natively; treat it the same as cancelling so the promise still settles.
      onCancel={(ev) => {
        ev.preventDefault();
        finish(null);
      }}
      // A <dialog>'s close event arrives after close() has returned. When a caller asks again straight
      // away (to point out a problem with what was entered), the event from the dialog just closed would
      // otherwise cancel the new one - so a close only counts for the request it was rendered for.
      onClose={() => request.peek() === req && finish(null)}
    >
      <form
        method="dialog"
        onSubmit={(ev) => {
          ev.preventDefault();
          if (missingRequired) return;
          finish(req.fields.length === 0 ? true : values.value);
        }}
      >
        <h1>{req.title}</h1>
        {req.message && (
          <p className="dialog-message" role={req.messageIsError ? "alert" : undefined}>
            {req.message}
          </p>
        )}
        {req.fields.map((field) => (
          <Field
            key={field.name}
            field={field}
            value={values.value[field.name]}
            onChange={(v) => (values.value = { ...values.value, [field.name]: v })}
          />
        ))}
        <div className="buttons">
          <DefaultButton type="submit" disabled={missingRequired}>
            {req.submitLabel ?? "Insert"}
          </DefaultButton>
          <DefaultButton type="button" onClick={() => finish(null)}>
            {req.cancelLabel ?? "Cancel"}
          </DefaultButton>
        </div>
      </form>
    </Form>
  );
};

export default FormDialog;
