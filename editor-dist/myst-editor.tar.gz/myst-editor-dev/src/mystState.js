import { markdownKeymap } from "@codemirror/lang-markdown";
import { Annotation, Prec } from "@codemirror/state";
import { keymap, lineNumbers, ViewPlugin } from "@codemirror/view";
import { signal, effect } from "@preact/signals";
import { createContext } from "preact";
import { closeBrackets } from "@codemirror/autocomplete";
import Settings from "./components/Settings";
import { CollaborationClient } from "./collaboration";
import { CodeMirror as VimCM, vim } from "@replit/codemirror-vim";
import { collabClientFacet, lineNumbersCompartment } from "./extensions";
import { TextManager } from "./text";

/** @type {{ id: string; tooltip?: string; text?: string; action?: Function; dropdown?: Function }} */
export const predefinedButtons = {
  // No `action` here: MystEditor supplies one that renders the whole document first (see buttonActions),
  // which a bare window.print() cannot do from module scope.
  printToPdf: { id: "print-to-pdf", tooltip: "Print document as pdf" },
  copyHtml: { id: "copy-html", tooltip: "Copy document as HTML" },
  refresh: { id: "refresh", tooltip: "Refresh GitLab Commits and Issues" },
  createBranch: { id: "create-branch", tooltip: "Create new branch" },
  settings: { id: "settings", tooltip: "Editor settings", dropdown: Settings },
  suggestMode: { id: "suggest-mode", tooltip: "Toggle suggest mode", active: (state) => state.suggestMode.value },
  bold: { id: "bold", tooltip: "Make Selected Text Bold" },
  italic: { id: "italic", tooltip: "Make Selected Text Italic" },
  equation: { id: "equation", tooltip: "Insert an Equation" },
  symbol: { id: "symbol", tooltip: "Insert a Symbol" },
  figure: { id: "figure", tooltip: "Insert a Figure" },
  highlight: { id: "highlight", tooltip: "Insert a Blockquote" },
  table: { id: "table", tooltip: "Insert a Table" },
  numlist: { id: "numlist", tooltip: "Insert a Numbered List" },
  bulllist: { id: "bulllist", tooltip: "Insert a Bulleted List" },
  link: { id: "link", tooltip: "Insert a Link" },
  admonition: { id: "admonition", tooltip: "Insert an Admonition" },
  codeCell: { id: "code-cell", tooltip: "Insert a Code Cell" },
  youtube: { id: "youtube", tooltip: "Embed a YouTube Video" },
};

/** Buttons whose feature only works with a collaboration server behind it. They are filtered out of the
 * topbar when `collaboration.enabled` is false, so a solo editor does not offer controls that cannot do
 * anything. Consumers listing them explicitly in `includeButtons` are filtered too - the flag wins. */
export const collabOnlyButtonIds = new Set(["suggest-mode"]);

export const defaultButtons = [
  predefinedButtons.settings,
  predefinedButtons.copyHtml,
  predefinedButtons.refresh,
  predefinedButtons.printToPdf,
  predefinedButtons.suggestMode,
  predefinedButtons.bold,
  predefinedButtons.italic,
  predefinedButtons.equation,
  predefinedButtons.symbol,
  predefinedButtons.figure,
  predefinedButtons.table,
  predefinedButtons.numlist,
  predefinedButtons.bulllist,
  predefinedButtons.link,
  predefinedButtons.highlight,
  predefinedButtons.admonition,
  predefinedButtons.codeCell,
  predefinedButtons.youtube,
];

// The vim plugin stores some functions as globals, but we need to differentiate between editors
const undoManagers = new WeakMap();
const { undo: originalUndo, redo: originalRedo } = VimCM.commands;
VimCM.commands.undo = (cm) => (undoManagers.get(cm)?.undo ?? originalUndo)(cm);
VimCM.commands.redo = (cm) => (undoManagers.get(cm)?.redo ?? originalRedo)(cm);

const formatRelativeNumbers = (line, state) => {
  if (line > state.doc.lines) return "0";
  const cursorLine = state.doc.lineAt(state.selection.main.head).number;
  return Math.abs(cursorLine - line).toString();
};

const defaultUserSettings = [
  {
    // The id is persisted in localStorage, so it stays `auto-markdown` even though the label changed.
    id: "auto-markdown",
    title: "Continue lists and quotes",
    enabled: false,
    extension: Prec.high(keymap.of(markdownKeymap)),
  },
  {
    id: "autoclose-bracket",
    title: "Autoclose brackets",
    enabled: false,
    extension: closeBrackets(),
  },
  {
    id: "links-new-tab",
    title: "Open links in new tabs",
    enabled: false,
  },
  {
    id: "scroll-past-end",
    title: "Scroll past last line",
    enabled: false,
    extension: ViewPlugin.fromClass(
      class {
        constructor(view) {
          this.view = view;
          this.observer = new ResizeObserver(() => {
            view.dom.style.paddingBottom = `${view.dom.parentElement.clientHeight - 20 - view.defaultLineHeight}px`;
          });
          this.observer.observe(view.dom.parentElement);
        }
        destroy() {
          this.view.dom.style.paddingBottom = "0px";
          this.observer.disconnect();
        }
      },
    ),
  },
  {
    id: "vim",
    title: "Vim mode",
    enabled: false,
    comments: true,
    extension: [
      Prec.high(vim()),
      ViewPlugin.fromClass(
        class {
          constructor(view) {
            const undoManager = view.state.facet(collabClientFacet)[0]?.undoManager;
            if (undoManager) undoManagers.set(view.cm, { undo: () => undoManager.undo(), redo: () => undoManager.redo() });
          }
        },
      ),
    ],
  },
  {
    id: "relative-line-numbers",
    title: "Relative line numbers",
    enabled: false,
    extension: [
      ViewPlugin.fromClass(
        class {
          constructor(view) {
            this.view = view;
            this.setRelativeLines();
          }
          update(update) {
            if (!update.selectionSet) return;
            this.setRelativeLines();
          }
          setRelativeLines() {
            queueMicrotask(() => {
              this.view.dispatch({
                effects: lineNumbersCompartment.reconfigure(lineNumbers({ formatNumber: formatRelativeNumbers })),
              });
            });
          }
          destroy() {
            queueMicrotask(() => {
              this.view.dispatch({
                effects: lineNumbersCompartment.reconfigure(lineNumbers()),
              });
            });
          }
        },
      ),
    ],
  },
];

const defaults = {
  id: "",
  title: "",
  subtitle: "",
  /** @type {"Both" | "Preview" | "Source" | "Diff" | "Resolved" | "Outline" | "Inline"} */
  mode: "Both",
  initialText: "",
  includeButtons: defaultButtons,
  topbar: true,
  collaboration: {
    enabled: false,
    commentsEnabled: false,
    resolvingCommentsEnabled: false,
    wsUrl: "ws://localhost:4444",
    username: "",
    room: "0",
    color: "#ff0000",
    mode: "websocket",
  },
  spellcheckOpts: null,
  customRoles: [],
  transforms: [],
  customDirectives: [],
  // this will create a bogus random avatar when no specific getAvatar function is provided
  getAvatar: (login) => `https://secure.gravatar.com/avatar/${login}?s=30&d=identicon`,
  avatarCrossorigin: null,
  getUserUrl: () => "#",
  backslashLineBreak: true,
  hideUsernameDelay: 5000,
  parent: null,
  syncScroll: true,
  unfoldedHeadings: null,
  mapUrl: (tag, url) => url,
  yamlSchema: null,
  onPreviewClick: () => {},
  onSubtitleClick: () => false,
  onDiscardChanges: () => {},
  // Called after the refresh button's default action; the git editor uses it to refresh branches/commits.
  onRefresh: null,
  mermaidTheme: "neutral",
  cmDarkTheme: false,
  onExit: false,
  // Let the external integration render the page index instead of the built-in sidebar.
  externalSidebar: false,
  showTitle: true,
  /** Show the editor's own version beside the title. Off by default because a page that embeds the
   * editor usually has its own idea of what belongs in the header; mountGitEditor turns it on for a
   * real git backend, where knowing which build is deployed is worth the few pixels. */
  showVersion: false,
  showModeButtons: true,
  /** A bar along the bottom with the cursor position and word count. Integrations add their own items
   * through `statusItems` (the git editor puts the branch, commit and unsaved changes there). */
  statusBar: true,
  /** @type {{ id: string, label: string, title?: string, onClick?: Function, mono?: boolean, dot?: boolean, attrs?: object }[]} */
  statusItems: [],
  /** A small image shown before the title, e.g. a brand mark while the integration's own logo is hidden. */
  titleMark: null,
  /** Lets the figure dialog, paste and drop take an image file and hold it for upload. An integration with
   * somewhere to put files supplies it (the git editor commits them with the page); without it, figures
   * take a URL only.
   * @type {null | {
   *   defaultPath: (fileName: string) => string,
   *   resolve: (pathFromPage: string) => string | null,
   *   relative: (repoPath: string) => string,
   *   exists: (repoPath: string) => Promise<boolean>,
   *   suggestFreePath: (repoPath: string) => Promise<string>,
   *   stage: (repoPath: string, blob: Blob) => void,
   * }} */
  assets: null,
  // Called with { state, git } once the git API is ready.
  onReady: null,
  language: "markdown",
};

export const modeChangeAnnotation = Annotation.define();

export function createMystState(/** @type {typeof defaults} */ opts) {
  const fullOptions = {
    ...defaults,
    ...opts,
    // `collaboration` is a nested object, so a shallow spread of a partial `opts.collaboration` would
    // drop the other defaults (wsUrl, username, color, …). Merge it explicitly. This also lets callers
    // (e.g. MystEditorGit forcing `mode: "manual"`) override a single field without clearing the rest.
    collaboration: { ...defaults.collaboration, ...opts.collaboration },
    initialText: (opts.initialText ?? defaults.initialText).replace(/\r/g, ""),
  };
  /** @typedef {Omit<typeof defaults, "parent">} SignalOpts */
  /** @type {{ [key in keyof SignalOpts]: import("@preact/signals").Signal<SignalOpts[key]> } & { parent: DocumentFragment }} */
  const signalOptions = { parent: fullOptions.parent };
  for (const opt in fullOptions) {
    if (Object.prototype.hasOwnProperty.call(fullOptions, opt) && opt != "parent") {
      signalOptions[opt] = signal(fullOptions[opt]);
    }
  }

  let browserSettings = JSON.parse(localStorage.getItem("myst/settings"));
  let userSettings = [...defaultUserSettings];
  if (browserSettings) {
    userSettings = userSettings.map((s) => {
      const browserSetting = browserSettings.find((bSetting) => bSetting.id == s.id);
      return browserSetting ? { ...s, enabled: browserSetting.enabled } : s;
    });
  }
  /** @type {import("@preact/signals").Signal<CollaborationClient>} */
  const collab = signal(null);
  const collabCleanup = effect(() => {
    if (!signalOptions.collaboration.value.enabled) return;
    const client = new CollaborationClient(signalOptions.collaboration.value, {
      id: signalOptions.id.value,
      parent: opts.parent,
      getAvatar: signalOptions.getAvatar.value,
      getUserUrl: signalOptions.getUserUrl.value,
    });
    collab.value = client;
    const destroy = (/** @type {PageTransitionEvent} */ ev) => {
      if (ev.persisted) return;
      client.destroy();
    };
    window.addEventListener("pagehide", destroy);

    return () => {
      client.destroy();
      window.removeEventListener("pagehide", destroy);
    };
  });

  const state = {
    options: signalOptions,
    /** @type {import("@preact/signals").Signal<import("codemirror").EditorView?>} */
    editorView: signal(null),
    cache: {
      transform: new Map(),
    },
    userSettings: signal(userSettings),
    collab,
    cleanups: [collabCleanup],
    linter: signal({ status: "disabled", diagnostics: [] }),
    /** @type {TextManager} */
    text: null,
    /** @type {import("@preact/signals").Signal<{level: number, text: string, pos: number}[]>} */
    headings: signal([]),
    /** @type {import("@preact/signals").Signal<{ src: string; error: Error } | null>} */
    error: signal(null),
    suggestMode: signal(false),
    /** Where the cursor is and how long the document is, for the status bar. */
    status: signal({ line: 1, col: 1, words: 0 }),
  };
  state.text = new TextManager({ ...signalOptions, ...state });

  const ignoredErrors = ["ResizeObserver loop completed with undelivered notifications"];
  // Only pick up errors coming from Myst in production
  window.addEventListener("error", (ev) => {
    if (state.error.value) return;
    if (typeof ev.message == "string" && ignoredErrors.some((ie) => ev.message.startsWith(ie))) return;

    const err = ev.error instanceof Error ? ev.error : new Error(ev.message);
    if (import.meta.env.PROD && !err.stack.includes("MystEditor.js")) return;

    state.error.value = { src: "ErrorEvent", error: err };
  });

  // Yjs catches errors when handling updates so we need this to detect them
  const defaultConsoleError = console.error;
  console.error = (msg, ...args) => {
    if (typeof msg === "string" && msg.startsWith("Caught error while handling a Yjs update")) {
      if (state.error.value == null) {
        state.error.value = { src: "Yjs update error", error: args[0] };
      }
    }

    if (typeof msg === "string" && msg.startsWith("Unable to compute message")) {
      return;
    }

    defaultConsoleError(msg, ...args);
  };

  let initialLoad = true;

  // Update comment positions when changing editor modes
  const modeCleanup = effect(() => {
    // Read only to subscribe: this effect re-runs whenever the mode changes.
    void state.options.mode.value;
    // It doesn't make sense to update comment positions on initial load because it's already done at src/components/CodeMirror.jsx:389
    if (initialLoad) {
      initialLoad = false;
      return;
    }
    // Prevent tracking further nested signals with queueMicrotask
    queueMicrotask(() => state.collab.peek()?.ycomments?.updateMainCodeMirror());
  });
  state.cleanups.push(modeCleanup);

  return state;
}

/** @type {import("preact").Context<ReturnType<createMystState>>} */
export const MystState = createContext();
