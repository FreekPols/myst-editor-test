import { Facet, StateEffect } from "@codemirror/state";

/** @type {Facet<import("./ycomments").YComments, import("./ycomments").YComments>} */
const ycommentsFacet = Facet.define({
  combine: (values) => values[values.length - 1],
  static: true,
});

/** @type {StateEffect<null>} */
const updateShownComments = StateEffect.define();

export { ycommentsFacet, updateShownComments };
