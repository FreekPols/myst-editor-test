import { visit } from "unist-util-visit";
import { findAfter } from "unist-util-find-after";
import { remove } from "unist-util-remove";
import { liftChildren, normalizeLabel } from "myst-common";
import { ReferenceState, enumerateTargetsTransform, resolveReferencesTransform } from "myst-transforms";
import { VFile } from "vfile";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type MdNode = any;

/**
 * The reference/enumeration stage, using the same code Jupyter Book does.
 *
 * This replaces `transform(new State())` from myst-to-html. That helper carries myst-to-html's own,
 * older copy of the reference machinery, and its target enumeration is a hardcoded three node types:
 *
 *     visit(tree, 'container', ...); visit(tree, 'math', ...); visit(tree, 'heading', ...);
 *
 * So anything else that can be labelled - an {exercise}, a {solution}, a {prf:theorem} - was never
 * registered as a target, and a reference to it could not resolve however it was written. myst-cli (the
 * package behind `myst build`) instead uses myst-transforms' `enumerateTargetsTransform`, which accepts
 * any node `isTargetIdentifierNode` recognises, and `resolveReferencesTransform`, which fills in the
 * reference text and numbering ("Exercise 1") rather than leaving the raw label.
 *
 * The rest of what myst-to-html's `transform` did is small and reproduced below, so nothing regresses:
 * paragraph-wrapped captions, mystTarget propagation, and lifting the directive/role wrappers. Caption
 * numbers are NOT ported: enumerateTargetsTransform already stamps them (and doing both produced two
 * spans, the second reading "Figure undefined" because the two shapes differ - see jbHandlers). Admonition headers are NOT re-added here - basicTransformations already did that, and
 * it checks for an existing title first (which is why the old call passed addAdmonitionHeaders: false).
 */

/** A caption's children must be a paragraph for the caption-number to have somewhere to go. */
const ensureCaptionIsParagraph = (tree: MdNode): void => {
  visit(tree, "caption", (node: MdNode) => {
    if (node.children && node.children[0]?.type !== "paragraph") {
      node.children = [{ type: "paragraph", children: node.children }];
    }
  });
};

/** `(target)=` on its own line labels the node that follows it. */
const propagateTargets = (tree: MdNode): void => {
  visit(tree, "mystTarget", ((node: MdNode, index: number) => {
    const nextNode = findAfter(tree, index) as MdNode;
    const normalized = normalizeLabel(node.label);
    if (nextNode && normalized) {
      nextNode.identifier = normalized.identifier;
      nextNode.label = normalized.label;
    }
    // Cast: unist-util-visit's BuildVisitor generics do not narrow for these untyped myst nodes.
  }) as never);
  remove(tree, "mystTarget");
};

export default function referencesMdast() {
  return (tree: MdNode): void => {
    // A fresh state per render: the editor renders one file with no project context, so targets are
    // whatever this document declares.
    const vfile = new VFile();
    const state = new ReferenceState("editor.md", { vfile });

    ensureCaptionIsParagraph(tree);
    propagateTargets(tree);
    enumerateTargetsTransform(tree, { state });
    resolveReferencesTransform(tree, vfile, { state });
    // The directive/role wrappers have served their purpose once targets are resolved.
    liftChildren(tree, "mystDirective");
    liftChildren(tree, "mystRole");
  };
}
