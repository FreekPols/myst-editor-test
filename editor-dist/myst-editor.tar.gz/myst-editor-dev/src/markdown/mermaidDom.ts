import mermaid, { type MermaidConfig } from "mermaid";

// The renderer emits `<pre class="mermaid">source</pre>` (see jbHandlers.ts); the diagram is drawn here,
// after the HTML is mounted - mermaid.render is async and needs a live element, so it cannot happen
// during the synchronous processSync pipeline.
//
// Results are cached by a hash of the diagram source. Whole-document rendering replaces the preview DOM
// on every update, so without the cache every keystroke would re-run mermaid and the diagram would
// visibly flicker.

/** Small FNV-1a over the diagram source; only used as a cache key, so collisions are harmless and it
 * saves pulling in the untyped imurmurhash the old pipeline used. */
const hashOf = (input: string): number => {
  let hash = 0x811c9dc5;
  for (let i = 0; i < input.length; i++) {
    hash ^= input.charCodeAt(i);
    hash = Math.imul(hash, 0x01000193);
  }
  return hash >>> 0;
};

const svgCache = new Map<number, string>();
let initializedTheme: string | null = null;

/** Render every mermaid block inside `root`. Synchronously fills in anything already cached, so an
 * unchanged diagram survives a re-render without flickering; anything new resolves shortly after. */
export function renderMermaidIn(root: ParentNode, theme: string): void {
  const blocks = [...root.querySelectorAll<HTMLElement>("pre.mermaid")];
  if (blocks.length === 0) return;

  if (initializedTheme !== theme) {
    // suppressErrorRendering stops a failed render drawing mermaid's error graphic; it would only land
    // in the scratch container below, which is thrown away, but this keeps it out of the DOM altogether.
    mermaid.initialize({ theme: theme as MermaidConfig["theme"], suppressErrorRendering: true });
    initializedTheme = theme;
  }

  for (const block of blocks) {
    const code = (block.textContent ?? "").trim();
    if (!code) continue;
    const hash = hashOf(code);

    const cached = svgCache.get(hash);
    if (cached) {
      block.innerHTML = cached;
      continue;
    }

    // mermaid.render needs somewhere to measure; keep it out of the visible layout.
    const scratch = document.createElement("div");
    scratch.style.position = "fixed";
    scratch.style.visibility = "hidden";
    document.body.appendChild(scratch);

    mermaid
      .render(`mermaid-${hash}-${Math.random().toString().replace(".", "")}`, code, scratch)
      .then(({ svg }) => {
        svgCache.set(hash, svg);
        // The preview may have been re-rendered while this was in flight, so only touch the element if
        // it is still in the document and still showing this diagram.
        if (block.isConnected) block.innerHTML = svg;
      })
      .catch(() => {
        /* invalid diagram: leave the source visible, as suppressErrorRendering intends */
      })
      .finally(() => scratch.remove());
  }
}
