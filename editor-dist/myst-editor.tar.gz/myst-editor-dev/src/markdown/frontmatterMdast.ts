import { getFrontmatter } from "myst-transforms";
import { VFile } from "vfile";

/**
 * Read the document's YAML frontmatter, then remove it from the tree.
 *
 * Two jobs. The obvious one is hiding it: parsing a document directly, as the editor does, leaves the
 * frontmatter in the tree as a leading `code` node with lang "yaml", so without this every document
 * that has frontmatter renders a YAML block at the top. (In a real mystmd build, myst-cli strips it
 * before parsing and hands it to the site generator.)
 *
 * The less obvious one is that frontmatter is CONFIGURATION, and discarding it cost real features:
 * `math` defines LaTeX macros the renderer needs, `abbreviations` defines tooltips, and `numbering`
 * controls how figures and equations are counted. `getFrontmatter` is the same helper myst-cli uses,
 * so the parsing rules (including a duplicated H1 title) match Jupyter Book's; the values are handed
 * back through `onFrontmatter` for the rest of the pipeline to use.
 */

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type MdNode = any;

export interface Frontmatter {
  /** LaTeX macro definitions, e.g. `\RR: \mathbb{R}` - passed to KaTeX. */
  math?: Record<string, string>;
  /** Abbreviation -> expansion, expanded across the document by abbreviationPlugin. */
  abbreviations?: Record<string, string>;
  /** Numbering configuration for figures, equations and headings. */
  numbering?: Record<string, unknown>;
  title?: string;
  subtitle?: string;
  [key: string]: unknown;
}

/** Only a document that actually opens with a `---` fence has frontmatter; one whose first block
 * happens to be a ```yaml code fence must keep it. */
export const hasFrontmatter = (source: string): boolean => /^---\r?\n/.test(source);

/** Keep only string->string entries: the transforms that consume these expect nothing else. */
const asStringMap = (value: unknown): Record<string, string> | undefined => {
  if (value == null || typeof value !== "object" || Array.isArray(value)) return undefined;
  const entries = Object.entries(value as Record<string, unknown>).filter(([, v]) => typeof v === "string");
  return entries.length ? (Object.fromEntries(entries) as Record<string, string>) : undefined;
};

export default function frontmatterMdast(source: string, onFrontmatter?: (frontmatter: Frontmatter) => void) {
  const present = hasFrontmatter(source);
  return () =>
    (tree: MdNode): void => {
      if (!present) return;
      // propagateTargets is off because referencesMdast already lifts directives and runs the target
      // transform; doing it twice here would be wasted work on every render.
      // keepTitleNode: Jupyter Book deletes an H1 that merely repeats the frontmatter title, because
      // its theme renders the title itself. The editor has no such title block, so deleting it would
      // make the document's heading vanish from the preview. Keep it until we render one.
      const { frontmatter } = getFrontmatter(new VFile(), tree, { propagateTargets: false, keepTitleNode: true }) as {
        frontmatter: Frontmatter;
      };
      if (!onFrontmatter || !frontmatter) return;
      onFrontmatter({
        ...frontmatter,
        math: asStringMap(frontmatter.math),
        abbreviations: asStringMap(frontmatter.abbreviations),
      });
    };
}
