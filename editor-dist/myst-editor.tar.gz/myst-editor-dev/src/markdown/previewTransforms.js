import { waitForElement } from "../utils";

/**
 * @typedef {{
 *  target: string | RegExp,
 *  transform: (input: string) => string | Promise<string>
 * }} Transform
 *
 * A consumer-supplied transformation applied to the rendered output.
 * `transform` is applied to all matches of `target`.
 */

/**
 * Async-transform plumbing shared by the consumer transforms/roles/directives API.
 *
 * A transform may return a Promise, but rendering is synchronous, so this emits a placeholder span up
 * front and swaps in the real HTML once the promise settles. That is why the API survived the parser
 * change unaltered: it lives in DOM post-processing, not in the parser.
 *
 * Used by src/markdown/transformsAdapter.ts.
 */
class PreviewWrapper {
  constructor(preview, cache) {
    this.preview = preview;
    this.cache = cache;
  }

  fillPlaceholder(placeholderId, html) {
    const placeholder = this.preview.getElementById(placeholderId);
    if (placeholder) placeholder.outerHTML = html;
  }

  cancelTransform(placeholderId) {
    const el = this.preview.getElementById(placeholderId);
    if (el) el.outerHTML = el.innerHTML;
  }

  /**
   * Creates a placeholder which will be replaced with the value of resolved `promise`.
   * If promise fails to resolve then placeholder will be removed
   *
   * @param {Promise<string>} promise
   * @returns {string}
   */
  createTransformPlaceholder(input, promise, target) {
    const placeholderId = "placeholder-" + Math.random().toString().slice(2);

    promise
      .then(waitForElement(this.preview, placeholderId))
      .then((result) => {
        this.cache.set(input, result);
        this.fillPlaceholder(placeholderId, result);
      })
      .catch((err) => {
        console.error("Error in custom transform:", target, "Caused by input:", input, "Error:", err);
        this.cancelTransform(placeholderId);
        this.cache.set(input, input);
      });

    return `<span id="${placeholderId}">${input}</span>`;
  }

  /**
   * Adds special handling to transformations which return promises.
   *
   * @param {Transform}
   * @returns {Transform}
   */
  overloadTransform({ transform: originalTransform, target, ...rest }) {
    return {
      target,
      transform: (input, ...params) => {
        const cached = this.cache.get(input);
        if (cached) return cached;

        let transformResult = originalTransform(input, ...params);

        if (typeof transformResult.then == "function") {
          return this.createTransformPlaceholder(input, transformResult, target);
        }

        return transformResult;
      },
      ...rest,
    };
  }
}

export { PreviewWrapper };
