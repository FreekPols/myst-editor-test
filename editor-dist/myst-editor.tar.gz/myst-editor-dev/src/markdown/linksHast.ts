import type { Root, RootContent, Element } from "hast";

// The three link-related behaviours the previous renderer implemented as three separate plugins hooking
// three different extension points (a core ruler, a renderer-rule override, and a per-setting plugin):
//
//   markdownUrlMapping.js  -> rewrite every href/src through the consumer's mapUrl()
//   markdownLinks.js       -> un-render links whose href starts with "(" back to literal markdown
//   userSettings links-new-tab -> add target=_blank rel=noreferrer
//
// They are all the same kind of thing - one pass over the output tree - so here they are one pass.

export interface LinkOptions {
  /** Consumer hook: rewrite an href/src. Used by the git integration to turn repo-relative paths
   * ("images/diagram.png") into API URLs, without which every relative asset 404s. */
  mapUrl?: (tag: string, url: string) => string;
  /** The "Open links in new tabs" user setting. */
  openLinksInNewTab?: boolean;
}

type HastNode = Root | RootContent;
const URL_ATTRS = ["href", "src"] as const;

/** `[label]((url))` parses (in CommonMark, so under BOTH parsers) to an <a> whose href starts with "(".
 * That is never a real link, so restore the original markdown text rather than emitting a broken one. */
const isBrokenLink = (node: Element) => node.tagName === "a" && typeof node.properties?.href === "string" && node.properties.href.startsWith("(");

const textOf = (node: HastNode): string => {
  if (node.type === "text") return node.value;
  const kids = (node as { children?: HastNode[] }).children;
  return kids ? kids.map(textOf).join("") : "";
};

export default function linksHast({ mapUrl, openLinksInNewTab }: LinkOptions) {
  return (tree: Root) => {
    const walk = (node: HastNode) => {
      const children = (node as { children?: HastNode[] }).children;
      if (!children) return;

      for (let i = 0; i < children.length; i++) {
        const child = children[i];
        if (child.type === "element") {
          if (isBrokenLink(child)) {
            // Replace the whole anchor with the source text it came from.
            children[i] = { type: "text", value: `[${textOf(child)}](${child.properties!.href as string})` };
            continue;
          }
          if (child.properties) {
            if (mapUrl) {
              for (const attr of URL_ATTRS) {
                const value = child.properties[attr];
                if (typeof value === "string") child.properties[attr] = mapUrl(child.tagName, value);
              }
            }
            if (openLinksInNewTab && child.tagName === "a" && typeof child.properties.href === "string") {
              child.properties.target = "_blank";
              // hast models `rel` as a space-separated list, not a plain string.
              child.properties.rel = ["noreferrer"];
            }
          }
        }
        walk(child);
      }
    };
    walk(tree);
  };
}
