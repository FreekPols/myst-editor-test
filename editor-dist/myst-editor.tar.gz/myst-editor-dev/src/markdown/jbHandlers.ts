import { all, defaultHandlers } from "mdast-util-to-hast";
import type { Handlers, H } from "mdast-util-to-hast";
import { iframeHandlers } from "./iframeHast";

// ---------------------------------------------------------------------------
// Why this file exists
//
// myst-to-html is only *half* of mystmd's HTML story. In a real Jupyter Book v2 build the mdast is
// handed to `myst-theme`'s React components, which render the interactive/structural markup; myst-to-html
// itself carries deliberately minimal handlers for those node types. Several are outright stubs that drop
// the node's children or its data:
//
//   details    -> <details>              (dropdown body and summary LOST)
//   mermaid    -> <div class="margin">   (diagram source LOST; wrong class - upstream copy/paste bug)
//   myst       -> <div class="margin">   (same copy/paste bug)
//   iframe     -> <div class="iframe">   (src LOST - see iframeHast.ts)
//   embed/output/bibliography/include/linkBlock -> empty wrappers
//
// and the myst-ext-* packages (tabs, cards, grids, exercises, proofs) ship NO html handlers at all -
// myst-ext-tabs even leaves them commented out in its source. Without handlers those nodes fall through
// to a bare <div>, which is why tab-sets and cards previously rendered as unstyled blobs.
//
// This module supplies the missing half: one handler per node type, emitting semantic HTML with stable
// class hooks that jupyterBookTheme.css styles. It is pure tree construction (O(nodes), no I/O), so it
// costs nothing measurable against the whole-doc render.
// ---------------------------------------------------------------------------

// `h` (upstream type `H`) is mdast-util-to-hast@12's element factory: h(node, tagName, props?, children?).
// It also applies node.data.hProperties, which is how sourceMapHast's data-line-id reaches the output.
//
// Nodes and hast children are typed loosely here for two reasons: these are myst/myst-ext node types with
// no shared mdast interface, and - as in mathHast.ts and sourceMapHast.ts - @types/hast is duplicated in
// the dependency tree (mdast-util-to-hast bundles its own copy), so importing hast's `Element` here
// produces a structurally identical but nominally incompatible type. The single `as Handlers` cast on the
// export below is the one place that discrepancy is absorbed.
type Node = any;
type Child = any;

const cx = (...parts: (string | false | undefined | null)[]) => parts.filter(Boolean).join(" ");

/** Children of `node` converted to hast. Every stub below was missing exactly this. */
const kids = (h: H, node: Node) => all(h as never, node as never);

// --- admonition title -----------------------------------------------------
// Upstream emits <p class="admonition-title">, but this editor's admonition styling (colours, per-kind
// icons - see Preview.js) is keyed on `aside.admonition > header`, which is what markdown-it-docutils
// produced. Emitting <header> here means we inherit that whole existing design for free
// instead of needing a parallel set of rules.
const admonitionTitle = (h: H, node: Node) => h(node, "header", { class: "admonition-title" }, kids(h, node));

// --- dropdown -------------------------------------------------------------
// `:::{dropdown}` produces details > [summary, ...body]. Both stubs dropped their children.
const details = (h: H, node: Node) => h(node, "details", { class: "dropdown" }, kids(h, node));
const summary = (h: H, node: Node) => h(node, "summary", { class: "dropdown-title" }, kids(h, node));

// --- mermaid --------------------------------------------------------------
// The diagram source lives on `node.value`. `<pre class="mermaid">` is the element mermaid.js renders
// in place (see markdown/mermaidDom.ts, which renders into it after mount).
const mermaid = (h: H, node: Node) => h(node, "pre", { class: "mermaid" }, [{ type: "text" as const, value: String(node.value ?? "") }]);

// --- asides / margins -----------------------------------------------------
// `:::{margin}`, `:::{aside}`, `:::{sidebar}` and `:::{topic}` are aliases of one directive producing an
// `aside` node; without a handler they collapsed to an anonymous <div>, losing semantics and hook alike.
// Upstream sets `kind` only for sidebar/topic - plain `aside` and `margin` both arrive undefined, and
// mystmd's convention is that a kind-less aside IS a margin note, so that is the fallback class.
const aside = (h: H, node: Node) => h(node, "aside", { class: cx("aside", node.kind || "margin") }, kids(h, node));

// --- tab-set --------------------------------------------------------------
// Rendered as a CSS-only tab control: one hidden radio + label per item, then the panels. The labels are
// pulled onto a single row with `order:-1` in the stylesheet, and `:checked + label + panel` reveals the
// active one. This gives real JB2 tab switching with no JavaScript in the preview.
let tabSetCount = 0;
const tabSet = (h: H, node: Node) => {
  const name = `tabset-${++tabSetCount}-${Math.random().toString(36).slice(2, 8)}`;
  const items: Node[] = (node.children ?? []).filter((c: Node) => c.type === "tabItem");
  const selected = Math.max(
    0,
    items.findIndex((i) => i.selected),
  );
  const children: Child[] = items.flatMap((item, index): Child[] => [
    {
      type: "element" as const,
      tagName: "input",
      properties: { type: "radio", class: "tab-input", name, id: `${name}-${index}`, checked: index === (selected || 0) },
      children: [],
    },
    {
      type: "element" as const,
      tagName: "label",
      properties: { class: "tab-label", for: `${name}-${index}` },
      children: [{ type: "text" as const, value: item.title ?? "Tab" }],
    },
    h(item, "div", { class: "tab-panel" }, kids(h, item)),
  ]);
  return h(node, "div", { class: "tab-set" }, children);
};
// tabItem is consumed by tabSet above; handle it standalone too so a stray one still renders its body.
const tabItem = (h: H, node: Node) => h(node, "div", { class: "tab-panel" }, kids(h, node));

// --- cards ----------------------------------------------------------------
const card = (h: H, node: Node) =>
  node.url ? h(node, "a", { class: "card card-link", href: node.url }, kids(h, node)) : h(node, "div", { class: "card" }, kids(h, node));
const cardTitle = (h: H, node: Node) => h(node, "div", { class: "card-title" }, kids(h, node));
const header = (h: H, node: Node) => h(node, "div", { class: "card-header" }, kids(h, node));
const footer = (h: H, node: Node) => h(node, "div", { class: "card-footer" }, kids(h, node));

// --- grid -----------------------------------------------------------------
// `columns` is sphinx-design's [xs, sm, md, lg]; we take the widest and let the stylesheet collapse it
// on narrow screens, which is how JB2 behaves in practice.
const grid = (h: H, node: Node) => {
  const columns = Array.isArray(node.columns) ? node.columns : [1, 2, 2, 3];
  return h(node, "div", { class: "grid", style: `--grid-columns:${columns[columns.length - 1] ?? 3}` }, kids(h, node));
};

// --- collapsible admonitions ----------------------------------------------
// `:class: dropdown` is how Jupyter Book makes an admonition (or an exercise/solution) collapsible.
// myst-to-html copies the class onto the element but always emits <aside>, so nothing collapsed. Emit
// <details>/<summary> instead, which needs no JavaScript and keeps the same class hooks for styling.
const hasDropdownClass = (node: Node) =>
  String(node.class ?? "")
    .split(/\s+/)
    .includes("dropdown");

/** The title child has already been rendered to <header> by admonitionTitle; a <details> needs the
 * summary as its FIRST child, so promote it in place rather than re-rendering the subtree. */
const promoteTitleToSummary = (children: Child[]): Child[] => {
  const index = children.findIndex((child) => child?.tagName === "header");
  if (index === -1) return children;
  const summaryEl = { ...children[index], tagName: "summary" };
  return [summaryEl, ...children.slice(0, index), ...children.slice(index + 1)];
};

/** Build an admonition-shaped callout, collapsible when it carries the dropdown class. */
const callout = (h: H, node: Node, classes: string, extra: Record<string, unknown> = {}) => {
  const children = kids(h, node);
  const properties = { class: cx(node.class, classes), id: node.identifier || undefined, ...extra };
  return hasDropdownClass(node) ? h(node, "details", properties, promoteTitleToSummary(children)) : h(node, "aside", properties, children);
};

// The generic admonition is not a stub upstream, but it has to go through `callout` too or
// `:class: dropdown` on a plain {note} would still render as a non-collapsible aside.
const admonition = (h: H, node: Node) => callout(h, node, cx("admonition", node.kind));

// --- exercises & proofs ---------------------------------------------------
// JB2 renders these as admonition-shaped callouts; reuse the admonition class so they inherit its frame.
const exercise = (h: H, node: Node) => callout(h, node, cx("admonition", "exercise", node.hidden && "hidden"));
const solution = (h: H, node: Node) => callout(h, node, "admonition solution");
const proof = (h: H, node: Node) => callout(h, node, cx("admonition", "proof", node.kind && `proof-${node.kind}`));

// --- caption numbers ------------------------------------------------------
// myst-to-html's own handler reads `node.value`, which is the shape ITS transform produced. The
// myst-transforms version we now run instead sets the formatted text as the node's children (and puts
// the number on `enumerator`), so reading `value` yielded "Figure undefined". Render the children.
const captionNumber = (h: H, node: Node) => {
  const children = kids(h, node);
  const kind = typeof node.kind === "string" ? node.kind.charAt(0).toUpperCase() + node.kind.slice(1) : "";
  return h(
    node,
    "span",
    { class: "caption-number" },
    children.length ? children : [{ type: "text" as const, value: `${kind} ${node.enumerator ?? ""}`.trim() }],
  );
};

// --- glossary terms -------------------------------------------------------
// glossaryTransform labels each term (identifier "term-<slug>") so `{term}` can reference it, but
// myst-to-html's definitionTerm handler emits a bare <dt> and drops the id - so the reference resolved
// to an anchor that pointed at nothing and clicking it did not move.
const definitionTerm = (h: H, node: Node) =>
  h(node, "dt", { id: node.html_id || node.identifier || undefined, class: node.identifier ? "glossary-term" : undefined }, kids(h, node));

// --- inline roles ---------------------------------------------------------
// myst-to-html has no handlers for these, so they fell through to the unknown handler and came out as
// <div> - a block element mid-paragraph, which is why small caps and underline appeared on their own
// line and chemical formulas and units rendered as bare text. The markup mirrors what Jupyter Book
// emits (see tests/fixtures/jb2-showcase.reference.html).
const smallcaps = (h: H, node: Node) => h(node, "span", { style: "font-variant:small-caps" }, kids(h, node));
const underline = (h: H, node: Node) => h(node, "span", { style: "text-decoration:underline" }, kids(h, node));
const span = (h: H, node: Node) => h(node, "span", { class: node.class || undefined, id: node.identifier || undefined }, kids(h, node));

/** H2O -> H<sub>2</sub>O. The parser leaves the formula as a flat string; JB2 splits it in its theme. */
const chemicalFormula = (h: H, node: Node) => {
  const parts = String(node.value ?? "").match(/\d+|\D+/g) ?? [];
  const children = parts.map((part) =>
    /^\d+$/.test(part)
      ? { type: "element" as const, tagName: "sub", properties: {}, children: [{ type: "text" as const, value: part }] }
      : { type: "text" as const, value: part },
  );
  return h(node, "span", { class: "chemical-formula", "aria-roledescription": "Chemical Formula" }, children);
};

/** The si role parses `4 <\kilogram>` into number+unit; on bad input it sets `error` and keeps the text. */
const si = (h: H, node: Node) =>
  h(node, "span", { class: cx("si-unit", node.error && "si-unit-error"), title: node.alt || undefined }, [
    { type: "text" as const, value: String(node.value ?? "") },
  ]);

/** {eval}`x` needs a running kernel, which the editor has not got. Show the expression, marked as such. */
const inlineExpression = (h: H, node: Node) =>
  h(node, "code", { class: "inline-expression", title: "Inline expression - evaluated when the notebook runs" }, [
    { type: "text" as const, value: String(node.value ?? "") },
  ]);

// --- block math -----------------------------------------------------------
// Upstream wraps MULTI-LINE math in <pre> (myst-to-html/dist/schema.js): sensible there, because it
// leaves the raw TeX as text and <pre> preserves its layout. We KaTeX-render it to MathML instead
// (mathHast), so the wrapper produces a <div> inside a <pre> - invalid, and it forces monospace and
// pre-wrap onto the rendered equation. Any math containing a newline hit this, which is every
// \begin{array} / \begin{aligned} block.
const math = (h: H, node: Node) => {
  const inner = {
    type: "element" as const,
    tagName: "div",
    properties: { class: "math-display" },
    children: [{ type: "text" as const, value: String(node.value ?? "") }],
  };
  if (!node.enumerator) return h(node, "div", { id: node.identifier || undefined, class: "math-block" }, [inner]);
  // The number is a sibling, not a child: mathHast overwrites .math-display's children with the MathML.
  const link = {
    type: "element" as const,
    tagName: "a",
    properties: { class: "equation-number", href: node.identifier ? `#${node.identifier}` : undefined },
    children: [{ type: "text" as const, value: `(${node.enumerator})` }],
  };
  return h(node, "div", { id: node.identifier || undefined, class: "math-block numbered" }, [inner, link]);
};

// --- cross-references -----------------------------------------------------
// myst-to-html has no crossReference handler, so `{solution} ex_fourier` rendered as the "unhandled
// role" markup: <span class=unhandled><code class=kind>{undefined}</code><code>ex_fourier</code></span>.
// Inside a coloured admonition header that is white-on-white and unreadable. Emit a real anchor to the
// target's id instead; crossReferencesMdast fills in the link text before this runs.
const crossReference = (h: H, node: Node) => {
  const children = kids(h, node);
  const target = node.identifier ?? node.label ?? "";
  return h(
    node,
    "a",
    { class: "cross-reference", href: target ? `#${target}` : undefined },
    children.length ? children : [{ type: "text" as const, value: String(target) }],
  );
};

// --- task list checkboxes --------------------------------------------------
// mystmd emits GFM task lists, but the checkbox is `disabled` (so it cannot be clicked) and the source
// line id lands on the <ul> rather than per item - sourceMapHast stamps one anchor per source line, and
// a list's first item shares its line with the list. Reuse the upstream listItem handler and fix up the
// checkbox it produced: enable it, and record its own line so syncCheckboxes can find the source.
const listItem = (h: H, node: Node, parent: Node) => {
  const element = (defaultHandlers as Record<string, (...args: unknown[]) => unknown>).listItem(h as never, node as never, parent as never) as Node;
  if (typeof node.checked !== "boolean") return element;

  const line = node.position?.start?.line;
  const stack: Node[] = [element];
  while (stack.length) {
    const current = stack.pop();
    if (current?.tagName === "input" && current.properties?.type === "checkbox") {
      delete current.properties.disabled;
      if (line != null) current.properties["data-line"] = String(line);
      break;
    }
    if (current?.children) stack.push(...current.children);
  }
  return element;
};

// --- CriticMarkup (suggest mode) -------------------------------------------
const criticIns = (h: H, node: Node) => h(node, "ins", { class: "critic-ins" }, kids(h, node));
const criticDel = (h: H, node: Node) => h(node, "del", { class: "critic-del" }, kids(h, node));

// --- remaining upstream stubs that dropped their children ------------------
const glossary = (h: H, node: Node) => h(node, "div", { class: "glossary" }, kids(h, node));
const embed = (h: H, node: Node) => h(node, "div", { class: "embed" }, kids(h, node));
const output = (h: H, node: Node) => h(node, "div", { class: "output" }, kids(h, node));
const bibliography = (h: H, node: Node) => h(node, "div", { class: "bibliography" }, kids(h, node));
const include = (h: H, node: Node) => h(node, "div", { class: "include", "data-file": node.file }, kids(h, node));
const linkBlock = (h: H, node: Node) => h(node, "a", { class: "link-block", href: node.url }, kids(h, node));
const myst = (h: H, node: Node) => h(node, "div", { class: "myst-demo" }, kids(h, node));

// mdast-util-to-hast renders a node type it does not know as a <div>. For the many MyST inline node
// types nobody has a handler for, that puts a block element in the middle of a paragraph - the browser
// then closes the paragraph around it, which is why unhandled roles appeared on their own line. Fall
// back to <span> unless the node actually contains block content.
const BLOCK_TYPES = new Set([
  "paragraph",
  "heading",
  "list",
  "listItem",
  "code",
  "blockquote",
  "table",
  "container",
  "admonition",
  "block",
  "math",
  "thematicBreak",
  "definitionList",
  "figure",
  "output",
]);

export const unknownHandler = (state: unknown, node: Node) => {
  const children = (node.children ?? []) as Node[];
  const hasBlockContent = children.some((child) => BLOCK_TYPES.has(child?.type));
  const tagName = hasBlockContent ? "div" : "span";
  const content = children.length
    ? all(state as never, node as never)
    : node.value != null
      ? [{ type: "text" as const, value: String(node.value) }]
      : [];
  return {
    type: "element" as const,
    tagName,
    // Keep the node type visible in the DOM: an unstyled blob is far easier to diagnose when you can
    // see which MyST node produced it.
    properties: { class: `myst-unhandled myst-${String(node.type)}` },
    children: content,
  };
};

export const jbHandlers = {
  ...iframeHandlers,
  admonition,
  admonitionTitle,
  captionNumber,
  definitionTerm,
  smallcaps,
  underline,
  span,
  chemicalFormula,
  si,
  inlineExpression,
  crossReference,
  math,
  listItem,
  criticIns,
  criticDel,
  details,
  summary,
  mermaid,
  aside,
  tabSet,
  tabItem,
  card,
  cardTitle,
  header,
  footer,
  grid,
  exercise,
  solution,
  proof,
  glossary,
  embed,
  output,
  bibliography,
  include,
  linkBlock,
  myst,
} as unknown as Handlers;
