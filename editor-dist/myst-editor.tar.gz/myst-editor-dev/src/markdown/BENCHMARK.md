# Whole-doc render benchmark (question i)

Median / p95 milliseconds per whole-document render
(myst-parser -> myst-to-html -> MathML -> sanitize-ready HTML, whole-doc, no chunk cache).
Renders while typing are debounced, so this is the cost once per quiet period, not per keystroke.

Environment: happy-dom under vitest (Node). Browser numbers differ but track these ratios.

| corpus | lines | median | p95 |
|---|---|---|---|
| small (myst-syntax.md) | 36 |     3.2 ms |     4.4 ms |
| showcase (jb2-showcase.md) | 436 |    24.1 ms |    28.1 ms |
| medium (cheatsheet.md) | 1208 |    39.3 ms |    43.5 ms |
| large (cheatsheet x4) | 4835 |   161.7 ms |   225.0 ms |

_Generated on 2026-09-12 by:_
`BENCHMARK_REPORT=1 npx vitest run tests/unit/renderBenchmark.test.js`
