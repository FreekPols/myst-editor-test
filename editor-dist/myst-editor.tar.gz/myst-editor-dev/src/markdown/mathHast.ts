import katex from "katex";
import type { Root, RootContent, Element } from "hast";

// Local, fully-typed hast walker. Avoids unist-util-visit here because @types/unist is duplicated in the
// tree (v2 via unist-util-visit@4, v3 via @types/hast), which makes visit's Node type clash with hast Root.
type HastNode = Root | RootContent;
const eachElement = (node: HastNode, fn: (el: Element) => void): void => {
  if (node.type === "element") fn(node);
  const kids = (node as { children?: HastNode[] }).children;
  if (kids) for (const k of kids) eachElement(k, fn);
};

// myst-to-html emits math as <span class="math-inline">TeX</span> and <div class="math-display">TeX</div>
// with the raw LaTeX as the text child. We KaTeX-render that to MathML *at the hast stage* (as a raw
// node) so the MathML lands in the HTML string before sanitize() — matching the existing markdown-it
// pipeline, which also inlines KaTeX MathML pre-sanitize. Output "mathml" avoids KaTeX's ~950KB font CSS.

const classNames = (node: Element): string[] => {
  // myst-to-html emits `properties.class` (string); standard hast uses `properties.className` (array).
  // Handle both so this works regardless of which stage produced the node.
  const raw = node.properties?.className ?? node.properties?.class;
  return Array.isArray(raw) ? (raw as string[]) : typeof raw === "string" ? raw.split(/\s+/) : [];
};

/** KaTeX implements a large part of amsmath, but not all of it. These three environments are common
 * in physics and engineering notes - MathJax accepts them, so anything written against a LaTeX
 * original or another renderer arrives using them - and KaTeX answers "No such environment", which
 * renders the entire block as red LaTeX source. Rewrite each to the nearest environment KaTeX does
 * implement, before it ever sees the TeX.
 *
 * Every target is a starred form: myst numbers a labelled `$$` block itself, so the environment must
 * not also number its rows. */
const ENVIRONMENT_ALIASES: Record<string, string> = {
  // eqnarray is left-hand side / relation / right-hand side. `align` keeps the relation column lined
  // up and tolerates eqnarray's extra `&`. An `array{rcl}` matches the column layout more exactly but
  // sets its cells in text style, which shrinks every fraction and integral limit in the block.
  eqnarray: "align*",
  // multline sets the first line flush left and the last flush right; gather centres them all. The
  // closest KaTeX has, and it keeps the breaks the author wrote.
  multline: "gather*",
  // flalign differs from align only in how it spreads horizontal space.
  flalign: "align*",
};

const ENVIRONMENT = /\\(begin|end)\s*\{\s*([a-zA-Z]+)\*?\s*\}/g;

/** Rewrite environments KaTeX cannot parse to ones it can. Exported for testing. */
export const aliasEnvironments = (tex: string): string =>
  tex.replace(ENVIRONMENT, (match, command: string, name: string) => {
    const alias = ENVIRONMENT_ALIASES[name];
    return alias ? `\\${command}{${alias}}` : match;
  });

const textOf = (node: Element): string => (node.children ?? []).map((child) => ("value" in child ? (child.value as string) : "")).join("");

export interface MathOptions {
  /** LaTeX macro definitions from frontmatter `math:`, e.g. { "\\RR": "\\mathbb{R}" }.
   * A getter, not a value: frontmatter is parsed during the run, after this plugin is registered. */
  getMacros?: () => Record<string, string> | undefined;
}

/** rehype/hast plugin: replace myst math elements' contents with rendered MathML. */
export default function mathHast(options: MathOptions = {}) {
  return (tree: Root) => {
    eachElement(tree, (node: Element) => {
      const classes = classNames(node);
      const displayMode = classes.includes("math-display");
      if (!displayMode && !classes.includes("math-inline")) return;

      const tex = aliasEnvironments(textOf(node).trim());
      if (!tex) return;

      let mathml: string;
      try {
        // KaTeX mutates the macros object it is given (it caches expansions), so hand it a copy.
        mathml = katex.renderToString(tex, {
          displayMode,
          throwOnError: false,
          output: "mathml",
          macros: { ...options.getMacros?.() },
        });
      } catch {
        return; // leave the raw LaTeX text in place on hard failures
      }
      // Emit as a raw node; rehype-stringify({ allowDangerousHtml: true }) serializes it verbatim, then
      // sanitize() (which allows MathML semantics/annotation tags) cleans it.
      node.children = [{ type: "raw", value: mathml } as never];
    });
  };
}
