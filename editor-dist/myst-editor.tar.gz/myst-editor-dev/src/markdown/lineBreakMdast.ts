// The `backslashLineBreak` option: treat a trailing `\` as a line break even at the end of a block.
//
// CommonMark already turns a backslash at the end of a line *inside* a paragraph into a hard break, so
// that case needs nothing here. What it does not do is handle a backslash at the end of a paragraph or
// block, where there is no following line to break onto - it renders a literal "\".
//
// Note the markdown-it implementation this replaces never actually fired: it looked for a text token
// whose content was exactly "\", but markdown-it joins adjacent text tokens, so the token always carried
// the preceding text too. The option was documented but inert. This makes it work, which means turning
// it on genuinely changes how a trailing backslash renders.

interface MdNode {
  type: string;
  value?: string;
  children?: MdNode[];
  position?: { end?: { line?: number } };
}

/** An escaped backslash (`\\`) and a trailing one (`\`) both reach mdast as a text value ending in a
 * single backslash - the escaping is already resolved. Consult the source line to tell them apart:
 * an odd number of trailing backslashes means the last one is a real line break. */
const endsWithUnescapedBackslash = (sourceLine: string | undefined): boolean => {
  if (!sourceLine) return false;
  const trailing = /\\+$/.exec(sourceLine.trimEnd());
  return trailing ? trailing[0].length % 2 === 1 : false;
};

export default function lineBreakMdast(source: string) {
  const lines = source.split("\n");
  return () =>
    (tree: MdNode): void => {
      const walk = (node: MdNode): void => {
        if (!node.children) return;
        for (const child of node.children) walk(child);

        const last = node.children[node.children.length - 1];
        if (last?.type !== "text" || typeof last.value !== "string" || !last.value.endsWith("\\")) return;
        if (!endsWithUnescapedBackslash(lines[(last.position?.end?.line ?? 0) - 1])) return;

        last.value = last.value.slice(0, -1);
        node.children.push({ type: "break" });
      };
      walk(tree);
    };
}
