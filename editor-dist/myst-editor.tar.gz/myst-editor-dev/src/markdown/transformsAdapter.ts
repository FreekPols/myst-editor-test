import type { DirectiveSpec, RoleSpec } from "myst-common";
// Reuse the existing async-placeholder + cache machinery so consumer transform behavior is identical
// across parsers (sync results inline; Promise results emit a placeholder span filled after mount).
import { PreviewWrapper } from "./previewTransforms.js";

// The public consumer API shapes (unchanged contract — see src/mystState.js defaults / git.html usage).
export interface Transform {
  target: string | RegExp;
  transform: (input: string, ...args: unknown[]) => string | Promise<string>;
}
export interface RoleOrDirective {
  target: string;
  transform: (input: string, ...args: unknown[]) => string | Promise<string>;
}

interface AdapterInput {
  transforms?: Transform[];
  customRoles?: RoleOrDirective[];
  customDirectives?: RoleOrDirective[];
  previewNode: unknown;
  cache: Map<string, string>;
}

// An mdast node carrying raw HTML. mystToHast({ allowDangerousHtml: true }) passes these through as raw
// hast, which rehype-stringify serializes and the caller's sanitize() then cleans.
const htmlNode = (value: string) => ({ type: "html", value });

/**
 * Map the consumer transforms/roles/directives API onto the mystmd pipeline:
 *  - customRoles      -> RoleSpec whose run() emits an html node
 *  - customDirectives -> DirectiveSpec whose run() emits an html node
 *  - transforms       -> an mdast plugin that regex-replaces text-node content (matching the existing
 *                        string-level behavior of markdownReplacer's text rule)
 * Async transforms are handled by PreviewWrapper.overloadTransform (emits a placeholder span synchronously
 * and fills it after mount), so everything below stays synchronous — required by mystmd's processSync.
 */
export function buildConsumerExtensions({ transforms = [], customRoles = [], customDirectives = [], previewNode, cache }: AdapterInput) {
  const preview = new PreviewWrapper(previewNode, cache);

  const roles: RoleSpec[] = customRoles.map((t) => {
    const wrapped = preview.overloadTransform(t) as RoleOrDirective;
    return {
      name: t.target,
      body: { type: String },
      run: (data: { body?: string }) => [htmlNode(String(wrapped.transform(data.body ?? "")))],
    } as RoleSpec;
  });

  const directives: DirectiveSpec[] = customDirectives.map((t) => {
    const wrapped = preview.overloadTransform(t) as RoleOrDirective;
    return {
      name: t.target,
      body: { type: String },
      run: (data: { body?: string; arg?: string; options?: Record<string, unknown> }) => {
        // Mirror the docutils adapter's input signature: body + args + options, plus the data object as
        // the 2nd arg so existing directives like git.html's {bold} (which read data.body) keep working.
        const args = data.arg ? [data.arg] : [];
        const input = (data.body ?? "") + JSON.stringify(args) + JSON.stringify(data.options ?? {});
        return [htmlNode(String(wrapped.transform(input, { body: data.body ?? "", args, options: data.options ?? {} })))];
      },
    } as DirectiveSpec;
  });

  // Precompute wrapped text transforms once.
  const wrappedTransforms = transforms.map((t) => preview.overloadTransform(t) as Transform);

  interface MdNode {
    type: string;
    value?: string;
    children?: MdNode[];
  }
  const applyToText = (value: string): string => {
    let out = value;
    for (const { target, transform } of wrappedTransforms) out = out.replaceAll(target as string | RegExp, transform as never);
    return out;
  };

  /** mdast plugin: replace text-node content whose value matches any transform with an html node. */
  const transformsPlugin =
    wrappedTransforms.length === 0
      ? undefined
      : () => (tree: MdNode) => {
          const walk = (node: MdNode) => {
            if (node.children) {
              for (const child of node.children) {
                if (child.type === "text" && typeof child.value === "string") {
                  const replaced = applyToText(child.value);
                  if (replaced !== child.value) {
                    (child as MdNode).type = "html";
                    child.value = replaced;
                  }
                } else {
                  walk(child);
                }
              }
            }
          };
          walk(tree);
        };

  return { roles, directives, transformsPlugin };
}
