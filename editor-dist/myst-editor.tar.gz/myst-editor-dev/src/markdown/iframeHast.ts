import type { H } from "mdast-util-to-hast";

// myst-to-html ships a STUB `iframe` handler: `h(node, 'div', { class: 'iframe' })` — it drops `src`,
// `width`, `align` and `title` entirely. That is deliberate upstream: in the full mystmd stack the real
// <iframe> is rendered by myst-theme's React components, and myst-to-html only emits the mount point.
// We render to an HTML string, so we override the handler here to emit an actual embed.
// mystToHast spreads `...opts?.handlers` after its defaults, so this wins.

// `h` (upstream type `H`) is mdast-util-to-hast's element factory; it also applies node.data.hProperties,
// which is how sourceMapHast's data-line-id survives onto the wrapper element.
// `iframe` is a myst node type unknown to mdast's own union, so it is typed structurally here (see
// jbHandlers.ts for the same reasoning applied to the myst-ext node types).
interface IframeNode {
  type: "iframe";
  src?: string;
  width?: string;
  align?: string;
  title?: string;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  [key: string]: any;
}

// Share URLs (youtu.be/ID, /watch?v=ID) send X-Frame-Options and REFUSE to be framed — only the
// /embed/ID form is embeddable. Rewriting here means authors can paste the URL straight from the
// address bar, which is what `:::{iframe}` invites them to do.
const YOUTUBE = /^(?:https?:)?\/\/(?:www\.|m\.)?(?:youtube\.com\/(?:watch\?(?:[^#]*&)?v=|embed\/|live\/|shorts\/)|youtu\.be\/)([\w-]{11})/;
const VIMEO = /^(?:https?:)?\/\/(?:www\.)?vimeo\.com\/(\d+)/;

/** Rewrite known share URLs to their embeddable form; anything else passes through untouched. */
export function toEmbedUrl(src: string): string {
  const youtube = YOUTUBE.exec(src);
  if (youtube) return `https://www.youtube.com/embed/${youtube[1]}`;
  const vimeo = VIMEO.exec(src);
  if (vimeo) return `https://player.vimeo.com/video/${vimeo[1]}`;
  return src;
}

// A relative or empty `src` is resolved by the browser against the page the editor is on, so
// `:::{iframe} myvideo` (or a bare `:::{iframe}`) loads the editor inside itself - the preview appears
// to recurse. Only absolute http(s) or protocol-relative URLs can name something embeddable, so
// anything else is reported instead of emitted.
const ABSOLUTE_URL = /^(?:https?:)?\/\/[^/\s]+/i;
export const isEmbeddable = (src: string): boolean => ABSOLUTE_URL.test(src.trim());

const ALIGN_MARGIN: Record<string, string> = {
  left: "0 auto 0 0",
  center: "0 auto",
  right: "0 0 0 auto",
};

// `:width:` is author-controlled and gets interpolated into a style attribute, so only accept a plain
// CSS length. Anything else falls back to full width rather than reaching the sanitizer as-is.
const CSS_LENGTH = /^\d+(?:\.\d+)?(?:%|px|em|rem|vw|vh|ch|pt|cm|mm|in)?$/;
const safeWidth = (width?: string): string => (width && CSS_LENGTH.test(width.trim()) ? width.trim() : "100%");

// See jbHandlers.ts on why the hast node here is typed structurally rather than imported from `hast`.
const iframe = (h: H, node: IframeNode) => {
  const src = toEmbedUrl((node.src ?? "").trim());
  if (!isEmbeddable(src)) {
    return h(node as never, "div", { class: "iframe iframe-invalid" }, [
      {
        type: "element" as const,
        tagName: "p",
        properties: {},
        children: [
          { type: "text" as const, value: "Cannot embed " },
          { type: "element" as const, tagName: "code", properties: {}, children: [{ type: "text" as const, value: node.src ?? "" }] },
          { type: "text" as const, value: " - an embed needs an absolute URL, for example https://www.youtube.com/watch?v=..." },
        ],
      },
    ]);
  }

  const inner = {
    type: "element" as const,
    tagName: "iframe",
    properties: {
      src,
      title: node.title,
      // 16:9 stops the embed collapsing to zero height (no intrinsic size); `border:0` stands in for
      // the legacy `frameborder` attribute, which DOMPurify strips.
      style: "width:100%;aspect-ratio:16/9;border:0",
      allowfullscreen: true,
    },
    children: [],
  };
  // The wrapper keeps myst-to-html's `.iframe` class hook and carries the data-line-id.
  return h(
    node as never,
    "div",
    { class: "iframe", style: `width:${safeWidth(node.width)};margin:${ALIGN_MARGIN[node.align ?? "center"] ?? ALIGN_MARGIN.center}` },
    [inner],
  );
};

export const iframeHandlers = { iframe };
