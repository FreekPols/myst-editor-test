import { tabDirectives } from "myst-ext-tabs";
import { cardDirective } from "myst-ext-card";
import { gridDirectives } from "myst-ext-grid";
import { exerciseDirectives } from "myst-ext-exercise";
import { proofDirective } from "myst-ext-proof";
import type { DirectiveSpec } from "myst-common";

// myst-parser only ships the *core* directive set. Jupyter Book v2 additionally registers these
// myst-ext-* packages, which is why `{tab-set}`, `{card}`, `{grid}`, `{exercise}` and `{prf:theorem}`
// previously rendered as "directive unhandled" blocks here. Registering the same packages is what makes
// the editor parse the same MyST dialect a `myst build` does.
//
// Kept as data (not baked into the renderer) so the set is auditable and easy to extend as JB2 grows.
export const jbDirectives: DirectiveSpec[] = [...tabDirectives, cardDirective, ...gridDirectives, ...exerciseDirectives, proofDirective];
