// mystmd parses `@label` as a citation (and `[@label]` as a parenthetical one), because in a real
// Jupyter Book project those resolve against a bibliography. The editor has no bibliography, so nothing
// can resolve - and `cite` has no handler in myst-to-html, which means every `@word` in ordinary prose
// rendered as an empty <div>: "Ping @some-user" lost the mention entirely.
//
// Turning citations back into their source text fixes that, and also restores the consumer `transforms`
// API for `@`-prefixed patterns (the git integration's @user mentions): transforms match text nodes, and
// the citation node had already swallowed the text before they ran.
//
// If bibliography support is added later, this is the pass to replace.

interface MdNode {
  type: string;
  value?: string;
  label?: string;
  identifier?: string;
  kind?: string;
  children?: MdNode[];
}

const sourceTextOf = (node: MdNode): string => {
  const label = node.label ?? node.identifier ?? "";
  return node.kind === "parenthetical" ? `[@${label}]` : `@${label}`;
};

export default function citationsMdast() {
  return (tree: MdNode): void => {
    const walk = (node: MdNode): void => {
      if (!node.children) return;
      node.children = node.children.map((child) => {
        if (child.type === "cite") return { type: "text", value: sourceTextOf(child) };
        // A citeGroup wraps several cites, e.g. [@a; @b]; flatten it to its rendered source text.
        if (child.type === "citeGroup") {
          const inner = (child.children ?? []).map((c) => `@${c.label ?? c.identifier ?? ""}`).join("; ");
          return { type: "text", value: `[${inner}]` };
        }
        walk(child);
        return child;
      });
    };
    walk(tree);
  };
}
