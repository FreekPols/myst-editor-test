// Reproduces the data-line-id / lineMap contract from src/markdown/markdownSourceMap.js, but for the
// mystmd pipeline. Runs at the MDAST stage (after myst `transform`, before mystToHast): raw parsed nodes
// carry `position.start.line`, and mdast-util-to-hast (which mystToHast is built on) copies
// `data.hProperties` onto the emitted hast element — so the attribute survives into the HTML string.
//
// Contract preserved so the 7+ consumers (syncDualPane, lineAuthors, checkboxes, inlinePreview, ...) work
// unchanged: `lineMap` is Map<sourceLine, randomId>, and exactly one element per source line carries
// data-line-id="<randomId>". findNearestElementForLine() walks backwards to the nearest mapped line.

// Minimal structural mdast type — avoids unist-util-visit / @types/unist version clashes in the tree.
interface MdNode {
  type: string;
  position?: { start?: { line?: number } };
  data?: { hProperties?: Record<string, unknown> };
  children?: MdNode[];
}

const randomLineId = () => Math.random().toString().replace(".", "");

// Nodes created by directive transforms (admonition/container/figure) have no position; their inner
// content (paragraphs, headings) does, so those provide the anchors. We skip the document root only.
const SKIP = new Set(["root"]);

const eachNode = (node: MdNode, fn: (n: MdNode) => void): void => {
  fn(node);
  if (node.children) for (const c of node.children) eachNode(c, fn);
};

export interface SourceMapOptions {
  /** Added to every line number. Inline-mode fragments are parsed standalone, so their positions start
   * at 1 and must be shifted back to where the fragment sits in the real document. */
  offset?: number;
  /** Fragments contribute to the document's existing map, so they must not wipe it. */
  keep?: boolean;
}

/** mdast plugin factory: stamps line ids and fills `lineMap`. */
export default function sourceMapPlugin(lineMap: Map<number, string>, { offset = 0, keep = false }: SourceMapOptions = {}) {
  return () =>
    (tree: MdNode): void => {
      if (!keep) lineMap.clear();
      eachNode(tree, (node) => {
        if (SKIP.has(node.type)) return;
        const rawLine = node.position?.start?.line;
        if (rawLine == null) return;
        const line = rawLine + offset;
        // One anchor per source line — the first (outermost/earliest in pre-order) node wins, mirroring
        // the previous renderer's block-token granularity.
        if (lineMap.has(line)) return;
        const id = randomLineId();
        lineMap.set(line, id);
        node.data ??= {};
        node.data.hProperties = { ...node.data.hProperties, "data-line-id": id };
      });
    };
}
