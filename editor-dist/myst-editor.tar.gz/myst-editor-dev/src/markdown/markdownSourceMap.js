/**
 * Lookup helpers for the source map shared by the editor and preview: `lineMap` maps a source line to a
 * random id that also appears as `data-line-id` on a preview element. The mystmd renderer fills it in
 * (src/markdown/sourceMapHast.ts); these read it back.
 */

export function findNearestElementForLine(lineNumber, lineMap, preview) {
  let id = null;
  let match = null;
  let num = lineNumber;
  for (; num >= 1; num--) {
    id = lineMap.get(num);
    if (id) {
      match = preview?.querySelector(`[data-line-id="${id}"]`);
      if (match) break;
    }
  }

  return [match, num];
}

export function getLineById(lineMap, id) {
  for (const [line, value] of lineMap.entries()) {
    if (value === id) {
      return line;
    }
  }
}
