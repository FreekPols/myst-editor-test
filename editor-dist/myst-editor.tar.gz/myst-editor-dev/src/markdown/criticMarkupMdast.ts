// CriticMarkup: {++added++}, {--removed--}, {~~old~>new~~}.
//
// Suggest mode writes these into the source and the CodeMirror side decorates them (see
// extensions/criticMarkup.js, which shares only the `criticMarkers` constant with the old markdown-it
// plugin). This is the preview half.
//
// Markers may be separated from their content by soft line breaks inside a paragraph, so this works on
// each parent's run of text/break children joined together rather than on individual text nodes.
//
// Not handled: a suggestion spanning a blank line (i.e. several blocks). The markdown-it implementation
// nominally supported that, but its multi-line *deletion* path was broken - it emitted mangled text with
// the raw marker still visible and characters dropped - so nothing working is lost here.

interface MdNode {
  type: string;
  value?: string;
  children?: MdNode[];
  data?: Record<string, unknown>;
}

// Content is captured lazily and never re-parsed as markdown, matching the old plugin (which pushed the
// inner content as a single text token).
const CRITIC = /\{(\+\+|--|~~)([\s\S]*?)\1\}/g;

const wrap = (type: "criticIns" | "criticDel", value: string): MdNode => ({ type, children: [{ type: "text", value }] });

/** Turn one matched marker into its replacement nodes. Returns null if the match is not a valid
 * suggestion, so the original text is left untouched. */
const nodesFor = (marker: string, content: string): MdNode[] | null => {
  if (marker === "~~") {
    // A replacement must actually replace something.
    const at = content.indexOf("~>");
    if (at < 0) return null;
    const before = content.slice(0, at);
    const after = content.slice(at + 2);
    if (!before || !after) return null;
    return [wrap("criticDel", before), wrap("criticIns", after)];
  }
  if (!content) return null;
  return [wrap(marker === "++" ? "criticIns" : "criticDel", content)];
};

export default function criticMarkupMdast() {
  return (tree: MdNode): void => {
    const walk = (node: MdNode): void => {
      if (!node.children) return;

      const out: MdNode[] = [];
      let run: MdNode[] = [];

      // Join a run of text/break siblings so a marker split across a soft break still matches.
      const flushRun = () => {
        if (run.length === 0) return;
        const joined = run.map((n) => (n.type === "break" ? "\n" : (n.value ?? ""))).join("");
        CRITIC.lastIndex = 0;
        let last = 0;
        let match: RegExpExecArray | null;
        let replaced = false;
        const built: MdNode[] = [];
        while ((match = CRITIC.exec(joined)) !== null) {
          const nodes = nodesFor(match[1], match[2]);
          if (!nodes) continue;
          if (match.index > last) built.push({ type: "text", value: joined.slice(last, match.index) });
          built.push(...nodes);
          last = match.index + match[0].length;
          replaced = true;
        }
        if (!replaced) {
          out.push(...run);
        } else {
          if (last < joined.length) built.push({ type: "text", value: joined.slice(last) });
          out.push(...built);
        }
        run = [];
      };

      for (const child of node.children) {
        if (child.type === "text" || child.type === "break") {
          run.push(child);
          continue;
        }
        flushRun();
        walk(child);
        out.push(child);
      }
      flushRun();

      node.children = out;
    };
    walk(tree);
  };
}
