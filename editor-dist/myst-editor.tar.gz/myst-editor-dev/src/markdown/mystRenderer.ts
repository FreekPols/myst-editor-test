import { unified } from "unified";
import { mystParser } from "myst-parser";
import { mystToHast } from "myst-to-html";
import {
  basicTransformationsPlugin,
  glossaryTransform,
  abbreviationTransform,
  indexIdentifierTransform,
  inlineMathSimplificationTransform,
  footnotesTransform,
} from "myst-transforms";
import referencesMdast from "./referencesMdast";
import rehypeStringify from "rehype-stringify";
import sourceMapPlugin from "./sourceMapHast";
import mathHast from "./mathHast";
import { jbHandlers, unknownHandler } from "./jbHandlers";
import { jbDirectives } from "./jbDirectives";
import linksHast, { type LinkOptions } from "./linksHast";
import criticMarkupMdast from "./criticMarkupMdast";
import lineBreakMdast from "./lineBreakMdast";
import frontmatterMdast, { type Frontmatter } from "./frontmatterMdast";
import citationsMdast from "./citationsMdast";

import type { DirectiveSpec, RoleSpec } from "myst-common";

export interface RenderCtx {
  /** Populated with sourceLine -> data-line-id, matching src/markdown/markdownSourceMap.js. */
  lineMap: Map<number, string>;
  /** Consumer-provided custom roles (from transformsAdapter). */
  roles?: RoleSpec[];
  /** Consumer-provided custom directives (from transformsAdapter). */
  directives?: DirectiveSpec[];
  /** mdast plugin applying consumer regex text transforms (from transformsAdapter). */
  transformsPlugin?: () => (tree: unknown) => void;
  /** mapUrl hook and the open-links-in-new-tab setting (see linksHast). */
  links?: LinkOptions;
  /** Shift stamped line numbers, for rendering a fragment of a larger document (inline mode). */
  lineOffset?: number;
  /** Add to the existing lineMap instead of replacing it (inline mode renders many fragments). */
  keepLineMap?: boolean;
  /** The `backslashLineBreak` option: a trailing `\` ends a line even at the end of a block. */
  backslashLineBreak?: boolean;
  /** Rendering part of a larger document (inline mode), so mystmd's block wrapper is stripped - it is
   * structure for a whole document, and a <div> is not valid inside the widget's <span>. */
  fragment?: boolean;
  /** With `fragment`, also strip the paragraph wrapper: an inline run, not a block. */
  inline?: boolean;
  /** Render CriticMarkup (`{++ ++}`, `{-- --}`, `{~~ ~> ~~}`) as ins/del. Off leaves it as literal text,
   * which is what Jupyter Book does - CriticMarkup is not MyST syntax. Suggestions are a collaboration
   * feature, so the editor turns this off when collaboration is disabled. */
  criticMarkup?: boolean;
}

export interface RenderResult {
  html: string;
  error: string | null;
}

// The mystmd render strategy: MyST source -> mdast (myst-parser) -> myst transforms (directives,
// numbering, cross-refs) -> stamp line ids -> hast (mystToHast) -> render math to MathML -> HTML string.
// Whole-doc and synchronous by design (cross-references/numbering need the full document). The caller
// applies sanitize() to the returned html (the shared security boundary, unchanged from the md-it path).
export function renderMyst(source: string, ctx: RenderCtx): RenderResult {
  try {
    // Frontmatter is read during the run, but the passes that consume it come later in the same
    // pipeline, so they read from this object rather than being configured up front.
    const frontmatter: Frontmatter = {};
    let processor = unified()
      // Consumer directives come last so a host app can override a Jupyter Book one by name.
      .use(mystParser, { roles: ctx.roles ?? [], directives: [...jbDirectives, ...(ctx.directives ?? [])] })
      // Before basicTransformations, which wraps top-level content in `block` nodes and would hide the
      // frontmatter node from a root-level check.
      .use(frontmatterMdast(source, (parsed) => Object.assign(frontmatter, parsed)))
      // Before consumer transforms, which match text nodes: a citation node would otherwise have
      // already swallowed any `@user` text they target.
      .use(citationsMdast as never)
      // Jupyter Book's own "basic" mdast stage, which myst-to-html does NOT run (in a real `myst build`
      // it happens in myst-cli, between parse and render). It is what turns a container's trailing
      // paragraph into a `caption` node, lifts directives/roles, nests math and blocks, assigns html ids
      // and adds admonition headers. Without it figures render captionless and unnumbered.
      .use(basicTransformationsPlugin, {})
      // Targets, cross-references and numbering, using the same myst-transforms code `myst build` runs
      // rather than myst-to-html's weaker built-in State. See referencesMdast.ts.
      // Cast as with transformsPlugin below: unified's Plugin generics do not survive this chain.
      // Glossary and abbreviations run BEFORE enumeration, as they do in myst-cli: the glossary turns
      // its definition list into labelled term targets, which references then resolve against.
      //
      // These read `frontmatter` inside the transform rather than taking it as a plugin option. The
      // option would be read when `.use()` is called, which is before the frontmatter pass has run -
      // so it would always be undefined.
      .use(() => (tree: unknown, file: unknown) => {
        // Ordered as myst-cli orders them. inlineMathSimplification turns trivial inline math into
        // plain text (replaceSymbol: false matches Jupyter Book, which keeps symbols as math).
        inlineMathSimplificationTransform(tree as never, { replaceSymbol: false });
        glossaryTransform(tree as never, file as never);
        abbreviationTransform(tree as never, { abbreviations: frontmatter.abbreviations });
        indexIdentifierTransform(tree as never);
      })
      .use(referencesMdast as never);
    // Consumer regex transforms run at the mdast stage, before line-ids are stamped.
    if (ctx.transformsPlugin) processor = processor.use(ctx.transformsPlugin as never);
    const file = processor
      // Footnotes run near the end in myst-cli: they collect definitions from wherever they appear and
      // attach them to their references, which needs the rest of the tree to be settled first.
      .use(() => (tree: unknown, file: unknown) => footnotesTransform(tree as never, file as never))
      .use(ctx.backslashLineBreak ? lineBreakMdast(source) : noopPlugin)
      .use(ctx.criticMarkup === false ? noopPlugin : criticMarkupMdast)
      .use(sourceMapPlugin(ctx.lineMap, { offset: ctx.lineOffset ?? 0, keep: ctx.keepLineMap ?? false }))
      // allowDangerousHtml lets html mdast nodes (custom roles/directives/transforms) pass through as raw.
      .use(mystToHast, { allowDangerousHtml: true, handlers: jbHandlers, unknownHandler })
      // Frontmatter `math:` entries are LaTeX macro definitions; without them a document that defines
      // \RR renders an undefined-control-sequence error wherever it is used. Passed as a getter for
      // the same reason as above: the value does not exist yet when this line runs.
      .use(mathHast, { getMacros: () => frontmatter.math })
      .use(linksHast, ctx.links ?? {})
      .use(ctx.fragment ? unwrapFragment(ctx.inline ?? false) : noopPlugin)
      .use(normalizeHast)
      // allowDangerousHtml here serializes the raw MathML from mathHast and the raw html above; the
      // caller's sanitize() then cleans the result.
      .use(rehypeStringify, { allowDangerousHtml: true })
      .processSync(source);
    return { html: String(file), error: null };
  } catch (error) {
    return { html: "", error: error instanceof Error ? error.message : "The preview could not be rendered." };
  }
}

export const mystmdSupportsChunks = false;

function noopPlugin() {
  return () => {};
}

// Inline mode renders pieces of a document, so the wrappers mystmd puts around a whole one
// (`<div class="block"><p>...</p></div>`) have to come off: the block wrapper always, and the paragraph
// too for an inline run. The old path used markdown-it render()/renderInline(), neither of which
// produced a block wrapper to begin with.
interface HastEl {
  type: string;
  tagName?: string;
  properties?: Record<string, unknown>;
  children?: HastEl[];
}
function unwrapFragment(inline: boolean) {
  return () => (tree: HastEl) => {
    const unwrapOnly = (tag: string) => {
      const elements = (tree.children ?? []).filter(
        (c) => c.type === "element" || (c.type === "text" && String((c as { value?: string }).value ?? "").trim()),
      );
      if (elements.length === 1 && elements[0].type === "element" && elements[0].tagName === tag) {
        tree.children = elements[0].children ?? [];
      }
    };
    unwrapOnly("div");
    if (inline) unwrapOnly("p");
  };
}

// Defensive hast pass: some myst-to-html outputs (e.g. execution-oriented {code-cell}/{glue} rendered in
// a static browser context) produce text/raw nodes with an undefined `value`, which crashes
// hast-util-to-html's entity stringifier. Coerce any non-string node value to "" before serialization.
interface ValueNode {
  type: string;
  value?: unknown;
  children?: ValueNode[];
}
function normalizeHast() {
  return (tree: ValueNode) => {
    const walk = (node: ValueNode) => {
      if ((node.type === "text" || node.type === "raw" || node.type === "comment") && typeof node.value !== "string") {
        node.value = node.value == null ? "" : String(node.value);
      }
      if (node.children) for (const c of node.children) walk(c);
    };
    walk(tree);
  };
}
