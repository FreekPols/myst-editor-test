/**
 * @param {{ target: HTMLElement }} ev
 * @param {import("codemirror").EditorView} editor
 */
export function syncCheckboxes(ev, editor) {
  if (ev.target.tagName != "INPUT") return;
  // The renderer records each checkbox's own source line on the input (see markdown/jbHandlers.ts).
  const lineNumber = Number(ev.target.getAttribute("data-line"));
  if (!lineNumber) return;
  const line = editor.state.doc.line(lineNumber);
  const openIdx = line.text.indexOf("[");
  const closeIdx = line.text.indexOf("]");

  editor.dispatch({
    changes: {
      from: line.from + openIdx + 1,
      to: line.from + closeIdx,
      insert: ev.target.checked ? "x" : " ",
    },
  });
}
