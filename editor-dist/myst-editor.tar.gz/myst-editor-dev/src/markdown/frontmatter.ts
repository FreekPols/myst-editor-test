/** Reading and patching a document's YAML frontmatter block from the editor side.
 *
 * Separate from frontmatterMdast.ts, which parses frontmatter during a render: this one works on the
 * raw source and hands back a character range, because the toolbar needs to *edit* the block. */

import yaml from "js-yaml";

/** A frontmatter block is a `---` fence on the very first line, closed by another on its own line.
 * Anything else - a `---` further down, a thematic break - is not frontmatter. */
const FRONTMATTER = /^---[ \t]*\r?\n([\s\S]*?)^---[ \t]*(?:\r?\n|$)/m;

export interface FrontmatterBlock {
  /** Always 0: a block that does not start the document is not frontmatter. */
  from: number;
  /** End of the closing fence, including its newline. */
  to: number;
  /** Position of the closing `---`, where a new key can be inserted. */
  closingFrom: number;
  /** The YAML between the fences. */
  body: string;
}

export function frontmatterBlock(doc: string): FrontmatterBlock | null {
  const match = FRONTMATTER.exec(doc);
  if (!match || match.index !== 0) return null;
  const body = match[1];
  return {
    from: 0,
    to: match[0].length,
    closingFrom: match[0].lastIndexOf("---"),
    body,
  };
}

/** Three answers, not two. "unknown" means there is a block but its YAML does not parse, and the
 * honest response to that is to leave it alone rather than to splice a key into something broken. */
export type KeyState = "present" | "missing" | "unknown";

export function frontmatterKeyState(doc: string, key: string): KeyState {
  const block = frontmatterBlock(doc);
  if (!block) return "missing";
  let parsed: unknown;
  try {
    parsed = yaml.load(block.body);
  } catch {
    return "unknown";
  }
  if (parsed == null) return "missing";
  if (typeof parsed !== "object" || Array.isArray(parsed)) return "unknown";
  return key in (parsed as Record<string, unknown>) ? "present" : "missing";
}

/** A CodeMirror-shaped change that adds `key` to the frontmatter, creating the block if there is none.
 *
 * Returns null when there is nothing to do or nothing safe to do - the key is already there, or the
 * block does not parse. Callers treat null as "leave the document alone". */
export function addFrontmatterKey(doc: string, key: string, value: unknown): { from: number; to: number; insert: string } | null {
  const state = frontmatterKeyState(doc, key);
  if (state !== "missing") return null;

  // yaml.dump ends with a newline and indents nested maps two spaces, which is the house style in
  // every Jupyter Book example.
  const entry = yaml.dump({ [key]: value }, { indent: 2, lineWidth: -1 });

  const block = frontmatterBlock(doc);
  if (!block) {
    // A blank line after the block, so the first heading does not end up glued to the closing fence.
    return { from: 0, to: 0, insert: `---\n${entry}---\n\n` };
  }
  // Append to the existing block rather than rewriting it: dumping the parsed YAML back out would
  // reformat the author's block, dropping comments and reordering keys.
  const insert = block.body.length && !block.body.endsWith("\n") ? `\n${entry}` : entry;
  return { from: block.closingFrom, to: block.closingFrom, insert };
}
