/** Building a Jupyter Book `{code-cell}` directive from what the toolbar dialog collected.
 *
 * Kept out of the button action so the awkward parts - which tags a choice implies, how long the fence
 * has to be, the blank line the directive requires - can be tested without a dialog or an editor. */

export interface CodeCellPreset {
  value: string;
  label: string;
  /** The tags this intent implies. The author never types these. */
  tags: string[];
}

/** What the cell is *for*, rather than which tags it needs. Jupyter Book's tag vocabulary is a table
 * of eight entries in the docs; an author writing one figure a month should not have to hold it. */
export const codeCellPresets: CodeCellPreset[] = [
  { value: "figure", label: "Show Output", tags: ["remove-input"] },
  { value: "both", label: "Show Code and Output", tags: [] },
  { value: "setup", label: "Execute only", tags: ["remove-cell"] },
  { value: "example", label: "Show Code (No Execution)", tags: ["skip-execution"] },
];

/** The rest of the tag vocabulary, as things an author might want rather than as tag names. Offered
 * alongside a preset, so the common case stays one choice and the uncommon one is still reachable. */
export const codeCellExtraTags = [
  { value: "hide-input", label: "Collapse the code behind a toggle" },
  { value: "remove-output", label: "Run it, but discard the output" },
  { value: "raises-exception", label: "Prevents exceptions from aborting the build" },
  { value: "remove-stderr", label: "Hide warnings (stderr)" },
  { value: "remove-stdout", label: "Hide printed text (stdout)" },
];

/** Kernels a language maps to, for the frontmatter `kernelspec` a markdown page needs before any of
 * its cells will run. Python is the one that matters; the others are a sensible starting point the
 * author can correct in the document, which is why this offers a value rather than refusing to guess. */
export const kernelspecs: Record<string, { name: string; display_name: string }> = {
  python: { name: "python3", display_name: "Python 3" },
  r: { name: "ir", display_name: "R" },
  julia: { name: "julia", display_name: "Julia" },
  javascript: { name: "javascript", display_name: "JavaScript" },
};

export const codeCellLanguages = Object.keys(kernelspecs);

export interface CodeCellSpec {
  language: string;
  /** Preset `value`, resolved to tags here. An unknown one contributes nothing. */
  preset?: string;
  /** Additional tags, from `codeCellExtraTags`. */
  extraTags?: string[];
  label?: string;
  caption?: string;
  linenos?: boolean;
  /** The cell's code. Usually whatever was selected when the button was pressed. */
  body?: string;
}

/** A directive fence has to be longer than the longest run of backticks inside it, or the body's own
 * fence closes it early - which matters here because a code cell's body is code, and a cell holding a
 * markdown example is exactly the case Jupyter Book's own docs write with four backticks. */
const fenceFor = (body: string): string => {
  const longest = [...body.matchAll(/`+/g)].reduce((max, [run]) => Math.max(max, run.length), 0);
  return "`".repeat(Math.max(3, longest + 1));
};

export interface BuiltCodeCell {
  /** The directive, with a leading and trailing newline so it lands as its own block. */
  text: string;
  /** Offset into `text` where the body starts, so the caller can leave the cursor in the code. */
  bodyOffset: number;
  /** Offset into `text` where the body ends - the end of a selection that was wrapped. */
  bodyEnd: number;
}

export function buildCodeCell(spec: CodeCellSpec): BuiltCodeCell {
  const body = (spec.body ?? "").replace(/^\n+|\n+$/g, "");
  const preset = codeCellPresets.find((p) => p.value === spec.preset);
  // Order follows Jupyter Book's own examples: label, caption, then tags. Deduplicated because a
  // preset and an extra tag can name the same thing, and a repeated tag is an error, not a no-op.
  const tags = [...new Set([...(preset?.tags ?? []), ...(spec.extraTags ?? [])])];

  const options = [
    spec.label?.trim() && `:label: ${spec.label.trim()}`,
    spec.caption?.trim() && `:caption: ${spec.caption.trim()}`,
    tags.length && `:tags: [${tags.join(", ")}]`,
    spec.linenos && ":linenos:",
  ].filter(Boolean) as string[];

  const fence = fenceFor(body);
  const lines = [`${fence}{code-cell} ${spec.language}`, ...options];
  // The blank line after the options block is required: without it the first line of code is read as
  // another option, and the build fails with `unexpected option ... provided`.
  if (options.length) lines.push("");

  const head = `\n${lines.join("\n")}\n`;
  return { text: `${head}${body}\n${fence}\n`, bodyOffset: head.length, bodyEnd: head.length + body.length };
}
