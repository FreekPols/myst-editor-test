import { css } from "styled-components";

/**
 * Styling for the Jupyter Book v2 constructs the mystmd parser path emits (see
 * src/markdown/jbHandlers.ts for the matching HTML).
 *
 * Kept separate from MdStyles because these rules exist purely to close the gap left by myst-to-html
 * not being a full renderer: in a real `myst build` this markup is styled by the `myst-theme` package,
 * which we can't use here (it is a React component library, not a stylesheet). These are hand-written
 * equivalents built from the editor's existing design tokens, so they follow the editor's theme rather
 * than importing Jupyter Book's palette wholesale.
 */
export const JupyterBookStyles = css`
  /* --- caption numbering ("Figure 1", "Table 2") from addContainerCaptionNumbers ------------- */
  figcaption .caption-number,
  .caption-number {
    font-weight: bold;
    margin-right: 0.4em;
  }

  /* --- tab-set: CSS-only tabs ----------------------------------------------------------------
     The handler emits input/label/panel triples. 'order: -1' pulls every label onto a single row
     above the panels, and the adjacent-sibling chain reveals the checked one. No JavaScript, so
     tab switching costs nothing at render time and survives re-renders of the preview. */
  .tab-set {
    display: flex;
    flex-wrap: wrap;
    margin-bottom: 16px;
  }
  .tab-input {
    position: absolute;
    opacity: 0;
    pointer-events: none;
  }
  .tab-label {
    order: -1;
    cursor: pointer;
    padding: 8px 14px;
    font-weight: bold;
    color: var(--gray-700);
    border-bottom: var(--border-2) solid var(--gray-400);
  }
  .tab-label:hover {
    color: var(--accent-dark);
  }
  .tab-input:checked + .tab-label {
    color: var(--accent-dark);
    border-bottom-color: var(--accent);
  }
  .tab-panel {
    display: none;
    width: 100%;
    padding-top: 12px;
  }
  .tab-input:checked + .tab-label + .tab-panel {
    display: block;
  }

  /* --- cards ---------------------------------------------------------------------------------
     Card framing, inherited from the styling the previous renderer used for the same construct. */
  .card {
    border: var(--border-2) solid var(--gray-400);
    border-radius: var(--border-radius);
    margin-bottom: 16px;
    overflow: hidden;
  }
  .card-title {
    background: var(--panel-bg);
    border-bottom: var(--border-2) solid var(--gray-400);
    font-weight: bold;
    padding: 8px 12px;
  }
  .card-header,
  .card-footer {
    background: var(--panel-bg);
    padding: 6px 12px;
    font-size: 0.9em;
    color: var(--gray-700);
  }
  .card-footer {
    border-top: var(--border-2) solid var(--gray-400);
  }
  .card > *:not(.card-title):not(.card-header):not(.card-footer) {
    margin-left: 12px;
    margin-right: 12px;
  }
  a.card-link {
    display: block;
    text-decoration: none;
    color: inherit;
  }
  a.card-link:hover {
    border-color: var(--accent);
  }

  /* --- grid ----------------------------------------------------------------------------------
     '--grid-columns' carries the author's declared column count from the directive. The actual
     track sizing uses auto-fit rather than that number because the preview is a resizable split
     pane, not the viewport - a viewport media query (which is what a column-count layout would
     need) would break the columns at the wrong width. */
  .grid {
    display: grid;
    gap: 16px;
    grid-template-columns: repeat(auto-fit, minmax(min(200px, 100%), 1fr));
    margin-bottom: 16px;
  }
  .grid > .card {
    margin-bottom: 0;
  }

  /* --- asides, margins, sidebars -------------------------------------------------------------- */
  aside.aside {
    border-left: var(--border-2) solid var(--gray-400);
    padding: 4px 0 4px 12px;
    margin-bottom: 16px;
    color: var(--gray-800);
    font-size: 0.95em;
  }
  aside.aside.sidebar,
  aside.aside.topic {
    border: var(--border-2) solid var(--gray-400);
    border-radius: var(--border-radius);
    padding: 12px;
  }

  /* --- dropdown ------------------------------------------------------------------------------- */
  details.dropdown {
    border: var(--border-2) solid var(--gray-400);
    border-radius: var(--border-radius);
    margin-bottom: 16px;
    overflow: hidden;
  }
  details.dropdown > summary.dropdown-title {
    background: var(--panel-bg);
    font-weight: bold;
    padding: 8px 12px;
    cursor: pointer;
  }
  details.dropdown > *:not(summary) {
    margin-left: 12px;
    margin-right: 12px;
  }

  /* --- exercises & proofs ----------------------------------------------------------------------
     These reuse .admonition (so they inherit the frame and header layout from MdStyles) and only
     override the accent colour, the way Jupyter Book distinguishes them. */
  :is(aside, details).admonition.exercise {
    border-color: var(--blue-500);
    & > header,
    & > summary {
      background-color: var(--header-blue);
    }
  }
  :is(aside, details).admonition.solution,
  :is(aside, details).admonition.proof {
    border-color: var(--brown-500);
    & > header,
    & > summary {
      background-color: var(--brown-500);
    }
  }

  /* --- admonition kinds --------------------------------------------------------------------------
     MdStyles only ever coloured note/warning/hint, so the other seven MyST kinds fell back to the
     generic green frame with no icon. Jupyter Book groups them by severity, which is what these do.
     The icons are inline SVG data URIs (white, to sit on the coloured header bar). */
  :is(aside, details).admonition.note,
  :is(aside, details).admonition.seealso {
    border-color: var(--accent);
    & > header,
    & > summary {
      background-color: var(--header-lightblue);
    }
  }

  :is(aside, details).admonition.important {
    border-color: var(--blue-500);
    & > header,
    & > summary {
      background-color: var(--header-blue);
    }
  }

  :is(aside, details).admonition.tip,
  :is(aside, details).admonition.hint {
    border-color: var(--green-500);
    & > header,
    & > summary {
      background-color: var(--header-green);
    }
  }

  :is(aside, details).admonition.attention,
  :is(aside, details).admonition.caution {
    border-color: var(--orange-500);
    & > header,
    & > summary {
      background-color: var(--header-orange);
    }
  }

  :is(aside, details).admonition.danger,
  :is(aside, details).admonition.error {
    border-color: var(--red-500);
    & > header,
    & > summary {
      background-color: var(--header-red);
    }
  }

  /* Severity icons for the kinds MdStyles never covered. */
  :is(aside, details).admonition.attention > :is(header, summary)::before,
  :is(aside, details).admonition.caution > :is(header, summary)::before {
    content: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 16 16'%3E%3Cpath d='M7.938 2.016a.13.13 0 0 1 .125 0 .15.15 0 0 1 .054.057l6.857 11.667c.036.06.035.124.002.183a.16.16 0 0 1-.054.06.12.12 0 0 1-.066.017H1.146a.12.12 0 0 1-.066-.017.16.16 0 0 1-.054-.06.18.18 0 0 1 .002-.183L7.884 2.073a.15.15 0 0 1 .054-.057zm1.044-.45a1.13 1.13 0 0 0-1.96 0L.165 13.233c-.457.778.091 1.767.98 1.767h13.713c.889 0 1.438-.99.98-1.767z' fill='white'%3E%3C/path%3E%3Cpath d='M7.002 12a1 1 0 1 1 2 0 1 1 0 0 1-2 0zM7.1 5.995a.905.905 0 1 1 1.8 0l-.35 3.507a.552.552 0 0 1-1.1 0z' fill='white'%3E%3C/path%3E%3C/svg%3E");
  }

  :is(aside, details).admonition.danger > :is(header, summary)::before,
  :is(aside, details).admonition.error > :is(header, summary)::before {
    content: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 16 16'%3E%3Cpath d='M4.54.146A.5.5 0 0 1 4.893 0h6.214a.5.5 0 0 1 .353.146l4.394 4.394a.5.5 0 0 1 .146.353v6.214a.5.5 0 0 1-.146.353l-4.394 4.394a.5.5 0 0 1-.353.146H4.893a.5.5 0 0 1-.353-.146L.146 11.46A.5.5 0 0 1 0 11.107V4.893a.5.5 0 0 1 .146-.353z' fill='white'%3E%3C/path%3E%3Cpath d='M8 4a.905.905 0 0 0-.9.995l.35 3.507a.552.552 0 0 0 1.1 0l.35-3.507A.905.905 0 0 0 8 4zm.002 6a1 1 0 1 0 0 2 1 1 0 0 0 0-2z' fill='%23e74a3c'%3E%3C/path%3E%3C/svg%3E");
  }

  :is(aside, details).admonition.seealso > :is(header, summary)::before {
    content: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 16 16'%3E%3Cpath d='M8 3C4.5 3 1.7 5.1.5 8c1.2 2.9 4 5 7.5 5s6.3-2.1 7.5-5c-1.2-2.9-4-5-7.5-5zm0 8.5A3.5 3.5 0 1 1 8 4.5a3.5 3.5 0 0 1 0 7zm0-5.5a2 2 0 1 0 0 4 2 2 0 0 0 0-4z' fill='white'%3E%3C/path%3E%3C/svg%3E");
  }

  /* --- cross-references ------------------------------------------------------------------------
     A reference inside a coloured admonition header has to stay legible: inherit the header's white
     rather than the page link colour, and never pick up the code background (which is what made
     "Solution to ex_fourier" render white-on-white). */
  .cross-reference {
    color: var(--accent-dark);
  }

  .admonition > :is(header, summary) .cross-reference {
    color: inherit;
    text-decoration: underline;
  }

  .admonition > :is(header, summary) code {
    background: transparent;
    color: inherit;
    padding: 0;
  }

  /* --- inline roles --------------------------------------------------------------------------- */
  .si-unit-error {
    border-bottom: 1px dotted var(--orange-500);
  }

  .inline-expression {
    border: 1px dashed var(--gray-500);
  }

  /* An unhandled MyST node. Visible but not alarming - it marks what still needs a handler. */
  .myst-unhandled {
    border-bottom: 1px dotted var(--gray-700);
  }

  /* --- equation numbers ------------------------------------------------------------------------
     Jupyter Book puts the number on the right of the equation, linking to it. */
  .math-block {
    margin: 1.15em 0;
  }

  .math-block.numbered {
    display: flex;
    align-items: center;
    gap: 1em;

    .math-display {
      flex: 1;
      margin: 0;
      overflow-x: auto;
    }
  }

  .equation-number {
    flex: none;
    color: inherit;
    text-decoration: none;
  }

  /* --- glossary ------------------------------------------------------------------------------- */
  .glossary dt {
    font-weight: bold;
  }

  /* --- embedded iframes (see iframeHast.ts) ---------------------------------------------------- */
  .iframe {
    margin-bottom: 16px;
  }

  /* A src that cannot be embedded is reported rather than rendered, since a relative one would load
     the editor inside itself. */
  .iframe-invalid {
    border: var(--border-2) dashed var(--orange-500);
    border-radius: var(--border-radius);
    padding: 8px 12px;
    font-size: 0.9em;

    p {
      margin: 0;
    }
  }

  /* --- Jupyter Book typography -------------------------------------------------------------------
     This block is last in the cascade on purpose: it restates the handful of type rules that differ
     from the editor's original look, so the whole pass can be tuned or reverted in one place rather
     than unpicked from MdStyles. */
  font-family: var(--font-body);
  font-size: var(--font-size-body);
  line-height: var(--line-height-body);

  /* The rendered document sits in a reading column rather than filling the pane edge to edge. */
  html-chunk > .block,
  html-chunk > *:not(.block) {
    max-width: var(--measure);
    margin-inline: auto;
  }

  p {
    line-height: var(--line-height-body);
    margin: 0 0 1.15em;
  }

  a {
    text-decoration: none;

    &:hover {
      text-decoration: underline;
    }
  }

  h1,
  h2,
  h3,
  h4,
  h5,
  h6 {
    font-weight: 650;
    line-height: 1.25;
    /* Generous space above, tight below, so a heading binds to the text it introduces. */
    margin: 1.8em 0 0.6em;
  }
  /* No leading gap for the first heading in the document. */
  html-chunk .block > :is(h1, h2, h3, h4, h5, h6):first-child {
    margin-top: 0;
  }
  h1 {
    font-size: 2em;
  }
  h2 {
    font-size: 1.6em;
  }
  h3 {
    font-size: 1.3em;
  }
  h4 {
    font-size: 1.15em;
  }
  h5 {
    font-size: 1.05em;
  }
  h6 {
    font-size: 1em;
    color: var(--gray-800);
  }

  code,
  pre,
  kbd,
  samp {
    font-family: var(--font-mono);
  }
  code {
    font-size: 0.875em;
  }
  pre {
    line-height: 1.5;
    overflow-x: auto;
  }

  li {
    line-height: var(--line-height-body);
    margin-bottom: 0.3em;
  }
  ul,
  ol {
    padding-left: 1.6em;
  }

  blockquote {
    border-left: 4px solid var(--gray-500);
    color: var(--gray-800);
    padding: 0.2em 0 0.2em 1em;
    margin: 0 0 1.15em;
  }

  /* Horizontal rules only, the way Jupyter Book renders tables - the boxed grid with a dark header bar
     is heavy next to the rest of the page. */
  table {
    border-collapse: collapse;
    width: 100%;
    font-size: 0.95em;
  }
  th,
  td {
    padding: 0.5em 0.75em;
    border: 0;
    border-bottom: 1px solid var(--gray-500);
  }
  th {
    background: none;
    color: inherit;
    border-top: 0;
    border-bottom: 2px solid var(--gray-800);
    font-weight: 650;

    &:first-of-type,
    &:last-of-type {
      border-radius: 0;
      border-left: 0;
      border-right: 0;
    }
  }
  td:first-of-type {
    border-left: 0;
  }
  table:not(:has(thead)) > tbody > tr:first-of-type > td {
    border-top: 0;
  }
`;
