import styled from "styled-components";

export const MystCSSVars = styled.div`
  --gray-900: #333;
  --gray-800: #5c5c5c;
  /* Secondary text (hints, captions, tab labels): #88818c was 3.8:1 on white. */
  --gray-700: #6b6570;
  --gray-600: #cccccc;
  --gray-500: #dadada;
  --gray-400: #e5e5e5;
  --gray-300: #e8e6e8;
  --gray-200: #f8f8f8;
  --gray-100: #f9f9f9;
  --blue-600: #0064ad;
  --blue-500: #0083e1;
  --blue-200: #82cfe6;
  --blue-100: #c1e4ef;
  --red-500: #e74a3c;
  --red-400: #fae6e6;
  --orange-500: #f59e0b;
  --green-500: #00af91;
  --green-400: #00ccaa;
  --green-300: #ecfce6;
  --brown-500: #940;

  --accent: var(--blue-200);
  --accent-light: var(--blue-100);
  /* Text-coloured blue: links, the current page, the title. #0083e1 measured 3.7:1 on the toolbar grey
     and 4.0:1 on white, under the 4.5:1 that WCAG AA asks of text; this is 5.8:1 and 6.1:1. */
  --accent-dark: var(--blue-600);
  /* The keyboard focus ring. One colour everywhere, so it reads as the same signal on every control. */
  --focus-ring: var(--blue-600);
  --primary-bg: var(--blue-600);
  --primary-bg-hover: #00548f;
  --primary-fg: white;
  --selected-bg: var(--accent);
  --statusbar-bg: #eef1f4;
  --statusbar-border: #dde2e7;
  --statusbar-fg: #3c4650;
  /* Unsaved work: the orange from the COMBINE mark, so it reads as "attention" without reading as an error. */
  --unsaved: #eb721c;
  --sidebar-border: #e4e4e4;
  /* Which logo variant shows: brand images are rendered in both variants and the theme picks one. */
  --logo-light-display: block;
  --logo-dark-display: none;

  /* Typography shared by the preview and the editor pane, so a document looks the same on both sides
     and close to how Jupyter Book renders it on the web. */
  --font-body:
    ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", sans-serif, "Apple Color Emoji",
    "Segoe UI Emoji";
  --font-mono: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
  --font-size-body: 16px;
  --line-height-body: 1.7;
  /* Jupyter Book constrains the article column; long lines are hard to read at full pane width. */
  --measure: 72ch;

  --border-2: 3px;
  --border-radius: 5px;
  --border: var(--gray-600);

  --navbar-bg: var(--gray-200);
  --button-bg: white;
  --button-bg-hover: var(--gray-400);
  --modal-bg: white;
  --switch-bg: var(--gray-500);
  --switch-active-bg: var(--blue-500);
  --panel-bg: white;
  --box-shadow: var(--gray-600);
  --icon-invert: 0;
  --string-fg: var(--brown-500);
  --deleted-bg: var(--red-400);
  --inserted-bg: var(--green-300);

  --editor-bg: var(--gray-200);
  --editor-gutter-fg: var(--gray-800);
  --editor-selection-bg: rgb(215, 212, 240);
  --editor-active-line-bg: #cceeff44;
  --editor-sync-flash-bg: #ffd54f77;
  --error-bg: var(--red-500);
  /* Error text, e.g. under a form field: 6.5:1 on white. */
  --error-fg: #b3261e;
  /* Admonition header bars carry white text, so they are a shade deeper than the frame around them:
     the frame colours themselves are 1.7-3.9:1 against white, below what a title needs. Each of these is
     at least 4.9:1. */
  --header-lightblue: #1d6f8f;
  --header-blue: var(--blue-600);
  --header-green: #00796b;
  --header-orange: #b45309;
  --header-red: #c0392b;
  --header-gray: #6b6570;

  /* Read out, not shown: context a sighted reader gets from layout, such as what a coloured dot means. */
  .visually-hidden {
    position: absolute;
    width: 1px;
    height: 1px;
    overflow: hidden;
    clip-path: inset(50%);
    white-space: nowrap;
  }

  & :focus-visible:not(.cm-content) {
    outline: 2px solid var(--focus-ring);
    outline-offset: 2px;
  }
`;

export const MystContainer = styled(MystCSSVars)`
  all: initial;
  font-family: "Lato", sans-serif;
  height: 100%;

  @media print {
    @page {
      margin: 1.5cm !important;
    }
  }

  .todo {
    background-color: yellow;
  }

  .file-link {
    color: var(--accent-dark);

    &:hover {
      cursor: pointer;
      text-decoration: underline;
    }
  }

  button,
  input,
  dialog,
  textarea {
    color: inherit;
  }

  ins {
    background: var(--inserted-bg);
  }

  del {
    background: var(--deleted-bg);
  }
`;

export const darkTheme = new CSSStyleSheet();
darkTheme.replaceSync(`
  #myst-css-namespace {
    color: white;
    --navbar-bg: #1a1a1a;
    --border: #878787;
    --button-bg: #333;
    --button-bg-hover: #5c5c5c;
    --switch-bg: #5c5c5c;
    --modal-bg: #1a1a1a;
    --panel-bg: #1a1a1a;
    --box-shadow: #333;
    --icon-invert: 1;
    --string-fg: #ffa657;

    --accent: #0083e1;
    --accent-light: #82cfe6;
    --accent-dark: rgb(121, 192, 255);
    --focus-ring: #6cb8ff;
    --primary-bg: #2d6ea3;
    --primary-bg-hover: #255d8c;
    /* White text on the selected view mode; the shared accent (#0083e1) only reaches 3.9:1. */
    --selected-bg: #1f6fb2;
    --statusbar-bg: #141414;
    --statusbar-border: #2c2c2c;
    --statusbar-fg: #c9c9c9;
    --sidebar-border: #333;
    /* The muted grey is for secondary text; #5c5c5c on this background is 2.6:1, too faint to read. */
    --gray-800: #a3a3a3;
    --gray-700: #a39ca8;
    --logo-light-display: none;
    --logo-dark-display: block;

    --editor-bg: #2a2a2a;
    --editor-gutter-fg: #ddd;
    --editor-selection-bg: #d7d4f020;
    --editor-active-line-bg: #cceeff10;
    --editor-sync-flash-bg: #ffd54f40;
    --error-bg: #f5766e;
    --error-fg: #ff8a80;
    --deleted-bg: #e74a3cb2;
    --inserted-bg: #00af91b2;
    
    color-scheme: dark;
  }
`);
