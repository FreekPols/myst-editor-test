import { render } from "preact";
import { useEffect, useRef, useMemo, useContext } from "preact/hooks";
import { StyleSheetManager, styled } from "styled-components";
import CodeMirror from "./components/CodeMirror";
import Preview, { PreviewFocusHighlight } from "./components/Preview";
import Diff from "./components/Diff";
import { EditorTopbar } from "./components/Topbar";
import { StatusBar } from "./components/StatusBar";
import ResolvedComments from "./components/Resolved";
import {
  handlePreviewClickToScroll,
  resolvePreviewFragmentLink,
  scrollEditorToElement,
  scrollPreviewToElement,
  suppressPreviewSync,
} from "./extensions/syncDualPane";
import { createMystState, MystState, predefinedButtons, defaultButtons, collabOnlyButtonIds } from "./mystState";
import { batch, computed, signal, effect, useSignal, useSignalEffect } from "@preact/signals";
import { MystContainer } from "./styles/MystStyles";
import { syncCheckboxes } from "./markdown/checkboxes";
import { buildCodeCell, codeCellExtraTags, codeCellLanguages, codeCellPresets, kernelspecs } from "./markdown/codeCell";
import { addFrontmatterKey, frontmatterKeyState } from "./markdown/frontmatter";
import { TableOfContents } from "./components/TableOfContents";
import ErrorModal from "./components/ErrorModal";
import FormDialog from "./components/FormDialog";
import { emptyImageValue, imageToUpload } from "./components/ImageField";
import ErrorBoundary from "./components/ErrorBoundary";
import { createLogger, Logger } from "./logger";

const EditorParent = styled.div`
  font-family: "Lato";
  display: flex;
  flex-flow: column;
  width: 100%;
  height: 100%;
  ${(props) => {
    switch (props.mode) {
      case "Preview":
        return "#editor-wrapper { display: none }";
      case "Source":
        return "#preview-wrapper { display: none }";
      case "Diff":
        return "#editor-wrapper { display: none }; #preview-wrapper { display: none }";
      case "Both":
        return "#resolved-wrapper { display: none }";
      case "Resolved":
        return "#preview-wrapper { display: none };";
      case "Outline":
        return "#preview-wrapper { display: none };";
      case "Inline":
        return "#preview-wrapper { display: none }";
      default:
        return ``;
    }
  }}

  /* Printing is preview-only and mode-independent: whatever the editor is showing on screen, the PDF is
   * the rendered document at full width. Without this the mode switch above leaks into the print layout
   * - "Both" prints the preview in its half-width column, and the source-only modes print nothing. */
  @media print {
    & {
      display: block !important;
      height: auto !important;
      position: static !important;
    }

    #editor-wrapper,
    #resolved-wrapper {
      display: none !important;
    }

    #preview-wrapper {
      display: block !important;
      width: 100% !important;
      height: auto !important;
    }
  }
`;

const MystWrapper = styled.div`
  padding: 20px;
  display: flex;
  box-sizing: border-box;
  flex: 1;
  min-height: 0;
  width: 100%;
  position: relative;
  background-color: var(--panel-bg);

  /* The on-screen editor is a fixed-height pane that scrolls; a printed page is not, so let the content
   * determine the height and flow across pages instead of clipping at one viewport. */
  @media print {
    & {
      display: block !important;
      height: auto !important;
      padding: 0 !important;
      background: none !important;
    }
  }
`;

const StatusBanner = styled.div`
  height: 40px;
  position: sticky;
  z-index: 10;
  width: 100%;
  top: 0;
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: var(--accent-light);
  font-weight: 600;
`;

/** CSS flexbox takes the content size of elements to determine the layout and ignores padding.
 * This wrapper is here to make sure the padding is added one element deeper and elements are equal width.
 * Ideally we would use CSS Grid but that has some performance issues with CodeMirror on Chromium. */
const FlexWrapper = styled.div`
  flex: 1;
  min-width: 0;
  height: 100%;

  & > * {
    min-height: 500px;
  }

  @media print {
    & {
      height: auto !important;
    }

    & > * {
      min-height: 0 !important;
    }
  }
`;

// Incrementing label for generated equations, so `{eq}` cross-references stay unique.
let equationCounter = 0;

/** Wrap the current selection (or the caret) with `before`/`after` markers and keep the inner text selected. */
const wrapSelection = (view, before, after) => {
  if (!view) return;

  const { from, to } = view.state.selection.main;

  if (from !== to) {
    const selectedText = view.state.doc.sliceString(from, to);
    view.dispatch({
      changes: { from, to, insert: `${before}${selectedText}${after}` },
      selection: { anchor: from + before.length, head: to + before.length },
    });
  } else {
    // No selection: insert the markers and place the caret between them.
    view.dispatch({
      changes: { from, insert: before + after },
      selection: { anchor: from + before.length },
    });
  }

  view.focus();
};

const MystEditor = () => {
  const mystState = useContext(MystState);
  const { editorView, cache, options, collab, text, suggestMode } = mystState;

  const preview = useRef(null);
  useEffect(() => {
    text.preview.value = preview.current;
  }, []);

  // `collaboration` can be swapped at runtime (MystEditorGit does it when changing rooms). If suggest
  // mode was on when collaboration went away its toggle disappears with it, so turn it off rather than
  // stranding the editor in a mode the user can no longer leave.
  useSignalEffect(() => {
    if (!options.collaboration.value.enabled) suggestMode.value = false;
  });

  useSignalEffect(() => {
    if (options.title.value) {
      document.title = options.title.value.replace(/\[([^\]]+)\]\([^)]+\)/g, "$1");
    }
  });

  // Toolbar dialogs. `ask` resolves with the field values, or null if the user cancelled, so an action
  // reads top-to-bottom instead of chaining window.prompt() calls.
  const dialogRequest = useSignal(null);
  const ask = (spec) => new Promise((resolve) => (dialogRequest.value = { ...spec, resolve }));

  const alert = useSignal(null);
  const alertFor = (alertText, secs) => {
    alert.value = alertText;
    setTimeout(() => (alert.value = null), secs * 1000);
  };

  /**
   * The figure dialog, from the toolbar or from an image pasted or dropped into the source (`prefill.file`).
   *
   * With `options.assets` the image can be a file from the computer: it is held until the next commit and
   * the figure points at where it will be saved. Without it, a figure takes a URL only.
   */
  async function insertFigure(prefill = {}) {
    const view = editorView.value;
    if (!view) return;
    const assets = options.assets.value;

    let values = assets && prefill.file ? { image: { ...emptyImageValue(), file: prefill.file } } : {};
    let message = null;
    for (;;) {
      const answers = await ask({
        title: "Insert a figure",
        message,
        messageIsError: !!message,
        fields: [
          assets
            ? { name: "image", label: "Image", type: "image", required: true, autoFocus: !prefill.file, assets, value: values.image }
            : { name: "url", label: "Image URL", placeholder: "image.jpg", required: true, autoFocus: true, value: values.url },
          {
            name: "alt",
            label: "Alt text",
            hint: "Describes the image for readers who cannot see it.",
            autoFocus: !!prefill.file,
            value: values.alt,
          },
          { name: "caption", label: "Caption", type: "textarea", value: values.caption },
          { name: "label", label: "Label", hint: "For cross-references, e.g. {numref}`my-figure`.", value: values.label },
          { name: "width", label: "Width", placeholder: "50% or 300px", value: values.width },
        ],
      });
      if (!answers) return;

      let url = answers.url;
      if (assets) {
        const image = answers.image;
        url = image.url?.trim();
        if (image.file) {
          const repoPath = assets.resolve(image.savePath.trim());
          let taken;
          try {
            taken = !repoPath || (await assets.exists(repoPath));
          } catch (err) {
            values = answers;
            message = `Could not check whether ${repoPath} is free: ${err?.message ?? err}. Try again.`;
            continue;
          }
          if (taken) {
            // Ask again rather than overwrite: an image already in the repository may be in use elsewhere.
            const free = repoPath ? await assets.suggestFreePath(repoPath) : null;
            values = { ...answers, image: { ...image, savePath: free ? assets.relative(free) : image.savePath } };
            message = repoPath
              ? `There is already a file at ${repoPath}. The name has been changed to ${free}; insert again to use it, or pick another.`
              : "Give the image a path to be saved at.";
            continue;
          }
          assets.stage(repoPath, imageToUpload(image));
          url = assets.relative(repoPath);
        }
      }

      const { alt: altText, caption, label, width } = answers;
      // Only emit options the user actually filled in - a blank `:width:` reaches the DOM as
      // width="" and a blank `:alt:` swallows whatever follows it as the alt text.
      const optionLines = [
        ["name", label],
        ["alt", altText],
        ["width", width],
      ]
        .filter(([, value]) => value.trim())
        .map(([key, value]) => `:${key}: ${value.trim()}`);

      // The caption is the directive BODY, not a `:caption:` option - as an option it is not
      // recognised and renders literally as ":caption: ...", including inside the alt attribute.
      const lines = [`\`\`\`{figure} ${url}`, ...optionLines];
      if (caption.trim()) {
        if (optionLines.length) lines.push("");
        lines.push(caption.trim());
      }
      lines.push("```");

      const insert = `\n${lines.join("\n")}\n`;
      const { from } = view.state.selection.main;
      view.dispatch({
        changes: { from, insert },
        selection: { anchor: from + insert.length },
      });
      view.focus();
      return;
    }
  }
  // Reachable from the source pane, which turns a pasted or dropped image into this dialog.
  mystState.insertFigure = insertFigure;

  const buttonActions = useMemo(
    () => ({
      "copy-html": async () => {
        await text.copy();
        alertFor("copied!", 2);
      },

      // The preview is only kept up to date in the modes that show it, so render the whole document
      // before handing over to the browser - otherwise printing from Source/Inline/Outline/Diff emits
      // whatever the preview happened to hold last, or nothing at all.
      "print-to-pdf": () => {
        text.renderText(true);
        window.print();
      },

      refresh: () => {
        cache.transform.clear();
        text.renderText();
        alertFor("Rich links refreshed!", 1);
        options.onRefresh.value?.();
      },

      "suggest-mode": () => (suggestMode.value = !suggestMode.peek()),

      bold: () => wrapSelection(editorView.value, "**", "**"),

      // `*` rather than `_`: CommonMark ignores intraword `_`, so italicising part of a word
      // (foo_bar_baz) would render the underscores literally.
      italic: () => wrapSelection(editorView.value, "*", "*"),

      equation: () => {
        const view = editorView.value;
        if (!view) return;

        const { from, to } = view.state.selection.main;
        const label = `eq_${++equationCounter}`;

        if (from !== to) {
          const selectedText = view.state.doc.sliceString(from, to);
          const insert = `\n$$ ${selectedText} $$ (${label})\n`;
          view.dispatch({
            changes: { from, to, insert },
            selection: { anchor: from + insert.length },
          });
        } else {
          // No selection: leave the cursor between the delimiters, ready to type.
          const head = "\n$$ ";
          const tail = ` $$ (${label})\n`;
          view.dispatch({
            changes: { from, insert: head + tail },
            selection: { anchor: from + head.length },
          });
        }

        view.focus();
      },

      symbol: () => wrapSelection(editorView.value, "$", "$"),

      figure: () => insertFigure(),

      table: () => {
        const view = editorView.value;
        if (!view) return;

        const { from } = view.state.selection.main;
        const insert = `\n| Header 1 | Header 2 |\n|----------|----------|\n| Cell 1   | Cell 2   |\n`;
        view.dispatch({
          changes: { from, insert },
          selection: { anchor: from + insert.length },
        });
        view.focus();
      },

      numlist: () => {
        const view = editorView.value;
        if (!view) return;

        const { from } = view.state.selection.main;
        const insert = `\n1. Item 1\n2. Item 2\n3. Item 3\n`;
        view.dispatch({
          changes: { from, insert },
          selection: { anchor: from + insert.length },
        });
        view.focus();
      },

      bulllist: () => {
        const view = editorView.value;
        if (!view) return;

        const { from } = view.state.selection.main;
        const insert = `\n- Item 1\n- Item 2\n- Item 3\n`;
        view.dispatch({
          changes: { from, insert },
          selection: { anchor: from + insert.length },
        });
        view.focus();
      },

      link: async () => {
        const view = editorView.value;
        if (!view) return;

        const { from, to } = view.state.selection.main;
        const selected = view.state.doc.sliceString(from, to);
        const answers = await ask({
          title: "Insert a link",
          fields: [
            { name: "url", label: "URL", placeholder: "https://example.com", required: true, autoFocus: true },
            { name: "text", label: "Link text", value: selected, hint: "Defaults to the selection, or the URL." },
          ],
        });
        if (!answers) return;
        const { url, text: answer } = answers;

        const insert = `[${answer.trim() || selected || url}](${url})`;
        view.dispatch({
          changes: { from, to, insert },
          selection: { anchor: from + insert.length },
        });
        view.focus();
      },

      highlight: () => {
        const view = editorView.value;
        if (!view) return;

        const { from, to } = view.state.selection.main;

        if (from !== to) {
          // Prefix every selected line with a blockquote marker.
          const selectedText = view.state.doc.sliceString(from, to);
          const quoted = selectedText
            .split("\n")
            .map((line) => `> ${line}`)
            .join("\n");
          view.dispatch({
            changes: { from, to, insert: quoted },
            selection: { anchor: from, head: from + quoted.length },
          });
        } else {
          view.dispatch({
            changes: { from, insert: "\n> " },
            // 3, not 2: the insert is "\n" + "> ", so the caret belongs after the marker's space.
            selection: { anchor: from + 3 },
          });
        }

        view.focus();
      },

      admonition: async () => {
        const view = editorView.value;
        if (!view) return;

        const answers = await ask({
          title: "Insert an admonition",
          fields: [
            {
              name: "type",
              label: "Type",
              type: "select",
              value: "note",
              autoFocus: true,
              options: ["note", "important", "hint", "tip", "seealso", "attention", "caution", "warning", "danger", "error"],
            },
            { name: "body", label: "Text", type: "textarea" },
          ],
        });
        if (!answers) return;
        const { type, body } = answers;

        const insert = `\n\`\`\`{${type}}\n${body}\n\`\`\`\n`;
        const { from } = view.state.selection.main;
        view.dispatch({
          changes: { from, insert },
          selection: { anchor: from + insert.length },
        });

        view.focus();
      },

      "code-cell": async () => {
        const view = editorView.value;
        if (!view) return;

        const { from, to } = view.state.selection.main;
        const selected = view.state.doc.sliceString(from, to);
        const doc = view.state.doc.toString();
        // A markdown page with no `kernelspec` cannot run its cells, and says so nowhere: the build
        // stays green and every figure on the page renders blank. So offer to add it here, where the
        // author is already thinking about the cell, rather than leaving them to find out later.
        // Only when it is genuinely absent - if the block does not parse we do not touch it.
        const needsKernelspec = frontmatterKeyState(doc, "kernelspec") === "missing";

        const answers = await ask({
          title: "Insert a code cell",
          fields: [
            { name: "preset", label: "What is the cell for?", type: "select", value: "figure", autoFocus: true, options: codeCellPresets },
            { name: "language", label: "Language", type: "select", value: "python", options: codeCellLanguages },
            { name: "label", label: "Label", hint: "Lets you show this output again elsewhere with ![](#label), and cross-reference it." },
            { name: "caption", label: "Caption" },
            { name: "tags", label: "Also", type: "multiselect", options: codeCellExtraTags },
            { name: "linenos", label: "Show line numbers", type: "checkbox" },
            ...(needsKernelspec
              ? [
                  {
                    name: "kernelspec",
                    label: "Add a kernel to this page",
                    type: "checkbox",
                    value: true,
                    hint: "This page has no kernelspec, so nothing here will run and every figure on it builds blank.",
                  },
                ]
              : []),
          ],
        });
        if (!answers) return;

        const {
          text: insert,
          bodyOffset,
          bodyEnd,
        } = buildCodeCell({
          language: answers.language,
          preset: answers.preset,
          extraTags: answers.tags,
          label: answers.label,
          caption: answers.caption,
          linenos: answers.linenos,
          body: selected,
        });

        const frontmatter = answers.kernelspec ? addFrontmatterKey(doc, "kernelspec", kernelspecs[answers.language] ?? kernelspecs.python) : null;
        // One transaction, so a single undo takes the cell and the frontmatter it needed back together.
        // Sorted because the two edits can land either way round - the cursor may sit above the closing
        // fence of an existing block - and CodeMirror wants its changes in document order.
        const changes = [...(frontmatter ? [frontmatter] : []), { from, to, insert }].sort((a, b) => a.from - b.from);
        // Only an edit that lands before the cell shifts where the cell ends up.
        const shift = frontmatter && frontmatter.from <= from ? frontmatter.insert.length : 0;

        view.dispatch({
          changes,
          // Leave the cursor in the code: at the end of a wrapped selection, or on the empty body line.
          selection: { anchor: from + shift + (selected ? bodyEnd : bodyOffset) },
        });
        view.focus();
      },

      youtube: async () => {
        const view = editorView.value;
        if (!view) return;

        const answers = await ask({
          title: "Embed a video",
          fields: [
            {
              name: "url",
              label: "Video URL",
              placeholder: "https://youtu.be/...",
              required: true,
              autoFocus: true,
              hint: "A normal watch or share link works; it is converted to an embed URL.",
            },
            { name: "caption", label: "Caption" },
          ],
        });
        if (!answers) return;
        const { url, caption } = answers;

        const insert = `
:::{iframe} ${url}
:width: 100%
${caption.trim() || "Insert a caption here!"}
:::
`;
        const { from } = view.state.selection.main;
        view.dispatch({
          changes: { from, insert },
          selection: { anchor: from + insert.length },
        });

        view.focus();
      },
    }),
    [],
  );

  const collabEnabled = options.collaboration.value.enabled;
  const buttons = useMemo(
    () =>
      options.includeButtons.value
        .filter((b) => collabEnabled || !collabOnlyButtonIds.has(b.id))
        .map((b) => ({
          ...b,
          action: b.action || buttonActions[b.id],
        })),
    [options.includeButtons.value, buttonActions, collabEnabled],
  );

  return (
    <StyleSheetManager target={options.parent}>
      <MystContainer id="myst-css-namespace">
        <ErrorModal />
        <FormDialog request={dialogRequest} />
        <ErrorBoundary>
          <EditorParent mode={options.mode.value}>
            {options.topbar.value && <EditorTopbar alert={alert} buttons={buttons} />}
            {options.collaboration.value.enabled && !collab.value?.ready?.value && (
              <StatusBanner>Connecting to the collaboration server ...</StatusBanner>
            )}
            {options.collaboration.value.enabled && collab.value?.lockMsg?.value && <StatusBanner>{collab.value.lockMsg}</StatusBanner>}
            <MystWrapper as="main" aria-label="Editor" className="myst-editor-wrapper">
              <FlexWrapper id="editor-wrapper" className="flex-wrapper">
                <CodeMirror />
              </FlexWrapper>
              <FlexWrapper id="preview-wrapper" className="flex-wrapper">
                <Preview
                  className="myst-preview"
                  ref={preview}
                  mode={options.mode.value}
                  onClick={(ev) => {
                    try {
                      if (options.onPreviewClick.value?.(ev)) return;

                      // Fragment links (footnote refs/backrefs, cross-references, heading anchors) cannot
                      // be followed by the browser because the editor lives in a shadow root, so scroll to
                      // the destination ourselves and sync the editor to *that* line rather than the link.
                      const fragmentTarget = resolvePreviewFragmentLink(ev, preview.current);
                      if (fragmentTarget) {
                        ev.preventDefault();
                        suppressPreviewSync(preview.current);
                        scrollPreviewToElement(fragmentTarget, preview.current);
                        if (options.syncScroll.value && options.mode.value == "Both") {
                          scrollEditorToElement(fragmentTarget, text.lineMap, editorView.value);
                        }
                        return;
                      }

                      syncCheckboxes(ev, editorView.value);

                      if (options.syncScroll.value && options.mode.value == "Both") {
                        handlePreviewClickToScroll(ev, text.lineMap, preview, editorView.value);
                      }
                    } catch (e) {
                      console.error("The following error occured while handling a click on the preview pane");
                      console.error(e);
                    }
                  }}
                >
                  <PreviewFocusHighlight className="cm-previewFocus" />
                </Preview>
              </FlexWrapper>
              {options.mode.value === "Diff" && (
                <FlexWrapper className="flex-wrapper">
                  <Diff />
                </FlexWrapper>
              )}
              {options.mode.value == "Resolved" &&
                options.collaboration.value.commentsEnabled &&
                options.collaboration.value.resolvingCommentsEnabled &&
                collab.value?.ready?.value && (
                  <FlexWrapper id="resolved-wrapper" className="flex-wrapper">
                    <ResolvedComments />
                  </FlexWrapper>
                )}
              {options.mode.value === "Outline" && (
                <FlexWrapper className="flex-wrapper">
                  <TableOfContents />
                </FlexWrapper>
              )}
            </MystWrapper>
            {options.statusBar.value && <StatusBar />}
          </EditorParent>
        </ErrorBoundary>
      </MystContainer>
    </StyleSheetManager>
  );
};

export default ({ additionalStyles, id, ...params }, /** @type {HTMLElement} */ target) => {
  if (!target.shadowRoot) {
    target.attachShadow({
      mode: "open",
    });
  }
  if (additionalStyles) {
    target.shadowRoot.adoptedStyleSheets = target.shadowRoot.adoptedStyleSheets.filter((s) => !additionalStyles.includes(s));
    target.shadowRoot.adoptedStyleSheets.push(...(Array.isArray(additionalStyles) ? additionalStyles : [additionalStyles]));
  }
  params.parent = target.shadowRoot;

  const editorId = id ?? crypto.randomUUID();
  if (!window.myst_editor) window.myst_editor = {};
  if (editorId in window.myst_editor) {
    throw `Editor with id ${editorId} is already on the page. Pick a different id, or leave it empty for a random one.`;
  }
  window.myst_editor[editorId] = {};

  const form = target.closest("form");
  if (form) {
    form.addEventListener("formdata", (e) => e.formData.append(params.name, window.myst_editor[editorId].text));
  }

  const state = createMystState({ id: editorId, ...params });
  window.myst_editor[editorId].state = state;
  const logger = createLogger(state);
  window.myst_editor[editorId].logger = logger;

  // cleanup function
  function remove() {
    state.cleanups.forEach((c) => c());
    delete window.myst_editor[editorId];
    render(null, target.shadowRoot);
  }
  window.myst_editor[editorId].remove = remove;
  // runs Preact cleanup logic when target is removed
  const observer = new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      if (Array.prototype.some.call(mutation.removedNodes, (n) => n == target)) {
        remove();
        observer.disconnect();
      }
    }
  });
  observer.observe(target.parentElement, { childList: true });

  render(
    <MystState.Provider value={state}>
      <Logger.Provider value={logger}>
        <MystEditor />
      </Logger.Provider>
    </MystState.Provider>,
    target.shadowRoot,
  );

  return state;
};

export { defaultButtons, predefinedButtons, batch, computed, signal, effect, MystEditor as MystEditorPreact };
export { default as MystEditorGit } from "./myst-git/MystEditorGit";
export { mountGitEditor } from "./myst-git/mountGitEditor";
export { CollaborationClient } from "./collaboration";
export { darkTheme } from "./styles/MystStyles";
/** The package version, injected at build time. Consumers can show it in their own topbar title. */
export const version = __MYST_EDITOR_VERSION__;
