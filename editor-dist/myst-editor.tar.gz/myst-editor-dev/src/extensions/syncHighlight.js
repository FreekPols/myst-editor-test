import { Decoration, EditorView } from "@codemirror/view";
import { StateEffect, StateField } from "@codemirror/state";

/** A brief mark on the source line the panes have just synced to.
 *
 * Clicking the preview moves the editor instantly, which is the fix it needed - but instant movement
 * leaves nothing to follow: the source pane simply is somewhere else now, and finding which line was
 * meant means reading until you recognise the text you clicked. The flash answers that without the
 * reader having to ask. */

/** Long enough to find with your eyes after both panes have moved, short enough that it is gone before
 * it starts reading as part of the document. */
const flashDuration = 1200;

const startFlash = StateEffect.define();
const endFlash = StateEffect.define();

const flashDeco = Decoration.line({ class: "cm-syncFlash" });

export const syncHighlight = StateField.define({
  create: () => Decoration.none,
  update(deco, tr) {
    for (const effect of tr.effects) {
      if (effect.is(endFlash)) return Decoration.none;
      if (effect.is(startFlash)) {
        const line = tr.state.doc.lineAt(Math.min(Math.max(effect.value, 0), tr.state.doc.length));
        return Decoration.set([flashDeco.range(line.from)]);
      }
    }
    // Dropped the moment the document changes underneath it: a mark that survives an edit is pointing
    // at a line that has since moved, which is worse than no mark at all.
    return tr.docChanged ? Decoration.none : deco;
  },
  provide: (field) => EditorView.decorations.from(field),
});

/** One timer per view, so a second click cancels the first click's cleanup instead of cutting its own
 * flash short. Weak because a view is replaced whenever the file or the mode changes. */
const pendingClear = new WeakMap();

/** Mark the line containing `pos`, and clear it again shortly afterwards.
 * A no-op in editors that do not carry the field - the effects simply go unread. */
export function flashSyncedLine(view, pos) {
  if (!view) return;
  clearTimeout(pendingClear.get(view));
  view.dispatch({ effects: startFlash.of(pos) });
  pendingClear.set(
    view,
    setTimeout(() => {
      pendingClear.delete(view);
      // The view may be gone by now - switching file, branch or mode rebuilds it - and dispatching
      // into a destroyed view throws.
      if (view.dom?.isConnected) view.dispatch({ effects: endFlash.of(null) });
    }, flashDuration),
  );
}
