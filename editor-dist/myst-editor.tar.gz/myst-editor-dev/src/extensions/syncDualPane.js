import { EditorView } from "codemirror";
import { markdownUpdatedEffect } from "../text";
import { findNearestElementForLine, getLineById } from "../markdown/markdownSourceMap";
import { EditorSelection } from "@codemirror/state";
import { flashSyncedLine } from "./syncHighlight";

const previewTopPadding = 20;
const debounceTimeout = 100;
/** This is the best way I can think of to check if the user caused the markdown to update.
 * If it takes longer than this to update the preview, we have bigger problems.
 */
const typedToUpdateThreshold = 500;
/** How long to leave the cursor->preview sync suppressed after a fragment link is followed. Generous
 * enough to cover the editor's smooth scroll, which emits updates the whole way. */
const fragmentNavSuppressMs = 1000;
/** Clicking in the preview drives the editor instantly, so its sync only has to stand down long enough
 * to cover syncPreviewWithCursor's own debounce plus the resulting scroll. */
const clickSyncSuppressMs = 300;
/** Stop re-aligning once a pass moves the editor less than this, and never run more than this many -
 * the estimates converge in two or three, and a cap means a pathological document cannot spin. */
const alignThresholdPx = 2;
const maxAlignPasses = 5;

/** When a fragment link is followed the *preview* is the pane being driven, so the cursor->preview sync
 * has to stand down: the editor also moves, and its update would otherwise scroll the preview straight
 * back off the destination. Time-based rather than a transaction annotation because the sync reacts to
 * geometry changes from the editor's smooth scroll too, not only to the selection dispatch. Keyed by
 * preview element so one editor cannot suppress another's sync when several share a page.
 * @type {WeakMap<HTMLElement, number>} */
const previewSyncSuppressedUntil = new WeakMap();
export function suppressPreviewSync(preview, ms = fragmentNavSuppressMs) {
  if (preview) previewSyncSuppressedUntil.set(preview, performance.now() + ms);
}

export const syncPreviewWithCursor = (text, preview, lastTyped) => {
  let timeout;

  return EditorView.updateListener.of((update) => {
    const cursorLineBefore = update.startState.doc.lineAt(update.startState.selection.main.head).number;
    const cursorLineAfter = update.state.doc.lineAt(update.state.selection.main.head).number;
    const selectionChanged = update.selectionSet && (cursorLineBefore !== cursorLineAfter || cursorLineBefore === 1);
    const timeSinceLastTyped = lastTyped.current === null ? typedToUpdateThreshold : performance.now() - lastTyped.current;
    const markdownUpdated =
      update.transactions.some((t) => t.effects.some((e) => e.is(markdownUpdatedEffect))) && timeSinceLastTyped < typedToUpdateThreshold;
    const resized = update.geometryChanged && !update.viewportChanged;
    if (update.docChanged || (!selectionChanged && !markdownUpdated && !resized)) {
      return;
    }

    function sync() {
      if (performance.now() < (previewSyncSuppressedUntil.get(preview) ?? 0)) return;
      const [matchingElem, matchingLine] = findNearestElementForLine(cursorLineAfter, text.lineMap, preview);
      if (matchingElem) {
        scrollPreviewElemIntoView({
          view: update.view,
          matchingLine,
          matchingElem,
          behavior: "smooth",
          preview,
        });
      }
    }

    clearTimeout(timeout);
    timeout = setTimeout(sync, debounceTimeout);
  });
};

/** @param {Object} param0
 * @param {EditorView} param0.view
 */
function scrollPreviewElemIntoView({ view, matchingLine, matchingElem, behavior = "auto", preview }) {
  const cursorBlock = view.lineBlockAt(view.state.doc.line(matchingLine).from);
  const previewRect = preview.getBoundingClientRect();
  const editor = view.dom.parentElement;
  let matchingRect = matchingElem.getBoundingClientRect();

  const elemScrollOffset = cursorBlock.top + previewTopPadding;

  const top = matchingRect.top + preview.scrollTop - elemScrollOffset - previewRect.top + (editor?.scrollTop ?? 0);
  preview.scrollTo({ top, behavior });
}

/**
 * @param {{ target: HTMLElement }} ev
 * @param {Map<number, string>} lineMap
 * @param {HTMLElement} preview
 * @param { EditorView } editor
 */
export function handlePreviewClickToScroll(ev, lineMap, preview, editor) {
  const match = sourceLineForElement(ev.target, lineMap);
  if (!match) return;
  const { lineNumber, elem } = match;

  const previewElem = preview?.current ?? preview;
  const line = editor.state.doc.line(lineNumber);

  // Move the cursor on the click itself. This used to wait for a smooth scroll to finish, and for a
  // line outside CodeMirror's rendered viewport it waited for a *chain* of them: each pass could only
  // work from estimated line heights, so it scrolled, waited for scrollend, and measured again. A
  // click near the bottom of a document took the better part of two seconds to do anything visible,
  // which reads as a dead click - so people clicked a second time.
  //
  // The preview is the pane being driven here, so the cursor -> preview sync has to stand down for a
  // moment; without this it would see the new selection and scroll the preview away from the very
  // element that was clicked. Just longer than that sync's own debounce.
  suppressPreviewSync(previewElem, clickSyncSuppressMs);
  editor.dispatch({
    selection: EditorSelection.cursor(line.to),
    effects: EditorView.scrollIntoView(line.from, { y: "start" }),
  });

  // Both panes have now moved at once. Mark where the editor landed, so the line that was meant can be
  // picked out without reading for the text that was clicked.
  flashSyncedLine(editor, line.from);

  alignEditorWithElement(elem, previewElem, line, editor);
}

/** Scroll the editor so `line` sits level with `elem` in the preview.
 *
 * CodeMirror only knows the real height of lines it has rendered; everything else is an estimate, so
 * one pass lands close rather than exactly. Rendering the region corrects the estimate, so we re-read
 * and adjust until the correction is negligible. That is what the previous implementation was doing
 * too, but it animated each pass and waited for `scrollend` between them - roughly a second per click.
 * These passes are instant and one animation frame apart, so the whole correction is invisible. */
function alignEditorWithElement(elem, preview, line, editor, pass = 0) {
  editor.requestMeasure({
    read: () => ({
      lineTop: editor.lineBlockAt(line.from).top,
      elemTop: elem.getBoundingClientRect().top,
      previewTop: preview.getBoundingClientRect().top,
    }),
    write: ({ lineTop, elemTop, previewTop }) => {
      const editorParent = editor.dom.parentElement;
      if (!editorParent) return;
      const top = lineTop - elemTop + previewTop + previewTopPadding;
      const correction = Math.abs(editorParent.scrollTop - top);
      editorParent.scrollTo({ top, behavior: "instant" });
      if (correction > alignThresholdPx && pass + 1 < maxAlignPasses) {
        requestAnimationFrame(() => alignEditorWithElement(elem, preview, line, editor, pass + 1));
      }
    },
  });
}

/** Resolve a preview element to its source line, falling back to the nearest mapped element before it
 * (directive-generated nodes carry no position of their own).
 *
 * `searchInside` additionally consults the element's own descendants first. Link destinations are often
 * wrappers that carry no line id themselves - a footnote definition is an <li> whose id lives on the <p>
 * inside it - and for those the content within is the right answer. Click handling leaves this off so
 * that clicking a container keeps its existing "nearest preceding element" behaviour.
 * @returns {{ lineNumber: number, elem: HTMLElement } | null} */
function sourceLineForElement(startElem, lineMap, { searchInside = false } = {}) {
  let id = startElem?.getAttribute?.("data-line-id");
  let elem = startElem;
  if (!id && searchInside) {
    const inner = startElem?.querySelector?.("[data-line-id]");
    if (inner) {
      id = inner.getAttribute("data-line-id");
      elem = inner;
    }
  }
  if (!id) {
    // check parents and siblings
    while (elem && elem.tagName !== "HTML-CHUNK") {
      const parent = elem.parentElement;
      [id, elem] = findSoruceMappedPreviousElement(elem);
      if (id) break;
      elem = parent;
    }
  }
  if (!id) return null;

  const lineNumber = getLineById(lineMap, id);
  return lineNumber ? { lineNumber, elem } : null;
}

/** Jump the editor straight to the source line of `elem`, for following a fragment link.
 *
 * Deliberately does NOT align the line against the preview element's on-screen rect, the way a click
 * does. During fragment navigation the preview is still mid smooth-scroll, so that rect is stale: the
 * editor would land at an intermediate position and only correct itself once the preview settled,
 * which reads as a jarring double jump. */
export function scrollEditorToElement(elem, lineMap, editor) {
  const match = sourceLineForElement(elem, lineMap, { searchInside: true });
  if (!match) return;

  const pos = editor.state.doc.line(match.lineNumber).from;
  editor.dispatch({
    selection: EditorSelection.cursor(pos),
    effects: EditorView.scrollIntoView(pos, { y: "start" }),
  });
  flashSyncedLine(editor, pos);
}

/** Resolve an in-preview fragment link (href="#id") to the element it points at.
 *
 * The editor renders inside a shadow root (see MystEditor.jsx), and the HTML "scroll to fragment"
 * algorithm resolves ids against the *document* tree only - shadow trees are invisible to it. So these
 * clicks update location.hash but scroll nothing: footnote references and their backrefs, {ref}/{numref}
 * cross-references and heading anchors are all affected, under either parser. We resolve them by hand.
 *
 * @param {{ target: HTMLElement }} ev
 * @param {HTMLElement} preview
 * @returns {HTMLElement | null} the destination element, or null if this was not an in-preview link.
 */
export function resolvePreviewFragmentLink(ev, preview) {
  const anchor = ev.target?.closest?.("a[href]");
  const href = anchor?.getAttribute("href");
  if (!href?.startsWith("#") || href.length < 2) return null;

  let id = href.slice(1);
  try {
    id = decodeURIComponent(id);
  } catch {
    // Malformed percent-encoding: fall back to the raw fragment.
  }
  // Scoped to the preview (not the whole shadow root) so a link can never scroll to editor chrome.
  return preview?.querySelector(`[id="${CSS.escape(id)}"]`) ?? null;
}

/** Scroll `preview` so that `elem` sits at the top of the pane, mirroring native anchor behaviour.
 *
 * Instant rather than smooth, unlike the cursor sync elsewhere in this file: the editor half of a
 * fragment jump uses CodeMirror's scrollIntoView, which cannot be animated without scrolling to a
 * position CodeMirror only *estimates* for lines outside the rendered viewport. Keeping both panes
 * instant makes them land together, and matches what a native anchor does. */
export function scrollPreviewToElement(elem, preview, behavior = "instant") {
  const top = elem.getBoundingClientRect().top - preview.getBoundingClientRect().top + preview.scrollTop - previewTopPadding;
  preview.scrollTo({ top, behavior });
}

export function findSoruceMappedPreviousElement(startingElem) {
  let elem = startingElem;
  while (elem != null) {
    const id = elem.getAttribute("data-line-id");
    if (id) return [id, elem];
    elem = elem.previousElementSibling;
  }

  return [undefined, elem];
}
