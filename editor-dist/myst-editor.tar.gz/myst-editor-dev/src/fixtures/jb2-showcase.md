---
title: Jupyter Book 2 syntax showcase
subtitle: Every construct the editor should render
authors:
  - name: COMBINE
abbreviations:
  MyST: Markedly Structured Text
  JB2: Jupyter Book 2
math:
  \nn: \mathbb{N}
  \RR: \mathbb{R}
---

# Jupyter Book 2 syntax showcase

This document exercises every MyST construct Jupyter Book 2 supports, so a change to the
render pipeline can be checked by eye. Anything that renders wrongly is a bug worth filing —
some sections are known to be incomplete and say so.

(sec-inline)=

## Inline formatting

**Bold**, *italic*, ***bold italic***, `inline code`, and a plain
[external link](https://mystmd.org). GitHub-style `~~strikethrough~~` is deliberately absent: it is
not MyST, and Jupyter Book leaves it as literal text too — use the {del}`del` role below.

Roles: {sub}`subscript`, {sup}`superscript`, {smallcaps}`small caps`, {u}`underline`,
{del}`deleted`, {kbd}`Ctrl-C`, {abbr}`HTML (HyperText Markup Language)`, and the
chemical formula {chem}`H2O`. A unit: {si}`299792458 <\metre\per\second>`, and a deliberately
malformed one: {si}`4 kg m2 s-2`.

An inline expression (needs a running kernel, so the editor shows the source): {eval}`2 + 2`.

Roles accept inline options: {span #my-span .highlight}`a span with a label and class`.

An abbreviation defined in frontmatter: MyST and JB2 should both gain a tooltip.

Escapes and specials: \*not italic\*, a backslash line break at the end of this line \
and the continuation.

## Headings and targets

A target above a heading:

(sec-targets)=

### A labelled subsection

Reference it with {ref}`sec-targets`, or with custom text: {ref}`this text <sec-targets>`.

## Directive options

The three ways to pass options to a directive all mean the same thing.

```{note}
:class: dropdown

Key/value pairs, the common form.
```

```{note}
---
class: dropdown
---

A YAML block, easier when there are many options.
```

```{note .dropdown #note-inline}
Inline options: a class and a label on the directive line itself.
```

Nesting needs more backticks on the outer directive:

`````{important}
````{note}
```{tip}
Three levels deep.
```
````
`````

## Cross-references and external references

Internal: {ref}`sec-targets`, {numref}`fig-myst`, {eq}`eq-taylor`, {doc}`this document <sec-inline>`,
{term}`mdast`.

A markdown link to a label: [](#sec-targets). A download: {download}`the source <./jb2-showcase.md>`.

## Lists

- Bullet one
- Bullet two
  - Nested bullet
    - Deeper still

1. Ordered one
2. Ordered two
   1. Nested ordered

Task list:

- [ ] Unchecked item
- [x] Checked item

Definition list:

Term one
: The definition of term one.

Term two
: The definition of term two.

## Blockquotes

> A plain blockquote.
> Spanning two lines.

> An epigraph-style quote.
>
> -- Someone Notable

## Code

```python
def greet(name: str) -> str:
    """A docstring."""
    return f"Hello, {name}"
```

```{code} javascript
:caption: A code directive with a caption
:linenos:

const x = 1;
```

Notebook-style executable cells:

```{code-cell} python
:tags: [hide-input]
:linenos:

import math
print(math.pi)
```

## Math

Inline math: $E = mc^2$, and a role form {math}`a^2 + b^2 = c^2`.

Display math:

$$
\int_{0}^{\infty} e^{-x^2} \, \mathrm{d}x = \frac{\sqrt{\pi}}{2}
$$

A labelled equation:

$$
f(x) = \sum_{n=0}^{\infty} \frac{f^{(n)}(0)}{n!} x^n
$$ (eq-taylor)

Referenced with {eq}`eq-taylor`.

Multi-line environments (these must not be wrapped in a `pre`):

$$
\begin{aligned}
  \nabla \cdot \mathbf{E} &= \frac{\rho}{\varepsilon_0} \\
  \nabla \cdot \mathbf{B} &= 0
\end{aligned}
$$

$$
\begin{array}{lcl}
  a & = & b \\
    & = & c
\end{array}
$$

Frontmatter macros (`\nn` and `\RR` are defined above): $x \in \nn$ and $y \in \RR$.

An AMS environment outside dollars:

\begin{equation}
  a^2 + b^2 = c^2
\end{equation}

## Tables

| Left | Centre | Right |
| :--- | :----: | ----: |
| a    |   b    |     c |
| d    |   e    |     f |

```{list-table} A list-table with a caption
:header-rows: 1
:name: tbl-list

* - Column A
  - Column B
* - Value 1
  - Value 2
```

```{csv-table} A csv-table
:header: "Name", "Value"

"alpha", 1
"beta", 2
```

Referenced with {numref}`tbl-list`.

## Figures and images

```{image} data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAxMjAgNjAiPjxyZWN0IHdpZHRoPSIxMjAiIGhlaWdodD0iNjAiIGZpbGw9IiMwMDgzZTEiLz48dGV4dCB4PSI2MCIgeT0iMzYiIGZvbnQtZmFtaWx5PSJzYW5zLXNlcmlmIiBmb250LXNpemU9IjE4IiBmaWxsPSJ3aGl0ZSIgdGV4dC1hbmNob3I9Im1pZGRsZSI+TXlTVDwvdGV4dD48L3N2Zz4=
:alt: A bare image
:width: 120px
```

```{figure} data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAxMjAgNjAiPjxyZWN0IHdpZHRoPSIxMjAiIGhlaWdodD0iNjAiIGZpbGw9IiMwMDgzZTEiLz48dGV4dCB4PSI2MCIgeT0iMzYiIGZvbnQtZmFtaWx5PSJzYW5zLXNlcmlmIiBmb250LXNpemU9IjE4IiBmaWxsPSJ3aGl0ZSIgdGV4dC1hbmNob3I9Im1pZGRsZSI+TXlTVDwvdGV4dD48L3N2Zz4=
:name: fig-myst
:alt: The MyST logo
:width: 200px
:align: center

A figure with a caption. Referenced as {numref}`fig-myst`.
```

## Admonitions

Every kind, so colours and icons can be compared side by side.

```{note}
A note.
```

```{important}
Something important.
```

```{hint}
A hint.
```

```{tip}
A tip.
```

```{seealso}
See also somewhere else.
```

```{attention}
Pay attention.
```

```{caution}
Be cautious.
```

```{warning}
A warning.
```

```{danger}
Danger.
```

```{error}
An error.
```

```{admonition} A custom title
A generic admonition with its own title.
```

```{admonition} A collapsible admonition
:class: dropdown

Hidden until the reader opens it.
```

```{note}
An admonition containing **markdown**, a list:

- one
- two

and nested math $a=b$.
```

## Dropdown

```{dropdown} A dropdown directive
Its body is hidden until opened.
```

## Cards, grids and tabs

```{card} A card title
Card body text.

+++
A card footer.
```

````{grid} 1 1 2 2
```{card} Grid item one
First.
```
```{card} Grid item two
Second.
```
````

````{tab-set}
```{tab-item} First tab
Content of the first tab.
```
```{tab-item} Second tab
Content of the second tab.
```
````

## Exercises and proofs

```{exercise} Compute a Fourier transform
:label: ex-fourier

Show that $\mathcal{F}\{e^{-\pi x^2}\} = e^{-\pi f^2}$.
```

```{solution} ex-fourier
:class: dropdown

The Gaussian is its own transform. Referenced back to {ref}`ex-fourier`.
```

```{prf:theorem} Pythagoras
:label: thm-pythagoras

For a right triangle, $a^2 + b^2 = c^2$.
```

```{prf:proof}
Left as an exercise. See {ref}`thm-pythagoras`.
```

## Asides and margins

```{aside}
An aside, rendered in the margin by Jupyter Book.
```

```{margin} A margin note
Margin content.
```

## Footnotes and citations

A sentence with a footnote.[^note1]

[^note1]: The footnote body, with *markdown*.

A citation reference: [@doe2020] and an inline one @doe2020.

## Glossary

```{glossary}
mdast
: The Markdown abstract syntax tree MyST parses into.

hast
: The HTML abstract syntax tree MyST renders to.
```

Referenced with {term}`mdast`.

## Diagrams

```{mermaid}
graph LR
  A[Parse] --> B[Transform]
  B --> C[Render]
```

## Embeds

```{iframe} https://www.youtube.com/watch?v=dQw4w9WgXcQ
:width: 60%

An embedded video.
```

An embed with a bad src, which must NOT frame the editor:

```{iframe} not-a-url
Should report an error instead.
```

## Raw HTML and blocks

<div class="raw-html-block">
  <strong>Raw HTML</strong> passed through the sanitizer.
</div>

+++ {"key": "value"}

A block after a block break.

## Comments and substitutions

% This is a MyST comment and should not render.

## Known gaps

These are expected to render imperfectly today; they are here so improvements are visible.

`{myst:directive}` and `{myst:role}` are not core MyST roles — they exist only on mystmd's own
documentation site — so both pipelines show them as unhandled: {myst:directive}`note`.

A `{code-cell}` produces an empty output node and `{toc}` needs a project, so both are inert here.

```{include} ./nonexistent.md
```

```{bibliography}
```

```{toc}
```
