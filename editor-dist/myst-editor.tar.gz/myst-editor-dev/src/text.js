import { effect, signal } from "@preact/signals";
import purify from "dompurify";
import { StateEffect } from "@codemirror/state";
import { renderMyst } from "./markdown/mystRenderer";
import { buildConsumerExtensions } from "./markdown/transformsAdapter";
import { renderMermaidIn } from "./markdown/mermaidDom";

export const markdownUpdatedEffect = StateEffect.define();

/** Quiet period after the last keystroke before the preview re-renders. Comfortably below
 * syncDualPane's 500ms typedToUpdateThreshold, so scroll sync still attributes the update to typing. */
const RENDER_DEBOUNCE_MS = 100;

/** This class stores the document text and renders the Markdown in the Preview */
export class TextManager {
  constructor({ initialText, editorView, cache, options, userSettings }) {
    this.text = signal(initialText.peek());
    this.lineMap = new Map();
    this.chunks = [];
    this.editorView = editorView;
    this.preview = signal(null);
    this.options = options;
    this.cache = cache;
    this.userSettings = userSettings;
    this.renderTimeout = null;
    this.lastRenderInputs = null;
    effect(() => {
      // A signal effect only re-subscribes to what it reads SYNCHRONOUSLY, so every render input has to
      // be touched here even though renderText() reads them again - deferring the reads into the
      // debounced callback would silently stop the preview updating.
      const inputs = {
        text: this.text.value,
        mode: this.options.mode.value,
        parser: this.options.parser?.value,
        transforms: this.options.transforms.value,
        customRoles: this.options.customRoles.value,
        customDirectives: this.options.customDirectives.value,
        preview: this.preview.value,
        editorView: this.editorView.value,
        mapUrl: this.options.mapUrl.value,
        userSettings: this.userSettings.value,
        mermaidTheme: this.options.mermaidTheme.value,
        backslashLineBreak: this.options.backslashLineBreak.value,
        collaboration: this.options.collaboration.value,
      };
      this.scheduleRender(inputs);
    });
    effect(() => (window.myst_editor[options.id.value].text = this.text.value));
    effect(() => this.observePreview());
  }

  /** Coalesce renders triggered by typing.
   *
   * The mystmd path renders the whole document on every call (cross-references and numbering need full
   * document context, so it cannot use the per-chunk cache), which is far too expensive to run on each
   * keystroke. Only typing is debounced: switching mode or parser, changing settings, or the preview
   * first mounting all render immediately, since delaying those reads as a broken UI. */
  scheduleRender(inputs) {
    const previous = this.lastRenderInputs;
    this.lastRenderInputs = inputs;
    const onlyTextChanged =
      previous != null && inputs.text !== previous.text && Object.keys(inputs).every((key) => key === "text" || inputs[key] === previous[key]);

    clearTimeout(this.renderTimeout);
    if (!onlyTextChanged) {
      this.renderTimeout = null;
      this.renderText();
      return;
    }
    this.renderTimeout = setTimeout(() => {
      this.renderTimeout = null;
      this.renderText();
    }, RENDER_DEBOUNCE_MS);
  }

  renderText(force = false) {
    // Any explicit render (copy(), the refresh button) supersedes a pending debounced one.
    clearTimeout(this.renderTimeout);
    this.renderTimeout = null;

    const previewVisible = ["Both", "Preview"].includes(this.options.mode.value) || force;
    if (!this.preview.value || !this.editorView.value || !previewVisible) {
      this.lastMode = this.options.mode.value;
      return;
    }

    this.renderWholeDoc();
    this.lastMode = this.options.mode.value;
  }

  /** Render the whole document via the mystmd pipeline, then sanitize and mount. Rebuilds
   * `this.lineMap` on every call (whole-doc, no incremental cache) so scroll-sync/comment consumers keep
   * the same data-line-id contract. A single html-chunk wrapper keeps copy() and the preview DOM shape. */
  renderWholeDoc() {
    const { roles, directives, transformsPlugin } = buildConsumerExtensions({
      transforms: this.options.transforms.value,
      customRoles: this.options.customRoles.value,
      customDirectives: this.options.customDirectives.value,
      previewNode: this.options.parent,
      cache: this.cache.transform,
    });
    const { html, error } = renderMyst(this.text.value, {
      lineMap: this.lineMap,
      roles,
      directives,
      transformsPlugin,
      backslashLineBreak: this.options.backslashLineBreak.value,
      // Suggestions are a collaboration feature: with no server behind them there is nothing to accept
      // or reject, so CriticMarkup stays literal text (as Jupyter Book renders it).
      criticMarkup: this.options.collaboration.value.enabled,
      links: {
        mapUrl: this.options.mapUrl.value,
        openLinksInNewTab: this.userSettings.value.some((s) => s.id === "links-new-tab" && s.enabled),
      },
    });
    if (error) console.error("[mystmd] preview render error:", error);
    const sanitized = sanitize(html);
    const toRemove = [...this.preview.value.childNodes].filter((c) => !c.classList || !c.classList.contains("cm-previewFocus"));
    toRemove.forEach((c) => this.preview.value.removeChild(c));
    this.preview.value.insertAdjacentHTML("beforeend", `<html-chunk id="html-chunk-0">${sanitized}</html-chunk>`);
    // Keep a single pseudo-chunk so copy() and any chunk consumers still function.
    this.chunks = [{ text: this.text.value, hash: 0, id: 0, html: sanitized }];
    renderMermaidIn(this.preview.value, this.options.mermaidTheme.value);
  }

  observePreview() {
    if (!this.preview.value) return;
    const imageObserver = new ResizeObserver(() => {
      // https://developer.mozilla.org/en-US/docs/Web/API/ResizeObserver#observation_errors
      // Using this without requestAnimationFrame caused some observation errors while rendering
      requestAnimationFrame(() => this.editorView.value.dispatch({ effects: markdownUpdatedEffect.of(true) }));
    });
    const observer = new MutationObserver(() => {
      this.editorView.value.dispatch({ effects: markdownUpdatedEffect.of(true) });
      this.preview.value.querySelectorAll("img").forEach((i) => imageObserver.observe(i));
    });
    observer.observe(this.preview.value, { childList: true, subtree: true });

    return () => {
      imageObserver.disconnect();
      observer.disconnect();
    };
  }

  shiftLineMap(update) {
    if (update.startState.doc.lines === update.state.doc.lines) return;
    let shiftStart = 0;
    let shiftAmount = 0;
    update.changes.iterChangedRanges((fromA, toA, fromB, toB) => {
      const startLine = update.startState.doc.lineAt(fromA).number;
      const endLine = update.startState.doc.lineAt(toA).number;
      const startLineB = update.state.doc.lineAt(fromB).number;
      const endLineB = update.state.doc.lineAt(toB).number;

      shiftStart = endLine;
      if (startLine === endLine) {
        shiftAmount = endLineB - startLineB;
      } else {
        shiftAmount = -(endLine - startLine);
      }
    });

    const newMap = new Map(this.lineMap);
    for (const [line, id] of this.lineMap.entries()) {
      if (line < shiftStart) continue;
      if (id === newMap.get(line)) {
        newMap.delete(line);
      }
      newMap.set(line + shiftAmount, id);
    }
    this.lineMap = newMap;
  }

  async copy() {
    this.renderText(true);
    const html = this.chunks.map((c) => c.html).join("\n");
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, "text/html");
    doc.querySelectorAll("[data-line-id]").forEach((n) => n.removeAttribute("data-line-id"));
    // This removes spans added for source mapping purposes.
    doc.querySelectorAll("span").forEach((n) => {
      if (n.attributes.length === 0) {
        n.insertAdjacentHTML("afterend", n.innerHTML);
        n.remove();
      }
    });
    doc.querySelectorAll("[data-remove]").forEach((n) => n.remove());
    // `div.block` is mystmd's whole-document structure; it means nothing once the HTML is pasted
    // elsewhere, so unwrap it and leave the content at the top level.
    doc.querySelectorAll("div.block").forEach((n) => {
      n.insertAdjacentHTML("afterend", n.innerHTML);
      n.remove();
    });
    const sanitized = doc.body.innerHTML;

    await navigator.clipboard.write([
      new ClipboardItem({
        "text/plain": new Blob([sanitized], { type: "text/plain" }),
        "text/html": new Blob([sanitized], { type: "text/html" }),
      }),
    ]);
  }
}

// `iframe` is allowed (the {iframe} directive and hand-written embeds depend on it), which means a
// document can frame arbitrary third-party content. Sandbox every iframe so that content cannot navigate
// the top-level page - the main phishing vector - while still permitting what video and notebook embeds
// actually need. `allow-same-origin` here means same-origin *to the embedded site*, not to this app.
let sandboxHookAdded = false;
const IFRAME_SANDBOX = "allow-scripts allow-same-origin allow-popups allow-forms allow-presentation allow-downloads";

function addIframeSandboxHook() {
  if (sandboxHookAdded) return;
  purify.addHook("afterSanitizeAttributes", (node) => {
    if (node.tagName === "IFRAME") node.setAttribute("sandbox", IFRAME_SANDBOX);
  });
  sandboxHookAdded = true;
}

export function sanitize(unsafeHTML) {
  addIframeSandboxHook();
  return purify.sanitize(unsafeHTML, {
    // Taken from Mermaid JS settings: https://github.com/mermaid-js/mermaid/blob/dd0304387e85fc57a9ebb666f89ef788c012c2c5/packages/mermaid/src/mermaidAPI.ts#L50
    // `semantics`/`annotation` are not in DOMPurify's default MathML allowlist: without them it strips
    // the wrapper KaTeX emits but keeps the raw-TeX text, so the source leaks next to the rendered math.
    ADD_TAGS: ["foreignobject", "iframe", "semantics", "annotation", "annotation-xml"],
    ADD_ATTR: ["dominant-baseline", "target", "encoding", "allowfullscreen", "sandbox"],
  });
}
