# [Issue Title]

## Overview

A concise description of the issue, task, or proposal.

## Type of Issue

<!-- Choose one option and describe: Bug | Feature | Performance | Refactoring | Documentation | Question / Other -->

[Selected Type: e.g. Feature] - [Brief description of the issue type]

## Details & Context

Explain the current situation, requirements, or problem that needs to be addressed. Include references to related issues or merge requests if applicable.

## Expected Outcome / Acceptance Criteria

Describe the desired end state or criteria that define when this issue is resolved.

- Criteria 1: [Description]
- Criteria 2: [Description]

## Relevant Links / Logs / Screenshots

- Links:
- Logs or error traces:
- Screenshots:
