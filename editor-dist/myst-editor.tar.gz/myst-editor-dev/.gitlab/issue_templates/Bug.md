# [Bug: Brief summary of the bug]

## Overview

A clear and concise description of what the bug is.

## Current Behavior

What actually happened? Include error messages or unexpected output.

## Expected Behavior

What should have happened instead?

## Steps to Reproduce

1. Go to '...'
2. Perform action '...'
3. Observe error '...'

## Environment & Context

- OS: [e.g. macOS, Ubuntu, Windows]
- Browser / Client: [e.g. Chrome 120, Firefox 121, Safari]
- Commit / Version: [e.g. main, v1.3.1-dev]
- Node.js / npm version: [if applicable]

## Logs & Screenshots

<!-- Paste terminal output, browser console logs, or attach screenshots below -->

## Possible Solution / Workaround

[Optional: ideas on root cause or suggested fixes]
