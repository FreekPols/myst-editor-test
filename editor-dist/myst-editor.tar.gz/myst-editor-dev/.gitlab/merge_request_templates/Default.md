## Overview

<!-- Provide a concise 2-3 sentence summary: what does this MR accomplish and why? -->

## Type of Change

<!-- Choose one option and describe: Feature | Bug Fix | Refactor | Performance | Documentation | Chore | Breaking Change -->

[Selected Type: e.g. Feature] - [Brief description of the change type]

## Motivation & Context

<!-- Reminder: Reference relevant issue or ticket IDs, explain the driver for this change, and add closing statements if needed (e.g., Closes #12, Fixes #34). -->

## Key Changes

<!-- Bullet points highlighting the main changes across components/modules -->

- **Component / File**: Summary of change

## Impact & Breaking Changes

<!-- List any breaking changes, database migrations, environment variable updates, or API contract modifications. State "None" if not applicable. -->

None

## Testing

<!-- Describe how these changes were tested (automated test suites run, manual test scenarios, browser verification). Do not use checkboxes. -->

- **Automated Tests**: Unit tests (`npm run test:unit`), linting/formatting (`npm run lint`, `npm run check-format`), type checks (`npm run typecheck`)
- **Manual Verification**: Description of manual testing steps performed and verification results
