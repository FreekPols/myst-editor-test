# GitHub token relay

Lets the MyST editor sign people in to GitHub with one click, through a GitHub App. GitHub's token endpoint wants the app's client
secret and sends no CORS headers, so the editor page cannot finish the sign-in itself; this relay does that one step. It adds the
secret, passes GitHub's answer back, stores nothing, and answers only the editor pages you allow.

Without a relay the editor still works on GitHub: people sign in with a fine-grained personal access token instead (see "Running against
GitHub" in the main README).

## 1. Create the GitHub App

On GitHub: **Settings → Developer settings → GitHub Apps → New GitHub App** (under an organisation's settings for an organisation's
books). Creating and installing apps costs nothing.

- **Callback URL:** the editor page, exactly as it is served, e.g. `https://jdoe.github.io/thesis/editor/`. Several books can share an
  app: add each callback URL.
- **Expire user authorization tokens:** on. Tokens then last 8 hours and are refreshed through the relay.
- **Request user authorization (OAuth) during installation:** off. **Webhook:** off.
- **Repository permissions:** Contents **Read and write**, Pull requests **Read-only**, Metadata **Read-only** (required).
- **Where can this GitHub App be installed?** "Only on this account" is enough for your own books.

Then **Generate a new client secret**, and note the **Client ID**. Finally **Install App** on the book's repository, choosing **Only
select repositories**. The editor can then reach that repository, and nothing else, for people who themselves have write access to it.

## 2. Deploy the relay

With a (free) Cloudflare account, from this folder:

```bash
# edit wrangler.toml: GITHUB_CLIENT_ID, and ALLOWED_ORIGINS = the origin(s) of your editor pages
npx wrangler deploy
npx wrangler secret put GITHUB_CLIENT_SECRET
```

`ALLOWED_ORIGINS` is the scheme and host only, comma-separated, e.g. `https://jdoe.github.io`. `GITHUB_URL` points the relay at a GitHub
Enterprise Server instead of github.com.

`worker.js` is a standard `fetch` handler, so any platform that runs one (Deno Deploy, Netlify Edge Functions, a Node server with a small
adapter) works as well.

## 3. Point the editor at it

In the book's `editor/options.js`:

```js
mountGitEditor(document.getElementById("myst"), {
  backend: "github",
  githubRepo: "jdoe/thesis",
  clientId: "Iv23li...", // the app's Client ID
  tokenUrl: "https://myst-editor-github-relay.<your-subdomain>.workers.dev",
});
```

Tests: `tests/unit/githubTokenRelay.test.js` in this repository.
