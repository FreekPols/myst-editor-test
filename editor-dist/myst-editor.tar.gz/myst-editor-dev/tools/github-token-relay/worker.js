// Token relay for signing in to the MyST editor with a GitHub App.
//
// GitHub's token endpoint wants the app's client secret and sends no CORS headers, so a page in the
// browser cannot finish an OAuth sign-in by itself. This relay does that one step: it takes the code
// (or a refresh token) the editor got from GitHub, adds the secret, asks GitHub for the token and hands
// GitHub's answer back. It stores nothing and logs nothing.
//
// It answers only pages on ALLOWED_ORIGINS, and only for its own app. Deploy it as a Cloudflare Worker
// (see README.md), or run it anywhere that serves the standard fetch handler.
//
// Settings (Worker variables; the secret as a Worker secret):
//   GITHUB_CLIENT_ID      the GitHub App's client id
//   GITHUB_CLIENT_SECRET  the GitHub App's client secret
//   ALLOWED_ORIGINS       comma-separated origins of the editor pages, e.g. https://jdoe.github.io
//   GITHUB_URL            optional, a GitHub Enterprise Server's address (default https://github.com)

const FORWARDED = {
  authorization_code: ["code", "redirect_uri", "code_verifier"],
  refresh_token: ["refresh_token"],
};

export default {
  async fetch(request, env) {
    const origin = request.headers.get("Origin") ?? "";
    const allowed = (env.ALLOWED_ORIGINS ?? "")
      .split(",")
      .map((o) => o.trim().replace(/\/+$/, ""))
      .filter(Boolean);
    if (!allowed.includes(origin)) return new Response("This page may not use this relay.", { status: 403 });
    const cors = {
      "Access-Control-Allow-Origin": origin,
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Accept",
      Vary: "Origin",
    };
    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: cors });
    if (request.method !== "POST") return new Response("Only POST.", { status: 405, headers: cors });

    const form = new URLSearchParams(await request.text());
    const grant = form.get("grant_type");
    const fields = FORWARDED[grant];
    if (!fields) return reply({ error: "unsupported_grant_type" }, 400, cors);
    // A page cannot borrow this relay's secret for another app.
    if (form.get("client_id") && form.get("client_id") !== env.GITHUB_CLIENT_ID) return reply({ error: "invalid_client" }, 400, cors);

    const body = new URLSearchParams({ client_id: env.GITHUB_CLIENT_ID, client_secret: env.GITHUB_CLIENT_SECRET, grant_type: grant });
    for (const field of fields) if (form.get(field)) body.set(field, form.get(field));
    const github = (env.GITHUB_URL ?? "https://github.com").replace(/\/+$/, "");
    const res = await fetch(`${github}/login/oauth/access_token`, {
      method: "POST",
      headers: { Accept: "application/json", "Content-Type": "application/x-www-form-urlencoded" },
      body,
    });
    return new Response(await res.text(), {
      status: res.status,
      headers: { ...cors, "Content-Type": "application/json", "Cache-Control": "no-store" },
    });
  },
};

function reply(json, status, cors) {
  return new Response(JSON.stringify(json), { status, headers: { ...cors, "Content-Type": "application/json" } });
}
