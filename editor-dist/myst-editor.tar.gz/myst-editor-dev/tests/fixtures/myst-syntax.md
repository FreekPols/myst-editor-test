# MyST syntax

Inline math $a^2 + b^2 = c^2$ and a force law $F = m \cdot a$.

$$\int_0^1 x^2 \, dx = \tfrac{1}{3}$$

:::{table} Some basic Markdown text formatting
:label: tl_basic_formatting
:align: center

| Element        | Syntax            | Example         |
| -------------- | ----------------- | --------------- |
| Bold           | `**bold text**`   | **Bold**        |
| Inline Formula | `$F = m \cdot a$` | $F = m \cdot a$ |
| :::            |

```{note}
This is a **note** with emphasis.
```

::::{card} Card title
Card body with _markdown_.
::::

:::{dropdown} More details
Hidden content with a $\sqrt{2}$ formula.
:::

:::{literalinclude} ../myst.yml
:start-after: toc
:end-at: - file: content/gallery.md
:lineno-match:
:caption: The Table of Contents (ToC) for this book.
:label: code_toc
:::
