# Parser comparison

This file targets the constructs where markdown-it-docutils and mystmd actually diverge.
Open it, select all, paste into both editor tabs, and compare the numbered/linked items.

(intro)=

## Introduction

Jump to a section: {ref}`intro`. Reference a figure: {numref}`fig-demo`.
Reference a table: {numref}`tbl-demo`. Reference an equation: {eq}`emc2`.

## Labeled figure

:::{figure} https://placehold.co/240x120
:label: fig-demo

A labeled figure with a caption.
:::

## Labeled math

$$ e = mc^2 $$ (emc2)

Einstein's equation is {eq}`emc2`.

## list-table with a name

:::{list-table} Fruit colors
:header-rows: 1
:name: tbl-demo

- - Fruit
  - Color
- - Apple
  - Red
- - Banana
  - Yellow
:::

## Admonition with a title and embedded markdown

:::{note} A titled note
Body with **bold**, _italic_, a [link](https://example.com), and inline math $a^2+b^2$.
:::

## Definition list

Term one
: Definition of the first term.

Term two
: Definition of the second term.
