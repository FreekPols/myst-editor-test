import { describe, it, expect, vi, beforeEach, afterEach } from "vite-plus/test";
import { render, h } from "preact";
import { signal } from "@preact/signals";
import GitPickerModal from "../../src/myst-git/GitPickerModal.jsx";

describe("GitPickerModal", () => {
  let container;

  beforeEach(() => {
    container = document.createElement("div");
    document.body.appendChild(container);
  });

  afterEach(() => {
    container.remove();
    container = null;
  });

  it("renders list of branches and highlights selected branch", () => {
    const open = signal(true);
    const options = signal([
      { label: "main", value: "main" },
      { label: "feature", value: "feature" },
    ]);

    render(
      h(GitPickerModal, {
        id: "git-branch-picker",
        title: "Switch or create branch",
        open,
        options,
        selectedValue: "main",
        onSelect: vi.fn(),
        searchPlaceholder: "Search or create branch...",
        searchOptions: vi.fn(async () => []),
      }),
      container,
    );

    const dialog = container.querySelector("#git-branch-picker");
    expect(dialog).not.toBeNull();
    expect(dialog.querySelector("h2").textContent).toBe("Switch or create branch");

    const items = container.querySelectorAll("li");
    expect(items.length).toBe(2);
    expect(items[0].textContent).toContain("main");
    expect(items[0].classList.contains("active")).toBe(true);
    expect(items[1].textContent).toContain("feature");
    expect(items[1].classList.contains("active")).toBe(false);
  });

  it("shows create branch option when searching for a non-existent branch", async () => {
    const open = signal(true);
    const options = signal([
      { label: "main", value: "main" },
      { label: "feature", value: "feature" },
    ]);
    const onCreate = vi.fn();

    render(
      h(GitPickerModal, {
        id: "git-branch-picker",
        title: "Switch or create branch",
        open,
        options,
        selectedValue: "main",
        currentBranch: "feature",
        onSelect: vi.fn(),
        onCreate,
        searchPlaceholder: "Search or create branch...",
        searchOptions: vi.fn(async () => []),
      }),
      container,
    );

    const input = container.querySelector("input");
    expect(input).not.toBeNull();

    input.value = "bugfix/123";
    input.dispatchEvent(new Event("input", { bubbles: true }));

    await new Promise((r) => setTimeout(r, 50));

    const createItem = container.querySelector(".create-branch-item");
    expect(createItem).not.toBeNull();
    expect(createItem.textContent).toContain("Create branch bugfix/123");
    expect(createItem.textContent).toContain("from feature");

    // Click the create item
    createItem.dispatchEvent(new MouseEvent("click", { bubbles: true }));
    expect(onCreate).toHaveBeenCalledWith("bugfix/123");
    expect(open.value).toBe(false);
  });

  it("triggers onCreate when Enter key is pressed and no exact match exists", async () => {
    const open = signal(true);
    const options = signal([
      { label: "main", value: "main" },
      { label: "feature", value: "feature" },
    ]);
    const onCreate = vi.fn();

    render(
      h(GitPickerModal, {
        id: "git-branch-picker",
        title: "Switch or create branch",
        open,
        options,
        selectedValue: "main",
        currentBranch: "main",
        onSelect: vi.fn(),
        onCreate,
        searchPlaceholder: "Search or create branch...",
        searchOptions: vi.fn(async () => []),
      }),
      container,
    );

    const input = container.querySelector("input");
    input.value = "new-branch";
    input.dispatchEvent(new Event("input", { bubbles: true }));

    await new Promise((r) => setTimeout(r, 50));

    input.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", bubbles: true }));
    // Nothing loaded matches, so the picker asks the backend before deciding the name is free.
    await new Promise((r) => setTimeout(r, 0));
    expect(onCreate).toHaveBeenCalledWith("new-branch");
    expect(open.value).toBe(false);
  });

  it("selects exact match on Enter instead of creating", async () => {
    const open = signal(true);
    const options = signal([
      { label: "main", value: "main" },
      { label: "feature", value: "feature" },
    ]);
    const onSelect = vi.fn();
    const onCreate = vi.fn();

    render(
      h(GitPickerModal, {
        id: "git-branch-picker",
        title: "Switch or create branch",
        open,
        options,
        selectedValue: "main",
        currentBranch: "main",
        onSelect,
        onCreate,
        searchPlaceholder: "Search or create branch...",
        searchOptions: vi.fn(async () => []),
      }),
      container,
    );

    const input = container.querySelector("input");
    input.value = "feature";
    input.dispatchEvent(new Event("input", { bubbles: true }));

    await new Promise((r) => setTimeout(r, 50));

    input.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", bubbles: true }));
    expect(onSelect).toHaveBeenCalledWith({ label: "feature", value: "feature" }, false);
    expect(onCreate).not.toHaveBeenCalled();
    expect(open.value).toBe(false);
  });

  it("shows create branch option initially and always, even with empty search query", () => {
    const open = signal(true);
    const options = signal([
      { label: "main", value: "main" },
      { label: "feature", value: "feature" },
    ]);
    const onCreate = vi.fn();

    render(
      h(GitPickerModal, {
        id: "git-branch-picker",
        title: "Switch or create branch",
        open,
        options,
        selectedValue: "main",
        currentBranch: "main",
        onSelect: vi.fn(),
        onCreate,
        searchPlaceholder: "Search or create branch...",
        searchOptions: vi.fn(async () => []),
      }),
      container,
    );

    const createItem = container.querySelector(".create-branch-item");
    expect(createItem).not.toBeNull();
    expect(createItem.textContent).toContain("Create new branch...");
    expect(createItem.textContent).toContain("from main");

    createItem.dispatchEvent(new MouseEvent("click", { bubbles: true }));
    expect(onCreate).toHaveBeenCalledWith("");
    expect(open.value).toBe(false);
  });

  it("opens the first match on Enter for a partly typed name, rather than creating a branch with that name", async () => {
    const open = signal(true);
    const options = signal([
      { label: "main", value: "main" },
      { label: "feature", value: "feature" },
    ]);
    const onSelect = vi.fn();
    const onCreate = vi.fn();
    const searchOptions = vi.fn(async () => [{ label: "feature", value: "feature" }]);

    render(
      h(GitPickerModal, { id: "git-branch-picker", title: "t", open, options, selectedValue: "main", onSelect, onCreate, searchOptions }),
      container,
    );

    const input = container.querySelector("input");
    input.value = "fea";
    input.dispatchEvent(new Event("input", { bubbles: true }));
    // Enter before the debounced search has answered: the loaded list is filtered instead.
    input.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", bubbles: true }));
    await new Promise((r) => setTimeout(r, 0));

    expect(onSelect).toHaveBeenCalledWith({ label: "feature", value: "feature" }, false);
    expect(onCreate).not.toHaveBeenCalled();
    expect(open.value).toBe(false);
  });

  it("does not create a branch that only the backend knows about", async () => {
    const open = signal(true);
    const options = signal([{ label: "main", value: "main" }]);
    const onSelect = vi.fn();
    const onCreate = vi.fn();
    const searchOptions = vi.fn(async () => [{ label: "old-release", value: "old-release" }]);

    render(
      h(GitPickerModal, { id: "git-branch-picker", title: "t", open, options, selectedValue: "main", onSelect, onCreate, searchOptions }),
      container,
    );

    const input = container.querySelector("input");
    input.value = "old-release";
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", bubbles: true }));
    await new Promise((r) => setTimeout(r, 0));

    expect(searchOptions).toHaveBeenCalledWith("old-release");
    expect(onSelect).toHaveBeenCalledWith({ label: "old-release", value: "old-release" }, true);
    expect(onCreate).not.toHaveBeenCalled();
  });

  it("shows options loaded while it is open, such as the next page after scrolling", async () => {
    const open = signal(true);
    const options = signal([{ label: "main", value: "main" }]);

    render(
      h(GitPickerModal, { id: "git-branch-picker", title: "t", open, options, selectedValue: "main", onSelect: vi.fn(), searchOptions: vi.fn() }),
      container,
    );
    expect(container.querySelectorAll("li").length).toBe(1);

    options.value = [...options.value, { label: "feature", value: "feature" }, { label: "release", value: "release" }];
    await new Promise((r) => setTimeout(r, 0));

    expect(container.querySelectorAll("li").length).toBe(3);
  });
});
