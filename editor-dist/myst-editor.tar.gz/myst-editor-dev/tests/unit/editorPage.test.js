import { describe, it, expect } from "vite-plus/test";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";

// src/index.html is not only the dev demo: it is the page that ships in the release tarball and gets
// served as <book>/editor/ by the mystmd editor plugin. So what its <head> contains is a deployment
// contract, not a detail of the demo.
const page = readFileSync(resolve(dirname(fileURLToPath(import.meta.url)), "../../src/index.html"), "utf8");

describe("the editor page", () => {
  it("takes its icon from the book it is served under", () => {
    // Relative, and exactly one level up: the editor sits at <book>/editor/, the book theme publishes
    // its icon at <book>/favicon.ico. An absolute "/favicon.ico" would reach past the book to the web
    // server's root, which is the bug this replaced - books are served from a path, not a domain.
    expect(page).toMatch(/<link rel="icon" href="\.\.\/favicon\.ico"\s*\/?>/);
  });
});
