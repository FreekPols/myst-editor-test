import { describe, it, expect } from "vite-plus/test";
import { parseTocYaml, parseToctree, tocExtends, TOC_CANDIDATES, isTocYaml } from "../../src/myst-git/toc.js";

const files = (text, prefix) => parseTocYaml(text, prefix).map((e) => e.file);

describe("myst.yml (Jupyter Book v2)", () => {
  const mystYml = `
version: 1
project:
  id: abc-123
  title: A book
  toc:
    - file: index.md
    - title: Part one
      children:
        - file: chapters/one.md
        - file: chapters/two.md
    - url: https://example.com
site:
  template: book-theme
`;

  it("reads project.toc, not any other 'file:' key in the document", () => {
    expect(files(mystYml)).toEqual(["index.md", "chapters/one.md", "chapters/two.md"]);
  });

  it("keeps nesting depth so the sidebar can indent", () => {
    expect(parseTocYaml(mystYml).map((e) => e.depth)).toEqual([0, 0, 0]);
  });

  it("nests under a file that has children", () => {
    const nested = "project:\n  toc:\n    - file: a.md\n      children:\n        - file: b.md\n";
    expect(parseTocYaml(nested).map((e) => [e.file, e.depth])).toEqual([
      ["a.md", 0],
      ["b.md", 1],
    ]);
  });

  it("prefixes with the docs root", () => {
    expect(files(mystYml, "docs/")).toEqual(["docs/index.md", "docs/chapters/one.md", "docs/chapters/two.md"]);
  });

  it("ignores url-only entries, which name no file to open", () => {
    expect(files(mystYml)).not.toContain(undefined);
  });
});

describe("_toc.yml (Jupyter Book v1)", () => {
  const jb1 = `
format: jb-book
root: intro
parts:
  - caption: Part one
    chapters:
      - file: markdown
      - file: notebooks
        sections:
          - file: deeper
`;

  it("reads root then parts/chapters/sections, adding the implied .md", () => {
    expect(files(jb1)).toEqual(["intro.md", "markdown.md", "notebooks.md", "deeper.md"]);
  });

  it("leaves an explicit extension alone", () => {
    expect(files("root: intro.ipynb")).toEqual(["intro.ipynb"]);
  });

  it("does not mistake a dotted directory for an extension", () => {
    expect(files("root: v1.2/intro")).toEqual(["v1.2/intro.md"]);
  });
});

describe("a bare list", () => {
  it("accepts plain strings and file entries", () => {
    expect(files("- a\n- file: b\n")).toEqual(["a.md", "b.md"]);
  });
});

describe("malformed input", () => {
  it("degrades to no entries rather than throwing", () => {
    for (const bad of ["", "::: not yaml :::", "just a string", "42", "project:\n  toc: not-a-list\n"]) {
      expect(parseTocYaml(bad)).toEqual([]);
    }
  });
});

describe("candidates", () => {
  it("prefers myst.yml, then Jupyter Book v1, then a hand-rolled name", () => {
    expect(TOC_CANDIDATES).toEqual(["myst.yml", "_toc.yml", "toc.yml"]);
  });

  it("recognises both yaml extensions", () => {
    expect(isTocYaml("myst.yml")).toBe(true);
    expect(isTocYaml("docs/toc.yaml")).toBe(true);
    expect(isTocYaml("docs/index.md")).toBe(false);
    expect(isTocYaml(null)).toBe(false);
  });
});

describe("a markdown index with a {toctree}", () => {
  const index = "# Docs\n\n```{toctree}\n:maxdepth: 2\nfile1\nfile2\n```\n\nWelcome.\n";

  it("lists the documents and skips directive options", () => {
    expect(parseToctree(index, "docs/").map((e) => e.file)).toEqual(["docs/file1.md", "docs/file2.md"]);
  });

  it("no longer doubles the extension when an entry already has one", () => {
    expect(parseToctree("```{toctree}\nfile1.md\n```").map((e) => e.file)).toEqual(["file1.md"]);
  });

  it("returns nothing when there is no toctree, or it is unterminated", () => {
    expect(parseToctree("# Just a page\n")).toEqual([]);
    expect(parseToctree("```{toctree}\nfile1\n")).toEqual([]);
  });
});

describe("a config that delegates its toc with extends", () => {
  // The shape the ap3122 book uses: myst.yml holds project metadata and points at toc.yml, with a
  // shared template alongside it. Parsed on its own it yields nothing, which is why extends matters.
  const mystYml = `
version: 1
project:
  id: ap3122-aoi-pilot
  title: Advanced Optical Imaging
extends:
  - toc.yml
  - https://gitlab.example/api/v4/projects/28934/packages/generic/template/template-v0.0.4/template.yml
site:
  template: book-theme
`;

  it("has no toc of its own", () => {
    expect(parseTocYaml(mystYml)).toEqual([]);
  });

  it("names the local file to follow, and drops the remote template", () => {
    expect(tocExtends(mystYml, "myst.yml")).toEqual(["toc.yml"]);
  });

  it("resolves relative to the directory of the file that named it", () => {
    expect(tocExtends("extends: toc.yml\n", "docs/myst.yml")).toEqual(["docs/toc.yml"]);
    expect(tocExtends("extends: ../shared/toc.yml\n", "docs/book/myst.yml")).toEqual(["docs/shared/toc.yml"]);
    expect(tocExtends("extends: ./toc.yml\n", "docs/myst.yml")).toEqual(["docs/toc.yml"]);
  });

  it("accepts a bare string as well as a list", () => {
    expect(tocExtends("extends: toc.yml\n")).toEqual(["toc.yml"]);
  });

  it("returns nothing for a config that extends nothing local", () => {
    expect(tocExtends("version: 1\n")).toEqual([]);
    expect(tocExtends("extends: https://example.com/template.yml\n")).toEqual([]);
    expect(tocExtends(":::not yaml:::")).toEqual([]);
  });
});
