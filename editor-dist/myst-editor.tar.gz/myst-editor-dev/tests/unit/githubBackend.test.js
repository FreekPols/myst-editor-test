import { describe, it, expect, vi } from "vite-plus/test";
import { createGitHubBackend, accessLevelFor, utf8ToBase64 } from "../../src/myst-git/githubBackend.js";

const jsonRes = (data) => ({ ok: true, status: 200, json: async () => data, text: async () => JSON.stringify(data) });
const textRes = (t) => ({
  ok: true,
  status: 200,
  text: async () => t,
  json: async () => JSON.parse(t),
  blob: async () => new Blob([t]),
  arrayBuffer: async () => new TextEncoder().encode(t).buffer,
});
const fail = (status) => Object.assign(new Error(`GitHub API ${status}`), { status });

const REPO = {
  id: 9,
  default_branch: "main",
  html_url: "https://github.com/jdoe/book",
  permissions: { admin: false, maintain: false, push: true, pull: true },
};
const SHA = "a".repeat(40);
const TIP = "b".repeat(40);

/**
 * A mock `authorizedFetch` covering the prefetch (the repository and branches page 1) that
 * `createGitHubBackend` always performs, delegating anything else to `extra`.
 */
function makeFetch(extra = () => null, repo = REPO) {
  return vi.fn(async (path, init) => {
    const e = await extra(path, init);
    if (e) return e;
    if (path === "repos/jdoe/book") return jsonRes(repo);
    if (path.startsWith("repos/jdoe/book/branches"))
      return jsonRes([
        { name: "dev", protected: false },
        { name: "main", protected: true },
      ]);
    throw fail(404);
  });
}

const make = (fetch, opts = {}) => createGitHubBackend({ repo: "jdoe/book", authorizedFetch: fetch, getBranch: () => "dev", ...opts });
const body = (fetch, fragment) => JSON.parse(fetch.mock.calls.find(([p]) => p.includes(fragment))[1].body);

describe("createGitHubBackend", () => {
  it("needs owner/name", async () => {
    await expect(createGitHubBackend({ repo: "book", authorizedFetch: vi.fn() })).rejects.toThrow(/owner\/name/);
  });

  it("puts the default branch first and describes itself as GitHub", async () => {
    const backend = await make(makeFetch());
    expect(backend.initialBranches).toEqual(["main", "dev"]);
    expect(backend.defaultBranch).toBe("main");
    expect(backend.serverName).toBe("GitHub");
    expect(backend.review.short).toBe("PR");
    expect(backend.newMergeRequestUrl({ sourceBranch: "jdoe/essay", targetBranch: "main" })).toBe(
      "https://github.com/jdoe/book/compare/main...jdoe/essay?expand=1",
    );
  });

  it("marks protected branches; whether this user may push to one stays unknown", async () => {
    const backend = await make(makeFetch());
    expect(backend.getBranchStatus("main")).toEqual({ protected: true, canPush: undefined });
    expect(backend.getBranchStatus("dev")).toEqual({ protected: false, canPush: true });
    const readOnly = await make(makeFetch(undefined, { ...REPO, permissions: { pull: true } }));
    expect(readOnly.getBranchStatus("dev")).toEqual({ protected: false, canPush: false });
  });
});

describe("reading", () => {
  it("searches branches by name through GraphQL", async () => {
    const fetch = makeFetch((path) =>
      path.endsWith("/graphql") ? jsonRes({ data: { repository: { refs: { nodes: [{ name: "jdoe-essay" }] } } } }) : null,
    );
    const backend = await make(fetch);
    expect(await backend.searchBranches("essay")).toEqual(["jdoe-essay"]);
    expect(body(fetch, "/graphql").variables).toMatchObject({ owner: "jdoe", name: "book", query: "essay" });
    // Branch protection is not asked for: GraphQL can refuse it to a token without administration rights,
    // which would fail the whole search.
    expect(body(fetch, "/graphql").query).not.toContain("branchProtectionRule");
  });

  it("reports GraphQL errors instead of returning nothing", async () => {
    const backend = await make(makeFetch((path) => (path.endsWith("/graphql") ? jsonRes({ errors: [{ message: "Bad credentials" }] }) : null)));
    await expect(backend.searchBranches("x")).rejects.toThrow("GitHub: Bad credentials");
  });

  it("lists commits with their full id and first line", async () => {
    const fetch = makeFetch((path) => (path.includes("/commits?") ? jsonRes([{ sha: SHA, commit: { message: "Fix typo\n\nlonger text" } }]) : null));
    const backend = await make(fetch);
    expect(await backend.getCommits("dev", 2)).toEqual([{ hash: SHA, message: "Fix typo" }]);
    expect(fetch.mock.calls.some(([p]) => p === "repos/jdoe/book/commits?sha=dev&per_page=20&page=2")).toBe(true);
  });

  it("lists the pages in a commit's tree in one request", async () => {
    const tree = {
      tree: [
        { type: "blob", path: "docs/a.md" },
        { type: "blob", path: "img/x.png" },
        { type: "tree", path: "docs" },
        { type: "blob", path: "b.rst" },
      ],
    };
    const backend = await make(makeFetch((path) => (path.includes("/git/trees/") ? jsonRes(tree) : null)));
    expect(await backend.getFiles("dev", { hash: SHA })).toEqual(["docs/a.md", "b.rst"]);
  });

  it("lists every file under a folder, and refuses a partial list", async () => {
    const tree = {
      tree: [
        { type: "blob", path: "docs/week1/index.md" },
        { type: "blob", path: "docs/week1/img/x.png" },
        { type: "tree", path: "docs/week1/img" },
        { type: "blob", path: "docs/week10/index.md" },
      ],
    };
    const backend = await make(makeFetch((path) => (path.includes("/git/trees/") ? jsonRes(tree) : null)));
    expect(await backend.listFiles({ hash: SHA }, "docs/week1")).toEqual(["docs/week1/index.md", "docs/week1/img/x.png"]);
    const truncated = await make(makeFetch((path) => (path.includes("/git/trees/") ? jsonRes({ ...tree, truncated: true }) : null)));
    await expect(truncated.listFiles({ hash: SHA }, "docs/week1")).rejects.toThrow(/too large/);
  });

  it("reads a file raw at a commit, and a missing one as empty", async () => {
    const fetch = makeFetch((path, init) => {
      if (path === `repos/jdoe/book/contents/docs/my%20page.md?ref=${SHA}`) {
        expect(init.headers.Accept).toBe("application/vnd.github.raw");
        return textRes("# Hello");
      }
      return null;
    });
    const backend = await make(fetch);
    expect(await backend.getText("dev", { hash: SHA }, "docs/my page.md")).toBe("# Hello");
    expect(await backend.getText("dev", { hash: SHA }, "docs/missing.md")).toBe("");
    expect(await backend.fileExists({ hash: SHA }, "docs/my page.md")).toBe(true);
    expect(await backend.fileExists({ hash: SHA }, "docs/missing.md")).toBe(false);
  });

  it("finds open pull requests from a branch", async () => {
    const pr = {
      id: 1,
      number: 12,
      title: "Essay",
      html_url: "https://github.com/jdoe/book/pull/12",
      head: { ref: "dev" },
      base: { ref: "main" },
      user: { login: "jdoe" },
    };
    const fetch = makeFetch((path) => (path.includes("/pulls?") ? jsonRes([pr]) : null));
    const backend = await make(fetch);
    expect(await backend.getOpenMergeRequests("dev")).toEqual([
      { id: 1, iid: 12, title: "Essay", webUrl: pr.html_url, sourceBranch: "dev", targetBranch: "main", state: "opened", author: "jdoe" },
    ]);
    expect(fetch.mock.calls.some(([p]) => p.includes("head=jdoe%3Adev"))).toBe(true);
  });

  it("says who is signed in, with their role on GitLab's scale, asking once", async () => {
    const fetch = makeFetch((path) => (path === "user" ? jsonRes({ id: 5, login: "jdoe", name: null }) : null));
    const backend = await make(fetch);
    expect(await backend.getCurrentUser()).toEqual({ id: 5, username: "jdoe", name: "jdoe", accessLevel: 30 });
    await backend.getCurrentUser();
    expect(fetch.mock.calls.filter(([p]) => p === "user")).toHaveLength(1);
  });
});

describe("writing", () => {
  const atTip = (extra = () => null) =>
    makeFetch((path, init) => {
      if (path === "repos/jdoe/book/git/ref/heads/dev") return jsonRes({ object: { sha: TIP } });
      if (path.endsWith("/graphql"))
        return jsonRes({ data: { createCommitOnBranch: { commit: { oid: SHA, url: `https://github.com/jdoe/book/commit/${SHA}` } } } });
      return extra(path, init);
    });

  it("commits pages and images together on top of the branch tip", async () => {
    const fetch = atTip();
    const backend = await make(fetch);
    const result = await backend.commitChanges(
      "Update essay\n\nWith a figure",
      [{ file: "docs/a.md", text: "é ✓" }],
      [{ path: "docs/x.png", base64: "iVBO" }],
    );
    expect(result).toEqual({ hash: SHA, webUrl: `https://github.com/jdoe/book/commit/${SHA}` });
    const { input } = body(fetch, "/graphql").variables;
    expect(input.branch).toEqual({ repositoryNameWithOwner: "jdoe/book", branchName: "dev" });
    expect(input.expectedHeadOid).toBe(TIP);
    expect(input.message).toEqual({ headline: "Update essay", body: "With a figure" });
    expect(input.fileChanges.additions).toEqual([
      { path: "docs/a.md", contents: utf8ToBase64("é ✓") },
      { path: "docs/x.png", contents: "iVBO" },
    ]);
  });

  it("commits page moves and deletes using additions and deletions", async () => {
    const fetch = atTip();
    const backend = await make(fetch);
    await backend.commitChanges("Move and delete", [
      { file: "docs/new-a.md", previous_path: "docs/old-a.md", action: "move", text: "moved content" },
      { file: "docs/remove.md", action: "delete" },
    ]);
    const { input } = body(fetch, "/graphql").variables;
    expect(input.fileChanges.deletions).toEqual([{ path: "docs/old-a.md" }, { path: "docs/remove.md" }]);
    expect(input.fileChanges.additions).toEqual([{ path: "docs/new-a.md", contents: utf8ToBase64("moved content") }]);
  });

  it("copies a file from the branch tip, byte for byte, when moving it without new text", async () => {
    const png = new Uint8Array([0x89, 0x50, 0x4e, 0x47, 0xff, 0x00, 0xd8]);
    const oldContent = (path) => {
      if (path === `repos/jdoe/book/contents/docs/old-a.md?ref=${TIP}`) return textRes("original text");
      if (path === `repos/jdoe/book/contents/docs/a/fig.png?ref=${TIP}`) return { ok: true, status: 200, arrayBuffer: async () => png.buffer };
      return null;
    };
    const fetch = atTip(oldContent);
    const backend = await make(fetch);
    await backend.commitChanges("Move only", [
      { file: "docs/new-a.md", previous_path: "docs/old-a.md", action: "move" },
      { file: "docs/b/fig.png", previous_path: "docs/a/fig.png", action: "move" },
    ]);
    const { input } = body(fetch, "/graphql").variables;
    expect(input.fileChanges.deletions).toEqual([{ path: "docs/old-a.md" }, { path: "docs/a/fig.png" }]);
    expect(input.fileChanges.additions).toEqual([
      { path: "docs/new-a.md", contents: utf8ToBase64("original text") },
      { path: "docs/b/fig.png", contents: btoa(String.fromCharCode(...png)) },
    ]);
  });

  it("refuses to move a file that is no longer on the branch", async () => {
    const backend = await make(atTip(() => null));
    await expect(backend.commitChanges("m", [{ file: "b/x.png", previous_path: "a/x.png", action: "move" }])).rejects.toThrow(
      /a\/x.png is no longer on dev/,
    );
  });

  it("will not replace an image already on the branch unless asked to", async () => {
    const exists = (path) => (path.startsWith(`repos/jdoe/book/contents/docs/x.png?ref=${TIP}`) ? textRes("") : null);
    const backend = await make(atTip(exists));
    await expect(backend.commitChanges("m", [], [{ path: "docs/x.png", base64: "iVBO" }])).rejects.toThrow(/docs\/x.png already exists on dev/);
    await expect(backend.commitChanges("m", [], [{ path: "docs/x.png", base64: "iVBO", replace: true }])).resolves.toMatchObject({ hash: SHA });
  });

  it("creates a branch from a branch or from a commit", async () => {
    const fetch = makeFetch((path, init) => {
      if (path === "repos/jdoe/book/git/ref/heads/main") return jsonRes({ object: { sha: TIP } });
      if (path === "repos/jdoe/book/git/ref/heads/abc1234") throw fail(404);
      if (path === "repos/jdoe/book/commits/abc1234") return jsonRes({ sha: SHA });
      if (path.startsWith("repos/jdoe/book/commits/")) return jsonRes({ commit: { message: "Start" } });
      if (path === "repos/jdoe/book/git/refs") return init.body.includes('"refs/heads/taken"') ? Promise.reject(fail(422)) : jsonRes({});
      return null;
    });
    const backend = await make(fetch);
    expect(await backend.createBranch("jdoe", "main")).toEqual({ name: "jdoe", commit: { hash: TIP, message: "Start" } });
    expect(body(fetch, "git/refs")).toEqual({ ref: "refs/heads/jdoe", sha: TIP });
    expect((await backend.createBranch("fix", "abc1234")).commit.hash).toBe(SHA);
    await expect(backend.createBranch("taken", "main")).rejects.toThrow("Branch 'taken' already exists");
  });
});

describe("helpers", () => {
  it("maps GitHub roles onto GitLab's access levels", () => {
    expect(accessLevelFor({ admin: true, push: true })).toBe(50);
    expect(accessLevelFor({ maintain: true })).toBe(40);
    expect(accessLevelFor({ push: true, pull: true })).toBe(30);
    expect(accessLevelFor({ pull: true })).toBe(10);
    expect(accessLevelFor(undefined)).toBe(0);
  });

  it("encodes UTF-8 text as base64, long pages included", () => {
    expect(atob(utf8ToBase64("é"))).toBe("Ã©");
    const long = "x".repeat(200_000);
    expect(atob(utf8ToBase64(long))).toBe(long);
  });
});
