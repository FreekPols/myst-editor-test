import { describe, it, expect, beforeEach } from "vite-plus/test";
import { createStubGitBackend } from "../../src/myst-git/stubGitBackend.js";

beforeEach(() => {
  if (typeof window !== "undefined" && window.localStorage) {
    window.localStorage.clear();
  }
});

describe("the stub backend keeps committed images", () => {
  it("serves an image from the commit that added it, and from later commits", async () => {
    const backend = createStubGitBackend({ repoKey: "images-test", getBranch: () => "main" });
    expect(backend.supportsAssets).toBe(true);
    const [tip] = await backend.getCommits("main", 1);
    const [file] = await backend.getFiles("main", tip);
    expect(await backend.getFileBlob("main", tip, "images/fig.png")).toBeNull();

    const { hash } = await backend.commitChanges(
      "add figure",
      [{ file, text: "x" }],
      [{ path: "images/fig.png", base64: "AAAA", type: "image/png" }],
    );
    expect(await backend.getFileBlob("main", { hash }, "images/fig.png")).toBe("data:image/png;base64,AAAA");
    expect(await backend.fileExists({ hash }, "images/fig.png")).toBe(true);
    expect(await backend.fileExists({ hash: tip.hash }, "images/fig.png")).toBe(false);

    const { hash: later } = await backend.commitChanges("edit", [{ file, text: "y" }]);
    expect(await backend.getFileBlob("main", { hash: later }, "images/fig.png")).toBe("data:image/png;base64,AAAA");
  });

  it("reports text files as existing too, so an upload cannot take a page's name", async () => {
    const backend = createStubGitBackend({ repoKey: "images-test-2" });
    const [tip] = await backend.getCommits("main", 1);
    const [file] = await backend.getFiles("main", tip);
    expect(await backend.fileExists(tip, file)).toBe(true);
  });

  it("returns open merge requests for matching branches", async () => {
    const backend = createStubGitBackend({ repoKey: "mr-test" });
    const mrs = await backend.getOpenMergeRequests("development");
    expect(mrs.length).toBeGreaterThan(0);
    expect(mrs[0].sourceBranch).toBe("development");
    expect(mrs[0].state).toBe("opened");

    const none = await backend.getOpenMergeRequests("nonexistent-branch");
    expect(none).toEqual([]);
  });
});

describe("the stub's demo user", () => {
  it("is a Maintainer called demo unless told otherwise", async () => {
    expect(await createStubGitBackend({ repoKey: "user-a" }).getCurrentUser()).toMatchObject({ username: "demo", accessLevel: 40 });
    const jdoe = await createStubGitBackend({ repoKey: "user-b", user: { username: "jdoe", accessLevel: 30 } }).getCurrentUser();
    expect(jdoe).toMatchObject({ username: "jdoe", accessLevel: 30 });
  });
});

describe("the stub refuses to replace an image unless asked, as GitLab does", () => {
  it("and a second tab on the same demo repository sees the first one's image", async () => {
    const tabA = createStubGitBackend({ repoKey: "collide", getBranch: () => "main" });
    const tabB = createStubGitBackend({ repoKey: "collide", getBranch: () => "main" });
    const image = { path: "images/fig.png", base64: "AAAA", type: "image/png" };
    await tabA.commitChanges("A adds it", [], [image]);

    await expect(tabB.commitChanges("B adds the same name", [], [image])).rejects.toThrow("already exists: images/fig.png");
    const [tip] = await tabB.getCommits("main", 1);
    expect(await tabB.fileExists(tip, "images/fig.png")).toBe(true);
    await expect(tabB.commitChanges("B replaces it", [], [{ ...image, replace: true }])).resolves.toMatchObject({ hash: expect.any(String) });
  });
});

describe("the stub can word things as GitHub does", () => {
  it("names GitHub, pull requests and its compare page", () => {
    const github = createStubGitBackend({ repoKey: "gh", flavor: "github" });
    expect(github.serverName).toBe("GitHub");
    expect(github.review).toMatchObject({ short: "PR", prefix: "#" });
    expect(github.newMergeRequestUrl({ sourceBranch: "feature", targetBranch: "main" })).toBe(
      "https://github.example.org/demo/book/compare/main...feature?expand=1",
    );
  });

  it("is GitLab otherwise", () => {
    const gitlab = createStubGitBackend({ repoKey: "gl" });
    expect(gitlab.serverName).toBe("GitLab");
    expect(gitlab.newMergeRequestUrl({ sourceBranch: "feature", targetBranch: "main" })).toContain("/-/merge_requests/new?");
  });
});
