import { describe, it, expect, vi } from "vite-plus/test";
import { createGitLabBackend } from "../../src/myst-git/gitlabBackend.js";

const jsonRes = (data) => ({ ok: true, status: 200, json: async () => data, text: async () => JSON.stringify(data) });
const textRes = (t) => ({ ok: true, status: 200, text: async () => t, json: async () => JSON.parse(t) });
function notFound() {
  const e = new Error("GitLab API 404");
  e.status = 404;
  return e;
}

/**
 * Build a mock `authorizedFetch` covering the prefetch (project metadata + branches page 1) that
 * `createGitLabBackend` always performs, delegating anything else to `extra`.
 */
function makeAuthFetch(extra = () => null) {
  return vi.fn(async (path, init) => {
    const e = await extra(path, init);
    if (e) return e;
    if (path === "projects/123") return jsonRes({ default_branch: "main" });
    if (path.startsWith("projects/123/repository/branches")) return jsonRes([{ name: "main" }, { name: "dev" }]);
    throw notFound();
  });
}

const make = (authorizedFetch, opts = {}) => createGitLabBackend({ projectId: "123", authorizedFetch, ...opts });
const called = (fn, frag) => fn.mock.calls.some(([p]) => p.includes(frag));

describe("createGitLabBackend prefetch", () => {
  it("puts the default branch first in initialBranches", async () => {
    const authFetch = makeAuthFetch();
    const backend = await make(authFetch);
    expect(backend.initialBranches).toEqual(["main", "dev"]);
  });

  it("throws without a projectId", async () => {
    await expect(createGitLabBackend({})).rejects.toThrow(/projectId/);
  });
});

describe("read callbacks", () => {
  it("getBranches maps names and requests the right page", async () => {
    const authFetch = makeAuthFetch();
    const backend = await make(authFetch);
    const names = await backend.getBranches(3);
    expect(names).toEqual(["main", "dev"]);
    expect(called(authFetch, "branches?per_page=20&page=3")).toBe(true);
  });

  it("remembers which listed branches are protected, and whether this user may push to them", async () => {
    const authFetch = makeAuthFetch((path) =>
      path.includes("search=")
        ? jsonRes([{ name: "release", protected: true, can_push: true }])
        : path.startsWith("projects/123/repository/branches")
          ? jsonRes([
              { name: "main", protected: true, can_push: false },
              { name: "dev", protected: false, can_push: true },
            ])
          : null,
    );
    const backend = await make(authFetch);
    expect(backend.getBranchStatus("main")).toEqual({ protected: true, canPush: false });
    expect(backend.getBranchStatus("dev")).toEqual({ protected: false, canPush: true });
    expect(backend.getBranchStatus("release")).toBeUndefined();
    await backend.searchBranches("rel");
    expect(backend.getBranchStatus("release")).toEqual({ protected: true, canPush: true });
  });

  it("getCommits maps short_id→hash and title→message with ref_name", async () => {
    const authFetch = makeAuthFetch((path) => {
      if (path.includes("/repository/commits")) {
        return jsonRes([{ short_id: "abc1234", title: "Fix bug", message: "Fix bug\n\ndetails" }]);
      }
      return null;
    });
    const backend = await make(authFetch);
    const commits = await backend.getCommits("dev", 1);
    expect(commits).toEqual([{ hash: "abc1234", message: "Fix bug" }]);
    expect(called(authFetch, "commits?ref_name=dev&per_page=20&page=1")).toBe(true);
  });

  it("getFiles keeps only .md/.rst blobs", async () => {
    const authFetch = makeAuthFetch((path) => {
      if (path.includes("/repository/tree")) {
        return jsonRes([
          { type: "blob", path: "docs/a.md" },
          { type: "blob", path: "docs/b.rst" },
          { type: "blob", path: "img/logo.png" },
          { type: "tree", path: "docs" },
        ]);
      }
      return null;
    });
    const backend = await make(authFetch);
    const files = await backend.getFiles("main", { hash: "abc" });
    expect(files).toEqual(["docs/a.md", "docs/b.rst"]);
  });

  it("lists every file under a folder, across pages of the tree", async () => {
    const page1 = Array.from({ length: 100 }, (_, i) => ({ type: "blob", path: `docs/week1/f${i}.md` }));
    const authFetch = makeAuthFetch((path) => {
      if (!path.includes("/repository/tree")) return null;
      expect(path).toContain("path=docs%2Fweek1");
      return jsonRes(
        path.endsWith("&page=1")
          ? page1
          : [
              { type: "tree", path: "docs/week1/img" },
              { type: "blob", path: "docs/week1/img/x.png" },
            ],
      );
    });
    const backend = await make(authFetch);
    const files = await backend.listFiles({ hash: "abc" }, "docs/week1");
    expect(files).toHaveLength(101);
    expect(files.at(-1)).toBe("docs/week1/img/x.png");
  });

  it("lists nothing for a folder that is not there", async () => {
    const authFetch = makeAuthFetch((path) =>
      path.includes("/repository/tree") ? Promise.reject(Object.assign(new Error("404"), { status: 404 })) : null,
    );
    expect(await (await make(authFetch)).listFiles({ hash: "abc" }, "docs/none")).toEqual([]);
  });

  it("getText returns raw file contents", async () => {
    const authFetch = makeAuthFetch((path) => (path.includes("/files/") ? textRes("# Title\n") : null));
    const backend = await make(authFetch);
    const text = await backend.getText("main", { hash: "abc" }, "docs/index.md");
    expect(text).toBe("# Title\n");
    expect(called(authFetch, "files/docs%2Findex.md/raw?ref=abc")).toBe(true);
  });

  it("getText returns empty string for a missing file (404)", async () => {
    const authFetch = makeAuthFetch((path) => {
      if (path.includes("/files/")) throw notFound();
      return null;
    });
    const backend = await make(authFetch);
    expect(await backend.getText("main", { hash: "abc" }, "docs/missing.md")).toBe("");
  });
});

describe("commitChanges", () => {
  it("POSTs update actions on the current branch and maps the response", async () => {
    const authFetch = makeAuthFetch((path, init) => {
      if (path.includes("/repository/commits") && init?.method === "POST") {
        return jsonRes({ short_id: "def5678", web_url: "https://gitlab.example.com/g/p/-/commit/def5678" });
      }
      return null;
    });
    const backend = await make(authFetch, { getBranch: () => "feature" });

    const result = await backend.commitChanges("my message", [{ file: "docs/a.md", text: "new" }]);

    expect(result).toEqual({ hash: "def5678", webUrl: "https://gitlab.example.com/g/p/-/commit/def5678" });
    const postCall = authFetch.mock.calls.find(([p, i]) => p.includes("/repository/commits") && i?.method === "POST");
    const payload = JSON.parse(postCall[1].body);
    expect(payload.branch).toBe("feature");
    expect(payload.commit_message).toBe("my message");
    expect(payload.actions).toEqual([{ action: "update", file_path: "docs/a.md", content: "new" }]);
  });

  it("supports action: 'create' for newly added documents", async () => {
    const authFetch = makeAuthFetch((path, init) => {
      if (path.includes("/repository/commits") && init?.method === "POST") {
        return jsonRes({ short_id: "def5678", web_url: "https://gitlab.example.com/g/p/-/commit/def5678" });
      }
      return null;
    });
    const backend = await make(authFetch, { getBranch: () => "feature" });

    await backend.commitChanges("add new file", [{ file: "docs/new.md", text: "# New", action: "create" }]);

    const postCall = authFetch.mock.calls.find(([p, i]) => p.includes("/repository/commits") && i?.method === "POST");
    const payload = JSON.parse(postCall[1].body);
    expect(payload.actions).toEqual([{ action: "create", file_path: "docs/new.md", content: "# New" }]);
  });

  it("moves a page with its new text in the same commit as the table of contents", async () => {
    const authFetch = makeAuthFetch((path, init) =>
      path.includes("/repository/commits") && init?.method === "POST" ? jsonRes({ short_id: "def5678", web_url: "u" }) : null,
    );
    const backend = await make(authFetch, { getBranch: () => "feature" });

    await backend.commitChanges("move", [
      { file: "docs/toc.yml", text: "toc" },
      { file: "docs/b/x.md", previous_path: "docs/a/x.md", action: "move", text: "![](../a/i.png)" },
      { file: "docs/b/i.png", previous_path: "docs/a/i.png", action: "move" },
    ]);

    const postCall = authFetch.mock.calls.find(([p, i]) => p.includes("/repository/commits") && i?.method === "POST");
    expect(JSON.parse(postCall[1].body).actions).toEqual([
      { action: "update", file_path: "docs/toc.yml", content: "toc" },
      { action: "move", file_path: "docs/b/x.md", previous_path: "docs/a/x.md", content: "![](../a/i.png)" },
      // Without content GitLab keeps the file as it is.
      { action: "move", file_path: "docs/b/i.png", previous_path: "docs/a/i.png" },
    ]);
  });
});

describe("commitChanges with images", () => {
  it("creates each image in the same commit as the pages, base64-encoded", async () => {
    const authFetch = makeAuthFetch((path, init) =>
      path.includes("/repository/commits") && init?.method === "POST" ? jsonRes({ short_id: "f00", web_url: "u" }) : null,
    );
    const backend = await make(authFetch, { getBranch: () => "main" });
    expect(backend.supportsAssets).toBe(true);

    await backend.commitChanges(
      "add figure",
      [{ file: "ch1/page.md", text: "![](images/fig.png)" }],
      [{ path: "ch1/images/fig.png", base64: "iVBORw==", type: "image/png" }],
    );

    const payload = JSON.parse(authFetch.mock.calls.find(([p, i]) => p.includes("/repository/commits") && i?.method === "POST")[1].body);
    expect(payload.actions).toEqual([
      { action: "update", file_path: "ch1/page.md", content: "![](images/fig.png)" },
      // `create`, never `update`: an existing file at that path makes GitLab refuse rather than overwrite.
      { action: "create", file_path: "ch1/images/fig.png", content: "iVBORw==", encoding: "base64" },
    ]);
  });
});

describe("fileExists", () => {
  it("asks for the file's metadata at the commit, and reads a 404 as free", async () => {
    const authFetch = makeAuthFetch((path, init) =>
      init?.method === "HEAD" && path.includes(encodeURIComponent("ch1/images/taken.png")) ? jsonRes({}) : null,
    );
    const backend = await make(authFetch);
    expect(await backend.fileExists({ hash: "abc" }, "ch1/images/taken.png")).toBe(true);
    expect(await backend.fileExists({ hash: "abc" }, "ch1/images/free.png")).toBe(false);
    expect(called(authFetch, "?ref=abc")).toBe(true);
  });

  it("does not hide other errors", async () => {
    const authFetch = makeAuthFetch((path, init) => {
      if (init?.method !== "HEAD") return null;
      const e = new Error("GitLab API 500");
      e.status = 500;
      throw e;
    });
    const backend = await make(authFetch);
    await expect(backend.fileExists({ hash: "abc" }, "x.png")).rejects.toThrow("500");
  });
});

describe("createBranch", () => {
  it("POSTs to /repository/branches with branch and ref and maps the response", async () => {
    const authFetch = makeAuthFetch((path, init) => {
      if (path.includes("/repository/branches") && init?.method === "POST") {
        return jsonRes({
          name: "new-feature",
          commit: { short_id: "abc999", title: "Latest commit" },
        });
      }
      return null;
    });
    const backend = await make(authFetch);

    const result = await backend.createBranch("new-feature", "main");

    expect(result).toEqual({ name: "new-feature", commit: { hash: "abc999", message: "Latest commit" } });
    const postCall = authFetch.mock.calls.find(([p, i]) => p.includes("/repository/branches") && i?.method === "POST");
    const payload = JSON.parse(postCall[1].body);
    expect(payload.branch).toBe("new-feature");
    expect(payload.ref).toBe("main");
  });
});

describe("error propagation", () => {
  it("rethrows non-404 API errors", async () => {
    const authFetch = makeAuthFetch((path) => {
      if (path.includes("/repository/commits")) {
        const e = new Error("GitLab API 500");
        e.status = 500;
        throw e;
      }
      return null;
    });
    const backend = await make(authFetch);
    await expect(backend.getCommits("dev", 1)).rejects.toThrow(/500/);
  });
});

describe("getOpenMergeRequests", () => {
  it("queries project merge requests for the branch and maps properties", async () => {
    const authFetch = makeAuthFetch((path) => {
      if (path.includes("/merge_requests?source_branch=development")) {
        return jsonRes([
          {
            id: 101,
            iid: 5,
            title: "Improve docs",
            web_url: "https://gitlab.example.com/p/-/merge_requests/5",
            source_branch: "development",
            target_branch: "main",
            state: "opened",
            author: { name: "Author" },
          },
        ]);
      }
      return null;
    });
    const backend = await make(authFetch);
    const mrs = await backend.getOpenMergeRequests("development");
    expect(mrs).toEqual([
      {
        id: 101,
        iid: 5,
        title: "Improve docs",
        webUrl: "https://gitlab.example.com/p/-/merge_requests/5",
        sourceBranch: "development",
        targetBranch: "main",
        state: "opened",
        author: "Author",
      },
    ]);
  });
});

describe("getCurrentUser", () => {
  const withRole = (permissions) =>
    makeAuthFetch((path) => {
      if (path === "projects/123") return jsonRes({ default_branch: "main", permissions });
      if (path === "user") return jsonRes({ id: 9, username: "jdoe", name: "J. Doe", email: "not@needed" });
      return null;
    });

  it("returns who is signed in and their role here, asking GitLab once", async () => {
    const authFetch = withRole({ project_access: { access_level: 30 }, group_access: null });
    const backend = await make(authFetch);
    expect(await backend.getCurrentUser()).toEqual({ id: 9, username: "jdoe", name: "J. Doe", accessLevel: 30 });
    await backend.getCurrentUser();
    expect(authFetch.mock.calls.filter(([p]) => p === "user")).toHaveLength(1);
  });

  it("takes the higher of a project and an inherited group role", async () => {
    const backend = await make(withRole({ project_access: { access_level: 30 }, group_access: { access_level: 50 } }));
    expect((await backend.getCurrentUser()).accessLevel).toBe(50);
  });

  it("reports no role for someone who only sees a public project", async () => {
    const backend = await make(withRole(undefined));
    expect((await backend.getCurrentUser()).accessLevel).toBe(0);
  });
});
