import { describe, it, expect } from "vite-plus/test";
import { buildCodeCell, codeCellPresets, kernelspecs } from "../../src/markdown/codeCell.ts";
import { addFrontmatterKey, frontmatterBlock, frontmatterKeyState } from "../../src/markdown/frontmatter.ts";

describe("buildCodeCell", () => {
  it("turns the figure preset into the tag it implies", () => {
    const { text } = buildCodeCell({ language: "python", preset: "figure" });
    expect(text).toContain("```{code-cell} python");
    expect(text).toContain(":tags: [remove-input]");
  });

  it("emits no options block for a plain cell", () => {
    const { text } = buildCodeCell({ language: "python", preset: "both" });
    expect(text).toBe("\n```{code-cell} python\n\n```\n");
  });

  it("separates the options from the code with the blank line the directive requires", () => {
    // Without it the first line of code is read as another option and the build fails with
    // `unexpected option ... provided`.
    const { text } = buildCodeCell({ language: "python", preset: "figure", body: "print(1)" });
    expect(text).toContain(":tags: [remove-input]\n\nprint(1)");
  });

  it("writes the options in Jupyter Book's order, and only the ones that were filled in", () => {
    const { text } = buildCodeCell({
      language: "python",
      preset: "figure",
      label: "  fig-airy  ",
      caption: "",
      extraTags: ["remove-stderr"],
      linenos: true,
    });
    // [0] is the leading blank line the directive is padded with, [1] the fence.
    expect(text.split("\n").slice(2, 6)).toEqual([":label: fig-airy", ":tags: [remove-input, remove-stderr]", ":linenos:", ""]);
  });

  it("never repeats a tag a preset already implies", () => {
    const { text } = buildCodeCell({ language: "python", preset: "setup", extraTags: ["remove-cell", "remove-stdout"] });
    expect(text).toContain(":tags: [remove-cell, remove-stdout]");
  });

  it("lengthens the fence past any backticks in the code", () => {
    // A cell holding a markdown example is the real case: its own ``` would close the directive early.
    const body = "print('''\n```{note}\nhi\n```\n''')";
    const { text } = buildCodeCell({ language: "python", preset: "both", body });
    expect(text.startsWith("\n````{code-cell}")).toBe(true);
    expect(text.trimEnd().endsWith("\n````")).toBe(true);
  });

  it("points bodyOffset and bodyEnd at the code itself", () => {
    const { text, bodyOffset, bodyEnd } = buildCodeCell({ language: "python", preset: "figure", body: "print(1)" });
    expect(text.slice(bodyOffset, bodyEnd)).toBe("print(1)");
  });

  it("leaves an empty line to type on when nothing was selected", () => {
    const { text, bodyOffset, bodyEnd } = buildCodeCell({ language: "python", preset: "figure" });
    expect(bodyOffset).toBe(bodyEnd);
    expect(text[bodyOffset]).toBe("\n");
  });

  it("offers a kernel for every language it offers", () => {
    for (const preset of codeCellPresets) expect(Array.isArray(preset.tags)).toBe(true);
    expect(kernelspecs.python).toEqual({ name: "python3", display_name: "Python 3" });
  });
});

describe("frontmatterBlock", () => {
  it("finds a block that opens the document", () => {
    const block = frontmatterBlock("---\ntitle: A page\n---\n\n# Heading\n");
    expect(block.body).toBe("title: A page\n");
    expect(block.from).toBe(0);
  });

  it("ignores a --- that is not at the very top", () => {
    // A thematic break, or the frontmatter of an example being quoted - neither is this page's.
    expect(frontmatterBlock("# Heading\n\n---\ntitle: not mine\n---\n")).toBeNull();
  });

  it("reports no block at all for a plain document", () => {
    expect(frontmatterBlock("# Heading\n")).toBeNull();
  });
});

describe("frontmatterKeyState", () => {
  it("sees a key that is there", () => {
    expect(frontmatterKeyState("---\nkernelspec:\n  name: python3\n---\n", "kernelspec")).toBe("present");
  });

  it("sees one that is missing, with or without a block", () => {
    expect(frontmatterKeyState("---\ntitle: A page\n---\n", "kernelspec")).toBe("missing");
    expect(frontmatterKeyState("# Heading\n", "kernelspec")).toBe("missing");
  });

  it("refuses to guess about YAML it cannot parse", () => {
    // "unknown", not "missing": adding a key to a broken block would corrupt it further, and the
    // caller skips the offer entirely rather than acting on a guess.
    expect(frontmatterKeyState("---\ntitle: [unclosed\n---\n", "kernelspec")).toBe("unknown");
  });
});

describe("addFrontmatterKey", () => {
  const apply = (doc, change) => doc.slice(0, change.from) + change.insert + doc.slice(change.to);

  it("appends to an existing block without rewriting it", () => {
    // Comments and key order are the author's; dumping the parsed YAML back out would lose both.
    const doc = "---\n# the page title\ntitle: A page\n---\n\n# Heading\n";
    const result = apply(doc, addFrontmatterKey(doc, "kernelspec", kernelspecs.python));
    expect(result).toContain("# the page title");
    expect(result).toBe("---\n# the page title\ntitle: A page\nkernelspec:\n  name: python3\n  display_name: Python 3\n---\n\n# Heading\n");
  });

  it("creates the block when the document has none", () => {
    const doc = "# Heading\n";
    const result = apply(doc, addFrontmatterKey(doc, "kernelspec", kernelspecs.python));
    expect(result).toBe("---\nkernelspec:\n  name: python3\n  display_name: Python 3\n---\n\n# Heading\n");
  });

  it("does nothing when the key is already there, or the block does not parse", () => {
    expect(addFrontmatterKey("---\nkernelspec: {}\n---\n", "kernelspec", {})).toBeNull();
    expect(addFrontmatterKey("---\ntitle: [unclosed\n---\n", "kernelspec", {})).toBeNull();
  });

  it("produces frontmatter that parses back to what was asked for", () => {
    const doc = "---\ntitle: A page\n---\n";
    const result = apply(doc, addFrontmatterKey(doc, "kernelspec", kernelspecs.python));
    expect(frontmatterKeyState(result, "kernelspec")).toBe("present");
  });
});
