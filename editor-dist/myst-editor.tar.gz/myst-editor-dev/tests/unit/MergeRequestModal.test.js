import { describe, it, expect, vi, beforeEach, afterEach } from "vite-plus/test";
import { render, h } from "preact";
import { MergeRequestModal } from "../../src/myst-git/MergeRequestModal.jsx";

describe("MergeRequestModal", () => {
  let container;

  beforeEach(() => {
    container = document.createElement("div");
    document.body.appendChild(container);
  });

  afterEach(() => {
    container.remove();
    container = null;
  });

  it("renders when open and pre-fills source branch, target branch, and project id", async () => {
    render(
      h(MergeRequestModal, {
        open: true,
        onClose: vi.fn(),
        currentBranch: "development",
        defaultBranch: "main",
        projectId: 28652,
        projectWebUrl: "https://gitlab.tudelft.nl/combine/myst-editor",
        branches: ["main", "development"],
      }),
      container,
    );

    const dialog = container.querySelector("#merge-request-modal");
    expect(dialog).not.toBeNull();

    const sourceInput = container.querySelector("#mr-field-source");
    expect(sourceInput).not.toBeNull();
    expect(sourceInput.value).toBe("development");

    const targetInput = container.querySelector("#mr-field-target");
    expect(targetInput).not.toBeNull();
    expect(targetInput.value).toBe("main");

    const previewInput = container.querySelector("input[aria-label='Generated GitLab Link']");
    expect(previewInput).not.toBeNull();
    expect(previewInput.value).toBe(
      "https://gitlab.tudelft.nl/combine/myst-editor/-/merge_requests/new?merge_request%5Bsource_project_id%5D=28652&merge_request%5Bsource_branch%5D=development&merge_request%5Btarget_project_id%5D=28652&merge_request%5Btarget_branch%5D=main",
    );
  });

  it("informs the user and displays a warning when an open MR exists for the branch", async () => {
    const getOpenMergeRequests = vi.fn(async (branch) => {
      if (branch === "development") {
        return [
          {
            id: 101,
            iid: 42,
            title: "Feature branch update",
            webUrl: "https://gitlab.tudelft.nl/combine/myst-editor/-/merge_requests/42",
            sourceBranch: "development",
            targetBranch: "main",
            state: "opened",
          },
        ];
      }
      return [];
    });

    render(
      h(MergeRequestModal, {
        open: true,
        onClose: vi.fn(),
        currentBranch: "development",
        defaultBranch: "main",
        projectId: 28652,
        projectWebUrl: "https://gitlab.tudelft.nl/combine/myst-editor",
        getOpenMergeRequests,
      }),
      container,
    );

    // Give effects a tick to resolve getOpenMergeRequests
    await new Promise((r) => setTimeout(r, 50));

    const warningBox = container.querySelector("[data-testid='mr-warning-box']");
    expect(warningBox).not.toBeNull();
    expect(warningBox.textContent).toContain("!42 Feature branch update");

    const viewMrBtn = warningBox.querySelector("button.view-mr-btn");
    expect(viewMrBtn).not.toBeNull();
    expect(viewMrBtn.textContent).toContain("View Merge Request !42");
  });

  it("does not render an advanced options section", () => {
    render(
      h(MergeRequestModal, {
        open: true,
        onClose: vi.fn(),
        currentBranch: "development",
        defaultBranch: "main",
        projectId: 28652,
        projectWebUrl: "https://gitlab.tudelft.nl/combine/myst-editor",
        branches: ["main", "development"],
      }),
      container,
    );

    const advancedSection = container.querySelector(".advanced-section");
    expect(advancedSection).toBeNull();
  });

  it("shows an error and disables submission when source and target branches are identical", () => {
    render(
      h(MergeRequestModal, {
        open: true,
        onClose: vi.fn(),
        currentBranch: "main",
        defaultBranch: "main",
        projectId: 28652,
        projectWebUrl: "https://gitlab.tudelft.nl/combine/myst-editor",
        branches: ["main", "development"],
      }),
      container,
    );

    const sameBranchError = container.querySelector("[data-testid='mr-same-branch-error']");
    expect(sameBranchError).not.toBeNull();
    expect(sameBranchError.textContent).toContain("Source and target branch cannot be the same");

    const submitBtn = container.querySelector("button.primary");
    expect(submitBtn).not.toBeNull();
    expect(submitBtn.disabled).toBe(true);
  });

  const renderModal = (props = {}) =>
    render(
      h(MergeRequestModal, {
        open: true,
        onClose: vi.fn(),
        currentBranch: "development",
        defaultBranch: "main",
        projectId: 28652,
        projectWebUrl: "https://gitlab.tudelft.nl/combine/myst-editor",
        branches: ["main", "development"],
        ...props,
      }),
      container,
    );
  const tick = (ms = 20) => new Promise((r) => setTimeout(r, ms));

  it("expands the preview when the link bar is clicked, without copying behind the author's back", async () => {
    const writeText = vi.fn(async () => {});
    vi.stubGlobal("navigator", { ...navigator, clipboard: { writeText } });
    try {
      renderModal();
      await tick(50);

      const previewInput = container.querySelector("input[aria-label='Generated GitLab Link']");
      const expectedUrl = previewInput.value;
      const copyBtn = container.querySelector("button.copy-btn");
      expect(copyBtn.textContent).toBe("Copy");

      previewInput.dispatchEvent(new MouseEvent("click", { bubbles: true }));
      await tick(50);

      const expandedTextarea = container.querySelector("textarea[aria-label='Generated GitLab Link']");
      expect(expandedTextarea).not.toBeNull();
      expect(expandedTextarea.value).toBe(expectedUrl);
      expect(writeText).not.toHaveBeenCalled();
      expect(copyBtn.textContent).toBe("Copy");

      // Collapse again
      container.querySelector("button.collapse-btn").dispatchEvent(new MouseEvent("click", { bubbles: true }));
      await tick();
      expect(container.querySelector("textarea[aria-label='Generated GitLab Link']")).toBeNull();
      expect(container.querySelector("input[aria-label='Generated GitLab Link']")).not.toBeNull();
    } finally {
      vi.unstubAllGlobals();
    }
  });

  it("says Copied! only when the link actually reached the clipboard", async () => {
    const writeText = vi.fn(async () => {});
    vi.stubGlobal("navigator", { ...navigator, clipboard: { writeText } });
    try {
      renderModal();
      await tick(50);
      const copyBtn = container.querySelector("button.copy-btn");
      copyBtn.dispatchEvent(new MouseEvent("click", { bubbles: true }));
      await tick();
      expect(writeText).toHaveBeenCalledWith(container.querySelector("input[aria-label='Generated GitLab Link']").value);
      expect(copyBtn.textContent).toBe("Copied!");
    } finally {
      vi.unstubAllGlobals();
    }
  });

  it("shows the whole link to copy by hand when there is no clipboard", async () => {
    // A deployment served over plain http has no navigator.clipboard at all.
    vi.stubGlobal("navigator", { ...navigator, clipboard: undefined });
    try {
      renderModal();
      await tick(50);
      const copyBtn = container.querySelector("button.copy-btn");
      copyBtn.dispatchEvent(new MouseEvent("click", { bubbles: true }));
      await tick();
      expect(copyBtn.textContent).not.toBe("Copied!");
      expect(copyBtn.textContent).toBe("Copy by hand");
      expect(container.querySelector("textarea[aria-label='Generated GitLab Link']")).not.toBeNull();
    } finally {
      vi.unstubAllGlobals();
    }
  });

  it("only offers branches as the source, since GitLab cannot open a merge request from a commit", async () => {
    renderModal({ branches: ["main", "development", "feature"] });
    await tick(50);

    expect(Array.from(container.querySelectorAll(".chip-btn")).some((b) => b.textContent.includes("Commit"))).toBe(false);

    const sourceInput = container.querySelector("#mr-field-source");
    sourceInput.dispatchEvent(new Event("focus", { bubbles: true }));
    await tick();
    expect(container.querySelectorAll(".searchable-branch-select li.commit-item").length).toBe(0);

    sourceInput.value = "feat";
    sourceInput.dispatchEvent(new Event("input", { bubbles: true }));
    await tick();
    const branchItem = container.querySelector(".searchable-branch-select li.branch-item");
    expect(branchItem.querySelector(".branch-name").textContent).toBe("feature");
    branchItem.dispatchEvent(new MouseEvent("mousedown", { bubbles: true }));
    await tick();

    const previewInput = container.querySelector("input[aria-label='Generated GitLab Link']");
    expect(previewInput.value).toContain("source_branch%5D=feature");

    // The current-branch chip brings the source back.
    const currentChip = Array.from(container.querySelectorAll(".chip-btn")).find((b) => b.textContent.includes("Current: development"));
    currentChip.dispatchEvent(new MouseEvent("click", { bubbles: true }));
    await tick();
    expect(previewInput.value).toContain("source_branch%5D=development");
    expect(currentChip.getAttribute("aria-pressed")).toBe("true");
  });
});
