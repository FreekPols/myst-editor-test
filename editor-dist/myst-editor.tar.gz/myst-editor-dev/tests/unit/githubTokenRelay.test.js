// @vitest-environment node
// The relay runs on a server, where a request may carry an Origin header (a browser-like test
// environment strips it as a forbidden header).
import { describe, it, expect, vi, afterEach } from "vite-plus/test";
import relay from "../../tools/github-token-relay/worker.js";

const env = { GITHUB_CLIENT_ID: "Iv1.abc", GITHUB_CLIENT_SECRET: "s3cret", ALLOWED_ORIGINS: "https://jdoe.github.io, https://book.example.org/" };
const ask = (fields, { origin = "https://jdoe.github.io", method = "POST" } = {}) => {
  const init = method === "POST" ? { method, body: new URLSearchParams(fields) } : { method };
  return relay.fetch(new Request("https://relay.example.org/token", { ...init, headers: { Origin: origin } }), env);
};

afterEach(() => vi.unstubAllGlobals());

describe("the GitHub token relay", () => {
  it("adds the secret, passes the code on and hands GitHub's answer back", async () => {
    const github = vi.fn(async () => new Response(JSON.stringify({ access_token: "ghu_x" }), { status: 200 }));
    vi.stubGlobal("fetch", github);
    const res = await ask({
      grant_type: "authorization_code",
      client_id: "Iv1.abc",
      code: "c",
      code_verifier: "v",
      redirect_uri: "https://jdoe.github.io/book/editor/",
    });

    expect(await res.json()).toEqual({ access_token: "ghu_x" });
    expect(res.headers.get("Access-Control-Allow-Origin")).toBe("https://jdoe.github.io");
    const [url, init] = github.mock.calls[0];
    expect(url).toBe("https://github.com/login/oauth/access_token");
    expect(Object.fromEntries(init.body)).toEqual({
      client_id: "Iv1.abc",
      client_secret: "s3cret",
      grant_type: "authorization_code",
      code: "c",
      redirect_uri: "https://jdoe.github.io/book/editor/",
      code_verifier: "v",
    });
  });

  it("refreshes a token", async () => {
    const github = vi.fn(async () => new Response("{}", { status: 200 }));
    vi.stubGlobal("fetch", github);
    await ask({ grant_type: "refresh_token", refresh_token: "ghr_y" }, { origin: "https://book.example.org" });
    expect(Object.fromEntries(github.mock.calls[0][1].body)).toMatchObject({
      grant_type: "refresh_token",
      refresh_token: "ghr_y",
      client_secret: "s3cret",
    });
  });

  it("answers no other page, and no other app", async () => {
    const github = vi.fn();
    vi.stubGlobal("fetch", github);
    expect((await ask({ grant_type: "authorization_code" }, { origin: "https://evil.example.com" })).status).toBe(403);
    expect((await ask({ grant_type: "authorization_code", client_id: "someone-else" })).status).toBe(400);
    expect((await ask({ grant_type: "password" })).status).toBe(400);
    expect(github).not.toHaveBeenCalled();
  });

  it("answers the browser's preflight for allowed pages", async () => {
    const res = await ask({}, { method: "OPTIONS" });
    expect(res.status).toBe(204);
    expect(res.headers.get("Access-Control-Allow-Methods")).toContain("POST");
  });
});
