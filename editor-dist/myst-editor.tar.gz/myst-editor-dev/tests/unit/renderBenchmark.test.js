import { describe, it, expect } from "vite-plus/test";
import { readFileSync, writeFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
import { renderMyst } from "../../src/markdown/mystRenderer.ts";

// Answers plan question (i): is whole-doc mystmd render fast enough to drop the chunk cache?
// We time renderMyst() across small/medium/large corpora
// whole-doc render (the current pipeline's core, minus the per-chunk cache that only re-renders one
// changed chunk per keystroke).
//
// The report is committed, but is only rewritten when BENCHMARK_REPORT=1 is set. Timings wobble by
// ~10% run to run, so writing it on every `npm run test:unit` left the working tree dirty with noise
// that reads like a real change in a diff. Regenerate deliberately:
//   BENCHMARK_REPORT=1 npx vitest run tests/unit/renderBenchmark.test.js

const here = dirname(fileURLToPath(import.meta.url));
const fx = (name) => readFileSync(resolve(here, "../fixtures", name), "utf8");
const REPORT = resolve(here, "../../src/markdown/BENCHMARK.md");

const showcase = readFileSync(resolve(here, "../../src/fixtures/jb2-showcase.md"), "utf8");
const small = fx("myst-syntax.md");
const medium = fx("cheatsheet.md");
const large = Array.from({ length: 4 }, () => medium).join("\n\n"); // ~4.8k lines worst case

const stats = (fn, iterations) => {
  // warmup
  for (let i = 0; i < 3; i++) fn();
  const times = [];
  for (let i = 0; i < iterations; i++) {
    const t0 = performance.now();
    fn();
    times.push(performance.now() - t0);
  }
  times.sort((a, b) => a - b);
  const median = times[Math.floor(times.length / 2)];
  const p95 = times[Math.floor(times.length * 0.95)];
  return { median, p95, min: times[0], max: times[times.length - 1] };
};

describe("render benchmark (question i)", () => {
  const rows = [];
  const corpora = [
    ["small (myst-syntax.md)", small, small.split("\n").length],
    // The feature-dense document the demo loads: every directive, role and admonition kind at once.
    ["showcase (jb2-showcase.md)", showcase, showcase.split("\n").length],
    ["medium (cheatsheet.md)", medium, medium.split("\n").length],
    ["large (cheatsheet x4)", large, large.split("\n").length],
  ];

  it("renders every corpus through mystmd without error", () => {
    for (const [, src] of corpora) {
      const { error } = renderMyst(src, { lineMap: new Map() });
      expect(error).toBeNull();
    }
  });

  // Deliberately generous: this test renders ~150 documents (four corpora x 15-40 iterations), so
  // under any real machine load it exceeds vitest's 5s default and fails on timing rather than on
  // anything it actually measures. The numbers it records are the point, not the clock.
  it("measures whole-doc render time", { timeout: 120_000 }, () => {
    for (const [label, src, lines] of corpora) {
      const iters = lines > 2000 ? 15 : 40;
      const myst = stats(() => renderMyst(src, { lineMap: new Map() }), iters);
      rows.push({ label, lines, myst });
    }

    const fmt = (n) => n.toFixed(1).padStart(7);
    const lines = [
      "# Whole-doc render benchmark (question i)",
      "",
      "Median / p95 milliseconds per whole-document render",
      "(myst-parser -> myst-to-html -> MathML -> sanitize-ready HTML, whole-doc, no chunk cache).",
      "Renders while typing are debounced, so this is the cost once per quiet period, not per keystroke.",
      "",
      "Environment: happy-dom under vitest (Node). Browser numbers differ but track these ratios.",
      "",
      "| corpus | lines | median | p95 |",
      "|---|---|---|---|",
      ...rows.map((r) => `| ${r.label} | ${r.lines} | ${fmt(r.myst.median)} ms | ${fmt(r.myst.p95)} ms |`),
      "",
      `_Generated on ${new Date().toISOString().slice(0, 10)} by:_`,
      "`BENCHMARK_REPORT=1 npx vitest run tests/unit/renderBenchmark.test.js`",
      "",
    ];
    if (process.env.BENCHMARK_REPORT) writeFileSync(REPORT, lines.join("\n"));

    // Sanity gate: even the worst-case large doc should render well under a second in this env.
    const largeRow = rows.find((r) => r.label.startsWith("large"));
    expect(largeRow.myst.median).toBeLessThan(1000);
  });
});
