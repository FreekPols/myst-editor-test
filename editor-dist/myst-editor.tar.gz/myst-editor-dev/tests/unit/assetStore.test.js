import { describe, it, expect, vi, beforeEach } from "vite-plus/test";
import { createAssetStore } from "../../src/myst-git/assetStore.js";

let urls;
beforeEach(() => {
  urls = 0;
  URL.createObjectURL = vi.fn(() => `blob:test/${++urls}`);
  URL.revokeObjectURL = vi.fn();
});

const png = () => new Blob(["x"], { type: "image/png" });
const commit = { hash: "abc123" };

describe("pending uploads", () => {
  it("are served before anything in the repository, without asking it", async () => {
    const getFileBlob = vi.fn(async () => "blob:repo");
    const store = createAssetStore({ getFileBlob });
    store.stage("main", "a/images/fig.png", png());
    expect(await store.lookup("main", commit, "a/images/fig.png")).toBe("blob:test/1");
    expect(getFileBlob).not.toHaveBeenCalled();
  });

  it("belong to their branch", async () => {
    const store = createAssetStore({ getFileBlob: async () => null });
    store.stage("feature", "fig.png", png());
    expect(store.pendingFor("feature")).toHaveLength(1);
    expect(store.pendingFor("main")).toHaveLength(0);
    expect(await store.lookup("main", commit, "fig.png")).toBeNull();
  });

  it("release the previous image when one is staged again at the same path", () => {
    const store = createAssetStore();
    store.stage("main", "fig.png", png());
    store.stage("main", "fig.png", png());
    expect(URL.revokeObjectURL).toHaveBeenCalledWith("blob:test/1");
    expect(store.pendingFor("main")).toHaveLength(1);
  });

  it("count every change, for whatever displays them", () => {
    const store = createAssetStore();
    const start = store.version.value;
    store.stage("main", "a.png", png());
    store.unstage("main", "a.png");
    expect(store.version.value).toBe(start + 2);
  });

  it("are dropped and released on discard", () => {
    const store = createAssetStore();
    store.stage("main", "a.png", png());
    store.discard("main");
    expect(store.pendingFor("main")).toHaveLength(0);
    expect(URL.revokeObjectURL).toHaveBeenCalledWith("blob:test/1");
  });
});

describe("images already in the repository", () => {
  it("are fetched once per commit, however often the preview re-renders", async () => {
    const getFileBlob = vi.fn(async () => "blob:repo/1");
    const store = createAssetStore({ getFileBlob });
    await store.lookup("main", commit, "fig.png");
    await store.lookup("main", commit, "fig.png");
    expect(getFileBlob).toHaveBeenCalledTimes(1);
    expect(store.peek("main", "abc123", "fig.png")).toBe("blob:repo/1");
    // Another commit is another file, as far as the cache is concerned.
    await store.lookup("main", { hash: "def456" }, "fig.png");
    expect(getFileBlob).toHaveBeenCalledTimes(2);
  });

  it("remember that an image is missing, but not that a fetch failed", async () => {
    const getFileBlob = vi.fn().mockRejectedValueOnce(new Error("network")).mockResolvedValue(null);
    const store = createAssetStore({ getFileBlob });
    await expect(store.lookup("main", commit, "x.png")).rejects.toThrow("network");
    expect(await store.lookup("main", commit, "x.png")).toBeNull();
    expect(await store.lookup("main", commit, "x.png")).toBeNull();
    expect(getFileBlob).toHaveBeenCalledTimes(2);
  });

  it("are capped, releasing the least recently used", async () => {
    let n = 0;
    const store = createAssetStore({ getFileBlob: async () => `blob:repo/${++n}`, maxCached: 2 });
    await store.lookup("main", commit, "a.png");
    await store.lookup("main", commit, "b.png");
    await store.lookup("main", commit, "a.png"); // a is now the most recent
    await store.lookup("main", commit, "c.png"); // so b goes
    expect(URL.revokeObjectURL).toHaveBeenCalledWith("blob:repo/2");
    expect(store.peek("main", "abc123", "a.png")).toBe("blob:repo/1");
  });
});

describe("after a commit", () => {
  it("moves the committed uploads into the cache under the new commit, without releasing them", async () => {
    const getFileBlob = vi.fn(async () => null);
    const store = createAssetStore({ getFileBlob });
    store.stage("main", "a.png", png());
    store.stage("main", "b.png", png());
    store.promote("main", "new1", ["a.png"]);

    expect(store.pendingFor("main").map((e) => e.path)).toEqual(["b.png"]);
    expect(await store.lookup("main", { hash: "new1" }, "a.png")).toBe("blob:test/1");
    expect(getFileBlob).not.toHaveBeenCalled();
    expect(URL.revokeObjectURL).not.toHaveBeenCalled();
  });
});
