import { describe, it, expect } from "vite-plus/test";
import yaml from "js-yaml";
import { parseTocTree, addTocPage, addTocChapter, moveTocEntry } from "../../src/myst-git/toc.js";

const myst = `# The book's settings
version: 1
project:
  title: Demo # shown in the header
  toc:
    - file: intro.md
    - title: Week 1
      children:
        - file: week1/a.md
        - file: week1/b.md

    # Pages at the top level that live in a folder
    - file: chapter/overview.md
    - file: ch2/index.md
      children:
        - file: ch2/x.md
`;
const tocOf = (text) => yaml.load(text).project.toc;

describe("parseTocTree", () => {
  it("gives every entry its position in the YAML", () => {
    const tree = parseTocTree(myst);
    expect(tree.map((n) => n.path)).toEqual([[0], [1], [2], [3]]);
    expect(tree[1].children.map((n) => n.path)).toEqual([
      [1, 0],
      [1, 1],
    ]);
  });

  it("keeps a chapter's own page on the chapter, and its children under it", () => {
    const [, , , ch2] = parseTocTree(myst, "docs/");
    expect(ch2).toMatchObject({ file: "docs/ch2/index.md", isFolder: true, home: "docs/ch2" });
    expect(ch2.children.map((n) => n.file)).toEqual(["docs/ch2/x.md"]);
  });

  it("finds the folder of a chapter without a page only when its pages share one", () => {
    expect(parseTocTree(myst)[1].home).toBe("week1");
    const scattered = parseTocTree(`project:\n  toc:\n    - title: Mixed\n      children: [{file: a/x.md}, {file: b/y.md}]\n`);
    expect(scattered[0].home).toBeNull();
  });

  it("names entries uniquely, even chapters with the same title", () => {
    const tree = parseTocTree(`project:\n  toc:\n    - title: Exercises\n      children: []\n    - title: Exercises\n      children: []\n`);
    expect(new Set(tree.map((n) => n.id)).size).toBe(2);
  });

  it("reads Jupyter Book v1, with the root page first and fixed in place", () => {
    const tree = parseTocTree(`format: jb-book\nroot: intro\nparts:\n  - caption: Basics\n    chapters:\n      - file: basics/one\n`);
    expect(tree[0]).toMatchObject({ file: "intro.md", path: null });
    expect(tree[1]).toMatchObject({ title: "Basics", isFolder: true, path: [0] });
    expect(tree[1].children[0]).toMatchObject({ file: "basics/one.md", path: [0, 0] });
  });

  it("skips links to other sites and reads bare file names", () => {
    const tree = parseTocTree(`- intro\n- url: https://example.org\n- file: two.md\n`);
    expect(tree.map((n) => n.file)).toEqual(["intro.md", "two.md"]);
    expect(tree[1].path).toEqual([2]);
  });

  it("reads broken YAML as no tree", () => {
    expect(parseTocTree("project: [")).toEqual([]);
  });
});

describe("addTocPage", () => {
  it("adds a page at the top level, relative to the docs root", () => {
    const out = addTocPage(myst, { file: "docs/new.md", prefix: "docs/" });
    expect(tocOf(out).at(-1)).toEqual({ file: "new.md" });
  });

  it("adds a page to a chapter", () => {
    const out = addTocPage(myst, { file: "week1/c.md", parentPath: [1] });
    expect(tocOf(out)[1].children.map((c) => c.file)).toEqual(["week1/a.md", "week1/b.md", "week1/c.md"]);
  });

  it("keeps comments, blank lines and the rest of the file", () => {
    const out = addTocPage(myst, { file: "new.md" });
    expect(out).toBe(`${myst}    - file: new.md\n`);
  });

  it("turns an empty inline list into a block list", () => {
    const out = addTocPage(`project:\n  toc:\n    - file: ch/index.md\n      children: []\n`, { file: "ch/a.md", parentPath: [0] });
    expect(out).toBe(`project:\n  toc:\n    - file: ch/index.md\n      children:\n        - file: ch/a.md\n`);
  });

  it("keeps lists that are not indented under their key that way", () => {
    const out = addTocPage(`project:\n  toc:\n  - file: a.md\n`, { file: "b.md" });
    expect(out).toBe(`project:\n  toc:\n  - file: a.md\n  - file: b.md\n`);
  });

  it("writes Jupyter Book v1 entries without .md, under `sections`", () => {
    const out = addTocPage(`format: jb-book\nroot: intro\nchapters:\n  - file: ch/index\n`, { file: "ch/a.md", parentPath: [0] });
    expect(yaml.load(out).chapters[0]).toEqual({ file: "ch/index", sections: [{ file: "ch/a" }] });
  });

  it("puts a top-level page in the last part of a Jupyter Book v1 book with parts", () => {
    const out = addTocPage(`root: intro\nparts:\n  - caption: A\n    chapters:\n      - file: a\n`, { file: "b.md" });
    expect(yaml.load(out).parts[0].chapters).toEqual([{ file: "a" }, { file: "b" }]);
  });

  it("refuses a chapter that is not there", () => {
    expect(() => addTocPage(myst, { file: "x.md", parentPath: [9] })).toThrow(/no longer/);
  });
});

describe("addTocChapter", () => {
  it("adds a mystmd chapter: its first page with an empty children list", () => {
    const out = addTocChapter(myst, { title: "Week 2", file: "week-2/index.md" });
    expect(tocOf(out).at(-1)).toEqual({ file: "week-2/index.md", children: [] });
  });

  it("adds a Jupyter Book v1 chapter with sections, or a part in a book of parts", () => {
    const chapters = addTocChapter(`root: intro\nchapters:\n  - file: a\n`, { title: "B", file: "b/index.md" });
    expect(yaml.load(chapters).chapters[1]).toEqual({ file: "b/index", sections: [] });
    const parts = addTocChapter(`root: intro\nparts:\n  - caption: A\n    chapters: [{file: a}]\n`, { title: "B", file: "b/index.md" });
    expect(yaml.load(parts).parts[1]).toEqual({ caption: "B", chapters: [{ file: "b/index" }] });
  });
});

describe("moveTocEntry", () => {
  it("reorders pages within a chapter without touching their files", () => {
    const out = moveTocEntry(myst, { from: [1, 1], to: [1, 0], position: "before" });
    expect(tocOf(out)[1].children).toEqual([{ file: "week1/b.md" }, { file: "week1/a.md" }]);
  });

  it("moves an entry after another at a different level", () => {
    const out = moveTocEntry(myst, { from: [1, 0], to: [0], position: "after" });
    expect(tocOf(out).map((n) => n.file ?? n.title)).toEqual(["intro.md", "week1/a.md", "Week 1", "chapter/overview.md", "ch2/index.md"]);
  });

  it("moves an entry into a chapter, and a page into another page that becomes a chapter", () => {
    const into = moveTocEntry(myst, { from: [0], to: [3], position: "inside" });
    expect(tocOf(into)[2].children.map((c) => c.file)).toEqual(["ch2/x.md", "intro.md"]);
    const page = moveTocEntry(`- a.md\n- b.md\n`, { from: [1], to: [0], position: "inside" });
    expect(yaml.load(page)).toEqual([{ file: "a.md", children: ["b.md"] }]);
  });

  it("takes the entry's comment along", () => {
    const out = moveTocEntry(myst, { from: [2], to: [0], position: "before" });
    expect(out).toContain("    # Pages at the top level that live in a folder\n    - file: chapter/overview.md\n    - file: intro.md");
    expect(out).toContain("# The book's settings");
    expect(out).toContain("title: Demo # shown in the header");
  });

  it("gives a moved page its new file, written as it was", () => {
    const renames = (p) => (p === "chapter/overview.md" ? "week1/overview.md" : null);
    const out = moveTocEntry(myst, { from: [2], to: [1], position: "inside", renames });
    expect(tocOf(out)[1].children.at(-1)).toEqual({ file: "week1/overview.md" });
    const jb1 = moveTocEntry(`root: i\nchapters:\n  - file: a/x\n  - file: b/index\n    sections: []\n`, {
      from: [0],
      to: [1],
      position: "inside",
      renames: (p) => (p === "a/x.md" ? "b/x.md" : null),
    });
    expect(yaml.load(jb1).chapters[0].sections).toEqual([{ file: "b/x" }]);
  });

  it("follows a chapter's folder wherever its files are listed", () => {
    const toc = [
      "project:",
      "  toc:",
      "    - file: index.md",
      "    - file: week1/index.md",
      "      children:",
      "        - week1/a.md",
      "        - file: week1/sub/b.md",
      "    - file: week2/index.md",
      "      children: []",
      "    - file: week10/c.md",
      "",
    ].join("\n");
    const renames = (p) => (p === "docs/week1" || p.startsWith("docs/week1/") ? `docs/week2/week1${p.slice("docs/week1".length)}` : null);
    const out = moveTocEntry(toc, { from: [1], to: [2], position: "inside", renames, prefix: "docs/" });
    expect(tocOf(out)).toEqual([
      { file: "index.md" },
      {
        file: "week2/index.md",
        children: [{ file: "week2/week1/index.md", children: ["week2/week1/a.md", { file: "week2/week1/sub/b.md" }] }],
      },
      // Only that folder: week10 is another one.
      { file: "week10/c.md" },
    ]);
    const jb1 = moveTocEntry(`root: week1/intro\nchapters:\n  - file: week1/x\n  - file: other\n`, {
      from: [0],
      to: [1],
      position: "after",
      renames: (p) => (p.startsWith("week1/") ? `w1/${p.slice(6)}` : null),
    });
    expect(yaml.load(jb1)).toEqual({ root: "w1/intro", chapters: [{ file: "other" }, { file: "w1/x" }] });
  });

  it("refuses to move a chapter into itself", () => {
    expect(() => moveTocEntry(myst, { from: [3], to: [3, 0], position: "after" })).toThrow(/itself/);
  });

  it("keeps parts at the top of a Jupyter Book v1 book, and pages inside them", () => {
    const book = `root: i\nparts:\n  - caption: A\n    chapters: [{file: a}]\n  - caption: B\n    chapters: [{file: b}]\n`;
    expect(() => moveTocEntry(book, { from: [1], to: [0], position: "inside" })).toThrow(/top level/);
    expect(() => moveTocEntry(book, { from: [0, 0], to: [1], position: "after" })).toThrow(/inside a part/);
    expect(yaml.load(moveTocEntry(book, { from: [1], to: [0], position: "before" })).parts.map((p) => p.caption)).toEqual(["B", "A"]);
  });

  it("refuses entries that are not there, and YAML it cannot edit safely", () => {
    expect(() => moveTocEntry(myst, { from: [9], to: [0], position: "after" })).toThrow(/changed/);
    expect(() => moveTocEntry(myst, { from: null, to: [0], position: "after" })).toThrow(/cannot be moved/);
    expect(() => moveTocEntry("project: [", { from: [0], to: [1], position: "after" })).toThrow(/not valid YAML/);
    const anchors = `project:\n  toc:\n    - &a {file: a.md}\n    - *a\n`;
    expect(() => moveTocEntry(anchors, { from: [1], to: [0], position: "before" })).toThrow(/anchors/);
  });
});
