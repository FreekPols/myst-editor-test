import { describe, it, expect, vi } from "vite-plus/test";
import { applyPluginBackends, runPluginSetups, PluginStop, PLUGIN_API_VERSION } from "../../src/myst-git/plugins.js";

const backend = () => ({
  initialBranches: ["main", "a", "b"],
  projectId: 7,
  defaultBranch: "main",
  getBranches: async () => ["main", "a", "b"],
  getCurrentUser: vi.fn(async () => ({ username: "jdoe", accessLevel: 30 })),
});

describe("applyPluginBackends", () => {
  it("lets each plugin wrap the backend in turn, async or not", async () => {
    const first = { name: "first", wrapBackend: (b) => ({ ...b, initialBranches: b.initialBranches.filter((x) => x !== "b") }) };
    const second = { name: "second", wrapBackend: async (b) => ({ ...b, initialBranches: [...b.initialBranches].reverse() }) };
    const result = await applyPluginBackends([first, second], backend(), { kind: "stub" });
    expect(result.initialBranches).toEqual(["a", "main"]);
  });

  it("keeps the backend when a plugin returns nothing, and skips plugins without wrapBackend", async () => {
    const b = backend();
    const result = await applyPluginBackends(
      [
        { name: "watcher", wrapBackend: () => undefined },
        { name: "ui-only", setup() {} },
      ],
      b,
      { kind: "stub" },
    );
    expect(result).toBe(b);
  });

  it("hands plugins the project, the default branch, the API and one shared user lookup", async () => {
    const b = backend();
    const api = vi.fn();
    const seen = [];
    const peek = { name: "peek", wrapBackend: async (_b, ctx) => void seen.push({ ...ctx, user: await ctx.user() }) };
    await applyPluginBackends([peek, peek], b, { kind: "gitlab", api });
    expect(seen[0]).toMatchObject({ backend: "gitlab", projectId: 7, defaultBranch: "main", api, user: { username: "jdoe" } });
    // Two plugins asked; GitLab was asked once.
    expect(b.getCurrentUser).toHaveBeenCalledTimes(1);
  });

  it("stops with the plugin's own message when it calls fail", async () => {
    const gate = { name: "gate", wrapBackend: (_b, ctx) => ctx.fail("You are not listed for this course.") };
    const after = { name: "after", wrapBackend: vi.fn() };
    const err = await applyPluginBackends([gate, after], backend(), { kind: "stub" }).catch((e) => e);
    expect(err).toBeInstanceOf(PluginStop);
    expect(err.message).toBe("You are not listed for this course.");
    expect(err.plugin).toBe("gate");
    expect(after.wrapBackend).not.toHaveBeenCalled();
  });

  it("turns any other error into a stop that names the plugin", async () => {
    const broken = { name: "broken", wrapBackend: async () => Promise.reject(new Error("CSV not found")) };
    const err = await applyPluginBackends([broken], backend(), { kind: "stub" }).catch((e) => e);
    expect(err).toBeInstanceOf(PluginStop);
    expect(err.message).toBe('The "broken" add-on could not start: CSV not found');
  });

  it("warns about a plugin written for another API version, and still runs it", async () => {
    const warn = vi.spyOn(console, "warn").mockImplementation(() => {});
    const wrapBackend = vi.fn();
    await applyPluginBackends([{ name: "future", apiVersion: PLUGIN_API_VERSION + 1, wrapBackend }], backend(), { kind: "stub" });
    expect(warn).toHaveBeenCalledWith(expect.stringContaining('"future" targets plugin API 2'));
    expect(wrapBackend).toHaveBeenCalled();
    warn.mockRestore();
  });
});

describe("runPluginSetups", () => {
  it("runs every setup with the editor, and a failing one does not stop the rest", async () => {
    const error = vi.spyOn(console, "error").mockImplementation(() => {});
    const notify = vi.fn();
    const editor = { state: {}, git: {} };
    const ok = { name: "ok", setup: vi.fn() };
    const throws = {
      name: "throws",
      setup: () => {
        throw new Error("boom");
      },
    };
    const rejects = { name: "rejects", setup: async () => Promise.reject(new Error("later")) };
    runPluginSetups([throws, rejects, ok], editor, notify);
    await new Promise((r) => setTimeout(r, 0));

    expect(ok.setup).toHaveBeenCalledWith(editor);
    expect(notify).toHaveBeenCalledWith('The "throws" add-on failed to start; the editor works without it.');
    expect(notify).toHaveBeenCalledWith('The "rejects" add-on failed to start; the editor works without it.');
    error.mockRestore();
  });
});
