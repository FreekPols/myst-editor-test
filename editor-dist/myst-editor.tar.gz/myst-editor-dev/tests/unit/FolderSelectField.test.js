import { describe, it, expect, vi, beforeEach, afterEach } from "vite-plus/test";
import { render, h } from "preact";
import { FolderSelectField } from "../../src/components/FormDialog.jsx";

describe("FolderSelectField", () => {
  let container;

  beforeEach(() => {
    container = document.createElement("div");
    document.body.appendChild(container);
  });

  afterEach(() => {
    container.remove();
    container = null;
  });

  const sampleOptions = [
    { label: "(Top level)", value: "" },
    { label: "Chapter 1", value: "ch1" },
    { label: "Chapter 2", value: "ch2" },
  ];

  it("renders with default display label for root level", () => {
    render(
      h(FolderSelectField, {
        id: "field-folder",
        field: { name: "parentFolder", options: sampleOptions, allowCreate: true },
        value: "",
        onChange: vi.fn(),
      }),
      container,
    );

    const input = container.querySelector("input");
    expect(input.value).toBe("(Top level)");
  });

  it("opens dropdown and allows selecting an existing folder", async () => {
    const onChange = vi.fn();
    render(
      h(FolderSelectField, {
        id: "field-folder",
        field: { name: "parentFolder", options: sampleOptions, allowCreate: true },
        value: "",
        onChange,
      }),
      container,
    );

    const input = container.querySelector("input");
    input.click();
    await new Promise((r) => setTimeout(r, 10));

    const dropdown = container.querySelector(".dropdown-menu");
    expect(dropdown).not.toBeNull();

    const items = Array.from(dropdown.querySelectorAll(".dropdown-item"));
    const ch1Item = items.find((el) => el.textContent.includes("Chapter 1"));
    expect(ch1Item).not.toBeNull();

    ch1Item.click();
    expect(onChange).toHaveBeenCalledWith("ch1");
  });

  it("allows creating a new folder inline", async () => {
    const onChange = vi.fn();
    render(
      h(FolderSelectField, {
        id: "field-folder",
        field: { name: "parentFolder", options: sampleOptions, allowCreate: true },
        value: "",
        onChange,
      }),
      container,
    );

    const input = container.querySelector("input");
    input.click();
    await new Promise((r) => setTimeout(r, 10));

    const createBtn = container.querySelector(".create-folder-btn");
    expect(createBtn).not.toBeNull();
    createBtn.click();
    await new Promise((r) => setTimeout(r, 10));

    const createInput = container.querySelector('.dropdown-create-row input[type="text"]');
    expect(createInput).not.toBeNull();

    createInput.value = "New Section";
    createInput.dispatchEvent(new Event("input", { bubbles: true }));
    await new Promise((r) => setTimeout(r, 20));

    const addBtn = container.querySelector(".create-submit-btn");
    expect(addBtn).not.toBeNull();
    addBtn.click();
    await new Promise((r) => setTimeout(r, 20));

    expect(onChange).toHaveBeenCalledWith("new:New Section");
  });
});
