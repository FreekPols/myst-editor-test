import { describe, it, expect } from "vite-plus/test";
import { pageTitle } from "../../src/myst-git/pageTitle.js";

describe("pageTitle", () => {
  it("takes the first level-one heading", () => {
    expect(pageTitle("# Wavefield propagation\n\nText\n\n# Another\n")).toBe("Wavefield propagation");
  });

  it("prefers the frontmatter title, which is what the book itself shows", () => {
    expect(pageTitle("---\ntitle: From frontmatter\n---\n# From heading\n")).toBe("From frontmatter");
    expect(pageTitle('---\ntitle: "Quoted"\n---\n')).toBe("Quoted");
  });

  it("looks past frontmatter that has no title", () => {
    expect(pageTitle("---\nkernelspec:\n  name: python3\n---\n(label)=\n# The heading\n")).toBe("The heading");
  });

  it("ignores a nested title key, which belongs to something else", () => {
    expect(pageTitle("---\nauthor:\n  title: Dr\n---\n# Real title\n")).toBe("Real title");
  });

  it("does not mistake a comment in a code cell for the title", () => {
    expect(pageTitle("```{code-cell} python\n# set up\nimport numpy\n```\n\n# After the cell\n")).toBe("After the cell");
  });

  it("ignores deeper headings and returns null when there is no title", () => {
    expect(pageTitle("## Only a section\n")).toBeNull();
    expect(pageTitle("")).toBeNull();
  });
});
