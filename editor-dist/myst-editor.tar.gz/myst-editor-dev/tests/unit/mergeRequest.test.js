import { describe, it, expect } from "vite-plus/test";
import { buildMergeRequestUrl } from "../../src/myst-git/mergeRequest.js";

describe("buildMergeRequestUrl", () => {
  it("generates the exact expected GitLab new merge request URL with default/user query params", () => {
    const url = buildMergeRequestUrl({
      projectWebUrl: "https://gitlab.tudelft.nl/combine/myst-editor",
      sourceProjectId: 28652,
      sourceBranch: "development",
      targetProjectId: 28652,
      targetBranch: "main",
    });

    expect(url).toBe(
      "https://gitlab.tudelft.nl/combine/myst-editor/-/merge_requests/new?merge_request%5Bsource_project_id%5D=28652&merge_request%5Bsource_branch%5D=development&merge_request%5Btarget_project_id%5D=28652&merge_request%5Btarget_branch%5D=main",
    );
  });

  it("refuses to guess the project", () => {
    // A default project would send authors to open merge requests in a repository that is not theirs.
    expect(() => buildMergeRequestUrl({ sourceBranch: "feature", targetBranch: "main" })).toThrow(/projectWebUrl/);
  });

  it("leaves out parameters that are not given", () => {
    const url = buildMergeRequestUrl({ projectWebUrl: "https://gitlab.example.org/group/book", sourceBranch: "feature" });
    expect(url).toBe("https://gitlab.example.org/group/book/-/merge_requests/new?merge_request%5Bsource_branch%5D=feature");
  });

  it("handles trailing slash in projectWebUrl cleanly", () => {
    const url = buildMergeRequestUrl({
      projectWebUrl: "https://gitlab.tudelft.nl/combine/myst-editor///",
      sourceBranch: "feature-test",
      targetBranch: "development",
    });
    expect(url.startsWith("https://gitlab.tudelft.nl/combine/myst-editor/-/merge_requests/new?")).toBe(true);
    expect(url).toContain("merge_request%5Bsource_branch%5D=feature-test");
    expect(url).toContain("merge_request%5Btarget_branch%5D=development");
  });
});
