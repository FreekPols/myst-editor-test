import { describe, it, expect } from "vite-plus/test";
import { buildConsumerExtensions } from "../../src/markdown/transformsAdapter.ts";
import { renderMyst } from "../../src/markdown/mystRenderer.ts";

// A stand-in for the preview root. PreviewWrapper only calls getElementById on it, but the async
// placeholder path also hands it to MutationObserver.observe, so it has to be a real node.
const previewStub = () => {
  const fragment = document.createDocumentFragment();
  fragment.getElementById = () => null;
  return fragment;
};

const renderWith = (src, opts) => {
  const cache = new Map();
  const { roles, directives, transformsPlugin } = buildConsumerExtensions({ ...opts, previewNode: previewStub(), cache });
  const lineMap = new Map();
  return renderMyst(src, { lineMap, roles, directives, transformsPlugin }).html;
};

describe("transformsAdapter (consumer API on mystmd)", () => {
  it("maps a custom role (git.html {say}) to rendered html", () => {
    const html = renderWith("Hello {say}`world`.\n", {
      customRoles: [{ target: "say", transform: (content) => `bob says: '${content}'` }],
    });
    expect(html).toContain("bob says: 'world'");
  });

  it("maps a custom directive (git.html {bold}) reading data.body", () => {
    const html = renderWith("```{bold}\nstrong text\n```\n", {
      customDirectives: [{ target: "bold", transform: (_input, data) => `<b class="bd">${data.body}</b>` }],
    });
    expect(html).toContain('<b class="bd">strong text</b>');
  });

  it("applies a regex text transform (git.html issue links)", () => {
    const html = renderWith("See owner/repo#42 today.\n", {
      transforms: [
        {
          target: /[0-9a-z-]+\/[0-9a-z-]+#\d{1,10}/g,
          transform: (match) => {
            const [repo, id] = match.split("#");
            return `<a href="https://github.com/${repo}/issues/${id}">${match}</a>`;
          },
        },
      ],
    });
    expect(html).toContain('href="https://github.com/owner/repo/issues/42"');
  });

  it("emits a placeholder span synchronously for an async transform (|date|)", () => {
    const html = renderWith("Today is |date|.\n", {
      transforms: [{ target: /\|date\|/g, transform: () => new Promise((r) => r("2026-07-28")) }],
    });
    // async result is not available at processSync time; a placeholder span is emitted and filled after mount
    expect(html).toMatch(/<span id="placeholder-\d+"/);
  });
});
