import { describe, it, expect } from "vite-plus/test";
import {
  normalizePath,
  rebaseReferences,
  relinkReferences,
  slugify,
  resolveAssetPath,
  relativeTo,
  sanitizeFileName,
  withUniqueSuffix,
  isExternalUrl,
  imageReferences,
} from "../../src/myst-git/assetPaths.js";

describe("resolveAssetPath", () => {
  it("resolves a relative reference against the page's own folder", () => {
    // The bug this replaces: the reference was fetched from the repository root as written.
    expect(resolveAssetPath("wavefieldpropagation/wavefieldpropagation.md", "huygensprinciple.png")).toBe(
      "wavefieldpropagation/huygensprinciple.png",
    );
    expect(resolveAssetPath("chapter1/page.md", "images/fig.png")).toBe("chapter1/images/fig.png");
    expect(resolveAssetPath("page.md", "fig.png")).toBe("fig.png");
  });

  it("follows ./ and ../", () => {
    expect(resolveAssetPath("book/chapter1/page.md", "../shared/fig.png")).toBe("book/shared/fig.png");
    expect(resolveAssetPath("chapter1/page.md", "./images/./fig.png")).toBe("chapter1/images/fig.png");
  });

  it("resolves an absolute reference against the project root, not the repository root", () => {
    expect(resolveAssetPath("docs/chapter1/page.md", "/images/fig.png", "docs")).toBe("docs/images/fig.png");
    expect(resolveAssetPath("chapter1/page.md", "/fig.png")).toBe("fig.png");
  });

  it("drops a query or fragment, and decodes escapes", () => {
    expect(resolveAssetPath("a/page.md", "my%20fig.png?raw=1#x")).toBe("a/my fig.png");
  });

  it("leaves URLs that are not repository paths alone", () => {
    expect(resolveAssetPath("a/page.md", "https://example.org/x.png")).toBeNull();
    expect(resolveAssetPath("a/page.md", "data:image/png;base64,xyz")).toBeNull();
    expect(resolveAssetPath("a/page.md", "//cdn.example.org/x.png")).toBeNull();
    expect(resolveAssetPath("a/page.md", "")).toBeNull();
    expect(isExternalUrl("blob:http://localhost/123")).toBe(true);
  });

  it("never climbs above the repository root", () => {
    expect(normalizePath("../../x.png")).toBe("x.png");
  });
});

describe("relativeTo", () => {
  it("writes the path a page needs to reach the file", () => {
    expect(relativeTo("chapter1/page.md", "chapter1/images/fig.png")).toBe("images/fig.png");
    expect(relativeTo("page.md", "images/fig.png")).toBe("images/fig.png");
    expect(relativeTo("book/chapter1/page.md", "book/shared/fig.png")).toBe("../shared/fig.png");
  });

  it("round-trips through resolveAssetPath", () => {
    for (const [page, file] of [
      ["a/b/page.md", "a/c/d.png"],
      ["page.md", "x/y.png"],
      ["a/page.md", "z.png"],
    ]) {
      expect(resolveAssetPath(page, relativeTo(page, file))).toBe(file);
    }
  });
});

describe("sanitizeFileName", () => {
  it("makes a name safe for a path and a directive line", () => {
    expect(sanitizeFileName("Screen Shot 2026-10-13 at 10.42.17.PNG")).toBe("screen-shot-2026-10-13-at-10.42.17.png");
    expect(sanitizeFileName("Café diagram (v2).jpeg")).toBe("cafe-diagram-v2.jpeg");
    expect(sanitizeFileName("C:\\Users\\me\\fig.png")).toBe("fig.png");
  });

  it("never returns an empty stem", () => {
    expect(sanitizeFileName("???.png")).toBe("image.png");
    expect(sanitizeFileName("")).toBe("image");
  });
});

describe("withUniqueSuffix", () => {
  it("keeps a free name and numbers a taken one", async () => {
    const taken = new Set(["a/fig.png", "a/fig-2.png"]);
    const exists = async (p) => taken.has(p);
    expect(await withUniqueSuffix("a/new.png", exists)).toBe("a/new.png");
    expect(await withUniqueSuffix("a/fig.png", exists)).toBe("a/fig-3.png");
  });

  it("does not mistake a dot in a folder name for an extension", async () => {
    expect(await withUniqueSuffix("v1.2/fig", async (p) => p === "v1.2/fig")).toBe("v1.2/fig-2");
  });
});

describe("imageReferences", () => {
  it("finds figures, images, Markdown images and HTML images", () => {
    const text = [
      "```{figure} images/one.png",
      ":alt: One",
      "```",
      ":::{image} ../two.jpg",
      ":::",
      'See ![a chart](images/three.png "title") and ![](<images/four five.png>).',
      '<img alt="x" src="five.svg">',
    ].join("\n");
    expect(imageReferences(text)).toEqual(["images/one.png", "../two.jpg", "images/three.png", "images/four five.png", "five.svg"]);
  });

  it("ignores other directives and plain links", () => {
    expect(imageReferences("```{code-cell} python\n```\n[a link](page.md)")).toEqual([]);
  });
});

describe("slugify", () => {
  it("makes a folder or file name from a title", () => {
    expect(slugify("Week 1: Forces")).toBe("week-1-forces");
    expect(slugify("Ünïcode  café")).toBe("unicode-cafe");
    expect(slugify("  --  ")).toBe("");
  });
});

describe("rebaseReferences", () => {
  it("keeps a moved page's images, includes and links pointing at the same files", () => {
    const page = [
      "![plot](images/plot.png)",
      ":::{figure} ../shared/fig.png",
      "```{include} snippet.md",
      "See [the next page](next.md#part) and [another site](https://example.org).",
      '<img src="images/a.png" alt="">',
      "![root](/logo.png) [anchor](#top) ![spaced](<my images/x.png>)",
    ].join("\n");
    expect(rebaseReferences(page, "chapter/page.md", "week1/sub/page.md").split("\n")).toEqual([
      "![plot](../../chapter/images/plot.png)",
      ":::{figure} ../../shared/fig.png",
      "```{include} ../../chapter/snippet.md",
      "See [the next page](../../chapter/next.md#part) and [another site](https://example.org).",
      '<img src="../../chapter/images/a.png" alt="">',
      "![root](/logo.png) [anchor](#top) ![spaced](<../../chapter/my images/x.png>)",
    ]);
  });

  it("changes nothing when the page stays in its folder", () => {
    expect(rebaseReferences("![a](b.png)", "x/a.md", "x/b.md")).toBe("![a](b.png)");
  });
});

describe("relinkReferences", () => {
  const folder = (from, to) => (p) => (p === from || p.startsWith(`${from}/`) ? to + p.slice(from.length) : null);

  it("points a page that stays at files that moved, and leaves the rest as written", () => {
    const page = [
      "See [week 1](./week1/index.md#start), ![fig](week1/img/f.png) and [notes](notes.md).",
      "```{include} week1/snippet.md",
      "[def]: week1/a.md",
      "![abs](/week1/img/f.png) ![other](/logo.png) [web](https://example.org/week1/a.md)",
    ].join("\n");
    expect(
      relinkReferences(page, { from: "docs/index.md", retarget: folder("docs/week1", "docs/part1/week1"), projectRoot: "docs" }).split("\n"),
    ).toEqual([
      "See [week 1](part1/week1/index.md#start), ![fig](part1/week1/img/f.png) and [notes](notes.md).",
      "```{include} part1/week1/snippet.md",
      "[def]: part1/week1/a.md",
      "![abs](/part1/week1/img/f.png) ![other](/logo.png) [web](https://example.org/week1/a.md)",
    ]);
  });

  it("keeps a page that moves with its folder pointing at its neighbours, and at what stayed", () => {
    const page = "![](img/f.png) [b](b.md) [home](../index.md)";
    expect(relinkReferences(page, { from: "docs/week1/a.md", to: "docs/part1/week1/a.md", retarget: folder("docs/week1", "docs/part1/week1") })).toBe(
      "![](img/f.png) [b](b.md) [home](../../index.md)",
    );
  });

  it("changes nothing when nothing it points at moved", () => {
    const page = "[a](./x.md) ![b](<my img.png>)";
    expect(relinkReferences(page, { from: "docs/p.md", retarget: folder("docs/week1", "docs/w1") })).toBe(page);
  });
});
