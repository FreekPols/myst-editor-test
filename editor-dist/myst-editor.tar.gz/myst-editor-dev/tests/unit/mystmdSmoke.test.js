import { describe, it, expect } from "vite-plus/test";
import { mystParser } from "myst-parser";
import { mystToHast, formatHtml, transform, State } from "myst-to-html";
import rehypeStringify from "rehype-stringify";
import { unified } from "unified";

// Acid test: myst-parser uses markdown-it@13 internally while its plugins dedupe onto our top-level
// markdown-it@14. This confirms that mixed state actually produces correct output through the pipeline,
// resolving the utils.js->.mjs alias the same way the browser build does.
const render = (src) =>
  String(unified().use(mystParser).use(transform, new State()).use(mystToHast).use(formatHtml).use(rehypeStringify).processSync(src));

describe("mystmd pipeline smoke", () => {
  it("renders headings, inline + block math, admonitions, and tables", () => {
    const src = [
      "# Hello",
      "",
      "Inline math $a^2+b^2$ and a block:",
      "",
      "$$\\int_0^1 x\\,dx$$",
      "",
      "```{note}",
      "An **admonition** with *markdown*.",
      "```",
      "",
      "| a | b |",
      "|---|---|",
      "| 1 | 2 |",
      "",
    ].join("\n");
    const html = render(src);
    expect(html).toContain("<h1");
    expect(html).toContain("admonition");
    expect(html).toContain("<table");
    // math is emitted as a node with a math class (rendered to MathML/KaTeX later in the hast stage)
    expect(html).toMatch(/class="[^"]*math/);
    // the embedded markdown inside the admonition must actually be parsed, not shown as a bare card
    expect(html).toContain("<strong>");
  });

  it("exposes source line positions on the mdast (needed for the data-line-id contract)", () => {
    const tree = unified().use(mystParser).parse("# Title\n\nA paragraph.\n");
    const heading = tree.children.find((n) => n.type === "heading");
    expect(heading?.position?.start?.line).toBe(1);
  });
});
