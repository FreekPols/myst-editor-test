import { describe, it, expect, vi, beforeEach, afterEach } from "vite-plus/test";
import { render, h } from "preact";
import { signal } from "@preact/signals";
import { TableOfContents } from "../../src/myst-git/TableOfContents.jsx";
import Sidebar from "../../src/myst-git/Sidebar.jsx";
import { MystState, createMystState } from "../../src/mystState.js";
import { parseTocTree } from "../../src/myst-git/toc.js";

const tick = () => new Promise((r) => setTimeout(r, 10));

const indexYaml = `
project:
  toc:
    - file: index.md
    - file: ch1/index.md
      children:
        - file: ch1/sec1.md
`;

/** Every file the toc lists exists, unless `files` says otherwise. */
const pagesOf = (tree) => tree.flatMap((n) => [...(n.file ? [n.file] : []), ...pagesOf(n.children)]);

describe("TableOfContents as a tree", () => {
  let container;
  let state;

  beforeEach(() => {
    container = document.createElement("div");
    document.body.appendChild(container);
    window.myst_editor = { "test-toc": {} };
    state = createMystState({ id: "test-toc" });
  });

  afterEach(() => {
    render(null, container);
    container.remove();
  });

  function show({ yaml = indexYaml, tree = signal(parseTocTree(yaml)), currentFile = "index.md", files = null, query = "", onMoveItem = null } = {}) {
    const indexedFiles = signal((files ?? pagesOf(tree.value)).map((file) => ({ file, fileName: file })));
    render(
      h(MystState.Provider, { value: state }, [
        h(TableOfContents, {
          indexedFiles,
          markedFiles: signal([]),
          currentFile,
          onFileClick: vi.fn(),
          getText: vi.fn(async () => ""),
          branch: signal("main"),
          commit: signal({ hash: "abc1234" }),
          tree,
          query,
          onMoveItem,
        }),
      ]),
      container,
    );
    return { tree };
  }
  const names = () => Array.from(container.querySelectorAll(".file-title, .file-name")).map((el) => el.textContent);

  it("keeps chapters closed unless they hold the open page", () => {
    show();
    expect(names()).toContain("index.md");
    expect(names()).toContain("ch1/index.md");
    expect(names()).not.toContain("sec1.md");
    expect(container.querySelector(".toggle-button").getAttribute("aria-expanded")).toBe("false");
  });

  it("opens the chapter holding the open page, naming its pages from the chapter's folder", () => {
    show({ currentFile: "ch1/sec1.md" });
    expect(names()).toContain("sec1.md");
    expect(container.querySelector(".toggle-button").getAttribute("aria-expanded")).toBe("true");
  });

  it("opens and closes a chapter with its toggle", async () => {
    show();
    const toggle = container.querySelector(".toggle-button");
    toggle.click();
    await tick();
    expect(toggle.getAttribute("aria-expanded")).toBe("true");
    expect(names()).toContain("sec1.md");
  });

  it("follows the table of contents as it changes", async () => {
    const { tree } = show();
    tree.value = parseTocTree(`project:\n  toc:\n    - file: index.md\n    - title: Week 2\n      children: []\n`);
    await tick();
    expect(names()).toContain("Week 2");
  });

  it("says a chapter has no pages yet", async () => {
    show({ yaml: `project:\n  toc:\n    - file: index.md\n    - title: Empty\n      children: []\n` });
    container.querySelector(".folder-title-only").click();
    await tick();
    expect(container.querySelector(".empty-folder-hint").textContent).toBe("No pages yet");
  });

  it("opens two chapters with the same title separately", async () => {
    show({
      yaml: `project:\n  toc:\n    - title: Exercises\n      children: [{file: w1/ex.md}]\n    - title: Exercises\n      children: [{file: w2/ex.md}]\n`,
      currentFile: "none.md",
    });
    const [first, second] = container.querySelectorAll(".folder-title-only");
    first.click();
    await tick();
    expect(first.getAttribute("aria-expanded")).toBe("true");
    expect(second.getAttribute("aria-expanded")).toBe("false");
  });

  it("leaves out pages whose file is missing", () => {
    show({ files: ["index.md", "ch1/index.md"], currentFile: "ch1/index.md" });
    expect(names()).not.toContain("sec1.md");
  });

  it("moves entries with Alt + arrow keys, as dragging does", () => {
    const onMoveItem = vi.fn();
    show({ yaml: `${indexYaml}    - file: other.md\n`, currentFile: "ch1/sec1.md", onMoveItem });
    const button = (name) => Array.from(container.querySelectorAll("button")).find((b) => b.textContent.endsWith(name));
    const press = (el, key) => el.dispatchEvent(new KeyboardEvent("keydown", { key, altKey: true, bubbles: true }));

    press(button("ch1/index.md"), "ArrowUp");
    expect(onMoveItem).toHaveBeenLastCalledWith(
      expect.objectContaining({ file: "ch1/index.md" }),
      expect.objectContaining({ file: "index.md" }),
      "before",
    );

    press(button("other.md"), "ArrowRight");
    expect(onMoveItem).toHaveBeenLastCalledWith(
      expect.objectContaining({ file: "other.md" }),
      expect.objectContaining({ file: "ch1/index.md" }),
      "inside",
    );

    // The first entry has nothing above it to go before or into.
    onMoveItem.mockClear();
    press(button("index.md"), "ArrowUp");
    press(button("index.md"), "ArrowRight");
    expect(onMoveItem).not.toHaveBeenCalled();

    press(button("sec1.md"), "ArrowLeft");
    expect(onMoveItem).toHaveBeenLastCalledWith(
      expect.objectContaining({ file: "ch1/sec1.md" }),
      expect.objectContaining({ file: "ch1/index.md" }),
      "after",
    );
    expect(button("sec1.md").getAttribute("aria-keyshortcuts")).toContain("Alt+ArrowUp");
  });

  it("does not offer to move entries while the list is filtered", () => {
    show({ onMoveItem: vi.fn(), query: "index" });
    expect(container.querySelector('[draggable="true"]')).toBeNull();
  });

  it("does not move the Jupyter Book v1 root page", () => {
    show({ yaml: `format: jb-book\nroot: intro\nchapters:\n  - file: a\n`, onMoveItem: vi.fn() });
    const draggable = Array.from(container.querySelectorAll('[draggable="true"]')).map((el) => el.textContent);
    expect(draggable).toEqual(["a"]);
  });

  it("stays a flat, indented list without a tree", () => {
    const indexedFiles = signal([
      { file: "a.md", fileName: "a.md", depth: 0 },
      { file: "b.md", fileName: "b.md", depth: 1 },
    ]);
    render(
      h(MystState.Provider, { value: state }, [
        h(TableOfContents, {
          indexedFiles,
          markedFiles: signal([]),
          currentFile: "a.md",
          onFileClick: vi.fn(),
          branch: signal("main"),
          commit: signal({ hash: "abc1234" }),
        }),
      ]),
      container,
    );
    expect(container.querySelector("li.depth-1")?.textContent).toContain("b.md");
  });
});

describe("Sidebar action buttons", () => {
  let container;

  beforeEach(() => {
    container = document.createElement("div");
    document.body.appendChild(container);
  });

  afterEach(() => {
    render(null, container);
    container.remove();
  });

  it("offers to add a page and a chapter", () => {
    const onAddFile = vi.fn();
    const onAddFolder = vi.fn();
    render(
      h(Sidebar, {
        file: signal("index.md"),
        branch: signal("main"),
        commit: signal({ hash: "abc" }),
        getText: vi.fn(),
        indexFile: signal(""),
        indexedFiles: signal([]),
        unIndexedFiles: signal([]),
        markedFiles: signal([]),
        switchFile: vi.fn(),
        collapseButton: h("button", { "data-testid": "collapse" }),
        onAddFile,
        onAddFolder,
      }),
      container,
    );
    container.querySelector('button[title="Add page"]').click();
    container.querySelector('button[title="Add chapter"]').click();
    expect(onAddFile).toHaveBeenCalledTimes(1);
    expect(onAddFolder).toHaveBeenCalledTimes(1);
  });
});
