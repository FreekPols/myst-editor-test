import { describe, it, expect, vi, beforeEach, afterEach } from "vite-plus/test";
import { render, h } from "preact";
import { SearchableBranchSelect } from "../../src/myst-git/SearchableBranchSelect.jsx";

const tick = () => new Promise((r) => setTimeout(r, 20));

describe("SearchableBranchSelect", () => {
  let container;

  beforeEach(() => {
    container = document.createElement("div");
    document.body.appendChild(container);
  });

  afterEach(() => {
    container.remove();
    container = null;
  });

  it("renders with initial selected value and shows only existing branches in dropdown", async () => {
    const branches = ["main", "development", "feature-docs"];
    const onChange = vi.fn();

    render(
      h(SearchableBranchSelect, {
        id: "test-branch-select",
        value: "main",
        onChange,
        branches,
        defaultBranch: "main",
        currentBranch: "development",
      }),
      container,
    );

    const input = container.querySelector("input.search-input");
    expect(input).not.toBeNull();
    expect(input.value).toBe("main");

    // Click toggle button to open dropdown
    const toggleBtn = container.querySelector("button.toggle-btn");
    toggleBtn.dispatchEvent(new MouseEvent("click", { bubbles: true }));
    await tick();

    const dropdown = container.querySelector("ul.dropdown-menu");
    expect(dropdown).not.toBeNull();

    // Verify all existing branches are shown and nothing else
    const items = container.querySelectorAll("li.dropdown-item");
    expect(items.length).toBe(3);

    const branchNames = Array.from(items).map((el) => el.querySelector(".branch-name")?.textContent);
    expect(branchNames).toEqual(["main", "development", "feature-docs"]);

    // Verify badges
    expect(items[0].querySelector(".badge-default")).not.toBeNull();
    expect(items[1].querySelector(".badge-current")).not.toBeNull();
  });

  it("filters branches dynamically when typing in search input", async () => {
    const branches = ["main", "development", "feature-login", "feature-logout"];
    const onChange = vi.fn();

    render(
      h(SearchableBranchSelect, {
        id: "test-branch-select",
        value: "main",
        onChange,
        branches,
      }),
      container,
    );

    const toggleBtn = container.querySelector("button.toggle-btn");
    toggleBtn.dispatchEvent(new MouseEvent("click", { bubbles: true }));
    await tick();

    const input = container.querySelector("input.search-input");
    input.value = "login";
    input.dispatchEvent(new Event("input", { bubbles: true }));
    await tick();

    const items = container.querySelectorAll("li.dropdown-item");
    expect(items.length).toBe(1);
    expect(items[0].querySelector(".branch-name")?.textContent).toBe("feature-login");

    // Click the branch
    items[0].dispatchEvent(new MouseEvent("mousedown", { bubbles: true }));
    await tick();
    expect(onChange).toHaveBeenCalledWith("feature-login", "branch");
  });

  it("shows an empty state when no existing branches match query", async () => {
    const branches = ["main", "development"];

    render(
      h(SearchableBranchSelect, {
        id: "test-branch-select",
        value: "main",
        onChange: vi.fn(),
        branches,
      }),
      container,
    );

    const toggleBtn = container.querySelector("button.toggle-btn");
    toggleBtn.dispatchEvent(new MouseEvent("click", { bubbles: true }));
    await tick();

    const input = container.querySelector("input.search-input");
    input.value = "nonexistent";
    input.dispatchEvent(new Event("input", { bubbles: true }));
    await tick();

    const noMatches = container.querySelector("li.no-branches");
    expect(noMatches).not.toBeNull();
    expect(noMatches.textContent).toContain('No existing branches match "nonexistent"');
  });

  it("shows branches in dropdown list initially and shows commit SHA and message on search", async () => {
    const branches = ["main", "development"];
    const commits = [
      { hash: "4a3f2b1", message: "Fix layout bug" },
      { hash: "9e8d7c6", message: "Update documentation" },
    ];
    const onChange = vi.fn();
    const onModeChange = vi.fn();

    render(
      h(SearchableBranchSelect, {
        id: "source-select",
        value: "development",
        onChange,
        onModeChange,
        branches,
        commits,
      }),
      container,
    );

    const toggleBtn = container.querySelector("button.toggle-btn");
    toggleBtn.dispatchEvent(new MouseEvent("click", { bubbles: true }));
    await tick();

    // Initially when query is empty, only branches are shown in dropdown list
    const branchItems = container.querySelectorAll("li.branch-item");
    expect(branchItems.length).toBe(2);
    expect(container.querySelectorAll("li.commit-item").length).toBe(0);

    // Now search for commit message "layout"
    const input = container.querySelector("input.search-input");
    input.value = "layout";
    input.dispatchEvent(new Event("input", { bubbles: true }));
    await tick();

    // Commit item appears with commit hash and message
    const commitItems = container.querySelectorAll("li.commit-item");
    expect(commitItems.length).toBe(1);
    expect(commitItems[0].querySelector(".commit-hash")?.textContent).toBe("4a3f2b1");
    expect(commitItems[0].querySelector(".commit-message")?.textContent).toBe("Fix layout bug");

    // Clicking the commit item selects its hash and triggers mode change to commit
    commitItems[0].dispatchEvent(new MouseEvent("mousedown", { bubbles: true }));
    await tick();
    expect(onChange).toHaveBeenCalledWith("4a3f2b1", "commit");
    expect(onModeChange).toHaveBeenCalledWith("commit");
  });

  it("shows only commit messages and no branches when mode is commit", async () => {
    const branches = ["main", "development"];
    const commits = [
      { hash: "4a3f2b1", message: "Fix layout bug" },
      { hash: "9e8d7c6", message: "Update documentation" },
    ];
    const onChange = vi.fn();
    const onModeChange = vi.fn();

    render(
      h(SearchableBranchSelect, {
        id: "commit-select",
        mode: "commit",
        value: "4a3f2b1",
        onChange,
        onModeChange,
        branches,
        commits,
      }),
      container,
    );

    const toggleBtn = container.querySelector("button.toggle-btn");
    toggleBtn.dispatchEvent(new MouseEvent("click", { bubbles: true }));
    await tick();

    // No branches should be in dropdown initially
    expect(container.querySelectorAll("li.branch-item").length).toBe(0);

    // Only commit messages are shown
    const commitItems = container.querySelectorAll("li.commit-item");
    expect(commitItems.length).toBe(2);
    expect(commitItems[0].querySelector(".commit-message")?.textContent).toBe("Fix layout bug");
    expect(commitItems[1].querySelector(".commit-message")?.textContent).toBe("Update documentation");

    // Filter commits by message
    const input = container.querySelector("input.search-input");
    input.value = "documentation";
    input.dispatchEvent(new Event("input", { bubbles: true }));
    await tick();

    const filteredItems = container.querySelectorAll("li.commit-item");
    expect(filteredItems.length).toBe(1);
    expect(filteredItems[0].querySelector(".commit-message")?.textContent).toBe("Update documentation");

    // When searching for a branch while in commit mode, branch is searchable but was not standard visible
    input.value = "development";
    input.dispatchEvent(new Event("input", { bubbles: true }));
    await tick();

    const searchedBranchItems = container.querySelectorAll("li.branch-item");
    expect(searchedBranchItems.length).toBe(1);
    expect(searchedBranchItems[0].querySelector(".branch-name")?.textContent).toBe("development");

    // Selecting the searched branch triggers mode change to branch
    searchedBranchItems[0].dispatchEvent(new MouseEvent("mousedown", { bubbles: true }));
    await tick();
    expect(onChange).toHaveBeenCalledWith("development", "branch");
    expect(onModeChange).toHaveBeenCalledWith("branch");
  });
});
