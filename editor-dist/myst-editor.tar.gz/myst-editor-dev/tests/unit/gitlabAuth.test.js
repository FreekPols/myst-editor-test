import { describe, it, expect, vi, beforeEach, afterEach } from "vite-plus/test";
import {
  base64url,
  randomString,
  sha256Challenge,
  configure,
  login,
  handleRedirect,
  isAuthenticated,
  logout,
  authorizedFetch,
  clearOAuthCallbackParams,
} from "../../src/myst-git/gitlabAuth.js";

/** Set the current URL without navigating (happy-dom supports history.replaceState). */
function setUrl(search) {
  window.history.replaceState({}, "", `/myst-git/git.html${search}`);
}

const tokenResponse = (body) => ({ ok: true, status: 200, json: async () => body, text: async () => JSON.stringify(body) });

beforeEach(() => {
  logout();
  sessionStorage.clear();
  setUrl("");
  vi.stubEnv("VITE_GITLAB_URL", "https://gitlab.example.com");
  vi.stubEnv("VITE_GITLAB_CLIENT_ID", "client-abc");
  vi.stubEnv("VITE_GITLAB_REDIRECT_URI", "https://app.example.com/cb");
});

afterEach(() => {
  configure(); // clear runtime overrides
  vi.unstubAllEnvs();
  vi.unstubAllGlobals();
  vi.restoreAllMocks();
});

describe("PKCE helpers", () => {
  it("base64url is URL-safe and unpadded", () => {
    // bytes [0xfb,0xff,0xfe] → base64 "+//+" → base64url "-__-"
    expect(base64url(new Uint8Array([0xfb, 0xff, 0xfe]))).toBe("-__-");
    const s = base64url(new Uint8Array([0, 0, 0, 0, 0]));
    expect(s).not.toMatch(/[+/=]/);
  });

  it("sha256Challenge matches the RFC 7636 Appendix B test vector", async () => {
    const verifier = "dBjftJeZ4CVP-mB92K27uhbUJU1p1r_wW1gFWFOEjXk";
    expect(await sha256Challenge(verifier)).toBe("E9Melhoa2OwvFrEMTJguCHaoeK1t8URWbuGJSstw-cM");
  });

  it("randomString returns distinct URL-safe strings", () => {
    const a = randomString();
    const b = randomString();
    expect(a).not.toBe(b);
    expect(a).not.toMatch(/[+/=]/);
  });
});

describe("login()", () => {
  it("stores PKCE verifier + state and redirects with an S256 challenge", async () => {
    const assign = vi.fn();
    window.location.assign = assign;

    await login();

    expect(sessionStorage.getItem("myst-gl-pkce-verifier")).toBeTruthy();
    const state = sessionStorage.getItem("myst-gl-oauth-state");
    expect(state).toBeTruthy();

    expect(assign).toHaveBeenCalledTimes(1);
    const url = new URL(assign.mock.calls[0][0]);
    expect(url.origin + url.pathname).toBe("https://gitlab.example.com/oauth/authorize");
    expect(url.searchParams.get("client_id")).toBe("client-abc");
    expect(url.searchParams.get("code_challenge_method")).toBe("S256");
    expect(url.searchParams.get("code_challenge")).toBeTruthy();
    expect(url.searchParams.get("scope")).toBe("api");
    expect(url.searchParams.get("state")).toBe(state);
    // the exact redirect_uri sent is stashed for the token exchange leg
    expect(sessionStorage.getItem("myst-gl-redirect-uri")).toBe(url.searchParams.get("redirect_uri"));
  });
});

describe("configure() runtime overrides", () => {
  it("takes precedence over env in the authorize URL", async () => {
    configure({ gitlabUrl: "https://runtime.example.com", clientId: "runtime-xyz" });
    const assign = vi.fn();
    window.location.assign = assign;

    await login();

    const url = new URL(assign.mock.calls[0][0]);
    expect(url.origin).toBe("https://runtime.example.com");
    expect(url.searchParams.get("client_id")).toBe("runtime-xyz");
  });

  it("falls back to env for values not overridden", async () => {
    configure({ clientId: "runtime-xyz" }); // gitlabUrl left to env
    const assign = vi.fn();
    window.location.assign = assign;

    await login();

    const url = new URL(assign.mock.calls[0][0]);
    expect(url.origin).toBe("https://gitlab.example.com"); // env
    expect(url.searchParams.get("client_id")).toBe("runtime-xyz"); // override
  });
});

describe("handleRedirect()", () => {
  it("returns null when there is no ?code", async () => {
    expect(await handleRedirect()).toBeNull();
  });

  it("throws on a state mismatch (CSRF guard)", async () => {
    sessionStorage.setItem("myst-gl-oauth-state", "expected");
    sessionStorage.setItem("myst-gl-pkce-verifier", "v");
    setUrl("?code=abc&state=WRONG");
    await expect(handleRedirect()).rejects.toThrow(/state mismatch/i);
  });

  it("exchanges the code, stores the token, and strips code/state from the URL", async () => {
    sessionStorage.setItem("myst-gl-oauth-state", "s1");
    sessionStorage.setItem("myst-gl-pkce-verifier", "the-verifier");
    setUrl("?code=the-code&state=s1&keep=1");

    const fetchMock = vi.fn().mockResolvedValue(tokenResponse({ access_token: "AT", refresh_token: "RT", expires_in: 7200 }));
    vi.stubGlobal("fetch", fetchMock);

    const token = await handleRedirect();

    expect(token).toBe("AT");
    expect(isAuthenticated()).toBe(true);
    // token endpoint called with the PKCE verifier and auth-code grant
    const [tokenUrl, init] = fetchMock.mock.calls[0];
    expect(tokenUrl).toBe("https://gitlab.example.com/oauth/token");
    const body = init.body.toString();
    expect(body).toContain("grant_type=authorization_code");
    expect(body).toContain("code_verifier=the-verifier");
    // PKCE material cleared, code/state stripped, unrelated params kept
    expect(sessionStorage.getItem("myst-gl-pkce-verifier")).toBeNull();
    expect(window.location.search).toBe("?keep=1");
  });

  it("reuses the stored redirect_uri for the exchange, not one re-derived from the URL", async () => {
    sessionStorage.setItem("myst-gl-oauth-state", "s1");
    sessionStorage.setItem("myst-gl-pkce-verifier", "v");
    // login() stored the no-slash form; the server then redirected us to a slash form.
    sessionStorage.setItem("myst-gl-redirect-uri", "https://app.example.com/editor");
    setUrl("?code=the-code&state=s1");

    const fetchMock = vi.fn().mockResolvedValue(tokenResponse({ access_token: "AT" }));
    vi.stubGlobal("fetch", fetchMock);

    await handleRedirect();

    const body = fetchMock.mock.calls[0][1].body.toString();
    expect(body).toContain(`redirect_uri=${encodeURIComponent("https://app.example.com/editor")}`);
  });
});

describe("clearOAuthCallbackParams()", () => {
  it("strips spent OAuth params but keeps unrelated ones", () => {
    setUrl("?code=c&state=s&session_state=x&error=bad&keep=1");
    clearOAuthCallbackParams();
    expect(window.location.search).toBe("?keep=1");
  });
});

describe("authorizedFetch()", () => {
  async function seedSession() {
    sessionStorage.setItem("myst-gl-oauth-state", "s");
    sessionStorage.setItem("myst-gl-pkce-verifier", "v");
    setUrl("?code=c&state=s");
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue(tokenResponse({ access_token: "AT", refresh_token: "RT" })));
    await handleRedirect();
  }

  it("adds the Bearer header and prefixes /api/v4", async () => {
    await seedSession();
    const fetchMock = vi.fn().mockResolvedValue({ ok: true, status: 200, text: async () => "ok", json: async () => ({}) });
    vi.stubGlobal("fetch", fetchMock);

    await authorizedFetch("projects/1/repository/branches");

    const [url, init] = fetchMock.mock.calls[0];
    expect(url).toBe("https://gitlab.example.com/api/v4/projects/1/repository/branches");
    expect(init.headers.Authorization).toBe("Bearer AT");
  });

  it("refreshes once on 401 and retries with the new token", async () => {
    await seedSession();
    const fetchMock = vi
      .fn()
      .mockResolvedValueOnce({ ok: false, status: 401, text: async () => "expired" }) // first API call
      .mockResolvedValueOnce(tokenResponse({ access_token: "AT2" })) // refresh
      .mockResolvedValueOnce({ ok: true, status: 200, text: async () => "ok", json: async () => ({}) }); // retry
    vi.stubGlobal("fetch", fetchMock);

    const res = await authorizedFetch("projects/1/version");

    expect(res.ok).toBe(true);
    expect(fetchMock).toHaveBeenCalledTimes(3);
    expect(fetchMock.mock.calls[1][0]).toBe("https://gitlab.example.com/oauth/token"); // refresh endpoint
    expect(fetchMock.mock.calls[2][1].headers.Authorization).toBe("Bearer AT2"); // retry uses refreshed token
  });
});
