import { describe, it, expect, vi, beforeEach, afterEach } from "vite-plus/test";
import {
  configure,
  getConfig,
  login,
  handleRedirect,
  isAuthenticated,
  logout,
  useToken,
  authorizedFetch,
  graphqlUrlFor,
} from "../../src/myst-git/githubAuth.js";

const okJson = (body) => ({ ok: true, status: 200, json: async () => body, text: async () => JSON.stringify(body) });

beforeEach(() => {
  logout();
  sessionStorage.clear();
  window.history.replaceState({}, "", "/editor/");
  configure({ clientId: "Iv1.abc", redirectUri: "https://book.example.org/editor/", tokenUrl: "https://relay.example.org/token" });
});

afterEach(() => {
  configure();
  vi.unstubAllGlobals();
  vi.restoreAllMocks();
});

describe("addresses", () => {
  it("uses github.com and api.github.com by default", () => {
    expect(getConfig()).toMatchObject({
      githubUrl: "https://github.com",
      apiUrl: "https://api.github.com",
      graphqlUrl: "https://api.github.com/graphql",
    });
  });

  it("derives a GitHub Enterprise Server's API and GraphQL addresses from its web address", () => {
    configure({ githubUrl: "https://git.example.edu/" });
    expect(getConfig()).toMatchObject({ apiUrl: "https://git.example.edu/api/v3", graphqlUrl: "https://git.example.edu/api/graphql" });
    expect(graphqlUrlFor("https://api.github.com")).toBe("https://api.github.com/graphql");
  });
});

describe("OAuth through the relay", () => {
  it("sends the browser to GitHub's authorize page with a PKCE challenge", async () => {
    const assign = vi.fn();
    vi.stubGlobal("location", { ...window.location, assign, origin: "https://book.example.org", pathname: "/editor/" });
    await login();
    const url = new URL(assign.mock.calls[0][0]);
    expect(url.origin + url.pathname).toBe("https://github.com/login/oauth/authorize");
    expect(url.searchParams.get("client_id")).toBe("Iv1.abc");
    expect(url.searchParams.get("code_challenge_method")).toBe("S256");
    expect(sessionStorage.getItem("myst-gh-pkce-verifier")).toBeTruthy();
  });

  it("exchanges the code at the relay, without any secret in the browser", async () => {
    sessionStorage.setItem("myst-gh-oauth-state", "s");
    sessionStorage.setItem("myst-gh-pkce-verifier", "v");
    window.history.replaceState({}, "", "/editor/?code=c&state=s");
    const fetchMock = vi.fn().mockResolvedValue(okJson({ access_token: "ghu_x", refresh_token: "ghr_y", expires_in: 28800 }));
    vi.stubGlobal("fetch", fetchMock);

    await handleRedirect();

    const [url, init] = fetchMock.mock.calls[0];
    expect(url).toBe("https://relay.example.org/token");
    const sent = Object.fromEntries(new URLSearchParams(init.body));
    expect(sent).toMatchObject({ client_id: "Iv1.abc", code: "c", code_verifier: "v", grant_type: "authorization_code" });
    expect(sent).not.toHaveProperty("client_secret");
    expect(isAuthenticated()).toBe(true);
    expect(window.location.search).toBe("");
  });

  it("reports GitHub's error, which arrives with status 200", async () => {
    sessionStorage.setItem("myst-gh-oauth-state", "s");
    sessionStorage.setItem("myst-gh-pkce-verifier", "v");
    window.history.replaceState({}, "", "/editor/?code=c&state=s");
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue(okJson({ error: "bad_verification_code", error_description: "The code passed is incorrect or expired." })),
    );
    await expect(handleRedirect()).rejects.toThrow("The code passed is incorrect or expired.");
    expect(isAuthenticated()).toBe(false);
  });

  it("says what is missing when no relay is configured", async () => {
    configure();
    configure({ clientId: "Iv1.abc" });
    sessionStorage.setItem("myst-gh-oauth-state", "s");
    sessionStorage.setItem("myst-gh-pkce-verifier", "v");
    window.history.replaceState({}, "", "/editor/?code=c&state=s");
    await expect(handleRedirect()).rejects.toThrow(/needs `tokenUrl`/);
  });
});

describe("token sign-in and API calls", () => {
  it("calls the REST API with the user's token and GitHub's API headers", async () => {
    useToken("github_pat_x");
    const fetchMock = vi.fn().mockResolvedValue(okJson({}));
    vi.stubGlobal("fetch", fetchMock);
    await authorizedFetch("repos/jdoe/book");
    const [url, init] = fetchMock.mock.calls[0];
    expect(url).toBe("https://api.github.com/repos/jdoe/book");
    expect(init.headers).toMatchObject({
      Authorization: "Bearer github_pat_x",
      Accept: "application/vnd.github+json",
      "X-GitHub-Api-Version": "2022-11-28",
    });
  });

  it("lets a caller ask for raw content instead", async () => {
    useToken("t");
    const fetchMock = vi.fn().mockResolvedValue(okJson({}));
    vi.stubGlobal("fetch", fetchMock);
    await authorizedFetch("repos/jdoe/book/contents/a.md?ref=x", { headers: { Accept: "application/vnd.github.raw" } });
    expect(fetchMock.mock.calls[0][1].headers.Accept).toBe("application/vnd.github.raw");
  });

  it("does not try to refresh a pasted token", async () => {
    useToken("expired");
    const fetchMock = vi.fn().mockResolvedValue({ ok: false, status: 401, text: async () => "Bad credentials", headers: new Headers() });
    vi.stubGlobal("fetch", fetchMock);
    await expect(authorizedFetch("user")).rejects.toMatchObject({ status: 401 });
    expect(fetchMock).toHaveBeenCalledTimes(1);
  });
});
