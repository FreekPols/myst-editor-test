import { describe, it, expect, vi, beforeEach, afterEach } from "vite-plus/test";

// The gate is the unit under test, so the two things it gates on - the OAuth module and the editor
// itself - are stubbed. Everything here is about which branch of the gate runs, not about OAuth.
const auth = {
  configure: vi.fn(),
  handleRedirect: vi.fn(async () => null),
  isAuthenticated: vi.fn(() => false),
  login: vi.fn(async () => {}),
  authorizedFetch: vi.fn(),
  clearOAuthCallbackParams: vi.fn(),
};
const mountEditor = vi.fn();
// GitHub's sign-in: the same OAuth calls, plus a pasted token (useToken) checked against the repository.
const ghAuth = {
  configure: vi.fn(),
  getConfig: vi.fn(() => ({ githubUrl: "https://github.com", graphqlUrl: "https://api.github.com/graphql" })),
  handleRedirect: vi.fn(async () => null),
  isAuthenticated: vi.fn(() => false),
  login: vi.fn(async () => {}),
  logout: vi.fn(),
  useToken: vi.fn(),
  authorizedFetch: vi.fn(),
};

vi.mock("../../src/myst-git/gitlabAuth.js", () => auth);
vi.mock("../../src/myst-git/githubAuth.js", () => ghAuth);
vi.mock("../../src/myst-git/MystEditorGit.jsx", () => ({ default: (...args) => mountEditor(...args) }));
vi.mock("../../src/myst-git/backends.js", () => ({
  createGitBackend: vi.fn(async () => ({ initialBranches: ["main"], getFiles: async () => [], getText: async () => "" })),
}));

const { mountGitEditor } = await import("../../src/myst-git/mountGitEditor.js");

const AUTO_LOGIN_AT_KEY = "myst-gl-auto-login-at";
const gitlab = { backend: "gitlab", gitlabProjectId: "1", id: "editor" };
let target;

beforeEach(() => {
  sessionStorage.clear();
  target = document.createElement("div");
  document.body.appendChild(target);
  for (const fn of [...Object.values(auth), ...Object.values(ghAuth)]) fn.mockClear?.();
  ghAuth.isAuthenticated.mockReturnValue(false);
  auth.handleRedirect.mockImplementation(async () => null);
  auth.isAuthenticated.mockReturnValue(false);
  auth.login.mockImplementation(async () => {});
  mountEditor.mockClear();
});

afterEach(() => {
  target.remove();
  vi.restoreAllMocks();
});

const button = () => target.querySelector("#myst-gl-login");
const spinner = () => target.querySelector("svg");

describe("the OAuth gate sends the user straight to GitLab", () => {
  it("logs in without waiting for a second click", async () => {
    await mountGitEditor(target, gitlab);
    expect(auth.login).toHaveBeenCalledTimes(1);
    // Nothing to click: the browser is on its way to GitLab.
    expect(button()).toBeNull();
    expect(target.textContent).toContain("Redirecting to GitLab");
  });

  it("records the attempt so the next load can tell it happened", async () => {
    await mountGitEditor(target, gitlab);
    expect(Number(sessionStorage.getItem(AUTO_LOGIN_AT_KEY))).toBeGreaterThan(0);
  });

  it("does not mount the editor while unauthenticated", async () => {
    await mountGitEditor(target, gitlab);
    expect(mountEditor).not.toHaveBeenCalled();
  });
});

describe("it falls back to the button rather than looping", () => {
  it("stops when an automatic attempt just came back without a session", async () => {
    // The shape of a failed round trip: we sent the browser to GitLab, and here we are again,
    // moments later, still logged out. Going again would loop forever.
    sessionStorage.setItem(AUTO_LOGIN_AT_KEY, String(Date.now()));
    await mountGitEditor(target, gitlab);
    expect(auth.login).not.toHaveBeenCalled();
    expect(button()).not.toBeNull();
    expect(target.textContent).toContain("did not complete");
  });

  it("tries again once the failed attempt is old news", async () => {
    sessionStorage.setItem(AUTO_LOGIN_AT_KEY, String(Date.now() - 60_000));
    await mountGitEditor(target, gitlab);
    expect(auth.login).toHaveBeenCalledTimes(1);
  });

  it("shows the button when the consumer opts out", async () => {
    await mountGitEditor(target, { ...gitlab, autoLogin: false });
    expect(auth.login).not.toHaveBeenCalled();
    expect(button()).not.toBeNull();
    expect(target.textContent).not.toContain("did not complete");
  });

  it("leaves the decision to onLoginRequired when one is given", async () => {
    const onLoginRequired = vi.fn();
    await mountGitEditor(target, { ...gitlab, onLoginRequired });
    expect(onLoginRequired).toHaveBeenCalledTimes(1);
    expect(auth.login).not.toHaveBeenCalled();
    expect(sessionStorage.getItem(AUTO_LOGIN_AT_KEY)).toBeNull();
  });

  it("surfaces a login() that throws instead of leaving 'Redirecting…' on screen", async () => {
    auth.login.mockImplementation(async () => {
      throw new Error("clientId is missing");
    });
    await mountGitEditor(target, gitlab);
    expect(target.textContent).toContain("clientId is missing");
    // The mark is cleared, so the next load may try again rather than being stuck on the button.
    expect(sessionStorage.getItem(AUTO_LOGIN_AT_KEY)).toBeNull();
  });

  it("still renders the OAuth error prompt when the redirect itself failed", async () => {
    auth.handleRedirect.mockImplementation(async () => {
      throw new Error("GitLab OAuth error: access_denied");
    });
    await mountGitEditor(target, gitlab);
    expect(auth.login).not.toHaveBeenCalled();
    expect(target.textContent).toContain("access_denied");
  });
});

describe("once signed in", () => {
  it("mounts the editor and forgets the earlier attempt", async () => {
    sessionStorage.setItem(AUTO_LOGIN_AT_KEY, String(Date.now()));
    auth.isAuthenticated.mockReturnValue(true);
    await mountGitEditor(target, gitlab);
    expect(mountEditor).toHaveBeenCalledTimes(1);
    expect(sessionStorage.getItem(AUTO_LOGIN_AT_KEY)).toBeNull();
  });
});

describe("the stub backend is untouched by any of this", () => {
  it("mounts with no OAuth at all", async () => {
    await mountGitEditor(target, { backend: "stub", id: "editor" });
    expect(auth.login).not.toHaveBeenCalled();
    expect(mountEditor).toHaveBeenCalledTimes(1);
  });
});

describe("the wait after a successful redirect is not a blank page", () => {
  it("shows a spinner while the token exchange and backend prefetch run", async () => {
    let releaseRedirect;
    auth.handleRedirect.mockImplementation(() => new Promise((r) => (releaseRedirect = r)));
    const mounting = mountGitEditor(target, gitlab);

    // Mid-boot: this is exactly the window that used to be white.
    expect(spinner()).not.toBeNull();
    expect(target.textContent).toContain("Loading the editor");

    auth.isAuthenticated.mockReturnValue(true);
    releaseRedirect(null);
    await mounting;
    expect(mountEditor).toHaveBeenCalledTimes(1);
  });

  it("names GitLab once the wait stops looking like the editor's fault", async () => {
    vi.useFakeTimers();
    let releaseRedirect;
    auth.handleRedirect.mockImplementation(() => new Promise((r) => (releaseRedirect = r)));
    const mounting = mountGitEditor(target, gitlab);

    const note = () => target.querySelector("#myst-slow-note");
    // Present from the start, but held back: on a normal load the editor is up long before this, and
    // a note about the server being slow would be the first thing it ever said.
    expect(note()).not.toBeNull();
    expect(note().hidden).toBe(true);

    await vi.advanceTimersByTimeAsync(4000);
    expect(note().hidden).toBe(false);
    expect(note().textContent).toMatch(/GitLab is taking a while/);
    expect(note().textContent).toMatch(/not stuck/);

    auth.isAuthenticated.mockReturnValue(true);
    releaseRedirect(null);
    vi.useRealTimers();
    await mounting;
  });

  it("says nothing about the server on the way out to GitLab", async () => {
    // The browser is leaving; there is no wait here to explain.
    await mountGitEditor(target, gitlab);
    expect(target.textContent).toContain("Redirecting to GitLab");
    expect(target.querySelector("#myst-slow-note")).toBeNull();
  });

  it("clears the loading screen once the editor takes over", async () => {
    auth.isAuthenticated.mockReturnValue(true);
    await mountGitEditor(target, gitlab);
    expect(target.innerHTML).toBe("");
  });

  it("animates unless the viewer asked for reduced motion", async () => {
    vi.stubGlobal("matchMedia", () => ({ matches: true }));
    await mountGitEditor(target, gitlab);
    expect(target.querySelector("animateTransform")).toBeNull();

    target.innerHTML = "";
    // The first mount recorded an auto-login attempt; without clearing it the loop guard would
    // (correctly) show the button here instead of a spinner.
    sessionStorage.clear();
    vi.stubGlobal("matchMedia", () => ({ matches: false }));
    await mountGitEditor(target, gitlab);
    expect(target.querySelector("animateTransform")).not.toBeNull();
  });

  it("uses the same spinner on the way out to GitLab", async () => {
    await mountGitEditor(target, gitlab);
    expect(spinner()).not.toBeNull();
    expect(target.textContent).toContain("Redirecting to GitLab");
  });
});

describe("the loading screen carries the brand", () => {
  const boot = (config) => {
    auth.handleRedirect.mockImplementation(() => new Promise(() => {}));
    mountGitEditor(target, config);
  };

  it("shows COMBINE above the spinner and TU Delft at the foot", () => {
    boot(gitlab);
    expect(target.querySelector("#myst-loading-logo")?.getAttribute("alt")).toBe("COMBINE");
    expect(target.querySelector("#myst-loading-secondary")?.getAttribute("alt")).toBe("TU Delft");
  });

  it("keeps the logos out of the live region, so only the wait is announced", () => {
    boot(gitlab);
    const status = target.querySelector('[role="status"]');
    expect(status.querySelector("img")).toBeNull();
    expect(status.textContent).toContain("Loading the editor");
  });

  it("can be switched off, or replaced", () => {
    boot({ ...gitlab, branding: false });
    expect(target.querySelector("img")).toBeNull();

    target.innerHTML = "";
    boot({ ...gitlab, branding: { logo: { light: "x.png", dark: "y.png", alt: 'Other "Org"' } } });
    expect(target.querySelector("#myst-loading-logo").getAttribute("alt")).toBe('Other "Org"');
    expect(target.querySelector("#myst-loading-secondary")).toBeNull();
  });

  it("passes the choice on to the editor", async () => {
    auth.isAuthenticated.mockReturnValue(true);
    await mountGitEditor(target, { ...gitlab, branding: false });
    expect(mountEditor.mock.calls[0][0].branding).toBe(false);
  });
});

describe("the deployed version is identified", () => {
  it("is switched on for a real git backend", async () => {
    auth.isAuthenticated.mockReturnValue(true);
    await mountGitEditor(target, gitlab);
    expect(mountEditor.mock.calls[0][0].showVersion).toBe(true);
  });

  it("is left to the demo pages for the stub", async () => {
    await mountGitEditor(target, { backend: "stub", id: "editor" });
    expect(mountEditor.mock.calls[0][0].showVersion).toBeUndefined();
  });

  it("never overrides a consumer that has decided for itself", async () => {
    auth.isAuthenticated.mockReturnValue(true);
    await mountGitEditor(target, { ...gitlab, showVersion: false });
    expect(mountEditor.mock.calls[0][0].showVersion).toBe(false);
  });
});

describe("add-ons", () => {
  const stub = { backend: "stub", id: "editor" };

  it("mount the editor on the backend the add-ons made of it", async () => {
    const narrow = { name: "narrow", wrapBackend: (b) => ({ ...b, initialBranches: ["group-03"], canOpenBranch: (n) => n === "group-03" }) };
    await mountGitEditor(target, { ...stub, plugins: [narrow] });
    const props = mountEditor.mock.calls[0][0];
    expect(props.initialBranches).toEqual(["group-03"]);
    expect(props.canOpenBranch("main")).toBe(false);
    // The option itself is the bootstrap's, not the editor's.
    expect(props.plugins).toBeUndefined();
  });

  it("show the add-on's message instead of the editor when it refuses to start", async () => {
    const gate = { name: "gate", wrapBackend: (_b, ctx) => ctx.fail("You are not listed for this course. Ask your teacher to add <jdoe>.") };
    await mountGitEditor(target, { ...stub, plugins: [gate] });
    expect(mountEditor).not.toHaveBeenCalled();
    const message = target.querySelector("#myst-plugin-stop");
    expect(message.getAttribute("role")).toBe("alert");
    // Shown as text, never as markup.
    expect(message.textContent).toBe("You are not listed for this course. Ask your teacher to add <jdoe>.");
    expect(target.querySelector("#myst-plugin-retry")).not.toBeNull();
  });

  it("set up once the editor is ready, after the page's own onReady", async () => {
    const order = [];
    const plugin = { name: "p", setup: (editor) => order.push(["plugin", editor]) };
    await mountGitEditor(target, { ...stub, onReady: (editor) => order.push(["page", editor]), plugins: [plugin] });
    const editor = { state: {}, git: { notify: vi.fn() } };
    mountEditor.mock.calls[0][0].onReady(editor);
    expect(order).toEqual([
      ["page", editor],
      ["plugin", editor],
    ]);
  });

  it("leave everything as it was when there are none", async () => {
    const onReady = vi.fn();
    await mountGitEditor(target, { ...stub, onReady });
    expect(mountEditor.mock.calls[0][0].onReady).toBe(onReady);
  });
});

describe("GitHub", () => {
  const github = { backend: "github", githubRepo: "jdoe/book", id: "editor" };
  /** Resolve the token check: GitHub answers for the repository with the token's permissions there. */
  const repoAnswer = (permissions) => async () => ({ json: async () => ({ permissions }) });
  const refusal = (status) => async () => Promise.reject(Object.assign(new Error(`GitHub API ${status}`), { status }));
  const submit = async (token) => {
    target.querySelector("#myst-gh-token").value = token;
    target.querySelector("#myst-gh-token-form").dispatchEvent(new Event("submit", { cancelable: true }));
    await new Promise((r) => setTimeout(r, 0));
  };

  it("needs to know which repository", async () => {
    await expect(mountGitEditor(target, { backend: "github", id: "editor" })).rejects.toThrow(/githubRepo/);
  });

  it("asks for a token in a form a password manager recognises, when there is no relay", async () => {
    const mounting = mountGitEditor(target, github);
    await new Promise((r) => setTimeout(r, 0));
    const user = target.querySelector("#myst-gh-repo");
    const token = target.querySelector("#myst-gh-token");
    expect(user.getAttribute("autocomplete")).toBe("username");
    expect(user.value).toBe("jdoe/book");
    expect(token.type).toBe("password");
    expect(token.getAttribute("autocomplete")).toBe("current-password");
    expect(target.querySelector('a[href="https://github.com/settings/personal-access-tokens/new"]')).not.toBeNull();
    expect(ghAuth.login).not.toHaveBeenCalled();

    ghAuth.authorizedFetch.mockImplementation(repoAnswer({ push: true }));
    await submit("github_pat_ok");
    await mounting;
    expect(ghAuth.useToken).toHaveBeenCalledWith("github_pat_ok");
    expect(mountEditor).toHaveBeenCalledTimes(1);
  });

  it("says why a token will not do, and keeps the form up", async () => {
    mountGitEditor(target, github);
    await new Promise((r) => setTimeout(r, 0));
    const error = () => target.querySelector("#myst-gh-token-error").textContent;

    ghAuth.authorizedFetch.mockImplementation(refusal(404));
    await submit("other-repo-token");
    expect(error()).toContain('cannot reach jdoe/book. When making it, choose this repository under "Repository access"');

    ghAuth.authorizedFetch.mockImplementation(repoAnswer({ pull: true }));
    await submit("read-only-token");
    expect(error()).toContain('"Contents: Read and write"');

    ghAuth.authorizedFetch.mockImplementation(refusal(401));
    await submit("expired");
    expect(error()).toContain("did not accept this token");
    expect(ghAuth.logout).toHaveBeenCalledTimes(3);
    expect(mountEditor).not.toHaveBeenCalled();
  });

  it("signs in through GitHub when a token relay is configured", async () => {
    await mountGitEditor(target, { ...github, clientId: "Iv1.abc", tokenUrl: "https://relay.example.org/token" });
    expect(ghAuth.configure).toHaveBeenCalledWith(expect.objectContaining({ clientId: "Iv1.abc", tokenUrl: "https://relay.example.org/token" }));
    expect(ghAuth.login).toHaveBeenCalledTimes(1);
    expect(target.textContent).toContain("Redirecting to GitHub");
    expect(target.querySelector("#myst-gh-token-form")).toBeNull();
  });

  it("can be told to use tokens even with a relay", async () => {
    mountGitEditor(target, { ...github, tokenUrl: "https://relay.example.org/token", auth: "token" });
    await new Promise((r) => setTimeout(r, 0));
    expect(target.querySelector("#myst-gh-token-form")).not.toBeNull();
    expect(ghAuth.login).not.toHaveBeenCalled();
  });
});
