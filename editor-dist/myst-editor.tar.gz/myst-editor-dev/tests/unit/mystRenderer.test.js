import { describe, it, expect } from "vite-plus/test";
import { renderMyst } from "../../src/markdown/mystRenderer.ts";
import { aliasEnvironments } from "../../src/markdown/mathHast.ts";

const render = (src) => {
  const lineMap = new Map();
  const { html, error } = renderMyst(src, { lineMap });
  return { html, error, lineMap };
};

describe("mystRenderer", () => {
  it("renders inline + block math as MathML (no KaTeX CSS needed)", () => {
    const { html, error } = render("Inline $a^2+b^2$ and:\n\n$$\\int_0^1 x\\,dx$$\n");
    expect(error).toBeNull();
    expect(html).toContain("<math");
    expect(html).toContain('display="block"'); // block math is display mode
    // The raw TeX must live ONLY inside the standard MathML annotation, never as bare visible text.
    expect(html).toContain('<annotation encoding="application/x-tex">');
    // the math element now holds rendered MathML, not the bare pre-render TeX text
    expect(html).not.toContain('class="math-inline">a^2+b^2<');
    expect(html).not.toContain('class="math-display">\\int');
  });

  it("renders amsmath environments KaTeX does not implement", () => {
    // Reported from the AP3122 book: an eqnarray block rendered as its own red LaTeX source, with the
    // equation number beside it - myst had parsed and numbered the block, KaTeX then refused the TeX.
    const { html, error } = render("$$\n\\begin{eqnarray}\na &=& b \\\\\n  &=& c\n\\end{eqnarray}\n$$(detectint)\n");
    expect(error).toBeNull();
    expect(html).not.toContain("katex-error");
    expect(html).toContain("<math");
    // Still myst's number, not one of KaTeX's: the aliases are the starred forms for that reason.
    expect(html).toContain('href="#detectint"');
    expect(html).toContain("(1)");
  });

  it("renders an admonition with the box AND embedded markdown (the docutils gap)", () => {
    const { html } = render("```{note}\nAn **admonition** with a [link](https://x).\n```\n");
    expect(html).toContain('class="admonition');
    expect(html).toContain("<strong>");
    expect(html).toContain("<a");
  });

  it("resolves numbered cross-references", () => {
    const src = ["```{figure} img.png", ":label: fig-1", "A caption.", "```", "", "See {numref}`fig-1`.", ""].join("\n");
    const { html } = render(src);
    expect(html).toContain('href="#fig-1"');
    expect(html).toMatch(/Figure\s*1/);
  });

  it("populates lineMap and stamps matching data-line-id attributes (source-map contract)", () => {
    const src = ["# Heading", "", "First paragraph.", "", "Second paragraph.", ""].join("\n");
    const { html, lineMap } = render(src);
    expect(lineMap.get(1)).toBeTruthy(); // heading on line 1
    expect(lineMap.get(3)).toBeTruthy(); // first paragraph on line 3
    // every id in the map must appear as a data-line-id in the output
    for (const id of lineMap.values()) {
      expect(html).toContain(`data-line-id="${id}"`);
    }
  });
});

describe("aliasEnvironments", () => {
  it("rewrites the environments KaTeX cannot parse, starred and unstarred", () => {
    expect(aliasEnvironments("\\begin{eqnarray}a&=&b\\end{eqnarray}")).toBe("\\begin{align*}a&=&b\\end{align*}");
    expect(aliasEnvironments("\\begin{eqnarray*}a\\end{eqnarray*}")).toBe("\\begin{align*}a\\end{align*}");
    expect(aliasEnvironments("\\begin{multline}a\\end{multline}")).toBe("\\begin{gather*}a\\end{gather*}");
    expect(aliasEnvironments("\\begin{flalign*}a\\end{flalign*}")).toBe("\\begin{align*}a\\end{align*}");
  });

  it("leaves environments KaTeX already understands alone", () => {
    for (const env of ["align", "align*", "gather", "aligned", "cases", "array", "matrix", "split"]) {
      const tex = `\\begin{${env}}a\\end{${env}}`;
      expect(aliasEnvironments(tex)).toBe(tex);
    }
  });
});
