import { describe, it, expect } from "vite-plus/test";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
import { renderMyst } from "../../src/markdown/mystRenderer";

/** Regression tests for the passes layered on top of the mystmd pipeline (src/markdown). Each of these
 * replaced a markdown-it plugin, so the behaviour is a compatibility contract, not just an implementation
 * detail. Assertions run on the pre-sanitize HTML: DOMPurify under happy-dom strips structural tags
 * (figure/aside/details/dl) that it keeps in a real browser, so sanitized output is not trustworthy here. */
const render = (src, ctx = {}) => renderMyst(src, { lineMap: new Map(), ...ctx }).html;

describe("CriticMarkup", () => {
  it("renders insertions, deletions and replacements", () => {
    expect(render("x {++added++} y")).toContain("<ins");
    expect(render("x {--gone--} y")).toContain("<del");
    expect(render("x {~~old~>new~~} y")).toMatch(/<del[^>]*>old<\/del><ins[^>]*>new<\/ins>/);
  });

  it("spans a soft line break inside a paragraph", () => {
    expect(render("{--\nremoved text\n--}")).toContain("<del");
  });

  it("leaves malformed markers alone", () => {
    expect(render("Braces {++++} stay.")).toContain("{++++}");
    expect(render("Braces {~~nothing~~} stay.")).toContain("{~~nothing~~}");
  });

  it("leaves the markup as literal text when disabled", () => {
    // Suggestions are a collaboration feature; with collaboration off the editor renders CriticMarkup
    // the way Jupyter Book does, as plain text.
    const html = render("x {++added++} y", { criticMarkup: false });
    expect(html).toContain("{++added++}");
    expect(html).not.toContain("<ins");
  });
});

describe("frontmatter as configuration", () => {
  it("hides the yaml but keeps a heading that repeats the title", () => {
    const html = render("---\ntitle: A title\n---\n\n# A title\n\nBody.\n");
    expect(html).not.toContain("language-yaml");
    // myst build deletes this H1 because its theme renders the title; we have no title block, so
    // deleting it would make the heading disappear from the preview entirely.
    expect(html).toContain("<h1");
  });

  it("expands LaTeX macros defined in frontmatter", () => {
    const withMacro = render("---\nmath:\n  \\RR: \\mathbb{R}\n---\n\n$x \\in \\RR$\n");
    expect(withMacro).toContain("double-struck");
    // Without the definition the same source is an undefined control sequence.
    expect(render("$x \\in \\RR$\n")).not.toContain("double-struck");
  });

  it("expands abbreviations defined in frontmatter", () => {
    const html = render("---\nabbreviations:\n  MyST: Markedly Structured Text\n---\n\nMyST is nice.\n");
    expect(html).toContain('<abbr title="Markedly Structured Text">MyST</abbr>');
  });

  it("survives invalid yaml without failing the render", () => {
    const { html, error } = renderMyst("---\ntitle: [unclosed\n---\n\nBody.\n", { lineMap: new Map() });
    expect(error).toBeNull();
    expect(html).toContain("Body.");
  });
});

describe("inline roles", () => {
  it("keeps unhandled inline nodes inside the paragraph", () => {
    // An unknown node type used to render as <div>, which closed the surrounding paragraph.
    const html = render("Text {smallcaps}`sc` and {u}`u` and {chem}`H2O` inline.\n");
    expect(html).toMatch(/<p[^>]*>Text <span style="font-variant:small-caps">/);
    expect(html).toContain('<span style="text-decoration:underline">');
    expect(html).toContain("H<sub>2</sub>O");
    expect(html).not.toContain("<div>sc</div>");
  });

  it("numbers display equations and links them", () => {
    const html = render("$$\nx=1\n$$ (eq-a)\n");
    expect(html).toContain('<a class="equation-number" href="#eq-a">(1)</a>');
  });

  it("gives glossary terms an id so {term} can reach them", () => {
    const html = render("```{glossary}\nmdast\n: The AST.\n```\n\nSee {term}`mdast`.\n");
    expect(html).toContain('<dt id="term-mdast"');
    expect(html).toContain('href="#term-mdast"');
  });
});

describe("the JB2 showcase document", () => {
  const showcase = readFileSync(resolve(dirname(fileURLToPath(import.meta.url)), "../../src/fixtures/jb2-showcase.md"), "utf8");

  it("renders without error", () => {
    expect(renderMyst(showcase, { lineMap: new Map() }).error).toBeNull();
  });

  it("produces every major construct", () => {
    const html = renderMyst(showcase, { lineMap: new Map() }).html;
    for (const marker of [
      "admonition",
      "<details",
      "<figure",
      "<table",
      "<math",
      'class="card"',
      'class="grid"',
      "tab-set",
      'pre class="mermaid"',
      "<iframe",
      "iframe-invalid",
      "cross-reference",
      "caption-number",
      "glossary",
      "<dl",
      "<kbd>",
      "<abbr",
      "equation-number",
      "chemical-formula",
      "glossary-term",
    ]) {
      expect(html, `showcase is missing ${marker}`).toContain(marker);
    }
  });
});

describe("Jupyter Book directives", () => {
  const exercise = "```{exercise} Fourier\n:label: ex_fourier\n\nDo it.\n```\n\n";

  it("renders :class: dropdown as a collapsible details, not a plain aside", () => {
    const html = render("```{note}\n:class: dropdown\n\nhi\n```\n");
    expect(html).toContain("<details");
    expect(html).toContain('<summary class="admonition-title"');
    expect(html).not.toContain("<aside");
  });

  it("honours dropdown on exercise-family directives too", () => {
    const html = render(exercise + "```{solution} ex_fourier\n:class: dropdown\n\n(a)\n```\n");
    expect(html).toContain('<details class="dropdown admonition solution"');
  });

  it("stays a plain aside without the dropdown class", () => {
    expect(render("```{note}\n\nhi\n```\n")).toContain("<aside");
  });

  it("resolves a cross-reference to a numbered link, as myst build does", () => {
    const html = render(exercise + "```{solution} ex_fourier\n\n(a)\n```\n");
    // myst-transforms enumerates the exercise and fills in the reference text; myst-to-html's own
    // State only ever enumerated container/math/heading, so this could not resolve at all.
    // myst-transforms joins kind and number with a non-breaking space so they never wrap apart.
    expect(html).toContain('<a class="cross-reference" href="#ex_fourier">Exercise\u00a01</a>');
    expect(html).not.toContain("unhandled");
  });

  it("numbers figures and resolves numref to the same number", () => {
    const html = render(":::{figure} img.png\n:name: fig-one\n\nA caption.\n:::\n\nSee {numref}`fig-one`.\n");
    // Exactly one caption number, in Jupyter Book's format (it appends the colon).
    expect(html).toContain('<span class="caption-number">Figure\u00a01:</span>');
    expect(html.match(/caption-number/g)).toHaveLength(1);
    expect(html).toContain(">Figure\u00a01</a>");
  });

  it("resolves a reference to a heading", () => {
    const html = render("(sec-intro)=\n# Introduction\n\nSee {ref}`sec-intro`.\n");
    expect(html).toContain('href="#sec-intro"');
  });

  it("does not wrap multi-line math in a pre", () => {
    const html = render("$$\n\\begin{array}{lcl}\na & = & b\n\\end{array}\n$$\n");
    expect(html).not.toContain("<pre");
    expect(html).toContain('<div class="math-display"');
  });

  it("keeps the id on a labelled equation so {eq} references resolve", () => {
    expect(render("$$\nx=1\n$$ (eq1)\n")).toContain('id="eq1"');
  });
});

describe("iframe embeds", () => {
  it("embeds an absolute url and rewrites share links", () => {
    const html = render(":::{iframe} https://youtu.be/bB943zSGzFA\n:::\n");
    expect(html).toContain('<iframe src="https://www.youtube.com/embed/bB943zSGzFA"');
  });

  it("refuses a relative or empty src instead of framing the editor itself", () => {
    // A relative src resolves against the page the editor is on, so emitting one would load the editor
    // inside its own preview. No <iframe> at all is the property that matters here.
    for (const src of ["myvideo", "", "some name", "/local/path", "./video.html"]) {
      const html = render(`:::{iframe} ${src}\n:::\n`);
      expect(html).not.toContain("<iframe");
    }
    // Where the directive does reach our handler, say why rather than rendering nothing.
    expect(render(":::{iframe} myvideo\n:::\n")).toContain("iframe-invalid");
  });
});

describe("links", () => {
  it("rewrites href and src through mapUrl", () => {
    const html = render("[d](p.md) ![i](img.png)", { links: { mapUrl: (tag, url) => `/api/${tag}/${url}` } });
    expect(html).toContain('href="/api/a/p.md"');
    expect(html).toContain('src="/api/img/img.png"');
  });

  it("restores the source text of a link CommonMark mis-parses", () => {
    // `[label]((url))` yields an href starting with "(" under CommonMark; never a usable link.
    const html = render("[label]((https://example.com))");
    expect(html).toContain("[label]((https://example.com))");
    expect(html).not.toContain('href="(https');
  });

  it("adds target/rel only when the setting is on, and only to anchors", () => {
    expect(render("[d](p.md)", { links: { openLinksInNewTab: true } })).toContain('target="_blank"');
    expect(render("[d](p.md)")).not.toContain("target=");
    expect(render("![i](img.png)", { links: { openLinksInNewTab: true } })).not.toContain("target=");
  });
});

describe("backslashLineBreak", () => {
  it("breaks on a trailing backslash only when enabled", () => {
    expect(render("a paragraph\\", { backslashLineBreak: true })).toContain("<br>");
    expect(render("a paragraph\\", { backslashLineBreak: false })).not.toContain("<br>");
  });

  it("leaves an escaped backslash literal", () => {
    expect(render("literal \\\\", { backslashLineBreak: true })).not.toContain("<br>");
  });

  it("does not affect CommonMark's own mid-paragraph hard break", () => {
    expect(render("line one\\\nline two", { backslashLineBreak: false })).toContain("<br>");
  });
});

describe("task list checkboxes", () => {
  it("are clickable and carry their own source line", () => {
    const html = render("Intro.\n\n- [ ] one\n- [x] two");
    expect(html).not.toContain("disabled");
    expect([...html.matchAll(/data-line="(\d+)"/g)].map((m) => m[1])).toEqual(["3", "4"]);
  });
});

describe("fragment rendering (inline mode)", () => {
  it("strips the block wrapper, and the paragraph too when inline", () => {
    expect(render("`code`", { fragment: true, inline: true })).toBe("<code>code</code>");
    expect(render("> quote", { fragment: true })).toMatch(/^<blockquote/);
  });

  it("offsets line ids to the fragment's place in the document", () => {
    const lineMap = new Map();
    renderMyst("some text", { lineMap, fragment: true, lineOffset: 41, keepLineMap: true });
    expect([...lineMap.keys()]).toEqual([42]);
  });
});

describe("frontmatter", () => {
  it("is hidden from the preview", () => {
    const html = render("---\ntitle: My doc\n---\n\nBody.");
    expect(html).not.toContain("title: My doc");
    expect(html).toContain("Body.");
  });

  it("does not swallow a leading yaml code fence", () => {
    expect(render("```yaml\nkey: value\n```")).toContain("key: value");
  });
});
