import { describe, it, expect, vi, beforeEach, afterEach } from "vite-plus/test";
import { render, h } from "preact";
import { StatusBar } from "../../src/components/StatusBar.jsx";
import { MystState, createMystState } from "../../src/mystState.js";

describe("StatusBar git items", () => {
  let container;

  beforeEach(() => {
    container = document.createElement("div");
    document.body.appendChild(container);
    if (typeof window !== "undefined") {
      if (!window.localStorage) {
        window.localStorage = {
          getItem: vi.fn(() => null),
          setItem: vi.fn(),
          removeItem: vi.fn(),
          clear: vi.fn(),
        };
      }
      window.myst_editor = { test: {} };
    }
  });

  afterEach(() => {
    container.remove();
    container = null;
  });

  it("renders status items ordered as commit first, then branch, then MR with icons", () => {
    const state = createMystState({ id: "test" });
    const onCommitClick = vi.fn();
    const onBranchClick = vi.fn();
    const onMrClick = vi.fn();

    const CommitIcon = () =>
      h("svg", { width: "14", height: "14", "data-testid": "status-commit-icon", viewBox: "0 0 24 24" }, [
        h("circle", { cx: "12", cy: "12", r: "4" }),
      ]);

    const BranchIcon = () =>
      h("svg", { width: "14", height: "14", "data-testid": "status-branch-icon", viewBox: "0 0 24 24" }, [
        h("circle", { cx: "18", cy: "6", r: "3" }),
      ]);

    const MrIcon = () =>
      h("svg", { width: "14", height: "14", "data-testid": "status-mr-icon", viewBox: "0 0 24 24" }, [h("circle", { cx: "18", cy: "18", r: "3" })]);

    state.options.statusItems.value = [
      {
        id: "commit",
        icon: CommitIcon,
        label: "4a3f2b1",
        mono: true,
        title: "Switch commit",
        onClick: onCommitClick,
        attrs: { "data-git-commit": "", "aria-label": "Commit 4a3f2b1. Switch commit" },
      },
      {
        id: "branch",
        icon: BranchIcon,
        label: "feature/awesome",
        title: "Switch or create branch",
        onClick: onBranchClick,
        attrs: { "data-git-branch": "", "aria-label": "Branch feature/awesome. Switch or create branch" },
      },
      {
        id: "merge-request",
        icon: MrIcon,
        label: "MR",
        title: "Create GitLab merge request",
        onClick: onMrClick,
        attrs: { "data-git-mr": "", "aria-label": "Create merge request" },
      },
    ];

    render(h(MystState.Provider, { value: state }, h(StatusBar, {})), container);

    // Verify ordering of status bar items in the DOM
    const buttons = container.querySelectorAll("#status-bar button.item");
    expect(buttons.length).toBe(3);
    expect(buttons[0].getAttribute("data-git-commit")).not.toBeNull();
    expect(buttons[1].getAttribute("data-git-branch")).not.toBeNull();
    expect(buttons[2].getAttribute("data-git-mr")).not.toBeNull();

    // Verify commit item has icon and text
    const commitBtn = buttons[0];
    expect(commitBtn.querySelector("[data-testid='status-commit-icon']")).not.toBeNull();
    expect(commitBtn.textContent).toContain("4a3f2b1");
    expect(commitBtn.getAttribute("title")).toBe("Switch commit");

    // Verify branch item has icon and text
    const branchBtn = buttons[1];
    expect(branchBtn.querySelector("[data-testid='status-branch-icon']")).not.toBeNull();
    expect(branchBtn.textContent).toContain("feature/awesome");
    expect(branchBtn.getAttribute("title")).toBe("Switch or create branch");

    // Verify MR item has icon and text
    const mrBtn = buttons[2];
    expect(mrBtn.querySelector("[data-testid='status-mr-icon']")).not.toBeNull();
    expect(mrBtn.textContent).toContain("MR");
    expect(mrBtn.getAttribute("title")).toBe("Create GitLab merge request");

    // Click commit button
    commitBtn.dispatchEvent(new MouseEvent("click", { bubbles: true }));
    expect(onCommitClick).toHaveBeenCalledTimes(1);

    // Click branch button
    branchBtn.dispatchEvent(new MouseEvent("click", { bubbles: true }));
    expect(onBranchClick).toHaveBeenCalledTimes(1);

    // Click MR button
    mrBtn.dispatchEvent(new MouseEvent("click", { bubbles: true }));
    expect(onMrClick).toHaveBeenCalledTimes(1);
  });

  it("renders MR badge with !iid when an open merge request exists", () => {
    const state = createMystState({ id: "test" });
    state.options.statusItems.value = [
      {
        id: "branch",
        label: "development",
        title: "Switch or create branch",
        onClick: vi.fn(),
        attrs: { "data-git-branch": "" },
      },
      {
        id: "merge-request",
        label: "MR !42",
        title: "Open merge request !42: Update docs. Click to view or create MR.",
        onClick: vi.fn(),
        attrs: { "data-git-mr": "", "data-git-open-mr": "" },
      },
    ];

    render(h(MystState.Provider, { value: state }, h(StatusBar, {})), container);

    const mrBtn = container.querySelector("[data-git-mr]");
    expect(mrBtn).not.toBeNull();
    expect(mrBtn.textContent).toContain("MR !42");
    expect(mrBtn.getAttribute("data-git-open-mr")).not.toBeNull();
  });
});
