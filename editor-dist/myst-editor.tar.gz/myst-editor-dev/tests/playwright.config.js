import { defineConfig } from "@playwright/test";
export default defineConfig({
  // Only e2e specs; unit tests (tests/unit/*.test.js) are run by vitest, not Playwright.
  testMatch: "**/*.spec.ts",
  use: {
    baseURL: "http://localhost:4173",
    video: "retain-on-failure",
  },
  workers: "100%",
  retries: process.env.CI ? 1 : 0,
});
