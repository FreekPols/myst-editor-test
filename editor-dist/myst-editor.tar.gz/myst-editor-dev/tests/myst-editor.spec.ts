import { ChangeSpec } from "@codemirror/state";
import { test, expect, Page } from "@playwright/test";
import { EditorView } from "codemirror";
import fs from "fs/promises";
import { createMystState } from "../src/mystState";
import { DEMO_FEATURE_TIP } from "../src/myst-git/demo-data.js";

declare global {
  interface Window {
    myst_editor: Record<
      string,
      {
        text: string;
        main_editor: EditorView;
        state: ReturnType<typeof createMystState>;
      }
    >;
  }
}

const id = "demo";

test.describe.parallel("With collaboration disabled", () => {
  test.beforeEach(async ({ page }) => {
    await applyPageOpts(page, { collab: "false" });
  });

  test("Loads initial document", async ({ page }) => {
    await expect(async () => {
      const editorContent = await page.evaluate((id) => window.myst_editor[id].text, id);
      expect(editorContent).toMatch(/^---\ntitle: Jupyter Book 2 syntax showcase/);
      expect(editorContent.indexOf(editorContent.slice(0, 20))).toBe(editorContent.lastIndexOf(editorContent.slice(0, 20))); // Assert that content isn't duplicated
    }).toPass();
  });

  test("Caches async transforms", async ({ page }) => {
    await clearEditor(page);
    const todayDate = new Date().toLocaleString("en-GB", { timeZone: "UTC" }).split(" ")[0];

    // |date| gets transformed for the first time
    await insertChangesAndCheckOutput(
      page,
      {
        from: 0,
        insert: "blah blah |date| blah blah",
      },
      (html) => expect(html).toContain(todayDate),
    );

    // Find out what the transform has returned
    const previewContent = (await page.locator(".myst-preview").first().textContent()) as string;
    const time = previewContent.split(" ")[3];

    await page.waitForTimeout(2000);

    // Assert that the next |date| returns the same time as the first one
    await clearEditor(page);
    await insertChangesAndCheckOutput(
      page,
      {
        from: 0,
        insert: "blah blah |date| blah blah",
      },
      (html) => expect(html).toContain(time),
    );

    // But if we click the refresh button then the transform will be updated and output will be different
    await page.getByTitle("Refresh GitLab Commits and Issues").click();
    await insertChangesAndCheckOutput(page, null, (html) => expect(html).not.toContain(time));
  });

  test.describe("Inserting a code cell", () => {
    const openDialog = async (page: Page) => {
      await page.locator("[name='code-cell']").click();
      const dialog = page.locator("#form-dialog[open]");
      await dialog.waitFor();
      return dialog;
    };
    const docText = (page: Page) => page.evaluate((id) => window.myst_editor[id].text, id);

    test("Writes the tags the chosen intent implies, and the kernel the page needs", async ({ page }) => {
      await clearEditor(page);
      await insertToMainEditor(page, { from: 0, insert: "---\ntitle: A page\n---\n\n# Heading\n" });
      await page.evaluate((id) => window.myst_editor[id].main_editor.dispatch({ selection: { anchor: 0 } }), id);

      const dialog = await openDialog(page);
      // "Figure" is the default intent, so the author picks nothing to get the common case.
      // Anchored rather than exact: the field's accessible name carries its hint text too.
      await dialog.getByLabel(/^Label/).fill("fig-airy");
      await dialog.getByLabel("Hide warnings (stderr)").check();
      await dialog.getByRole("button", { name: "Insert" }).click();

      await expect(async () => {
        const text = await docText(page);
        expect(text).toContain("```{code-cell} python");
        expect(text).toContain(":label: fig-airy");
        // The preset's tag and the extra one, in the order the dialog showed them.
        expect(text).toContain(":tags: [remove-input, remove-stderr]");
        // Without a kernelspec the page builds green with every figure blank, so the dialog offers it
        // ticked and it lands in the frontmatter that is already there rather than in a second block.
        expect(text).toContain("title: A page\nkernelspec:\n  name: python3\n  display_name: Python 3\n---");
        expect(text.match(/^---$/gm)).toHaveLength(2);
      }).toPass();
    });

    test("Stops offering the kernel once the page has one", async ({ page }) => {
      await clearEditor(page);
      await insertToMainEditor(page, { from: 0, insert: "---\nkernelspec:\n  name: python3\n---\n\n# Heading\n" });
      await page.evaluate((id) => window.myst_editor[id].main_editor.dispatch({ selection: { anchor: 0 } }), id);

      const dialog = await openDialog(page);
      await expect(dialog.getByText("Add a kernel to this page")).toHaveCount(0);
      await dialog.getByRole("button", { name: "Insert" }).click();

      await expect(async () => {
        const text = await docText(page);
        expect(text).toContain("```{code-cell} python");
        // Still one kernelspec, and still the author's own.
        expect(text.match(/kernelspec:/g)).toHaveLength(1);
      }).toPass();
    });

    test("Wraps the selected code, and one undo takes the whole insertion back", async ({ page }) => {
      await clearEditor(page);
      await insertToMainEditor(page, { from: 0, insert: "print(1)\n" });
      await page.evaluate((id) => window.myst_editor[id].main_editor.dispatch({ selection: { anchor: 0, head: 8 } }), id);

      const dialog = await openDialog(page);
      await dialog.getByRole("button", { name: "Insert" }).click();
      await expect(async () => {
        expect(await docText(page)).toContain(":tags: [remove-input]\n\nprint(1)\n```");
      }).toPass();

      // The cell and the frontmatter it needed go in as one transaction, so this is one undo, not two.
      await page.locator(".cm-content").press("ControlOrMeta+z");
      await expect(async () => {
        expect(await docText(page)).toBe("print(1)\n");
      }).toPass();
    });
  });

  test.describe("Clicking the preview syncs the editor", () => {
    /** Click through the app's own handler on an element already in view, so nothing auto-scrolls
     * behind the assertion the way locator.click() would. Returns how far the source line ended up
     * from the element that was clicked, and which line the cursor landed on. */
    const clickPreviewAt = (page: Page, fraction: number, settleMs: number) =>
      page.evaluate(
        ({ id, fraction, settleMs }) => {
          const root = (document.getElementById("myst") as HTMLElement).shadowRoot as ShadowRoot;
          const preview = root.querySelector(".myst-preview") as HTMLElement;
          const view = window.myst_editor[id].state.editorView.value;
          const scroller = view.dom.parentElement as HTMLElement;
          view.dispatch({ selection: { anchor: 0, head: 0 } });
          scroller.scrollTop = 0;

          const mapped = [...preview.querySelectorAll("[data-line-id]")] as HTMLElement[];
          const target = mapped[Math.floor(mapped.length * fraction)];
          preview.scrollTop = target.offsetTop - preview.clientHeight / 3;

          return new Promise<{ cursorLine: number; alignmentGap: number; previewMoved: number }>((resolve) =>
            requestAnimationFrame(() => {
              const previewScrollBefore = preview.scrollTop;
              target.dispatchEvent(new MouseEvent("click", { bubbles: true, composed: true }));
              setTimeout(() => {
                const line = view.state.doc.lineAt(view.state.selection.main.head);
                const lineScreenTop = view.lineBlockAt(line.from).top + view.dom.getBoundingClientRect().top;
                resolve({
                  cursorLine: line.number,
                  alignmentGap: Math.round(lineScreenTop - target.getBoundingClientRect().top),
                  previewMoved: Math.round(preview.scrollTop - previewScrollBefore),
                });
              }, settleMs);
            }),
          );
        },
        { id, fraction, settleMs },
      );

    test("Moves the cursor on the first click, not the second", async ({ page }) => {
      // The old implementation waited for a chain of smooth scrolls to finish before setting the
      // cursor - up to ~1.7s for a line far down the document - so a single click looked like a dead
      // click and people clicked again. 150ms is far below that and far above what the fix needs.
      for (const fraction of [0.4, 0.9]) {
        const { cursorLine } = await clickPreviewAt(page, fraction, 150);
        expect(cursorLine, `click ${fraction * 100}% down did not move the cursor`).toBeGreaterThan(1);
      }
    });

    test("Flashes the source line it landed on, then lets it go", async ({ page }) => {
      // Both panes move at once and the editor arrives instantly, so without a mark there is nothing
      // to follow: finding the line that was meant means reading for the text you clicked.
      const { cursorLine } = await clickPreviewAt(page, 0.35, 150);
      const flashed = await page.evaluate((id) => {
        const root = (document.getElementById("myst") as HTMLElement).shadowRoot as ShadowRoot;
        const marks = root.querySelectorAll(".cm-syncFlash");
        const view = window.myst_editor[id].state.editorView.value;
        const line = view.state.doc.lineAt(view.state.selection.main.head);
        return { count: marks.length, matchesCursorLine: marks[0]?.textContent === line.text };
      }, id);
      expect(flashed.count, "no line was marked").toBe(1);
      expect(flashed.matchesCursorLine, `the mark is not on line ${cursorLine}, where the cursor went`).toBe(true);

      // It is a flash, not a highlight: a mark that stays becomes part of the document.
      await expect(page.locator(".cm-syncFlash")).toHaveCount(0, { timeout: 4000 });
    });

    test("Lines the source up with the element that was clicked", async ({ page }) => {
      for (const fraction of [0.15, 0.4, 0.9]) {
        const { alignmentGap, previewMoved } = await clickPreviewAt(page, fraction, 600);
        // Line heights outside CodeMirror's viewport are estimates, so the alignment converges over a
        // few frames; a few pixels of slack absorbs sub-pixel rounding.
        expect(Math.abs(alignmentGap), `misaligned by ${alignmentGap}px at ${fraction * 100}%`).toBeLessThan(10);
        // The preview is the pane being driven: it must not scroll away from what the user clicked.
        expect(previewMoved, "the preview scrolled away from the clicked element").toBe(0);
      }
    });
  });

  test.describe("Renders input", () => {
    [1, 2, 3].forEach((header) => {
      test("Renders header: " + header, async ({ page }) => {
        await clearEditor(page);
        await insertChangesAndCheckOutput(
          page,
          {
            from: 0,
            insert: "#".repeat(header) + " Some title",
          },
          (html) => expect(html.match(`<h${header}.*>Some title`)).toHaveLength(1),
        );
      });
    });

    test("Renders synchronous transforms", async ({ page }) => {
      await clearEditor(page);
      await insertChangesAndCheckOutput(
        page,
        {
          from: 0,
          insert: "blah blah @some-user blah  blah ",
        },
        (html) => expect(html).toContain(`<a href="https://github.com/some-user">`),
      );
    });

    test("Renders async transforms", async ({ page }) => {
      const today = new Date().toLocaleString("en-GB", { timeZone: "UTC" });
      const [date] = today.split(" ");
      await clearEditor(page);
      await insertChangesAndCheckOutput(
        page,
        {
          from: 0,
          insert: "blah blah |date| blah blah",
        },
        (html) => expect(html).toContain(date),
      );
    });

    test("Renders custom roles", async ({ page }) => {
      await clearEditor(page);
      await insertChangesAndCheckOutput(
        page,
        {
          from: 0,
          insert: "blah blah {say}`something` blah blah",
        },
        (html) => expect(html).toContain(" says: 'something'"),
      );
    });
  });

  test("Copy as HTML button copies to clipboard", async ({ page, context }) => {
    await context.grantPermissions(["clipboard-write", "clipboard-read"]);
    await page.getByTitle("Copy document as HTML").click();
    await page.waitForSelector(".topbar-alert");
    await expect(async () => {
      const clipboard = await page.evaluate(() => navigator.clipboard.readText());
      expect(clipboard).toContain("<h1");
    }).toPass();
  });

  test("Mermaid diagrams", async ({ page }) => {
    await clearEditor(page);
    await insertChangesAndCheckOutput(
      page,
      {
        from: 0,
        insert: `\`\`\`mermaid
graph TD
    A-->B
\`\`\``,
      },
      (html) => expect(html).toContain("<svg"),
    );
  });

  test.describe.parallel("Inline mode", () => {
    test("Starts properly", async ({ page }) => {
      await startInlineMode(page);
      await clearEditor(page);
      await insertToMainEditor(page, { from: 0, insert: `# |date|\n## Test heading\ntest123` });
      await page.waitForSelector(".inline-custom-styles");
    });

    test.describe("Common transforms", () => {
      test("Bold text is being rendered", async ({ page }) => {
        await startInlineMode(page);
        await clearEditor(page);
        const text = "This text should render as bold";
        await insertToMainEditor(page, { from: 0, insert: `**${text}**` });
        expect((await page.locator(".tok-strong").allInnerTexts()).join("")).toBe(text);
      });

      test("Italic text is being rendered", async ({ page }) => {
        await startInlineMode(page);
        await clearEditor(page);
        const text = "This text should render as italic";
        await insertToMainEditor(page, { from: 0, insert: `_${text}_` });
        expect((await page.locator(".tok-emphasis").allInnerTexts()).join("")).toBe(text);
      });

      test("Strikethrough text is being rendered", async ({ page }) => {
        await startInlineMode(page);
        await clearEditor(page);
        const text = "This text should render as strikethrough";
        await insertToMainEditor(page, { from: 0, insert: `~~${text}~~` });
        // Strikethrough is special because it doesn't add any "tok-..." classes to the tokens. Therefore we need to check the style manually.
        expect(
          await page.locator(".cm-content *").evaluateAll((elements) =>
            elements
              .filter((element) => getComputedStyle(element).textDecorationLine === "line-through")
              .map((element) => element.textContent)
              .filter(Boolean)
              .join(" ")
              .replace(/\s+/g, " "),
          ),
        ).toBe(text);
      });
    });
  });

  // Suggestions are collaboration-only: the toggle is hidden, CriticMarkup stays literal text, and no
  // accept/reject widgets appear. The behavioural tests live in the "With collaboration enabled" block.
  test.describe.parallel("Suggestions are off", () => {
    test("Does not offer the suggest mode toggle", async ({ page }) => {
      await expect(page.locator('[name="suggest-mode"]')).toHaveCount(0);
    });

    test("Leaves CriticMarkup as literal text with no accept/reject widgets", async ({ page }) => {
      await clearEditor(page);
      await insertToMainEditor(page, { from: 0, insert: `A {++suggested++} change.` });
      await expect(page.locator("html-chunk")).toContainText("A {++suggested++} change.");
      await expect(page.locator("html-chunk ins")).toHaveCount(0);
      await expect(page.locator(".cm-critic-widget")).toHaveCount(0);
    });
  });

  test("Unfinished substitution suggestions don't cause the text inside to merge into the previous block", async ({ page }) => {
    await clearEditor(page);
    await insertToMainEditor(page, {
      from: 0,
      insert: `# Heading 1 {~~
This text shouldn't merge inside the previous block~~}`,
    });
    // Check whether the heading exists and whether the line under it is rendered in a seperate block.
    await expect(page.locator("html-chunk").locator("h1").locator("..").locator("p")).toHaveCount(1);
  });
});

test.describe.parallel("MyST syntax rendering", () => {
  test("renders math, directive bodies, and a soft literalinclude placeholder", async ({ page }) => {
    const fixture = await fs.readFile("tests/fixtures/myst-syntax.md", "utf8");
    await applyPageOpts(page, { collab: "false" });
    await clearEditor(page);
    await insertChangesAndCheckOutput(page, { from: 0, insert: fixture }, (html) => {
      // LaTeX math renders to MathML (both inline and block)
      expect(html).toContain("<math");
      expect(html).toContain('display="block"');
      // The <semantics> wrapper must survive sanitization, otherwise the raw TeX in <annotation>
      // leaks as a text node and renders next to the math (double rendering).
      expect(html).toContain("<semantics>");
      // :::{table} with :label:/:align: renders the nested pipe table instead of an error card
      expect(html).toContain("<table");
      expect(html).toContain("<td");
      expect(html).not.toContain("directive-error");
      // admonition body still renders markdown
      expect(html).toContain("admonition");
      // container directives render their wrappers + nested markdown
      expect(html).toContain("card");
      expect(html).toContain("<details");
      // every directive in the fixture, literalinclude included, is handled
      expect(html).not.toContain("unhandled");
    });
  });

  test("renders MyST end to end (math, admonition box + embedded markdown, cross-refs)", async ({ page }) => {
    await applyPageOpts(page, { collab: "false" });
    await clearEditor(page);
    const src = [
      "# Heading one",
      "",
      "Inline math $a^2+b^2$ and a block:",
      "",
      "$$\\int_0^1 x\\,dx$$",
      "",
      "```{note}",
      "An **admonition** with a [link](https://x).",
      "```",
      "",
      "```{figure} data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=",
      ":label: fig-1",
      "A caption.",
      "```",
      "",
      "See {numref}`fig-1`.",
    ].join("\n");
    await insertChangesAndCheckOutput(page, { from: 0, insert: src }, (html) => {
      // math -> MathML
      expect(html).toContain("<math");
      expect(html).toContain('display="block"');
      // admonition renders the box AND the embedded markdown (the docutils gap)
      expect(html).toContain("admonition");
      expect(html).toContain("<strong>");
      // cross-reference numbering resolved
      expect(html).toContain('href="#fig-1"');
      // source-map contract preserved: data-line-id anchors are present for scroll-sync/comments
      expect(html).toContain("data-line-id");
    });
  });
});

test.describe.parallel("With collaboration enabled", () => {
  test("Keeps the initial document if collaborative state is empty", async ({ context }) => {
    const page = await applyPageOpts(await context.newPage(), defaultCollabOpts());

    await expect(async () => {
      const editorContent = await page.evaluate((id) => window.myst_editor[id].text, id);
      expect(editorContent).toMatch(/^---\ntitle: Jupyter Book 2 syntax showcase/);
      expect(editorContent.indexOf(editorContent.slice(0, 20))).toBe(editorContent.lastIndexOf(editorContent.slice(0, 20))); // Assert that content isn't duplicated
    }).toPass();
  });

  test("Rejects the initial document if collaborative state is not empty", async ({ context }) => {
    const collabOpts = defaultCollabOpts();
    const pageA = await applyPageOpts(await context.newPage(), collabOpts);

    // Initialize the document from pageA
    await clearEditor(pageA);
    await insertChangesAndCheckOutput(pageA, { from: 0, insert: "Some content" }, (html) => expect(html).toContain("Some content"));
    await pageA.close();

    // Open the document as another user and verify that the initial content was ignored
    const pageB = await applyPageOpts(await context.newPage(), collabOpts);

    await expect(async () => {
      const editorContent = await pageB.evaluate((id) => window.myst_editor[id].text, id);
      expect(editorContent).not.toContain("# Jupyter Book 2 syntax showcase");
      expect(editorContent).toContain("Some content");
      expect(editorContent.indexOf("Some content")).toBe(editorContent.lastIndexOf("Some content")); // Assert that content isn't duplicated
    }).toPass();
  });

  test("Synces document between peers", async ({ context }) => {
    const collabOpts = defaultCollabOpts();
    const pageA = await applyPageOpts(await context.newPage(), collabOpts);

    // Initialize the document from pageA and add some content
    await clearEditor(pageA);
    await insertChangesAndCheckOutput(pageA, { from: 0, insert: "This is from pageA!" }, (html) => expect(html).toContain("This is from pageA!"));

    // Open the document as another user and add some content
    const pageB = await applyPageOpts(await context.newPage(), collabOpts);
    await expect(async () => {
      const currentText = await pageB.evaluate((id) => window.myst_editor[id].text, id);
      expect(currentText).toBe("This is from pageA!");

      await insertChangesAndCheckOutput(
        pageB,
        {
          from: currentText.length,
          insert: "And this is from pageB!",
        },
        (html) => {
          // Verify that both contents are present
          expect(html).toContain("This is from pageA!");
          expect(html).toContain("And this is from pageB!");
        },
      );
    }).toPass();
  });

  test.describe("Comments", () => {
    test("Positions are synced", async ({ context }) => {
      const collabOpts = defaultCollabOpts();
      const pageA = await applyPageOpts(await context.newPage(), collabOpts);
      const pageB = await applyPageOpts(await context.newPage(), collabOpts);

      // Initialize the document from pageA and add some content
      await clearEditor(pageA);
      await insertChangesAndCheckOutput(pageA, { from: 0, insert: "Line1\nLine2\nLine3\nLine4" }, (html) => expect(html).toContain("Line4"));

      await addComment(pageA, 2);

      // Confirm that comment was added
      await expect(pageA.locator(".comment-wrapper")).toHaveCount(1);
      await expect(pageB.locator(".comment-wrapper")).toHaveCount(1);

      // Remove the comment from pageB
      await getCommentBtn(pageB, 2).hover({ force: true });
      await pageB.getByText("DELETE", { exact: true }).click();

      // Verify that comment was removed on both peers
      await expect(pageB.locator(".comment-wrapper")).toHaveCount(0);
      await expect(pageA.locator(".comment-wrapper")).toHaveCount(0);
    });

    test("Can be dragged", async ({ context }) => {
      const collabOpts = defaultCollabOpts();
      const pageA = await applyPageOpts(await context.newPage(), collabOpts);
      const pageB = await applyPageOpts(await context.newPage(), collabOpts);

      // Initialize the document from pageA and add some content
      await clearEditor(pageA);
      await insertChangesAndCheckOutput(pageA, { from: 0, insert: "Line1\nLine2\nLine3\nLine4" }, (html) => expect(html).toContain("Line4"));

      await addComment(pageA, 1);

      const initialCommentPosition = await pageA
        .locator("div:has(> .comment-wrapper)")
        .first()
        .evaluate((e) => Number(e.getAttribute("top")));

      // Drag the comment
      await getCommentBtn(pageA, 1).hover({ force: true });
      await pageA.mouse.down();
      const box = await getCommentBtn(pageA, 3).boundingBox();
      expect(box).not.toBeNull();
      await pageA.mouse.move(box!.x + box!.width / 2, box!.y + box!.height / 2, { steps: 5 });
      await pageA.mouse.up();

      await expect(pageA.locator(".comment-wrapper")).toHaveCount(1);
      await expect(pageB.locator(".comment-wrapper")).toHaveCount(1);

      // Confirm that the comment position has changed
      await expect(async () => {
        const newCommentPosition = await pageA
          .locator("div:has(> .comment-wrapper)")
          .first()
          .evaluate((e) => Number(e.getAttribute("top")));
        expect(newCommentPosition).toBeGreaterThan(initialCommentPosition);
      }).toPass();
    });

    test("Can be resolved", async ({ context }) => {
      const collabOpts = defaultCollabOpts();
      const pageA = await applyPageOpts(await context.newPage(), collabOpts);
      const pageB = await applyPageOpts(await context.newPage(), collabOpts);

      await addComment(pageA, 1);

      // Resolve the comment
      await getCommentBtn(pageA, 1).hover({ force: true });
      await pageA.locator("#demo-editor").getByText("RESOLVE", { exact: true }).click();

      // Verify that it disappeared from the editor
      await expect(pageA.locator(".comment-wrapper")).toHaveCount(0);

      // Verify that it appeared in the resolved comments
      await openResolvedComments(pageA);
      await pageA.waitForSelector(".resolved-comment");
      await expect(pageA.locator(".resolved-comment")).toHaveCount(1);

      // Verify that the resolved comments are synced among peers
      await openResolvedComments(pageB);
      await pageB.waitForSelector(".resolved-comment");
      await expect(pageB.locator(".resolved-comment")).toHaveCount(1);
    });

    test("Can be deleted", async ({ context }) => {
      const collabOpts = defaultCollabOpts();
      const pageA = await applyPageOpts(await context.newPage(), collabOpts);
      const pageB = await applyPageOpts(await context.newPage(), collabOpts);

      await addComment(pageA, 1);

      // Resolve the comment
      await getCommentBtn(pageA, 1).hover({ force: true });
      await pageA.locator("#demo-editor").getByText("DELETE", { exact: true }).click();

      // Verify it is gone
      await expect(pageA.locator(".comment-wrapper")).toHaveCount(0);
      await expect(pageB.locator(".comment-wrapper")).toHaveCount(0);
    });

    test("Can be merged", async ({ context }) => {
      const collabOpts = defaultCollabOpts();
      const pageA = await applyPageOpts(await context.newPage(), collabOpts);
      const pageB = await applyPageOpts(await context.newPage(), collabOpts);

      // Initialize the document from pageA and add some content
      await clearEditor(pageA);
      await insertChangesAndCheckOutput(pageA, { from: 0, insert: "Line1\nLine2\nLine3\nLine4" }, (html) => expect(html).toContain("Line4"));

      await addComment(pageA, 1, "1");
      await addComment(pageA, 3, "2");

      // Drag the comment
      // Locator.dragTo() has issues as reported in https://github.com/microsoft/playwright/issues/20254
      await getCommentBtn(pageA, 1).hover({ force: true });
      await pageA.mouse.down();
      const box = await getCommentBtn(pageA, 3).boundingBox();
      expect(box).not.toBeNull();
      await pageA.mouse.move(box!.x + box!.width / 2, box!.y + box!.height / 2, { steps: 5 });
      await pageA.mouse.up();

      await expect(pageA.locator(".comment-wrapper")).toHaveCount(1);
      await expect(pageB.locator(".comment-wrapper")).toHaveCount(1);

      // Confirm the comment contents are merged
      await expect(pageA.locator(".cm-comment-author-colored").first()).toContainText("2");
      await expect(pageA.locator(".cm-comment-author-colored").last()).toContainText("1");
      await expect(pageB.locator(".cm-comment-author-colored").first()).toContainText("2");
      await expect(pageB.locator(".cm-comment-author-colored").last()).toContainText("1");
    });
  });

  test.describe("Resolved Comments", () => {
    test("Can be restored", async ({ context }) => {
      const collabOpts = defaultCollabOpts();
      const pageA = await applyPageOpts(await context.newPage(), collabOpts);
      const pageB = await applyPageOpts(await context.newPage(), collabOpts);

      // Switch to resolved comments view
      await openResolvedComments(pageA);
      await openResolvedComments(pageB);

      await addComment(pageA, 1);

      // Resolve the comment
      await getCommentBtn(pageA, 1).hover({ force: true });
      await pageA.locator("#demo-editor").getByText("RESOLVE", { exact: true }).click();

      // Restore the comment
      await pageA.locator(".myst-dropdown-toggle").first().hover({ force: true });
      await pageA.locator(".myst-restore-btn").first().click();

      // Verify it is gone from resolved comments
      await expect(pageA.locator(".resolved-comment")).toHaveCount(0);
      await expect(pageB.locator(".resolved-comment")).toHaveCount(0);

      // Verify it appeared in the editor
      await expect(pageA.locator(".comment-wrapper")).toHaveCount(1);
      await expect(pageB.locator(".comment-wrapper")).toHaveCount(1);
    });

    test("Can be occupied and restored", async ({ context }) => {
      const collabOpts = defaultCollabOpts();
      const pageA = await applyPageOpts(await context.newPage(), collabOpts);
      const pageB = await applyPageOpts(await context.newPage(), collabOpts);

      // Switch to resolved comments view
      await openResolvedComments(pageA);
      await openResolvedComments(pageB);

      await addComment(pageA, 1, "1");

      // Resolve the comment
      await getCommentBtn(pageA, 1).hover({ force: true });
      await pageA.locator("#demo-editor").getByText("RESOLVE", { exact: true }).click();

      await addComment(pageA, 1, "2");

      // Restore the comment
      await pageA.locator(".myst-dropdown-toggle").first().hover({ force: true });
      await pageA.locator(".myst-restore-btn").first().click();

      // Verify it is gone from resolved comments
      await expect(pageA.locator(".resolved-comment")).toHaveCount(0);
      await expect(pageB.locator(".resolved-comment")).toHaveCount(0);

      // Verify it is in the editor and contains both lines
      await expect(pageA.locator(".cm-comment-author-colored").first()).toContainText("2");
      await expect(pageA.locator(".cm-comment-author-colored").last()).toContainText("1");
      await expect(pageB.locator(".cm-comment-author-colored").first()).toContainText("2");
      await expect(pageB.locator(".cm-comment-author-colored").last()).toContainText("1");
    });

    test("Can be orphaned and restored", async ({ context }) => {
      const collabOpts = defaultCollabOpts();
      const pageA = await applyPageOpts(await context.newPage(), collabOpts);
      const pageB = await applyPageOpts(await context.newPage(), collabOpts);

      // Switch to resolved comments view
      await openResolvedComments(pageA);
      await openResolvedComments(pageB);

      await addComment(pageA, 1);

      // Resolve the comment
      await getCommentBtn(pageA, 1).hover({ force: true });
      await pageA.locator("#demo-editor").getByText("RESOLVE", { exact: true }).click();

      await clearEditor(pageA);

      // Restore comment
      await pageA.locator(".myst-dropdown-toggle").first().hover({ force: true });
      await pageA.locator(".myst-restore-btn").first().click();

      // Verify it is at the end of the document
      await expect(pageA.locator(".comment-wrapper")).toHaveCount(1);
      await expect(pageB.locator(".comment-wrapper")).toHaveCount(1);
    });

    test("Can be deleted", async ({ context }) => {
      const collabOpts = defaultCollabOpts();
      const pageA = await applyPageOpts(await context.newPage(), collabOpts);
      const pageB = await applyPageOpts(await context.newPage(), collabOpts);

      // Switch to resolved comments view
      await openResolvedComments(pageA);
      await openResolvedComments(pageB);

      await addComment(pageA, 1);

      // Resolve the comment
      await getCommentBtn(pageA, 1).hover({ force: true });
      await pageA.locator("#demo-editor").getByText("RESOLVE", { exact: true }).click();

      // Delete the comment
      await pageA.locator(".myst-dropdown-toggle").first().hover({ force: true });
      await pageA.locator(".myst-delete-btn").first().click();

      // Verify it is gone
      await expect(pageA.locator(".resolved-comment")).toHaveCount(0);
      await expect(pageB.locator(".resolved-comment")).toHaveCount(0);
    });
  });

  test.describe("Dynamic options", () => {
    test("Can modify UI", async ({ context }) => {
      const collabOpts = defaultCollabOpts();
      const page = await applyPageOpts(await context.newPage(), collabOpts);
      await page.evaluate(() => {
        window.myst_editor.demo.state.options.title.value = "Playwright";
        const btns = window.myst_editor.demo.state.options.includeButtons.value;
        window.myst_editor.demo.state.options.includeButtons.value = [...btns, { id: "test", text: "test" }];
        window.myst_editor.demo.state.options.mode.value = "Resolved";
      });

      await expect(page.locator("#document-title")).toContainText("Playwright");
      await page.evaluate(() => {
        window.myst_editor.demo.state.options.subtitle.value = "A subtitle";
      });
      await expect(page.locator("#document-subtitle")).toContainText("A subtitle");
      await expect(page.locator("#topbar .side:last-child .btns button")).toHaveCount(1);
      await expect(page.locator("#resolved-wrapper")).toBeVisible();
    });

    test("Can change rooms", async ({ context }) => {
      const collabOpts = defaultCollabOpts();
      // A, B - room 0
      const pageA = await applyPageOpts(await context.newPage(), collabOpts);
      const pageB = await applyPageOpts(await context.newPage(), collabOpts);

      await clearEditor(pageA);
      const text0 = "this is room 0";
      await insertToMainEditor(pageA, { from: 0, insert: text0 });
      await expect(async () => {
        const text = await pageB.evaluate((id) => window.myst_editor[id].text, id);
        expect(text).toBe(text0);
      }).toPass();

      const text1 = "this is room 1";
      const room1 = collabOpts.room + "1";
      // A - join room 1
      await changeRoom(pageA, room1);
      await clearEditor(pageA);
      await insertToMainEditor(pageA, { from: 0, insert: text1 });
      await expect(async () => {
        const text = await pageA.evaluate((id) => window.myst_editor[id].text, id);
        expect(text).toBe(text1);
      }).toPass();

      await expect(async () => {
        const text = await pageB.evaluate((id) => window.myst_editor[id].text, id);
        expect(text).toBe(text0);
      }).toPass();
      // B - join room 1
      await changeRoom(pageB, room1);
      await expect(async () => {
        const text = await pageB.evaluate((id) => window.myst_editor[id].text, id);
        expect(text).toBe(text1);
      }).toPass();
    });
  });

  test.describe.parallel("Suggestions", () => {
    test("Can accept suggestions", async ({ context }) => {
      const page = await applyPageOpts(await context.newPage(), defaultCollabOpts());
      await clearEditor(page);
      await insertToMainEditor(page, { from: 0, insert: `# {~~Heading~>Better heading~~}\nThis{++ is++} some text.\nThis is some text{-- text--}.` });
      await page.waitForSelector(".cm-critic-widget");
      await page.getByTitle("Accept suggestion").first().click();
      await page.getByTitle("Accept suggestion").first().click();
      await page.getByTitle("Accept suggestion").first().click();
      await expect(async () => {
        const text = await page.evaluate((id) => window.myst_editor[id].text, id);
        expect(text).toBe(`# Better heading\nThis is some text.\nThis is some text.`);
      }).toPass();
    });

    test("Can reject suggestions", async ({ context }) => {
      const page = await applyPageOpts(await context.newPage(), defaultCollabOpts());
      await clearEditor(page);
      await insertToMainEditor(page, { from: 0, insert: `# {~~Heading~>Better heading~~}\nThis{++ is++} some text.\nThis is some text{-- text--}.` });
      await page.waitForSelector(".cm-critic-widget");
      await page.getByTitle("Reject suggestion").first().click();
      await page.getByTitle("Reject suggestion").first().click();
      await page.getByTitle("Reject suggestion").first().click();
      await expect(async () => {
        const text = await page.evaluate((id) => window.myst_editor[id].text, id);
        expect(text).toBe(`# Heading\nThis some text.\nThis is some text text.`);
      }).toPass();
    });

    test("A multiline suggestion doesn't delete the paragraph above", async ({ context }) => {
      const page = await applyPageOpts(await context.newPage(), defaultCollabOpts());
      await clearEditor(page);
      await insertToMainEditor(page, {
        from: 0,
        insert: `Paragraph 1 {++
      The text here shouldn't overwrite the text above++}`,
      });
      const ins = page.locator("ins").first();
      await ins.waitFor();
      await expect(ins.locator("xpath=..")).toContainText("Paragraph 1");
    });

    test("A multiline suggestion doesn't delete the paragraph below", async ({ context }) => {
      const page = await applyPageOpts(await context.newPage(), defaultCollabOpts());
      await clearEditor(page);
      await insertToMainEditor(page, {
        from: 0,
        insert: `Paragraph 1 {++
        The text here shouldn't overwrite the text below
        ++} Paragraph 2`,
      });
      const ins = page.locator("ins").last();
      await ins.waitFor();
      await expect(ins.locator("xpath=..")).toContainText("Paragraph 2");
    });

    // KNOWN LIMITATION (v1.0.0): the mystmd path does not support a suggestion that spans a block
    // boundary, so the heading below parses as an H1 plus an indented code block instead of one H1.
    // Suggestions within a single block work. The markdown-it path handled this with a `critic-block`
    // core rule that re-sliced the raw source and spliced the token stream; porting that to mdast is
    // deferred - COMBINE tracks review via git rather than in-editor suggestions.
    test.fixme("The original type of the block is preserved when using multiline suggestions", async ({ context }) => {
      const page = await applyPageOpts(await context.newPage(), defaultCollabOpts());
      await clearEditor(page);
      await insertToMainEditor(page, {
        from: 0,
        insert: `# Heading 1 {++
      The text here shouldn't overwrite the text above++}`,
      });
      const ins = page.locator("ins").first();
      await expect(ins).toHaveJSProperty("parentElement.tagName", "H1");
    });
  });

  test("Can use suggest mode", async ({ context }) => {
    const page = await applyPageOpts(await context.newPage(), defaultCollabOpts());
    await clearEditor(page);
    await insertToMainEditor(page, { from: 0, insert: `# Heading` });
    await enableSuggestMode(page);
    await insertToMainEditor(page, { from: 2, to: 9, insert: `Better heading` });
    await expect(page.locator(".cm-critic-widget")).toBeVisible();
  });

  test("Resolved suggestions are shown", async ({ context }) => {
    const collabOpts = defaultCollabOpts();
    const pageA = await applyPageOpts(await context.newPage(), collabOpts);
    const pageB = await applyPageOpts(await context.newPage(), collabOpts);

    await clearEditor(pageA);
    await insertToMainEditor(pageA, { from: 0, insert: `# {~~Heading~>Better heading~~}\nThis{++ is++} some text.\nThis is some text{-- text--}.` });
    await pageA.waitForSelector(".cm-critic-widget");

    await openResolvedComments(pageA);
    await pageA.getByTitle("Accept suggestion").first().click();
    await pageA.getByTitle("Reject suggestion").first().click();
    await pageA.getByTitle("Accept suggestion").first().click();
    await expect(pageA.locator(".resolved-suggestion")).toHaveCount(3);

    await openResolvedComments(pageB);
    await expect(pageB.locator(".resolved-suggestion")).toHaveCount(3);
  });
});

test.describe.parallel("MystEditorGit wrapper", () => {
  test("Mounts without a collaboration option (minimal consumer config)", async ({ context }) => {
    // git.html omits the `collaboration` key entirely for ?collab=omit. applyPageOpts fails the test on
    // any page/console error, so an unguarded props.collaboration read would surface here as a crash.
    const page = await applyPageOpts(await context.newPage(), { collab: "omit", git_backend: "stub" }, true);
    await expect(page.locator(".cm-content")).toBeVisible();
  });

  test("Answers a click in the preview without being told to sync", async ({ context }) => {
    // The reported bug: `syncScroll` used to default to off, and both demo pages switched it on by
    // hand - so a real deployment, which does not, got a preview that ignored every click. Neither
    // demo page sets it now, which is what makes this a check of what a deployment actually gets.
    const page = await applyPageOpts(await context.newPage(), defaultCollabOpts(), true);
    await expect(page.locator(".myst-preview p")).not.toHaveCount(0);
    const cursorLine = await page.evaluate((id) => {
      const root = (document.getElementById("myst") as HTMLElement).shadowRoot as ShadowRoot;
      const preview = root.querySelector(".myst-preview") as HTMLElement;
      const view = window.myst_editor[id].state.editorView.value;
      view.dispatch({ selection: { anchor: 0, head: 0 } });
      const mapped = [...preview.querySelectorAll("[data-line-id]")] as HTMLElement[];
      mapped[mapped.length - 1].dispatchEvent(new MouseEvent("click", { bubbles: true, composed: true }));
      return view.state.doc.lineAt(view.state.selection.main.head).number;
    }, id);
    expect(cursorLine, "the preview ignored the click").toBeGreaterThan(1);
  });

  test("Opens the first page in the table of contents, and indexes from myst.yml", async ({ context }) => {
    // The demo repo carries docs/myst.yml and no `index` option, so the editor has to find the toc
    // itself. Before this, the sidebar needed an explicit index and the editor opened README.md.
    const page = await applyPageOpts(await context.newPage(), defaultCollabOpts(), true);
    await expect(async () => {
      const file = await page.evaluate((id) => window.myst_editor[id].git.file.value, id);
      expect(file).toBe("docs/index.md");
    }).toPass();
    await expect(page.locator(".file .file-name")).toHaveText(["index.md", "file1.md", "file2.md", "feature.md"]);
  });

  test("Follows `extends` to a toc kept in its own file", async ({ context }) => {
    // The demo repo is laid out like a real COMBINE book: myst.yml carries no `project.toc` of its
    // own, only `extends: toc.yml` plus a remote template. Parsing myst.yml alone yields nothing, so
    // without following extends the page index is empty and the editor falls back to README.md.
    const page = await applyPageOpts(await context.newPage(), defaultCollabOpts(), true);
    await expect(page.locator(".file .file-name")).toHaveText(["index.md", "file1.md", "file2.md", "feature.md"]);
    await expect(async () => {
      const file = await page.evaluate((id) => window.myst_editor[id].git.file.value, id);
      expect(file).toBe("docs/index.md");
    }).toPass();
  });

  test("Re-reads the table of contents when the branch or commit changes", async ({ context }) => {
    // The toc is per-commit: the feature branch lists feature.md, main does not. A stale index would
    // offer files that do not exist at the commit being edited.
    const page = await applyPageOpts(await context.newPage(), defaultCollabOpts(), true);
    await expect(page.locator(".file .file-name")).toHaveText(["index.md", "file1.md", "file2.md", "feature.md"]);

    await page.click("[data-git-branch]");
    await page.locator("#git-branch-picker[open]").waitFor();
    await page.locator("#git-branch-picker-list >> text=main").first().click();
    await expect(page.locator(".file .file-name")).toHaveText(["index.md", "file1.md", "file2.md"]);

    await page.click("[data-git-branch]");
    await page.locator("#git-branch-picker[open]").waitFor();
    await page.locator("#git-branch-picker-list >> text=feature").first().click();
    await expect(page.locator(".file .file-name")).toHaveText(["index.md", "file1.md", "file2.md", "feature.md"]);

    // An older commit on the same branch predates feature.md being added to the toc.
    await page.click("[data-git-commit]");
    await page.locator("#git-commit-picker[open]").waitFor();
    await page.locator("#git-commit-picker-list li").nth(1).click();
    await expect(page.locator(".file .file-name")).toHaveText(["index.md", "file1.md", "file2.md"]);
  });

  test("Collapses and restores the page index, and remembers which", async ({ context }) => {
    const page = await applyPageOpts(await context.newPage(), defaultCollabOpts(), true);
    const toggle = page.locator('[name="toggle-sidebar"]');
    const editorWidth = () =>
      page.evaluate(() => {
        const root = (document.getElementById("myst") as HTMLElement).shadowRoot as ShadowRoot;
        return Math.round((root.querySelector(".myst-editor-wrapper") as HTMLElement).getBoundingClientRect().width);
      });

    await expect(page.locator(".file").first()).toBeVisible();
    const withSidebar = await editorWidth();

    await toggle.click();
    await expect(page.locator(".file")).toHaveCount(0);
    // The point of collapsing is the space: the editor has to actually take it.
    expect(await editorWidth()).toBeGreaterThan(withSidebar);

    await toggle.click();
    await expect(page.locator(".file").first()).toBeVisible();
    expect(await editorWidth()).toBe(withSidebar);

    // The preference outlives the page, so it does not have to be closed again every visit.
    await toggle.click();
    await expect(page.locator(".file")).toHaveCount(0);
    await page.reload();
    await page.waitForSelector(".cm-content");
    await expect(page.locator(".file")).toHaveCount(0);
    await expect(toggle).toBeVisible();
  });

  test("Announces a slow git fetch, and stays silent on a fast one", async ({ context }) => {
    // ?latency makes the stub backend answer slowly; without it the popup is untestable because the
    // in-memory stub always returns inside the threshold.
    const page = await applyPageOpts(await context.newPage(), { ...defaultCollabOpts(), latency: 1200 }, true);
    await page.waitForFunction((id) => !window.myst_editor[id].git.loading.value, id);

    // Fire and forget: awaiting the switch would let it finish before we can look.
    await page.evaluate((id) => void window.myst_editor[id].git.switchFile("docs/file2.md"), id);
    await expect(page.locator("#loading-status")).toHaveText("Loading docs/file2.md…");
    await expect(page.locator("#loading-status")).toHaveCount(0, { timeout: 20000 });
    expect(await page.evaluate((id) => window.myst_editor[id].git.file.value, id)).toBe("docs/file2.md");
  });

  test("Says who is being waited on when the wait runs long", async ({ context }) => {
    // Past a few seconds the honest answer is "the server", and saying so is the point: a slow
    // morning at GitLab otherwise reads as a broken editor, with no way to tell the two apart.
    const page = await applyPageOpts(await context.newPage(), { ...defaultCollabOpts(), latency: 4000 }, true);
    await page.waitForFunction((id) => !window.myst_editor[id].git.loading.value, id, { timeout: 40000 });

    await page.evaluate((id) => void window.myst_editor[id].git.switchFile("docs/file2.md"), id);
    const status = page.locator("#loading-status");
    // The label comes up almost at once; the attribution only after the wait has become unusual.
    await expect(status).toHaveText(/Loading docs\/file2\.md/, { timeout: 5000 });
    await expect(status).not.toContainText("Waiting for");
    await expect(status).toContainText("Waiting for GitLab", { timeout: 10000 });

    // And it goes away with the popup rather than lingering into the next fetch.
    await expect(status).toHaveCount(0, { timeout: 20000 });
    expect(await page.evaluate((id) => window.myst_editor[id].git.waitingOnServer.value, id)).toBe(false);
  });

  test("Shows no loading popup when the backend is fast", async ({ context }) => {
    const page = await applyPageOpts(await context.newPage(), defaultCollabOpts(), true);
    await page.evaluate((id) => void window.myst_editor[id].git.switchFile("docs/file2.md"), id);
    // The whole point of the delay: an instant fetch must not flash a popup at the user.
    await page.waitForTimeout(250);
    await expect(page.locator("#loading-status")).toHaveCount(0);
  });

  test("Shows branch and commit in subtitle", async ({ context }) => {
    const page = await applyPageOpts(await context.newPage(), defaultCollabOpts(), true);
    await expect(page.locator("[data-git-branch]")).toContainText("feature");
    await expect(page.locator("[data-git-commit]")).toContainText(DEMO_FEATURE_TIP);
  });

  test("Refresh button refreshes the git view without losing unsaved work or changing branch", async ({ context }) => {
    const page = await applyPageOpts(await context.newPage(), defaultCollabOpts(), true);
    const branchBefore = (await page.locator("[data-git-branch]").textContent()) as string;
    const commitBefore = (await page.locator("[data-git-commit]").textContent()) as string;

    await clearEditor(page);
    await insertToMainEditor(page, { from: 0, insert: "UNSAVED EDIT MARKER" });

    await page.getByTitle("Refresh GitLab Commits and Issues").click();

    // Unsaved edit is preserved and the user stays on the same branch/commit.
    await expect(async () => {
      const text = await page.evaluate((id) => window.myst_editor[id].text, id);
      expect(text).toContain("UNSAVED EDIT MARKER");
    }).toPass();
    await expect(page.locator("[data-git-branch]")).toHaveText(branchBefore);
    await expect(page.locator("[data-git-commit]")).toHaveText(commitBefore);
  });

  test("Synces document between peers", async ({ context }) => {
    const collabOpts = defaultCollabOpts();
    const pageA = await applyPageOpts(await context.newPage(), collabOpts, true);

    // Initialize the document from pageA and add some content
    await clearEditor(pageA);
    await insertChangesAndCheckOutput(pageA, { from: 0, insert: "This is from pageA!" }, (html) => expect(html).toContain("This is from pageA!"));

    // Open the document as another user and add some content
    const pageB = await applyPageOpts(await context.newPage(), collabOpts, true);
    await expect(async () => {
      const currentText = await pageB.evaluate((id) => window.myst_editor[id].text, id);
      expect(currentText).toBe("This is from pageA!");

      await insertChangesAndCheckOutput(
        pageB,
        {
          from: currentText.length,
          insert: "And this is from pageB!",
        },
        (html) => {
          // Verify that both contents are present
          expect(html).toContain("This is from pageA!");
          expect(html).toContain("And this is from pageB!");
        },
      );
    }).toPass();
  });

  test("Switches rooms", async ({ context }) => {
    const collabOpts = defaultCollabOpts();
    const page = await applyPageOpts(await context.newPage(), collabOpts, true);

    async function checkRoomSwitch(roomId: number, action: () => Promise<void>) {
      await clearEditor(page);
      await insertToMainEditor(page, { from: 0, insert: `room ${roomId}` });
      await action();
      // Discarding unsaved changes is confirmed by the editor's own modal, not a native dialog.
      const confirmDialog = page.locator("#form-dialog[open]");
      await confirmDialog.waitFor();
      await confirmDialog.getByText("Discard changes").click();
      await page.waitForSelector(".cm-content");
      await expect(async () => {
        const text = await page.evaluate((id) => window.myst_editor[id].text, id);
        expect(text).not.toContain(`room ${roomId}`);
      }).toPass();
    }

    // commits first — pick a different revision than the current tip
    await checkRoomSwitch(1, async () => {
      await page.click("[data-git-commit]");
      await page.locator("#git-commit-picker[open]").waitFor();
      await page.locator("#git-commit-picker-list li").nth(1).click();
    });
    await checkRoomSwitch(2, async () => {
      await page.click("[data-git-branch]");
      await page.locator("#git-branch-picker[open]").waitFor();
      await page.locator("#git-branch-picker-list >> text=main").click();
    });
    await checkRoomSwitch(3, async () => {
      await page.locator(".file").nth(1).click();
    });
  });

  test("Commits changes", async ({ context }) => {
    const collabOpts = defaultCollabOpts();
    const pageA = await applyPageOpts(await context.newPage(), collabOpts, true);
    await clearEditor(pageA);
    await insertToMainEditor(pageA, { from: 0, insert: `change` });

    const pageB = await applyPageOpts(await context.newPage(), collabOpts, true);

    await pageA.getByTitle("Compare changes and commit").click();
    // Check if document is locked for the other user
    await pageB.getByText("A commit is being prepared").waitFor();

    // Check if text used for commit contains the changes
    await expect(async () => {
      const textA = await pageA.evaluate((id) => window.myst_editor[id].text, id);
      expect(textA).toContain("change");
      const textB = await pageB.evaluate((id) => window.myst_editor[id].text, id);
      expect(textB).toContain("change");
    }).toPass();

    // Commit
    await pageA.click("button[type=submit]");
    await pageA.waitForSelector(".cm-content");

    await expect(async () => {
      const hashA = await pageA.evaluate((id) => window.myst_editor[id].git.commit.value.hash, id);
      const hashB = await pageB.evaluate((id) => window.myst_editor[id].git.commit.value.hash, id);
      expect(hashA).toMatch(/^offline-/);
      expect(hashB).toBe(hashA);
      await expect(pageA.locator("[data-git-commit]")).toContainText(hashA);
      await expect(pageB.locator("[data-git-commit]")).toContainText(hashB);
    }).toPass();
  });

  test("Creates a new branch from current branch and switches to it", async ({ context }) => {
    const page = await applyPageOpts(await context.newPage(), defaultCollabOpts(), true);
    await expect(page.locator("[data-git-branch]")).toContainText("feature");

    await page.locator("[data-git-branch]").click();
    await page.locator("#git-branch-picker[open]").waitFor();

    const branchNameInput = page.locator("#git-branch-picker input");
    await branchNameInput.fill("my-new-branch");

    await page.locator("#git-branch-picker .create-branch-item").click();
    await page.locator("#form-dialog[open]").waitFor();

    const sourceInput = page.locator("#form-dialog input").nth(1);
    await expect(sourceInput).toHaveValue("feature");

    await page.locator("#form-dialog button[type=submit]").click();

    await expect(page.locator("[data-git-branch]")).toHaveText("my-new-branch");
  });

  test("Shows current branches in source dropdown and autocompletes commit", async ({ context }) => {
    const page = await applyPageOpts(await context.newPage(), defaultCollabOpts(), true);
    await expect(page.locator("[data-git-branch]")).toContainText("feature");

    await page.locator("[data-git-branch]").click();
    await page.locator("#git-branch-picker[open]").waitFor();

    // The create button is always visible without typing
    await page.locator("#git-branch-picker .create-branch-item").click();
    await page.locator("#form-dialog[open]").waitFor();

    const sourceInput = page.locator("#form-dialog input").nth(1);
    await expect(sourceInput).toHaveValue("feature");

    // Open the dropdown by clicking the source input
    await sourceInput.click();
    const dropdownMenu = page.locator("#form-dialog .dropdown-menu");
    await expect(dropdownMenu).toBeVisible();

    // The current branches need to be visible
    await expect(dropdownMenu.locator(".branch-item", { hasText: "feature" })).toBeVisible();
    await expect(dropdownMenu.locator(".branch-item", { hasText: "main" })).toBeVisible();

    // Type a commit message to search and autocomplete
    await sourceInput.fill("Initial");
    const commitItem = dropdownMenu.locator(".commit-item").first();
    await expect(commitItem).toBeVisible();
    await expect(commitItem).toContainText("Initial commit");

    // Click commit to autocomplete it
    await commitItem.click();
    await expect(dropdownMenu).toBeHidden();
    await expect(sourceInput).toHaveValue("4a3f2b1");

    // Fill branch name and submit
    const branchNameInput = page.locator("#form-dialog input").nth(0);
    await branchNameInput.fill("branch-from-commit");
    await page.locator("#form-dialog button[type=submit]").click();

    await expect(page.locator("[data-git-branch]")).toHaveText("branch-from-commit");
  });
});

test.describe.parallel("Identity and accessibility", () => {
  /** WCAG 2.2 AA plus axe's best practices, on whatever is on screen. */
  const axeViolations = async (page: Page) => {
    await page.addScriptTag({ path: "node_modules/axe-core/axe.min.js" });
    return page.evaluate(async () => {
      // @ts-ignore - injected above
      const result = await window.axe.run(document, {
        resultTypes: ["violations"],
        runOnly: { type: "tag", values: ["wcag2a", "wcag2aa", "wcag21aa", "wcag22aa", "best-practice"] },
      });
      return result.violations.map((v) => `${v.id}: ${v.nodes.map((n) => n.html.slice(0, 80)).join(" | ")}`);
    });
  };

  test("Shows COMBINE above the page index and TU Delft in its corner", async ({ context }) => {
    const page = await applyPageOpts(await context.newPage(), defaultCollabOpts(), true);
    await expect(page.locator("#brand-logo img:visible")).toHaveAttribute("alt", "COMBINE");
    await expect(page.locator("#brand-secondary img:visible")).toHaveAttribute("alt", "TU Delft");
    // The secondary logo closes the panel: nothing in the page index sits below it.
    const [logoTop, listBottom] = await page.evaluate(() => {
      const root = (document.getElementById("myst") as HTMLElement).shadowRoot as ShadowRoot;
      return [
        (root.querySelector("#brand-secondary") as HTMLElement).getBoundingClientRect().top,
        (root.querySelector("#page-list") as HTMLElement).getBoundingClientRect().bottom,
      ];
    });
    expect(logoTop).toBeGreaterThan(listBottom);
  });

  test("Leaves the brand out when a deployment turns it off", async ({ context }) => {
    const page = await applyPageOpts(await context.newPage(), { ...defaultCollabOpts(), branding: "off" }, true);
    await expect(page.locator(".file").first()).toBeVisible();
    await expect(page.locator("#brand-logo")).toHaveCount(0);
    await expect(page.locator("#brand-secondary")).toHaveCount(0);
    await page.locator('[name="toggle-sidebar"]').click();
    await expect(page.locator(".title-mark")).toHaveCount(0);
  });

  test("Lists pages by title, marks the open one, and filters", async ({ context }) => {
    const page = await applyPageOpts(await context.newPage(), defaultCollabOpts(), true);
    await expect(page.locator('.file[aria-current="page"] .file-name')).toHaveText("index.md");
    // Titles of pages that are not open are read from the repository in the background.
    await expect(page.locator(".file .file-title")).toHaveText(["Demo Documentation", "Document 1", "Document 2", "Feature Document"]);

    await page.getByLabel("Filter pages").fill("feature");
    await expect(page.locator(".file .file-name")).toHaveText(["feature.md"]);
    await page.getByLabel("Filter pages").fill("nothing like this");
    await expect(page.locator(".file")).toHaveCount(0);
    await expect(page.getByText("No pages match.")).toBeVisible();
  });

  test("Opens a page from the keyboard", async ({ context }) => {
    const page = await applyPageOpts(await context.newPage(), defaultCollabOpts(), true);
    const file2 = page.locator(".file", { has: page.locator(".file-name", { hasText: /^file2\.md$/ }) });
    await file2.focus();
    await page.keyboard.press("Enter");
    await expect(async () => {
      expect(await page.evaluate((id) => window.myst_editor[id].git.file.value, id)).toBe("docs/file2.md");
    }).toPass();
    await expect(file2).toHaveAttribute("aria-current", "page");
  });

  test("Collapsing the index keeps the keyboard on the toggle, and shows the mark", async ({ context }) => {
    const page = await applyPageOpts(await context.newPage(), defaultCollabOpts(), true);
    const toggle = page.locator('[name="toggle-sidebar"]');
    await expect(toggle).toHaveAttribute("aria-expanded", "true");
    await toggle.focus();
    await page.keyboard.press("Enter");
    await expect(toggle).toHaveAttribute("aria-expanded", "false");
    await expect(page.locator(".title-mark")).toBeVisible();
    await expect(async () => {
      const focused = await page.evaluate(() => (document.getElementById("myst") as HTMLElement).shadowRoot?.activeElement?.getAttribute("name"));
      expect(focused).toBe("toggle-sidebar");
    }).toPass();
  });

  test("View modes say which one is selected, by more than colour", async ({ context }) => {
    const page = await applyPageOpts(await context.newPage(), defaultCollabOpts(), true);
    const group = page.getByRole("group", { name: "View" });
    await expect(group.getByRole("button", { name: "Split" })).toHaveAttribute("aria-pressed", "true");
    await group.getByRole("button", { name: "Source" }).click();
    await expect(group.getByRole("button", { name: "Source" })).toHaveAttribute("aria-pressed", "true");
    await expect(group.getByRole("button", { name: "Split" })).toHaveAttribute("aria-pressed", "false");
  });

  test("The extra views and the settings open from the keyboard", async ({ context }) => {
    const page = await applyPageOpts(await context.newPage(), defaultCollabOpts(), true);
    const more = page.locator(".more");
    await expect(more).toHaveAccessibleName("More");
    await more.focus();
    await page.keyboard.press("Enter");
    await expect(more).toHaveAttribute("aria-expanded", "true");
    await expect(page.locator('[name="outline"]')).toBeVisible();
    await page.keyboard.press("Escape");
    await expect(more).toHaveAttribute("aria-expanded", "false");
    await expect(page.locator('[name="outline"]')).toBeHidden();

    const settings = page.locator('[name="settings"]');
    await settings.focus();
    await page.keyboard.press("Enter");
    await expect(settings).toHaveAttribute("aria-expanded", "true");
    await expect(page.locator("#dropdown-settings")).toBeVisible();
  });

  test("Shows a focus ring for the keyboard", async ({ context }) => {
    const page = await applyPageOpts(await context.newPage(), defaultCollabOpts(), true);
    await page.locator('[name="bold"]').focus();
    await page.keyboard.press("Tab");
    const outline = await page.evaluate(() => {
      const el = (document.getElementById("myst") as HTMLElement).shadowRoot?.activeElement as HTMLElement;
      const style = getComputedStyle(el);
      return { name: el.getAttribute("name"), style: style.outlineStyle, width: parseFloat(style.outlineWidth) };
    });
    expect(outline.name).toBe("italic");
    expect(outline.style).toBe("solid");
    expect(outline.width).toBeGreaterThanOrEqual(2);
  });

  test("Every toolbar button has a name", async ({ context }) => {
    const page = await applyPageOpts(await context.newPage(), defaultCollabOpts(), true);
    await expect(page.getByRole("toolbar", { name: "Formatting" })).toBeVisible();
    const unnamed = await page.evaluate(() => {
      const root = (document.getElementById("myst") as HTMLElement).shadowRoot as ShadowRoot;
      return [...root.querySelectorAll("#topbar button")]
        .filter((b) => !(b.getAttribute("aria-label") || b.textContent?.trim()))
        .map((b) => b.getAttribute("name"));
    });
    expect(unnamed).toEqual([]);
  });

  test("The status bar carries the branch, commit and cursor", async ({ context }) => {
    const page = await applyPageOpts(await context.newPage(), defaultCollabOpts(), true);
    const bar = page.locator("#status-bar");
    await expect(bar.locator("[data-git-branch]")).toHaveText("feature");
    await expect(bar.locator("[data-git-commit]")).toHaveText(DEMO_FEATURE_TIP);
    // The branch and commit moved here, so they are not repeated under the title.
    await expect(page.locator("#document-subtitle")).toHaveCount(0);
    await expect(page.locator("#status-words")).toHaveText(/^\d[\d,]* words?$/);

    await page.locator(".cm-content").click();
    await page.keyboard.press("Control+Home");
    await expect(page.locator("#status-position")).toHaveText("Ln 1, Col 1");
    await page.keyboard.press("ArrowDown");
    await expect(page.locator("#status-position")).toHaveText("Ln 2, Col 1");
  });

  test("The source pane is named for screen readers", async ({ context }) => {
    const page = await applyPageOpts(await context.newPage(), defaultCollabOpts(), true);
    await expect(page.locator(".cm-content").first()).toHaveAttribute("aria-label", "Document source");
  });

  test("Has no accessibility violations, light or dark, index open or closed", async ({ context }) => {
    const page = await applyPageOpts(await context.newPage(), defaultCollabOpts(), true);
    await expect(page.locator(".file .file-title")).toHaveCount(4);
    expect(await axeViolations(page)).toEqual([]);

    await page.locator('[name="toggle-sidebar"]').click();
    await expect(page.locator(".title-mark")).toBeVisible();
    expect(await axeViolations(page)).toEqual([]);

    // The same rules a consumer adopts as `darkTheme`, read from the source because the bundle's demo
    // entry does not re-export it.
    const styles = await fs.readFile("src/styles/MystStyles.js", "utf8");
    const darkCss = (styles.match(/darkTheme\.replaceSync\(`([\s\S]*?)`\);/) as RegExpMatchArray)[1];
    await page.evaluate((css) => {
      const sheet = new CSSStyleSheet();
      sheet.replaceSync(css);
      const root = (document.getElementById("myst") as HTMLElement).shadowRoot as ShadowRoot;
      root.adoptedStyleSheets = [...root.adoptedStyleSheets, sheet];
    }, darkCss);
    // Buttons ease their colours over 0.4s; measure the theme, not the fade into it.
    await page.waitForTimeout(600);
    expect(await axeViolations(page)).toEqual([]);
  });
});

test.describe.parallel("Image uploads", () => {
  /** An image made in the browser, so the tests carry no binary fixtures: noise, so a JPEG cannot squeeze it. */
  const makeImage = async (page: Page, width: number, height: number, type = "image/png", quality = 0.95) => {
    const base64 = await page.evaluate(
      ({ width, height, type, quality }) => {
        const canvas = document.createElement("canvas");
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d") as CanvasRenderingContext2D;
        const data = ctx.createImageData(width, height);
        for (let i = 0; i < data.data.length; i++) data.data[i] = i % 4 === 3 ? 255 : (i * 2654435761) % 251;
        ctx.putImageData(data, 0, 0);
        return canvas.toDataURL(type, quality).split(",")[1];
      },
      { width, height, type, quality },
    );
    return Buffer.from(base64, "base64");
  };

  const openFigureDialog = async (page: Page) => {
    await page.locator(".cm-content").click();
    await page.keyboard.press("Control+End");
    await page.locator('[name="figure"]').click();
    await expect(page.locator("#form-dialog")).toBeVisible();
  };

  const upload = async (page: Page, name: string, buffer: Buffer, mimeType = "image/png") => {
    await page.locator('#form-dialog input[type="file"]').setInputFiles({ name, mimeType, buffer });
    await expect(page.locator("#form-dialog .image-name")).toHaveText(name);
  };

  const lastPreviewImage = (page: Page) => page.locator(".myst-preview img").last();

  test("Shows an uploaded image in the preview before it is committed, and commits it with the page", async ({ context }) => {
    const page = await applyPageOpts(await context.newPage(), defaultCollabOpts(), true);
    await openFigureDialog(page);
    await upload(page, "Wave Diagram.png", await makeImage(page, 320, 200));
    await expect(page.getByLabel("Save as")).toHaveValue("images/wave-diagram.png");
    await expect(page.locator("#form-dialog")).toContainText("docs/images/wave-diagram.png");
    await page.getByLabel("Alt text").fill("A wave");
    await page.locator('#form-dialog button[type="submit"]').click();

    await expect(page.locator(".cm-content")).toContainText("```{figure} images/wave-diagram.png");
    await expect(async () => expect(await lastPreviewImage(page).evaluate((img: HTMLImageElement) => img.naturalWidth)).toBe(320)).toPass();
    await expect(page.locator("#status-bar")).toContainText("1 image waiting to be committed");

    await page.locator('[name="commit"]').click();
    const row = page.locator("#commit-images li");
    await expect(row).toContainText("docs/images/wave-diagram.png");
    await expect(row.locator('input[type="checkbox"]')).toBeChecked();
    await expect(page.locator("#summary")).toHaveValue(/add docs\/images\/wave-diagram\.png/);
    await page.locator("form button[type=submit]", { hasText: "Commit" }).click();

    await expect(async () => {
      const git = await page.evaluate(
        (id) => ({ commit: window.myst_editor[id].git.commit.value?.hash, pending: window.myst_editor[id].git.pendingImages.value.length }),
        id,
      );
      expect(git.commit).toMatch(/^offline-/);
      expect(git.pending).toBe(0);
    }).toPass();
    await expect(page.locator("#status-bar")).not.toContainText("waiting to be committed");
    await expect(async () => expect(await lastPreviewImage(page).evaluate((img: HTMLImageElement) => img.naturalWidth)).toBe(320)).toPass();
  });

  test("Asks before replacing an image someone else committed under the same name", async ({ context }) => {
    // Two tabs on one demo repository stand in for two people on one branch.
    const shared = { collab: "false", repo: `repos/${crypto.randomUUID()}` };
    const addFigure = async (page: Page) => {
      await openFigureDialog(page);
      await upload(page, "chart.png", await makeImage(page, 40, 30));
      await page.getByLabel("Alt text").fill("A chart");
      await page.locator('#form-dialog button[type="submit"]').click();
      await expect(page.locator("#status-bar")).toContainText("1 image waiting to be committed");
    };
    const mine = await applyPageOpts(await context.newPage(), shared, true);
    const theirs = await applyPageOpts(await context.newPage(), shared, true);
    await addFigure(mine);
    await addFigure(theirs);
    await theirs.locator('[name="commit"]').click();
    await theirs.locator("form button[type=submit]", { hasText: "Commit" }).click();
    await expect(theirs.locator("#status-bar")).not.toContainText("waiting to be committed");

    await mine.locator('[name="commit"]').click();
    const row = mine.locator("#commit-images li");
    await expect(row).toContainText("An image with this name was committed since you uploaded this one");
    await expect(row.locator('input[type="checkbox"]')).not.toBeChecked();
    await row.locator('input[type="checkbox"]').check();
    await expect(row).toContainText("Replaces the image with this name that is already on the branch");
    await mine.locator("form button[type=submit]", { hasText: "Commit" }).click();
    await expect(mine.locator("#status-bar")).not.toContainText("waiting to be committed");
    await expect(mine.locator("#toast")).toContainText("Changes have been commited");
  });

  test("Offers to shrink a large photo, and the smaller copy is what gets held", async ({ context }) => {
    const page = await applyPageOpts(await context.newPage(), defaultCollabOpts(), true);
    await openFigureDialog(page);
    const photo = await makeImage(page, 3000, 2000, "image/jpeg");
    await upload(page, "photo.jpg", photo, "image/jpeg");
    const shrink = page.getByLabel(/Shrink to at most 2000 px wide/);
    await expect(shrink).toBeChecked();
    await page.locator('#form-dialog button[type="submit"]').click();

    await expect(async () => expect(await lastPreviewImage(page).evaluate((img: HTMLImageElement) => img.naturalWidth)).toBe(2000)).toPass();
    const held = await page.evaluate((id) => window.myst_editor[id].git.pendingImages.value[0].size, id);
    expect(held).toBeLessThan(photo.length);
  });

  test("Will not save over an existing file, and suggests a free name", async ({ context }) => {
    const page = await applyPageOpts(await context.newPage(), defaultCollabOpts(), true);
    const image = await makeImage(page, 40, 30);
    for (const attempt of [1, 2]) {
      await openFigureDialog(page);
      await upload(page, "fig.png", image);
      await page.locator('#form-dialog button[type="submit"]').click();
      if (attempt === 2) {
        await expect(page.locator("#form-dialog .dialog-message")).toContainText("There is already a file at docs/images/fig.png");
        await expect(page.getByLabel("Save as")).toHaveValue("images/fig-2.png");
        await page.locator('#form-dialog button[type="submit"]').click();
      }
      await expect(page.locator("#form-dialog")).toBeHidden();
    }
    const paths = await page.evaluate((id) => window.myst_editor[id].git.pendingImages.value.map((e) => e.path), id);
    expect(paths).toEqual(["docs/images/fig.png", "docs/images/fig-2.png"]);
  });

  test("A pasted or dropped image opens the figure dialog with it", async ({ context }) => {
    const page = await applyPageOpts(await context.newPage(), defaultCollabOpts(), true);
    const base64 = (await makeImage(page, 64, 48)).toString("base64");
    const send = (kind: "paste" | "drop") =>
      page.evaluate(
        ({ kind, base64 }) => {
          const root = (document.getElementById("myst") as HTMLElement).shadowRoot as ShadowRoot;
          const content = root.querySelector(".cm-content") as HTMLElement;
          const bytes = Uint8Array.from(atob(base64), (c) => c.charCodeAt(0));
          const data = new DataTransfer();
          // What a browser hands over for a screenshot on the clipboard.
          data.items.add(new File([bytes], kind === "paste" ? "image.png" : "dropped chart.png", { type: "image/png" }));
          const box = content.getBoundingClientRect();
          const event =
            kind === "paste"
              ? new ClipboardEvent("paste", { clipboardData: data, bubbles: true, cancelable: true })
              : new DragEvent("drop", { dataTransfer: data, bubbles: true, cancelable: true, clientX: box.left + 20, clientY: box.top + 10 });
          content.dispatchEvent(event);
        },
        { kind, base64 },
      );

    await page.locator(".cm-content").click();
    await send("paste");
    await expect(page.locator("#form-dialog .image-name")).toHaveText(/^pasted-\d{8}-\d{6}\.png$/);
    await expect(page.getByLabel("Save as")).toHaveValue(/^images\/pasted-\d{8}-\d{6}\.png$/);
    await page.locator('#form-dialog button[type="submit"]').click();
    await expect(page.locator(".cm-content")).toContainText("{figure} images/pasted-");

    await send("drop");
    await expect(page.locator("#form-dialog .image-name")).toHaveText("dropped chart.png");
    await expect(page.getByLabel("Save as")).toHaveValue("images/dropped-chart.png");
  });

  test("Marks an image the repository does not have", async ({ context }) => {
    const page = await applyPageOpts(await context.newPage(), defaultCollabOpts(), true);
    await insertToMainEditor(page, { from: 0, insert: "```{figure} images/not-there.png\n```\n\n" });
    await expect(page.locator(".myst-preview img.git-img-missing")).toHaveAttribute("title", "Not in the repository yet: docs/images/not-there.png");
  });

  test("The editor without a repository behind it keeps the URL-only figure dialog", async ({ context }) => {
    const page = await applyPageOpts(await context.newPage(), { collab: "false" });
    await page.locator('[name="figure"]').click();
    await expect(page.getByLabel("Image URL")).toBeVisible();
    await expect(page.locator('#form-dialog input[type="file"]')).toHaveCount(0);
  });

  test("The figure dialog has no accessibility violations", async ({ context }) => {
    const page = await applyPageOpts(await context.newPage(), defaultCollabOpts(), true);
    await openFigureDialog(page);
    await upload(page, "fig.png", await makeImage(page, 40, 30));
    await page.addScriptTag({ path: "node_modules/axe-core/axe.min.js" });
    const violations = await page.evaluate(async () => {
      // @ts-ignore - injected above
      const result = await window.axe.run(document, {
        resultTypes: ["violations"],
        runOnly: { type: "tag", values: ["wcag2a", "wcag2aa", "wcag21aa", "wcag22aa"] },
      });
      return result.violations.map((v) => `${v.id}: ${v.nodes.map((n) => n.html.slice(0, 80)).join(" | ")}`);
    });
    expect(violations).toEqual([]);
  });
});

test("dist/MystEditor.js exports src/MystEditor.js module", async () => {
  const module = await fs.readFile("dist/MystEditor.js");
  expect(module.length).toBeGreaterThan(3000);

  const moduleContent = module.toString();

  ["spellcheckOpts", "transforms", "collaboration", "ycomments", "commentsEnabled"].forEach((s) => expect(moduleContent).toContain(s));
});

///////////////////////// UTILITY FUNCTIONS /////////////////////////

const insertToMainEditor = (page: Page, changes: ChangeSpec | null): Promise<void> /** @ts-ignore */ =>
  page.evaluate(({ changes, id }) => window.myst_editor[id].main_editor.dispatch({ changes }), { changes, id });

const mainEditorText = (page: Page): Promise<string> => page.evaluate((id) => window.myst_editor[id].main_editor.state.doc.toString(), id);

const clearEditor = async (page: Page) => {
  const currentText = await page.evaluate((id) => window.myst_editor[id].text, id);
  await insertToMainEditor(page, {
    from: 0,
    to: currentText.length,
    insert: "",
  });
};

test.describe.parallel("Committing without collaboration", () => {
  const editorText = (page: Page) => page.evaluate((id) => window.myst_editor[id].main_editor.state.doc.toString(), id);
  const openCommit = async (page: Page) => {
    await page.locator('[name="commit"]').click();
    await page.locator("#diffs .cm-content").first().waitFor();
  };
  const diffLines = (page: Page, kind: "changed" | "original") =>
    page.locator(kind === "changed" ? "#diffs .cm-changedLine" : "#diffs .cm-deletedChunk").allTextContents();

  test("Discarding on a branch switch drops the edits, even where the page is the same", async ({ context }) => {
    const page = await applyPageOpts(await context.newPage(), { collab: "false" }, true);
    await insertToMainEditor(page, { from: 0, insert: "DISCARDED " });
    // Looking at the commit and backing out must not leave this edit behind in the dialog either.
    await openCommit(page);
    await page.locator("form button", { hasText: "Cancel" }).click();

    // Choosing the branch again reloads the same page, so the loaded text does not change.
    const current = (await page.locator("[data-git-branch]").first().textContent())!.trim();
    await page.click("[data-git-branch]");
    await page.locator("#git-branch-picker[open]").waitFor();
    await page.locator("#git-branch-picker-list li", { hasText: new RegExp(`^${current}$`) }).click();
    await page.locator("#form-dialog[open]").getByText("Discard changes").click();
    await expect(async () => expect(await editorText(page)).not.toContain("DISCARDED")).toPass();

    await insertToMainEditor(page, { from: 0, insert: "KEPT " });
    await openCommit(page);
    const changed = (await diffLines(page, "changed")).join("\n");
    expect(changed).toContain("KEPT");
    expect(changed).not.toContain("DISCARDED");
  });

  test("Compares the next commit with the last one, not with what came before it", async ({ context }) => {
    const page = await applyPageOpts(await context.newPage(), { collab: "false" }, true);
    await insertToMainEditor(page, { from: 0, insert: "FIRST " });
    await openCommit(page);
    await page.locator("form button[type=submit]", { hasText: "Commit" }).click();
    await expect(async () => expect(await page.evaluate((id) => window.myst_editor[id].git.commit.value?.hash, id)).toMatch(/^offline-/)).toPass();

    await insertToMainEditor(page, { from: 0, insert: "SECOND " });
    await openCommit(page);
    // The line as committed is the original side of the diff.
    expect((await diffLines(page, "original")).join("\n")).toContain("FIRST");
    expect((await diffLines(page, "changed")).join("\n")).toContain("SECOND FIRST");
  });
});

test.describe.parallel("Adding and moving pages", () => {
  const git = (page: Page) => ({
    file: () => page.evaluate((id) => window.myst_editor[id].git.file.value, id),
    files: () => page.evaluate((id) => window.myst_editor[id].git.files.value, id),
    toc: () => page.evaluate((id) => window.myst_editor[id].git.indexFile.value, id),
  });
  const dialog = (page: Page) => page.locator("#form-dialog[open]");
  const entry = (page: Page, name: string) => page.locator("#page-list button.file", { hasText: name });
  const commitsTo = async (page: Page, hash: string | undefined) =>
    expect(async () => expect(await page.evaluate((id) => window.myst_editor[id].git.commit.value?.hash, id)).not.toBe(hash)).toPass();
  const currentHash = (page: Page) => page.evaluate((id) => window.myst_editor[id].git.commit.value?.hash, id);
  /** Open a page and wait until the editor shows it, so that an edit made next is not overwritten by the page loading. */
  const openPage = async (page: Page, name: string, heading: string) => {
    await entry(page, name).click();
    await expect(async () => expect(await mainEditorText(page)).toMatch(new RegExp(`^# ${heading}`))).toPass();
  };
  /** Edit the open page, and wait until the edit has taken. */
  const edit = async (page: Page, insert: string) => {
    await insertToMainEditor(page, { from: 0, insert });
    await expect(async () => expect(await mainEditorText(page)).toContain(insert)).toPass();
  };

  test("Adds a page in a new chapter, commits it and opens it", async ({ context }) => {
    const page = await applyPageOpts(await context.newPage(), { collab: "false" }, true);
    const before = await currentHash(page);
    await page.locator('button[title="Add page"]').click();
    await dialog(page).getByLabel("Page name").fill("Quick start");
    await dialog(page).locator("#field-parent").click();
    await dialog(page).locator(".create-folder-btn").click();
    await dialog(page).locator(".dropdown-create-row input").fill("Week 1");
    await dialog(page).locator(".create-submit-btn").click();
    await expect(dialog(page).locator("#field-parent")).toHaveValue("Week 1 (new chapter)");
    await dialog(page).getByRole("button", { name: "Add and commit" }).click();

    await commitsTo(page, before);
    await expect(async () => expect(await git(page).file()).toBe("docs/week-1/quick-start.md")).toPass();
    expect(await git(page).toc()).toContain("    - file: week-1/quick-start.md\n      children: []");
    await expect(page.locator("#page-list")).toContainText("Quick start");
  });

  test("Adds a chapter as a folder with its first page", async ({ context }) => {
    const page = await applyPageOpts(await context.newPage(), { collab: "false" }, true);
    await page.locator('button[title="Add chapter"]').click();
    await dialog(page).getByLabel("Chapter title").fill("Week 2: Forces");
    await dialog(page).getByRole("button", { name: "Add and commit" }).click();
    await expect(async () => expect(await git(page).file()).toBe("docs/week-2-forces/index.md")).toPass();
    expect(await git(page).files()).toContain("docs/week-2-forces/index.md");
    await expect(page.locator("#page-list .folder-header")).toContainText("Week 2: Forces");
  });

  test("Reorders pages from the keyboard without moving their files", async ({ context }) => {
    const page = await applyPageOpts(await context.newPage(), { collab: "false" }, true);
    const before = await currentHash(page);
    await entry(page, "file2.md").focus();
    await page.keyboard.press("Alt+ArrowUp");
    await expect(dialog(page)).toContainText('Move "Document 2" before "Document 1"?');
    // Same folder: there is no file to move.
    await expect(dialog(page).getByText("Also move the file")).toHaveCount(0);
    await dialog(page).getByRole("button", { name: "Move and commit" }).click();

    await commitsTo(page, before);
    await expect(async () => expect(await git(page).toc()).toContain("    - file: file2.md\n    - file: file1.md")).toPass();
    expect(await git(page).files()).toEqual(expect.arrayContaining(["docs/file1.md", "docs/file2.md"]));
  });

  test("Moving a page into a chapter can move its file too", async ({ context }) => {
    const page = await applyPageOpts(await context.newPage(), { collab: "false" }, true);
    await page.locator('button[title="Add chapter"]').click();
    await dialog(page).getByLabel("Chapter title").fill("Week 3");
    await dialog(page).getByRole("button", { name: "Add and commit" }).click();
    await expect(async () => expect(await git(page).file()).toBe("docs/week-3/index.md")).toPass();

    await entry(page, "file1.md").dragTo(page.locator("#page-list .folder-header").filter({ hasText: "Week 3" }));
    await dialog(page).getByText("Also move the file to docs/week-3/file1.md").click();
    await dialog(page).getByRole("button", { name: "Move and commit" }).click();

    await expect(async () => expect(await git(page).files()).toContain("docs/week-3/file1.md")).toPass();
    expect(await git(page).files()).not.toContain("docs/file1.md");
    expect(await git(page).toc()).toContain("    - file: week-3/index.md\n      children:\n        - file: week-3/file1.md");
  });

  test("Carries the open page's edits over to the new commit", async ({ context }) => {
    const page = await applyPageOpts(await context.newPage(), { collab: "false" }, true);
    await openPage(page, "file1.md", "Document 1");
    await edit(page, "EDIT ");
    const before = await currentHash(page);
    await entry(page, "file2.md").focus();
    await page.keyboard.press("Alt+ArrowUp");
    await dialog(page).getByRole("button", { name: "Move and commit" }).click();

    await commitsTo(page, before);
    await expect(async () => expect(await git(page).toc()).toContain("    - file: file2.md\n    - file: file1.md")).toPass();
    // Still uncommitted, on the new commit.
    await expect(async () => expect(await mainEditorText(page)).toMatch(/^EDIT /)).toPass();
    expect(await page.evaluate((id) => window.myst_editor[id].git.file.value, id)).toBe("docs/file1.md");
  });

  test("Moves a chapter's folder with its pages, and updates links to them", async ({ context }) => {
    const page = await applyPageOpts(await context.newPage(), { collab: "false" }, true);
    for (const title of ["Week 5", "Week 4"]) {
      await page.locator('button[title="Add chapter"]').click();
      await dialog(page).getByLabel("Chapter title").fill(title);
      await dialog(page).getByRole("button", { name: "Add and commit" }).click();
      await expect(async () => expect(await git(page).file()).toBe(`docs/week-${title.at(-1)}/index.md`)).toPass();
    }
    await page.locator('button[title="Add page"]').click();
    await dialog(page).getByLabel("Page name").fill("Notes");
    await dialog(page).locator("#field-parent").click();
    await dialog(page).locator("[data-option]", { hasText: "week-4/index.md" }).click();
    await dialog(page).getByRole("button", { name: "Add and commit" }).click();
    await expect(async () => expect(await git(page).file()).toBe("docs/week-4/notes.md")).toPass();

    // An uncommitted link from another page to one that is about to move.
    await openPage(page, "file1.md", "Document 1");
    await edit(page, "[notes](week-4/notes.md)\n");

    // Week 4 goes into Week 5, the chapter above it.
    await page.locator("#page-list .folder-header button.file", { hasText: "Week 4" }).focus();
    await page.keyboard.press("Alt+ArrowRight");
    await dialog(page).getByText("Also move the folder docs/week-4 to docs/week-5/week-4 (2 files)").click();
    await dialog(page).getByRole("button", { name: "Move and commit" }).click();

    await expect(async () =>
      expect(await git(page).files()).toEqual(expect.arrayContaining(["docs/week-5/week-4/index.md", "docs/week-5/week-4/notes.md"])),
    ).toPass();
    expect((await git(page).files()).filter((f: string) => f.startsWith("docs/week-4/"))).toEqual([]);
    expect(await git(page).toc()).toContain(
      "    - file: week-5/index.md\n      children:\n        - file: week-5/week-4/index.md\n          children:\n            - file: week-5/week-4/notes.md",
    );
    await expect(async () => expect(await mainEditorText(page)).toMatch(/^\[notes\]\(week-5\/week-4\/notes\.md\)\n/)).toPass();
  });

  test("Carries everyone's uncommitted pages over, with a collaboration server", async ({ context }) => {
    const page = await applyPageOpts(await context.newPage(), defaultCollabOpts(), true);
    await openPage(page, "file1.md", "Document 1");
    await edit(page, "ONE ");
    await expect(entry(page, "file1.md")).toHaveClass(/marked/);
    await entry(page, "file2.md").click();
    // The edits stay in the page's room on the server; the dialog only says this tab leaves them.
    await dialog(page).getByRole("button", { name: "Discard changes" }).click();
    await expect(async () => expect(await mainEditorText(page)).toMatch(/^# Document 2/)).toPass();
    await edit(page, "TWO ");
    await expect(page.locator("#page-list button.file.marked")).toHaveCount(2);

    const before = await currentHash(page);
    await entry(page, "file2.md").focus();
    await page.keyboard.press("Alt+ArrowUp");
    await dialog(page).getByRole("button", { name: "Move and commit" }).click();
    await commitsTo(page, before);

    await expect(async () => expect(await mainEditorText(page)).toMatch(/^TWO /)).toPass();
    // Both pages count as changed on the new commit.
    await expect(page.locator("#page-list button.file.marked")).toHaveCount(2);
    await entry(page, "file1.md").click();
    await dialog(page).getByRole("button", { name: "Discard changes" }).click();
    await expect(async () => expect(await mainEditorText(page)).toMatch(/^ONE /)).toPass();
  });

  test("Changes nothing from an older commit", async ({ context }) => {
    const page = await applyPageOpts(await context.newPage(), { collab: "false" }, true);
    await entry(page, "file2.md").focus();
    await page.keyboard.press("Alt+ArrowUp");
    await dialog(page).getByRole("button", { name: "Move and commit" }).click();
    await expect(async () => expect(await git(page).toc()).toContain("- file: file2.md\n    - file: file1.md")).toPass();

    // Back to the commit before the move.
    await page.click("[data-git-commit]");
    await page.locator("#git-commit-picker[open]").waitFor();
    await page.locator("#git-commit-picker-list li").nth(1).click();
    await expect(async () => expect(await git(page).toc()).toContain("- file: file1.md\n    - file: file2.md")).toPass();
    await page.locator('button[title="Add chapter"]').click();
    await expect(page.locator("#toast")).toContainText("This is not the latest commit");
  });
});

test.describe.parallel("Links in the preview", () => {
  test("Open the page they point at in the editor, at the heading", async ({ context }) => {
    const page = await applyPageOpts(await context.newPage(), { collab: "false" }, true);
    const file = () => page.evaluate((id) => window.myst_editor[id].git.file.value, id);
    await page.locator("#page-list button.file", { hasText: "file1.md" }).click();
    await expect(async () => expect(await mainEditorText(page)).toMatch(/^# Document 1/)).toPass();
    await insertToMainEditor(page, { from: 0, insert: "[to two](file2.md#details) [gone](missing.md) [web](https://example.org)\n\n" });

    await page.getByRole("link", { name: "gone" }).click();
    await expect(page.locator("#toast")).toContainText("docs/missing.md is not a page in this version of the book.");
    expect(await file()).toBe("docs/file1.md");
    await expect(page.getByRole("link", { name: "web" })).toHaveAttribute("href", "https://example.org");

    await page.getByRole("link", { name: "to two" }).click();
    // The edit above is unsaved, so the editor asks first.
    await page.locator("#form-dialog[open]").getByRole("button", { name: "Discard changes" }).click();
    await expect(async () => expect(await file()).toBe("docs/file2.md")).toPass();
    await expect(page.locator("h2#details")).toBeInViewport();
    expect(page.url()).toContain("/myst-git/git.html");
  });
});

test.describe.parallel("GitHub wording", () => {
  // ?flavor=github makes the demo backend describe itself as GitHub does, so the wording can be checked
  // without a GitHub account.
  test("Speaks of pull requests and links to GitHub's compare page", async ({ context }) => {
    const page = await applyPageOpts(await context.newPage(), { collab: "false", flavor: "github" }, true);
    await expect(page.locator("#status-bar [data-git-mr]")).toHaveText("PR");
    await page.locator("#status-bar [data-git-mr]").click();
    const dialog = page.locator("#merge-request-modal[open]");
    await expect(dialog.locator("h2")).toHaveText("New Pull Request");
    await expect(dialog).toContainText("initiate a new pull request in GitHub");
    await expect(dialog.getByText("Open in GitHub")).toBeVisible();
    await expect(dialog.getByLabel("Generated GitHub Link")).toHaveValue("https://github.example.org/demo/book/compare/main...feature?expand=1");
  });
});

test.describe.parallel("Add-ons", () => {
  // git.html's ?only_branches= turns on a small demo add-on (see the page) built on the plugin API.
  const withAddon = async (context, onlyBranches: string) =>
    applyPageOpts(await context.newPage(), { ...defaultCollabOpts(), only_branches: onlyBranches }, true);

  test("Narrows the branches on offer and opens on the first one", async ({ context }) => {
    const page = await withAddon(context, "feature,main");
    await expect(page.locator("[data-git-branch]").first()).toContainText("feature");
    await expect(page.locator("#toast")).toContainText("Demo add-on: only feature, main on offer.");

    // The add-on's own status bar item survives the bar being rebuilt for the branch, and opens the picker.
    await page.locator("#status-bar").getByText("Demo add-on: feature, main").click();
    await page.locator("#git-branch-picker[open]").waitFor();
    await expect(page.locator("#git-branch-picker-list li")).toHaveText(["feature", "main"]);

    // Searching goes through the add-on too, so nothing outside the list turns up.
    await page.locator("#git-branch-picker input").fill("a");
    await expect(page.locator("#git-branch-picker-list li")).toHaveText(["feature", "main"]);
    await page.locator("#git-branch-picker input").fill("ma");
    await expect(page.locator("#git-branch-picker-list li")).toHaveText(["main"]);
  });

  test("Refuses to open a branch the add-on keeps closed", async ({ context }) => {
    const page = await withAddon(context, "feature");
    await expect(page.locator("[data-git-branch]").first()).toContainText("feature");
    // However the editor is asked to switch - here through its own API - the add-on is consulted.
    await page.evaluate(() => (window as any).myst_editor.demo.git.switchBranch("main"));
    await expect(page.locator("#toast")).toContainText("Branch 'main' is not available to you.");
    await expect(page.locator("[data-git-branch]").first()).toContainText("feature");
  });

  test("Marks protected branches in the branch picker", async ({ context }) => {
    const page = await applyPageOpts(await context.newPage(), { collab: "false", protected: "main" }, true);
    await page.click("[data-git-branch]");
    await page.locator("#git-branch-picker[open]").waitFor();
    const tag = page.locator("#git-branch-picker-list li", { hasText: "main" }).locator(".tag");
    await expect(tag).toHaveText("protected");
    await expect(tag).toHaveAttribute("title", "Protected branch: you cannot commit to it");
    await expect(page.locator("#git-branch-picker-list li", { hasText: "feature" }).locator(".tag")).toHaveCount(0);
  });

  test("Keeps the default branch as a merge request target", async ({ context }) => {
    const page = await withAddon(context, "feature");
    await page.locator("#status-bar [data-git-mr]").click();
    await page.locator("#merge-request-modal[open]").waitFor();
    await expect(page.locator("#mr-field-target")).toHaveValue("main");
    await page.locator("#mr-field-target").focus();
    await expect(page.locator("#merge-request-modal .searchable-branch-select li.branch-item .branch-name", { hasText: "main" })).toHaveCount(1);
  });

  test("Can keep the editor from opening, with a reason", async ({ context }) => {
    // Not through applyPageOpts: that waits for an editor, and here there must never be one.
    const page = await context.newPage();
    await page.goto("/myst-git/git.html?only_branches=no-such-branch&collab=false");
    await expect(page.locator("#myst-plugin-stop")).toHaveText("None of the branches no-such-branch exist in this repository.");
    await expect(page.locator("#myst-plugin-retry")).toBeVisible();
    await expect(page.locator("[data-git-branch]")).toHaveCount(0);
  });
});

const defaultCollabOpts = () => ({ collab_server: "ws://localhost:4455", room: crypto.randomUUID(), repo: `repos/${crypto.randomUUID()}` });

/** Toggling suggest mode rebuilds the whole EditorView, so dispatching a change straight after the click
 * can land on the old view and never go through the suggest-mode transaction filter. Mark the current
 * view and wait until it has actually been replaced. */
const enableSuggestMode = async (page: Page) => {
  /** @ts-ignore */
  await page.evaluate((i) => (window.myst_editor[i].main_editor.__preToggle = true), id);
  await page.locator('[name="suggest-mode"]').click();
  /** @ts-ignore */
  await page.waitForFunction((i) => !window.myst_editor[i].main_editor.__preToggle, id);
};

const collaborationReady = (page: Page) => page.waitForFunction((id) => window?.myst_editor[id]?.state?.collab?.value?.ready?.value, id);

const insertChangesAndCheckOutput = async (page: Page, changes: ChangeSpec | null, check: (html: string) => void | Promise<void>) => {
  await insertToMainEditor(page, changes);
  await expect(async () => {
    const preview = await page.locator(".myst-preview").first().innerHTML();
    check(preview);
  }).toPass();
};

const applyPageOpts = async (page: Page, opts: object, git = false) => {
  let query = new URLSearchParams();
  Object.entries(opts).forEach(([k, v]) => query.set(k, v));

  // Fail on errors
  page.on("pageerror", (err) => {
    // Same reasoning as the console filter below. The demo document embeds a video player, and that
    // script sometimes throws inside its own iframe ("writeEmbed is not defined"), which failed
    // whichever test happened to be running at the time. Third-party frames carry the embed's origin,
    // never ours. An exception with no stack at all still counts, so an uncaught app error cannot hide.
    const stack = err.stack ?? "";
    if (stack.includes("http") && !stack.includes("localhost:4173")) return;
    throw new Error(`Unhandled page exception: ${stack || err}`);
  });
  page.on("console", (msg) => {
    if (msg.type() !== "error") return;
    // Only OUR errors should fail a test. The demo document embeds third-party content (a video player,
    // avatars), and those scripts log errors of their own - a YouTube permissions-policy warning or a
    // failed avatar fetch is not a regression in the editor, but it used to fail whichever test happened
    // to be running. Anything without a URL (an uncaught app error) still counts.
    const url = msg.location()?.url ?? "";
    if (url && !url.startsWith("http://localhost:4173")) return;
    throw new Error(`Console error: ${msg.text()} ${JSON.stringify(msg.location())}`);
  });

  await page.goto(`${git ? "/myst-git/git.html" : "/"}?` + query.toString());
  await page.waitForSelector(".cm-content");
  if ("collab_server" in opts) {
    await collaborationReady(page);
  }
  // Wait for initial text
  await expect(async () => {
    const text = await page.evaluate((id) => window.myst_editor[id].text, id);
    expect(text).not.toHaveLength(0);
  }).toPass();
  return page;
};

const getCommentBtn = (page: Page, lineNumber: number) =>
  page.locator(`.cm-gutters > .cm-gutter:first-child > .cm-gutterElement:nth-child(${lineNumber + 1}) .comment-gutter-icon`);

const addComment = async (page: Page, lineNumber: number, text?: string) => {
  await getCommentBtn(page, lineNumber).click();
  if (text) {
    await page.locator(`[data-comment-line="${lineNumber}"] .cm-line`).first().fill(text);
  }
  await page.mouse.move(0, 0);
};

const openResolvedComments = async (page: Page) => {
  await page.hover(".more");
  await page.click('[name="resolved"]');
};

async function changeRoom(page: Page, room: string) {
  await page.evaluate(
    ({ id, room }) => {
      const collab = window.myst_editor[id].state.options.collaboration.value;
      window.myst_editor[id].state.options.collaboration.value = { ...collab, room };
    },
    { id, room },
  );
  await page.waitForSelector(".cm-content");
  await collaborationReady(page);
  await expect(async () => {
    const text = await page.evaluate((id) => window.myst_editor[id].main_editor?.state?.doc?.toString?.(), id);
    expect(text).not.toHaveLength(0);
  }).toPass();
}

const startInlineMode = async (page: Page) => {
  await page.getByTitle("Inline Preview").click();
  await expect(page.locator("#preview-wrapper")).toHaveCSS("display", "none");
};
