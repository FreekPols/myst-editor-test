# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.11.0] - 2026-11-07

### Added

- **Adding pages and chapters from the sidebar.** "Add page" asks for a name and a chapter (or a new
  one) and creates the page in that chapter's folder; "Add chapter" creates a folder with an
  `index.md` as its first page. Each is committed straight away together with the table of contents.
- **Rearranging the table of contents** by dragging entries, or with Alt + arrow keys. Only the table
  of contents changes, unless the author also moves the files: a page into the folder of the chapter it
  goes into, or a chapter's whole folder (images and subfolders included) into its new parent's. Links
  and images pointing at moved files are updated in the moved pages and across the rest of the book.
- **Uncommitted work survives these commits.** Adding or moving pages no longer asks to commit or
  discard first: edits and comments on the current version (everyone's, with a collaboration server)
  are carried over to the same pages of the new commit, following pages that moved.
- `listFiles(commit, dir)` on the GitLab, GitHub and demo backends, listing every file under a folder.
- **Links between pages work in the preview.** In the git editor, a link to another page opens it in
  the editor (at the heading, for a link with an anchor) instead of leaving for a page that does not
  exist; `#anchor` links scroll the preview. Links to other sites are unchanged.
- **Collapsible chapters in the sidebar.** A YAML table of contents is shown as a tree; a chapter
  opens by itself while it holds the open page.
- **Merge request preview builds in GitLab CI.** Each merge request pipeline uploads `.zip` and
  `.tar.gz` builds to the package registry under `mr-<iid>`, with a preview release; they are cleaned
  up when `main` is released.

### Changed

- The table of contents is edited in place with the `yaml` package, so comments, blank lines and
  other settings in `myst.yml` survive. Changes are written in the file's own dialect (mystmd or
  Jupyter Book v1).
- Updated Vite+ to 1.4.0 and `@lezer/markdown` to 1.8.1.

### Fixed

- Without collaboration, edits made just after opening a page or commit could be replaced by the
  page's loaded text when the editor rebuilt its view in the same moment.
- The GitHub backend copies a moved file byte for byte; it re-encoded it as text, which would have
  corrupted images.

## [1.10.0] - 2026-10-31

### Added

- **A GitHub backend.** The git editor now works on a GitHub repository
  (`backend: "github"`, `githubRepo: "owner/name"`) as it does on GitLab:
  branches, commits, pages and images, branch creation and pull requests. The
  wording follows the forge ("pull request", "PR #12"). Two ways to sign in:
  a fine-grained personal access token limited to the one repository, entered
  in a form password managers save and fill; or one-click sign-in through a
  GitHub App, with a small token relay holding the app's secret
  (`tools/github-token-relay`, a Cloudflare Worker). GitHub Enterprise Server
  works through `githubUrl`. See "Running against GitHub" in the README.
- **Asking before an image replaces another.** When the commit dialog opens,
  each waiting image is checked against the branch as it is now. One whose name
  someone else has taken since the upload is listed unticked, with a warning;
  ticking it replaces the other image. On GitLab this used to fail the commit;
  on GitHub it would have replaced the image silently.

### Changed

- **One sign-in module for both forges** (`oauth.js`), with GitLab and GitHub
  presets. `gitlabAuth.js` keeps its exports. The backend factory moved to
  `backends.js`; importing `createGitBackend` from `stubGitBackend.js` still
  works.
- **Each backend names itself** (`serverName`, `review`,
  `newMergeRequestUrl`), and the editor takes its wording and merge request
  link from there instead of assuming GitLab.
- **Long commit ids are shortened** to 8 characters where they are shown, as
  GitLab already did.

## [1.9.0] - 2026-10-30

### Added

- **The branch picker marks protected branches** with a small "protected" tag;
  hovering it says whether you can commit there. The GitLab backend notes this
  from the branch lists it already fetches (`getBranchStatus(name)`), so it
  costs no extra requests. The demo marks branches with `?protected=main`.

## [1.8.1] - 2026-10-30

### Fixed

- **The commit dialog showed the changes from its previous opening.** After a
  commit, or after opening the dialog and cancelling, the next opening compared
  the page with the text from that earlier time, so changes already committed
  or discarded showed up again. What was committed was always right; only the
  preview was wrong.
- **"Discard changes" kept the edits when the next page had the same text**,
  for example when switching to the same branch, or to a branch where the page
  is unchanged. They stayed in the editor and went into the next commit. (Without
  collaboration; with it, edits stay in their room as before.)

## [1.8.0] - 2026-10-23

### Added

- **Add-ons for the git editor.** `mountGitEditor` takes `plugins`, so a
  deployment can change what the editor offers without patching it: which
  branches are listed, searched, opened and created, what the user starts on,
  and what the status bar shows. An add-on can also keep the editor from
  opening, with a message saying why. Deployment-specific features (such as
  COMBINE's per-course branch access) live in add-ons shipped next to the
  editor. See "Add-ons" in the README; the demo page shows one with
  `?only_branches=main,feature`.
- **The GitLab backend knows who is signed in** (`getCurrentUser()`), including
  their role in the project, for add-ons to use.
- **For add-ons and pages embedding the editor:** `git.addStatusItem(item)`,
  `git.notify(text)` and `git.openBranchPicker()` on the editor's `git` API.

### Changed

- **The merge request dialog always offers the default branch as a target**,
  even when an add-on has narrowed the branch list.

## [1.7.2] - 2026-10-20

### Changed

- **Dependencies updated**, among them mermaid 10 → 12 and KaTeX 0.18 → 0.19.
  Diagrams and maths render as before: KaTeX 0.19 produces the same MathML,
  and an invalid diagram still shows its source instead of mermaid's error
  graphic. Mermaid 12 is larger: `MystEditor.js` grows from 10.9 to 13.5 MB
  (2.5 to 3.0 MB compressed), loaded with the editor whether or not a page has
  a diagram.

### Security

- **`overrides` clear the three high-severity advisories** in the dependency
  tree: `katex` (also used by mermaid and myst-transforms) to 0.19, `uuid`
  (used by mermaid) to 11.1.1, and `linkify-it` (used by markdown-it, under
  myst-parser) to 5.0.2. markdown-it 13 asks for linkify-it 4, but the editor
  never turns linkify on, so the newer version is only loaded, not used.

## [1.7.1] - 2026-10-20

### Changed

- **Vite+ as the toolchain.** Building, the dev server, formatting (Oxfmt),
  linting (Oxlint) and unit tests (Vitest) run through Vite+ (`vp`), configured
  in one place, `vite.config.js`; `vitest.config.js` and `.oxlintrc.json` are
  gone. The npm scripts keep their names. Vite+ needs Node `^22.18.0`,
  `^24.11.0` or `>=26.0.0`, now declared in `package.json`.
- **CI runs the unit tests** alongside the format and lint check; before, only
  the end-to-end tests ran. CI jobs are interruptible, so a newer push cancels
  the older pipeline, except for the release jobs.

## [1.7.0] - 2026-10-15

### Added

- **Merge requests from the editor.** The status bar has a merge request item
  next to the branch. It opens a dialog that prepares the merge request (source
  branch, target branch, defaulting to the project's default branch) and opens
  GitLab's "new merge request" page with both filled in. If the branch already
  has an open merge request, the item shows its number and the dialog links to
  it. The source is always a branch, since GitLab cannot open a merge request
  from a commit. Without the status bar the dialog is reached from the branch
  name under the title. The controls only appear when the backend names the
  book's GitLab project.

- **Create a branch from the branch picker.** The branch picker now offers to
  create a branch, from the current one or any branch or commit, and replaces
  the separate toolbar button. Enter opens the matching branch; it only offers
  to create one when nothing matches.

### Changed

- **The status bar reads commit, branch, merge request.**
- **Dependencies updated** to their latest minor versions, including
  `myst-parser` 1.7.

## [1.6.0] - 2026-10-13

### Added

- **Upload images from the figure dialog.** In the git editor a figure can be
  an image from the computer, not only a URL. It is saved under `images/` next
  to the page (editable) and goes into GitLab in the same commit as the page
  that shows it, so a page never lands without its image. Until then it is held
  in the open tab: the preview shows it immediately, the status bar counts it,
  and leaving the tab or switching branch warns first. The commit dialog lists
  the images and ticks the ones a changed page uses; one no page uses any more
  is offered unticked. Large photos are offered a smaller copy (at most 2000 px
  wide), the limit is 10 MB per image, and a name already taken in the
  repository is refused with a free one suggested.

- **Paste or drop an image into the source.** It opens the figure dialog with
  the image filled in. A pasted screenshot gets a dated name instead of
  "image.png".

### Fixed

- **Images on pages in sub-folders now show in the preview.** References were
  fetched from the root of the repository as written, so `{figure} fig.png` on
  `chapter1/page.md` was looked for at `fig.png` and never found. They are now
  resolved against the page, and `/…` against the project root, as MyST does.

- **Images are no longer fetched again on every edit.** Each re-render of a
  paragraph with an image asked GitLab for it again. Images are now cached per
  commit, and an image the repository does not have is shown as a marked gap
  rather than as nothing at all.

- **A dialog that reopens straight away is no longer cancelled.** The close
  event of the dialog just dismissed could arrive after the next one opened and
  close it.

## [1.5.1] - 2026-10-13

### Changed

- **Oxlint replaces ESLint.** ESLint had not actually run since the move to
  ESLint 9. Oxlint now runs in CI next to the format check, and the imports
  and variables it found unused are gone. The check for undefined names is on,
  so a removed import that was still needed fails the lint instead of the
  page.

### Fixed

- **Commit no longer disappears when a changed page cannot be loaded.** If
  fetching one of the other changed pages failed while preparing a commit, the
  Commit button vanished until a reload and the connections already opened for
  the other pages stayed open. It now says what went wrong, closes them and
  brings the button back.
- **Comment editors pick up the author's settings from the start.** A new
  comment's editor relied on a re-render to apply settings such as Vim mode.
  They are now applied when it is created.

## [1.5.0] - 2026-10-12

### Added

- **COMBINE's identity in the git editor.** The COMBINE wordmark heads the page
  index, where a Jupyter Book shows the book's own logo, and the TU Delft logo
  sits small in the index's bottom-left corner. While the index is collapsed
  the COMBINE mark stands in beside the title. The loading screen after the
  GitLab sign-in carries both logos. TU Delft's logo is their own vector export,
  clear space included, and the COMBINE images are four times their displayed
  size, so both stay sharp on high-density screens and when zoomed. A
  deployment can replace the branding or turn it off with the new `branding`
  option.

- **A status bar.** Branch and commit move from under the title to a bar along
  the bottom, where they still open the pickers. It also counts the pages with
  uncommitted changes and shows the cursor position and word count. Turn it off
  with `statusBar: false`.

- **A page index that works like navigation.** Pages are listed by their title
  (from the table of contents, the page's frontmatter or its first heading) with
  the file name underneath, nested as the table of contents nests them. The open
  page is marked by a bar and a tint as well as by colour, its sections sit
  directly beneath it, and an orange dot marks uncommitted changes. A filter
  field narrows long books. The collapse control is now on the panel it
  collapses.

### Changed

- **A calmer toolbar.** The formatting buttons are grouped by job (text, maths,
  links and callouts, lists, media) and lose their individual boxes. Commit is
  the one labelled, coloured button. The view modes are labelled (Source,
  Split, Preview, Inline, More) and fall back to icons when the bar is narrow.

### Fixed

- **Accessibility, against WCAG 2.2 AA.** The editor chrome now passes an
  axe-core scan in light and dark mode, which is part of the test suite:
  - The page index can be used from the keyboard, and the open page is
    announced as the current one.
  - Keyboard focus is visible: the focus outline was switched off everywhere
    and nothing replaced it.
  - Link blue, the dark-mode version stamp and the muted grey used for hints
    and captions now meet the 4.5:1 contrast text needs; they measured 3.7,
    2.6 and 3.8.
  - Every toolbar button has a name, not just a hover tooltip. The formatting
    row is announced as a toolbar, and toggles say whether they are on.
  - The "More" views and the settings menu open from the keyboard; both only
    opened on mouse hover. The selected view mode is no longer shown by colour
    alone.
  - The source pane has an accessible name, and the layout has landmarks.
  - In the preview, the coloured admonition headers were white text on colours
    as light as 1.7:1; the header bars are now a shade deeper and every one
    passes.

## [1.3.0] - 2026-09-15

### Added

- **A code-cell button.** Inserts a Jupyter Book `{code-cell}` directive from a
  dialog that asks what the cell is _for_ - a figure, code and output, a setup
  cell, an example that never runs - and writes the tags that intent implies,
  rather than asking the author to hold Jupyter Book's tag table in their head.
  The rest of the vocabulary is offered alongside it as plain descriptions
  ("Hide warnings (stderr)"), with a label, caption and line numbers.

  It also offers to add the page's `kernelspec` when there is none, ticked by
  default. That is the trap it exists to close: a markdown page without one
  cannot run its cells, and says so nowhere - the build stays green and every
  figure on the page comes out blank. The cell and the frontmatter go in as one
  transaction, so a single undo takes back both. A page whose frontmatter does
  not parse is left alone rather than guessed at.

  The button is in `defaultButtons`, since this fork is aimed at Jupyter Book 2.
  Pass an `includeButtons` list without `predefinedButtons.codeCell` to drop it.

- **A long wait says whose wait it is.** Both spinners now name GitLab once the
  wait has gone past what the editor could plausibly be responsible for - after
  3 seconds the in-editor popup adds "Waiting for GitLab" under its label, and
  after 4 the boot screen explains that GitLab is slow to answer and the editor
  is waiting on it, not stuck. Held back rather than shown up front, so a normal
  load never mentions it. `MystEditorGit` takes `serverName` if a consumer is
  behind something other than GitLab.
- **The panes flash the line they synced to.** Clicking the preview moves the
  editor instantly, which is what it should do - but instant movement leaves
  nothing to follow, so finding the line that was meant meant reading for the
  text you had just clicked. It is marked for a moment instead, in a colour the
  active-line highlight does not use, and dropped as soon as the document
  changes under it. Fragment links - footnote references, cross-references,
  heading anchors - mark their destination the same way.
- `FormDialog` gains `checkbox` and `multiselect` fields, and option lists now
  take `{ value, label }` as well as plain strings - so a dialog can show "Hide
  warnings (stderr)" for a tag called `remove-stderr`.

### Fixed

- **The preview answers clicks again in a real deployment.** Syncing the two
  panes hangs off the `syncScroll` option, which was off by default - and both
  demo pages switched it on by hand, so every test saw it on while a real
  deployment got neither the cursor-to-preview sync nor click-to-jump, and a
  click in the preview did nothing at all. Neither demo page sets it now, so
  they exercise the same path a deployment does.
- **The editor page takes the book's favicon.** Served from `<book>/editor/`, it
  carried no icon of its own, so the browser fell back to whatever sits at the
  web server's root - not the book's. It now points at the icon the book theme
  publishes, whichever image the book configured.
- **The page-index toggle is recognisable.** It was a panel glyph - a rectangle
  with one edge filled - which is what an IDE uses, but on a bar that already
  carries the Dual Pane button a second rectangle-with-a-divider reads as another
  view mode. It is a double chevron now: `<<` closes the index, `>>` brings it
  back. The button itself has been there since 1.2.0.
- **`eqnarray`, `multline` and `flalign` render.** KaTeX implements a large part
  of amsmath but not those three, and a block using one came out as its own
  LaTeX source in red - with the equation number beside it, since myst had
  parsed and numbered the block quite happily before KaTeX refused the maths.
  They are rewritten to the nearest environment KaTeX does implement (`align*`,
  `gather*`, `align*`) on the way in.

### Changed

- **`syncScroll` now defaults to on.** Two panes that move together is what a
  dual-pane editor is for; off by default only ever served an embedder who
  wanted a preview and nothing else, and it cost every deployment its pane sync.
  Pass `syncScroll: false` for the old behaviour.

## [1.2.0] - 2026-09-14

### Fixed

- The editor fills its container again: the wrapper's height was hard-coded to
  `calc(100% - 60px)` against a wrapping row layout, which only matched when the
  topbar happened to be exactly 60px tall. It is a column that flexes instead.
- The browser tab is named after the editor's `title` option rather than
  whatever the host page set, with any markdown link syntax stripped.

### Added

- Added `changelog-check` to the CI policy stage to enforce that `CHANGELOG.md` is updated for new releases and contains an entry for the version in `package.json`.
- **The page index can be collapsed.** A button in the toolbar hides the sidebar
  and gives its 300px to the editor, which matters on a laptop screen once the
  source and preview are side by side. The state is remembered per editor, so an
  index closed stays closed across reloads, and the icon shows which state you
  are in rather than only what clicking will do.
- **`showVersion`**, which prints the editor's own version as a small superscript
  beside the topbar title. `mountGitEditor` turns it on for a real git backend:
  once a repository is behind the editor, a report from a book author is hard to
  place without knowing which build produced it. Off by default, since a page
  embedding the editor has its own idea of what belongs in its header, and the
  version is still exported as `version` for anyone who would rather place it
  themselves. The two demo pages now use it instead of writing the version into
  the title themselves, so the browser tab no longer carries a version number.

- **A spinner while the editor boots.** Coming back from the GitLab redirect
  meant a blank white page for a few seconds - the token exchange, then the
  backend's prefetch of project metadata and branches - which after a login round
  trip reads as a failure rather than as progress. The wait is now a centred
  spinner, and so is the moment on the way out to GitLab.

### Changed

- **Signing in no longer needs a second click.** Opening the editor with no
  session showed a "Log in with GitLab" button, which asked nothing the user had
  not already answered by clicking through to the editor in the first place. The
  browser now goes straight to GitLab. Pass `autoLogin: false` to `mountGitEditor`
  for the old behaviour; `onLoginRequired` still replaces the whole step.

  The button remains the fallback, and is what appears if an automatic attempt
  comes back moments later still logged out - a denied consent, a misconfigured
  redirect URI - so a failing login cannot turn into a redirect loop. It also
  appears when session storage is unavailable, since the loop cannot be detected
  without it. Denied consent and a failed token exchange keep going to the
  existing error screen with its "Restart login" button.

## [1.1.5] - 2026-09-14

### Changed

- Updated version check in CI to also check `package-lock.json`.
- Trigger keywords give cleaner output.

## [1.1.4] - 2026-09-14

### Changed

- Updated pipeline trigger with assets token.

## [1.1.3] - 2026-09-14

### Fixed

- **A `myst.yml` that keeps its table of contents in a separate file is followed.**
  mystmd lets a config delegate with `extends:`, and a book whose toc lives in its
  own `toc.yml` does exactly that - `myst.yml` carries the project metadata and
  `extends: toc.yml`. The editor read only the file it was pointed at, found no
  `project.toc` in it, and concluded the project had no index: an empty sidebar,
  and the first document falling back to `README.md`. `extends` is now followed
  (local files only - a shared template served over https carries styling, not a
  toc), up to three levels, and a config that turns out to hold no toc no longer
  stops the search.
- The demo repository now mirrors that layout, so the case is covered end to end
  rather than only in the parser's unit tests.

## [1.1.2] - 2026-09-14

### Changed

- Release to test auto release of assets plugin.

## [1.1.1] - 2026-09-14

### Added

- Auto release of editor plugin in assets.

## [1.1.0] - 2026-09-13

Numbering note: from here on, `Y` is bumped for features and `Z` for fixes. This
release only fixes something, which would normally be a `Z` bump; it takes the `Y`
instead because 1.0.1 shipped two features - the table-of-contents page index and
the slow-fetch popup - under the old numbering, before the scheme was agreed.
Realigning here keeps the minor version meaning "the feature line this builds on".
Fixes from now on will be 1.1.1, 1.1.2, and so on.

### Fixed

- **Clicking the preview moves the cursor on the first click.** It used to set
  the cursor only after a smooth scroll had finished, and for a line outside
  CodeMirror's rendered viewport it waited for a _chain_ of them: each pass could
  only work from estimated line heights, so it scrolled, waited for `scrollend`,
  measured, and went again. Measured on the demo document, a click took 0.75s
  near the top and 1.8s near the bottom to do anything visible - long enough to
  read as a dead click, so people clicked a second time and assumed the feature
  needed a double click. The cursor now moves on the click itself (under 50ms at
  any distance), and the editor is aligned instantly over a frame or two instead.
  Where the source ends up is unchanged; only the waiting is gone.

  This was not new in 1.0.0 - the repeated-smooth-scroll loop dates back to
  v0.0.9 - but the preview click path had no test, so nothing caught it.

## [1.0.1] - 2026-09-13

### Added

- **The page index is read from a Jupyter Book table of contents.** When the
  consumer does not set `index`, the editor now looks for `myst.yml` (Jupyter
  Book v2), then `_toc.yml` (v1), then `toc.yml`, under `docsRoot` and then the
  repository root, and uses the first one it finds. Nesting is understood in both
  dialects (`children`, `parts`, `chapters`, `sections`), an entry without an
  extension gets `.md`, and an entry's own `title` is what the sidebar shows.
  Setting `index` explicitly still pins one file, so existing consumers are
  unaffected.
- **The table of contents decides which document opens.** The editor opened
  `README.md`, then `index.md`, then whatever the backend listed first - the
  `index` option had no say in it at all. It now opens the first page the table
  of contents lists, falling back to the old order only when there is no table of
  contents.
- **A slow git fetch says so.** Loading a file, branch or commit that takes
  longer than 400ms shows a status popup naming what is being fetched, so a slow
  repository no longer looks like a frozen editor. Faster than that and nothing
  appears, because a spinner that flashes on every click is worse than none. The
  popup does not block editing: the current document stays readable while the
  next one loads.
- `latency` on the stub git backend (also `?latency=` on the demo page), which
  delays every read. The in-memory stub answers instantly, so without it the
  slow-fetch indicator cannot be seen or tested.

### Fixed

- A `{toctree}` entry that already carried an extension became `file.md.md` and
  so matched nothing. Both index formats now leave an explicit extension alone.
- The table of contents is parsed as YAML rather than scraped with a regex for
  `- file:`, which previously also matched that key anywhere else in the
  document, including outside the table of contents.

### Dependencies

- Added `js-yaml` (4.3.1) as a direct dependency. It was already in the bundle
  via `myst-parser`; declaring it lets the table of contents be parsed properly.

## [1.0.0] - 2026-09-12

Replaces the markdown-it rendering pipeline with **mystmd** (`myst-parser` →
`myst-to-html`), the same engine Jupyter Book v2 uses.

### Breaking

- **`userSettings[].markdown` is removed.** It took a markdown-it instance, so it
  cannot survive the parser change. It was never documented in the README, so the
  blast radius should be small. The bundled setting that used it, "Open links in
  new tabs", still works.
- **Preview DOM and class names changed.** Any consumer CSS targeting the preview
  needs updating:
  | before                                 | now                                     |
  | -------------------------------------- | --------------------------------------- |
  | `.myst-card`, `.myst-card-title`       | `.card`, `.card-title`                  |
  | `.myst-dropdown`                       | `details.dropdown`                      |
  | `.myst-directive-placeholder`          | (directives are handled, not placeheld) |
  | `<p class="admonition-title">`         | `<header class="admonition-title">`     |
  | one `<html-chunk>` per heading section | a single `<html-chunk>`                 |
- **`backslashLineBreak` now does something.** It was documented but inert: the
  markdown-it rule it relied on never matched. With the default (`true`), a
  trailing `\` at the end of a block now renders as a line break rather than a
  literal backslash. Set it to `false` for the old output.
- **The chunk cache is gone.** Rendering is whole-document, because
  cross-references, numbering and footnotes need full-document context. Preview
  updates are debounced while typing instead.

### Added

- Jupyter Book v2 directives: `{tab-set}`, `{card}`, `{grid}`, `{exercise}`,
  `{prf:*}`, via the upstream `myst-ext-*` packages. Tabs are interactive with no
  JavaScript in the preview.
- Working `{iframe}` directive, including YouTube/Vimeo share-URL rewriting (share
  URLs refuse to be framed, so they are rewritten to their embed form).
- Figure captions and caption numbering ("Figure 1", "Table 2"), by running the
  transform stage Jupyter Book runs and `myst-to-html` does not.
- Debounced preview rendering while typing.
- Toolbar buttons: italic, equation, symbol, figure, table, numbered and bulleted
  list, link, blockquote, admonition, YouTube embed.

### Security

- Every `<iframe>` in the preview is now sandboxed, so embedded content cannot
  navigate the top-level page. A document cannot opt out by supplying a more
  permissive `sandbox` of its own. Scripts, popups, forms, presentation and
  downloads remain permitted, which is what video and notebook embeds need.

### Fixed

- Fragment links (footnote references and their backrefs, cross-references,
  heading anchors) now scroll the preview. They never could: the editor renders in
  a shadow root, and the HTML scroll-to-fragment algorithm only resolves ids in the
  document tree. Both panes now jump to the destination together.
- Multi-line CriticMarkup deletions render correctly; previously they emitted
  mangled text with the marker still visible and characters dropped.
- Mermaid diagrams no longer re-render on every keystroke.
- YAML frontmatter is hidden from the preview again; it was rendering as a visible
  code block.
- Copied HTML no longer carries the renderer's internal `div.block` wrapper.

### Changed

- `mapUrl`, the `[label]((url))` link guard, and the new-tab setting are now a
  single pass over the output tree rather than three separate plugins.
- Collaboration-only UI is now hidden when `collaboration.enabled` is false: the
  suggest-mode toggle, the "Resolved" tab, and the comments gutter. Previously
  the suggest-mode button was always shown, and the "Resolved" tab and comments
  keyed off `resolvingCommentsEnabled`/`commentsEnabled` alone, so a consumer
  could get controls backed by no collaboration server.
- Suggestions are collaboration-only in full: with collaboration disabled,
  CriticMarkup (`{++ ++}`, `{-- --}`, `{~~ ~> ~~}`) renders as literal text in
  both the editor and the preview, and no accept/reject widgets appear. This
  matches Jupyter Book, which has no CriticMarkup; the Diff view covers
  reviewing your own changes. Only affects consumers running with
  `collaboration.enabled: false`.

### UI

- **Printing is now mode-independent.** The PDF is always the full rendered
  document at full width, whatever the editor is showing. Previously it printed
  the preview pane as laid out on screen, so "Both" produced a half-width
  column, the source-only modes produced nothing, and the output was clipped to
  wherever the preview happened to be scrolled. Print styling also keeps
  headings with their text and avoids splitting figures, tables, admonitions and
  code blocks across pages; link URLs are no longer appended in parentheses,
  matching Jupyter Book's PDF output.
- **The fullscreen button is removed.** It only ever did anything when the
  editor was embedded in a container smaller than the window; in a full-page
  embedding it was a no-op. Use the browser's own fullscreen. `predefinedButtons.fullscreen`
  no longer exists.
- The topbar title in the bundled demo pages now points at the COMBINE GitLab
  and shows the package version. `version` is exported for consumers that want
  to do the same.

### UI (continued)

- **Toolbar dialogs are in-theme modals.** The figure, link, admonition and
  video buttons showed a chain of native `window.prompt()` boxes (five in a row
  for a figure); each is now a single centred form with labelled fields, a
  cancel button and Escape support. Discarding unsaved changes in the git editor
  uses the same modal instead of `window.confirm()`.
- The modal is now centred on the viewport rather than pinned near the top.
- **All ten MyST admonition kinds are styled.** Only `note`, `warning` and
  `hint` had colours before, so `important`, `tip`, `caution`, `attention`,
  `danger`, `error` and `seealso` fell back to a generic green frame with no
  icon. They are now grouped by severity, matching Jupyter Book.
- **Admonitions print correctly.** Browsers drop background colours when
  printing unless told otherwise, so the coloured header bar and its icon
  vanished, leaving a bare outline. Fixed with `print-color-adjust`.
- **Removed:** the Templates button and the `templatelist` option (the bundled
  list was antmicro demo data that fetched Vue/React/Svelte READMEs from a CDN),
  and the "Automatically number ordered lists" setting.
- Removed ~50 lines of dead CSS for `.myst-card`, `.myst-dropdown` and
  `.myst-directive-placeholder`, which nothing has emitted since the parser swap.

### Jupyter Book styling

- The preview now uses Jupyter Book's reading typography: a system sans stack at
  16px/1.7, a constrained reading column (72ch) rather than full pane width, a
  larger heading scale bound tightly to the text below it, links underlined only
  on hover, and tables reduced to horizontal rules instead of a boxed grid with
  a dark header bar. The editor pane shares the same monospace stack.
- Tokens for this live in `MystStyles.js` (`--font-body`, `--font-mono`,
  `--font-size-body`, `--line-height-body`, `--measure`) and the rules are one
  block at the end of `jupyterBook.js`, so the pass can be tuned or reverted
  without unpicking `MdStyles`.

### Testing

- The demo document is now `src/fixtures/jb2-showcase.md`, which exercises every
  Jupyter Book construct the editor claims to support - all ten admonition kinds,
  cards, grids, tabs, exercises, proofs, glossary, footnotes, mermaid, embeds,
  math including frontmatter macros - plus a "known gaps" section for the ones
  that do not work yet, so regressions and improvements are both visible.
- `tools/render-jb2-reference.sh` renders that same document with the real
  `mystmd` CLI and writes `tests/fixtures/jb2-showcase.reference.html`, giving a
  side-by-side reference for what Jupyter Book itself produces.
- Console errors from third-party embeds (the demo's video player, avatars) no
  longer fail whichever end-to-end test happens to be running.

### Jupyter Book pipeline (phase 2)

- **Frontmatter is configuration again, not just something to hide.** It is now
  parsed with `getFrontmatter` - the helper myst-cli uses - instead of being
  dropped, so `math:` macro definitions reach KaTeX (a document defining `\RR`
  no longer renders an undefined-control-sequence error), and `abbreviations:`
  produce tooltips throughout the document. Invalid YAML leaves the preview
  rendering rather than erroring. Unlike `myst build`, a heading that repeats the
  frontmatter title is kept, because the editor has no title block to move it to.
- **Glossary terms carry an id**, so `{term}` links reach their definition
  instead of pointing at nothing.
- Runs the rest of myst-cli's per-file transforms in its order: glossary,
  abbreviations, index identifiers, inline-math simplification and footnotes.
  Costs roughly 10% render time on a large document (35 to 40 ms on the 1.2k-line
  corpus), for the fidelity gained.

### Fixed (inline rendering)

- **Unhandled MyST nodes no longer break paragraphs.** mdast-util-to-hast renders
  an unknown node type as a `<div>`, so every inline role without a handler put a
  block element mid-sentence and the browser closed the paragraph around it -
  which is why small caps, underline and similar appeared on their own line. The
  fallback is now a `<span>` unless the node really holds block content, and it
  carries a `myst-<type>` class so the responsible node is visible in the DOM.
- Added handlers for `{smallcaps}`, `{u}`, `{span}`, `{chem}` (now
  `H<sub>2</sub>O`, as Jupyter Book renders it), `{si}` and `{eval}`.
- **Display equations are numbered.** The enumerator was computed but never
  rendered; equations now carry a linked `(1)` to the right, as Jupyter Book does.
- **`display: flex` removed from admonition headers.** A flex container makes each
  child its own item and trims the whitespace between them, so a title like
  "Solution to {ref}`ex`" rendered as "Solution toExercise 1".

### Jupyter Book pipeline

- **Cross-references and numbering now use the same myst-transforms code
  `myst build` runs**, instead of myst-to-html's own older copy. That copy
  enumerated only `container`, `math` and `heading` nodes, so a reference to an
  `{exercise}`, `{solution}` or `{prf:*}` could never resolve no matter how it
  was written. References now render as Jupyter Book does - `{ref}` to an
  exercise reads "Exercise 1", not the raw label - and figure captions use
  Jupyter Book's "Figure 1:" format. No measurable render cost.

### Fixed (rendering)

- **`:class: dropdown` now collapses an admonition.** myst-to-html copied the
  class onto the element but always emitted `<aside>`, so nothing was
  collapsible. Admonitions, exercises, solutions and proofs carrying it render
  as `<details>`/`<summary>` (no JavaScript), keeping their colours and icons.
- **Cross-references render as links.** `{solution} ex_fourier` produced
  myst-to-html's "unhandled role" markup, which on a coloured admonition header
  was white-on-white and unreadable. It is now an anchor to the target, labelled
  with the target's own title where the document defines one.
- **Multi-line math is no longer wrapped in `<pre>`.** Upstream wraps any math
  containing a newline, which is every `\begin{array}` / `\begin{aligned}`
  block; since we render to MathML that produced a `<div>` inside a `<pre>` and
  forced monospace onto the equation. Labelled equations keep their id.

### Fixed (UI)

- **An embed with a relative or empty `src` no longer loads the editor inside
  itself.** `:::{iframe} myvideo` resolved against the current page, so the
  preview appeared to recurse. Only absolute http(s) URLs are embedded; anything
  else reports why.
- The "Autocomplete Markdown" setting is now called "Continue lists and quotes",
  which is what it does (its stored id is unchanged).

### Known limitations

- A CriticMarkup suggestion that spans a **block boundary** is not merged back
  into the original block. `# Heading {++\n  text++}` renders as a heading
  followed by a separate block rather than one heading. Suggestions inside a
  single block are unaffected. The markdown-it path handled this with a
  `critic-block` core rule operating on the raw token stream; the mdast
  equivalent is deferred.

## [0.1.0] - 2026-06-04

### Added

- Implemented a `.gitlab-ci.yml` configuration pipeline to automate the release of build files.

### Changed

- Updated project dependencies to ensure compatibility with the latest versions of underlying libraries and frameworks.
